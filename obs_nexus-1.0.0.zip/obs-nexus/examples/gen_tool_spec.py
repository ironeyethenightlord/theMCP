#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从运行中的 OBS Nexus 拉取 conn.capabilities，生成大模型工具（function calling）定义。

不手写 schema —— 服务端是唯一事实来源，OBS 升级/加了新 op 之后重跑一次就行。

    python3 examples/gen_tool_spec.py --out examples/llm_tool_spec.json
    python3 examples/gen_tool_spec.py --style anthropic
    python3 examples/gen_tool_spec.py --only text.set,source.visibility,stream.control

输出（--style both，默认）:
    {
      "openai":    [{"type":"function","function":{...}}],
      "anthropic": [{"name":..., "input_schema":{...}}],
      "ops":       {...原样 capabilities...}
    }
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import agent_client as ac  # noqa: E402

TYPE_MAP = {
    "str": {"type": "string"},
    "int": {"type": "integer"},
    "float": {"type": "number"},
    "num": {"type": "number"},
    "bool": {"type": "boolean"},
    "obj": {"type": "object"},
    "[str]": {"type": "array", "items": {"type": "string"}},
    "[obj]": {"type": "array", "items": {"type": "object"}},
    "any": {},
}

OP_ENUM_DOC = (
    "OBS 控制指令名。完整清单与每个 op 的参数由 OBS 实时提供：先用 op=conn.capabilities 查。"
    "常用：system.overview（先看清现场）、scene.list/scene.switch（切场景）、"
    "source.list/source.visibility（显隐贴片）、text.set（写字幕）、audio.mute/audio.volume（音频）、"
    "stream.control（推流/录制）、canvas.snapshot（看画面）、source.move/source.lock/source.transform。"
)


def json_type(spec):
    """args 里的 {"type":..} 元组 → JSON Schema 片段。"""
    kind = (spec or ["any"])[0]
    out = dict(TYPE_MAP.get(str(kind), {})) or {"type": ["string", "number", "boolean", "object", "array"]}
    desc = (spec or [None, None, ""])[2] if len(spec) > 2 else ""
    if desc:
        out["description"] = str(desc)
    return out


def build(cap, style, only=None, with_op_enum=True):
    ops = cap.get("ops") or []
    if only:
        keep = {x.strip() for x in only.split(",") if x.strip()}
        ops = [o for o in ops if o.get("op") in keep]
    names = [o.get("op") for o in ops if o.get("op")]

    def schema_one(op):
        props = {}
        required = []
        for k, v in (op.get("args") or {}).items():
            props[k] = json_type(v)
            if isinstance(v, (list, tuple)) and len(v) > 1 and v[1]:
                required.append(k)
        props["op"] = {"type": "string", "description": "要执行的 op 名"}
        required.append("op")
        if props:
            props["__note"] = {  # 占位说明：让模型知道可以不带其它参数
                "type": "string",
                "description": "（可省略）额外参数放这里；不确定就先调 conn.capabilities。",
            }
        return {
            "type": "object",
            "properties": props,
            "required": required,
            "additionalProperties": True,
        }

    if style == "anthropic":
        tools = []
        for op in ops:
            tools.append(
                {
                    "name": "obs_nexus_" + op["op"].replace(".", "_"),
                    "description": (op.get("summary") or "") + (" ⚠️需要 OBS 脚本开启 advanced" if op.get("requires_advanced") else ""),
                    "input_schema": schema_one(op),
                }
            )
        if not tools:  # 一个都没匹配上时给个兜底
            tools = [
                {
                    "name": "obs_nexus",
                    "description": "控制 OBS Studio（经本地 OBS Nexus 桥）。",
                    "input_schema": {
                        "type": "object",
                        "properties": {"op": {"type": "string", "description": OP_ENUM_DOC}, "args": {"type": "object", "description": "该 op 的参数"}},
                        "required": ["op"],
                    },
                }
            ]
        return tools

    # openai：一个工具 + op 枚举（比 40 个工具省得多，模型也更好选）
    fn = {
        "name": "obs_nexus",
        "description": (
            "控制本机 OBS Studio（通过本地 TCP 桥 OBS Nexus）。一次请求可做多个动作：把 op 填成要执行的指令，"
            "其余键作为该指令的参数。写操作前先 system.overview 看清现场；不确定参数就先用 op=conn.capabilities。"
            "注意：stream.control 的 stop_stream 需要 confirm:true；source.settings_merge / scene.create / scene.remove "
            "需要 OBS 端开启 advanced。"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "op": ({"type": "string", "enum": names, "description": OP_ENUM_DOC} if (with_op_enum and names) else {"type": "string", "description": OP_ENUM_DOC}),
                "ops": {
                    "type": "array",
                    "items": {"type": "object", "properties": {"op": {"type": "string"}, "args": {"type": "object"}}},
                    "description": "批量模式：按顺序执行多个 op（一次往返完成一组动作）。与 op 二选一。",
                },
                "continue_on_error": {"type": "boolean", "description": "批量里某步失败是否继续（默认 false，遇错即停）"},
            },
            "required": [],
        },
    }
    # 把每个 op 的参数说明塞进 description，避免模型瞎猜
    lines = []
    for op in ops:
        args = op.get("args") or {}
        astr = ", ".join("%s%s" % (k, "（必填）" if isinstance(v, (list, tuple)) and len(v) > 1 and v[1] else "") for k, v in args.items())
        lines.append("- %s: %s%s%s" % (op["op"], op.get("summary") or "", "；参数: " if astr else "", astr))
    fn["description"] += "\n\n可用 op:\n" + "\n".join(lines)
    return [{"type": "function", "function": fn}]


def main(argv=None):
    p = argparse.ArgumentParser(description="从运行中的 OBS Nexus 生成 LLM 工具定义")
    p.add_argument("--conn-file", help="connection.json 路径")
    p.add_argument("--style", choices=("openai", "anthropic", "both"), default="both")
    p.add_argument("--only", help="只包含这些 op（逗号分隔）")
    p.add_argument("--out", help="写到文件（默认打 stdout）")
    p.add_argument("--indent", type=int, default=2)
    cli = p.parse_args(argv)

    info, err = ac.ConnInfo.load(cli.conn_file)
    if err:
        sys.stderr.write("[配置] %s\n" % err)
        return 3
    try:
        with ac.Client(info.host, info.port, token=info.token, timeout=10) as c:
            c.hello()
            if info.token:
                c.auth()
            cap = c.request({"op": "conn.capabilities"})
    except ac.NexusError as exc:
        sys.stderr.write("[%s] %s\n" % (exc.code, exc))
        return exc.exit_code
    if not cap.get("ok"):
        sys.stderr.write("conn.capabilities 失败: %s\n" % json.dumps(cap.get("error"), ensure_ascii=False))
        return 1
    data = cap["result"]["data"]
    out = {"generated_from": {"nexus_version": data.get("nexus_version"), "proto": data.get("proto"), "limits": data.get("limits")}}
    styles = ("openai", "anthropic") if cli.style == "both" else (cli.style,)
    for st in styles:
        out[st] = build(data, st, cli.only)
    out["usage_notes"] = [
        "每个 op 的参数说明来自 OBS 实例本身；OBS 版本或设置变了请重跑 gen_tool_spec.py。",
        "canvas.snapshot 必须是批量里的最后一个 op（截图是异步收尾）。",
        "单次响应默认截断（limit/max_list_items）；要更多就用 offset 翻页或 fields 裁字段。",
    ]
    text = json.dumps(out, ensure_ascii=False, indent=cli.indent)
    if cli.out:
        with open(os.path.expanduser(cli.out), "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
        sys.stderr.write("已写入 %s\n" % cli.out)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
