#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ai_overlay_agent.py —— 「大模型当导播」的最小可用参考实现。

它做三件事：
  1. 把解说文本写进字幕源（text.set），带节流，避免每秒刷 OBS；
  2. 按关键词弹出/收起 AI 贴片（source.visibility + 可选 scene.switch）；
  3. 需要时控制录制（stream.control），并且退出前把界面恢复干净。

它不依赖任何第三方库；调 LLM 的部分留了一个 `--llm-cmd` 钩子（任何「读 stdin 吐一行文本」
的脚本/CLI 都能接上），不配就用内置的关键词规则引擎，方便你先跑通 OBS 侧链路。

    # 直接喂文本（管道）
    echo -e "开场欢迎大家\n这局有点难\n感谢礼物" | python3 examples/ai_overlay_agent.py --demo-stdin

    # 外接一个 LLM CLI：每行输入 -> 调它 -> 得到解说词
    some_llm_cli --prompt-file prompts.txt | python3 examples/ai_overlay_agent.py --llm-cmd "myllm --tone 主播"

    # 只做字幕、不动贴片
    python3 examples/ai_overlay_agent.py --no-overlays

常用参数：
    --subtitle-source 字幕          text.set 的目标源名
    --overlay '关键词=源名[:场景]'  可重复；命中就把该源设为可见，离开场景时隐藏
    --hide-overlay 源名             可重复；命中 stop/结束 类关键词时隐藏
    --min-interval-ms 900           字幕最小写入间隔（节流，保护 OBS 主线程）
    --max-chars 42                  单行字幕最大字符数（超了自动折行/截断）
    --dry-run                       只打印将要发送的 op，不碰 OBS
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import subprocess
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import agent_client as ac  # noqa: E402

# 默认规则：命中就把对应贴片弹出来。用 --overlay 覆盖。
DEFAULT_OVERLAYS = [
    ("感谢|谢谢|礼物|打赏", "感谢贴片"),
    ("关注|订阅|点关注", "关注提示"),
    ("难|翻车|寄了|完蛋", "表情_苦笑"),
]
HIDE_WORDS = re.compile(r"(下播|结束|拜拜|再见|收工|stop)")
SUBTITLE_SUFFIX = "  "  # 换行时的小修饰，可按平台改


class DryRun(object):
    """--dry-run：把请求打印出来，方便先验证策略再接 OBS。"""

    def __init__(self):
        self.n = 0

    def request(self, obj, **kw):
        self.n += 1
        print("[dry-run] " + json.dumps(obj, ensure_ascii=False)[:400])
        return {"ok": True, "result": {"op": obj.get("op"), "data": {"dry_run": True}}, "request_id": obj.get("id")}

    def close(self):
        pass


class Agent(object):
    def __init__(self, client, cli):
        self.c = client
        self.cli = cli
        self.shown = set()
        self.last_text_at = 0.0
        self.last_text = None
        self.ops_sent = 0

    # ---------------- 底层：一次请求，失败只记日志不炸 ----------------
    def send(self, req):
        try:
            r = self.c.request(req, timeout=self.cli.timeout)
        except ac.NexusError as exc:
            sys.stderr.write("[warn] 发送失败: %s\n" % exc)
            return None
        self.ops_sent += 1
        if not r.get("ok"):
            sys.stderr.write("[obs] %s\n" % json.dumps(r.get("error"), ensure_ascii=False)[:300])
        return r

    def batch(self, ops, continue_on_error=True):
        if not ops:
            return None
        return self.send({"ops": ops, "continue_on_error": continue_on_error})

    # ---------------- 字幕 ----------------
    def subtitle(self, text):
        text = " ".join((text or "").split())
        if not text:
            return
        if self.cli.max_chars and len(text) > self.cli.max_chars:
            text = text[: max(0, self.cli.max_chars - 1)] + "…"
        now = time.time()
        wait_ms = self.cli.min_interval_ms / 1000.0
        if text != self.last_text and now - self.last_text_at < wait_ms:
            time.sleep(min(wait_ms - (now - self.last_text_at), 1.0))
        self.last_text_at = time.time()
        self.last_text = text
        ops = [{"op": "text.set", "source": self.cli.subtitle_source, "text": text}]
        if self.cli.subtitle_scene:
            ops[0]["scene"] = self.cli.subtitle_scene
        self.send({"op": "text.set", "source": self.cli.subtitle_source, "text": text} if not self.cli.subtitle_scene else {"ops": ops})

    # ---------------- 贴片 ----------------
    def apply_overlays(self, line):
        if self.cli.no_overlays:
            return
        rules = self.cli.parsed_overlays
        wanted = set()
        for pattern, source in rules:
            if re.search(pattern, line, re.IGNORECASE):
                wanted.add(source)
        if self.cli.auto_hide and HIDE_WORDS.search(line):
            wanted = set()
        to_show = wanted - self.shown
        to_hide = self.shown - wanted if self.cli.auto_hide else set()
        ops = []
        for name in sorted(to_show):
            ops.append({"op": "source.visibility", "source": name, "visible": True})
            self.shown.add(name)
        for name in sorted(to_hide):
            ops.append({"op": "source.visibility", "source": name, "visible": False})
            self.shown.discard(name)
        self.batch(ops)

    # ---------------- 录制 ----------------
    def record(self, action):
        r = self.send({"op": "stream.control", "action": action})
        return r

    def cleanup(self):
        if self.cli.hide_on_exit and self.shown and not self.cli.dry_run:
            self.batch([{"op": "source.visibility", "source": n, "visible": False} for n in sorted(self.shown)])
            self.shown.clear()


def llm_rewrite(llm_cmd, raw):
    """把观众弹幕/原始输入交给外部 LLM CLI，拿回「适合当字幕的解说词」。

    约定：stdin 收一行，stdout 吐一行；出错就原样返回（宁可丑，不可断）。
    """
    if not llm_cmd:
        return raw
    try:
        p = subprocess.run(shlex.split(llm_cmd), input=raw.encode("utf-8"), capture_output=True, timeout=20)
        out = (p.stdout or b"").decode("utf-8", "replace").strip()
        return out or raw
    except Exception as exc:
        sys.stderr.write("[llm] 调用失败，用原文: %r\n" % exc)
        return raw


def main(argv=None):
    p = argparse.ArgumentParser(description="LLM 驱动的 OBS 导播示例")
    p.add_argument("--conn-file")
    p.add_argument("--dry-run", action="store_true", help="只打印将发送的 op")
    p.add_argument("--llm-cmd", help="外部「一行进一行出」的 LLM 命令，用来把输入改写成解说词")
    p.add_argument("--subtitle-source", default="字幕")
    p.add_argument("--subtitle-scene", help="字幕源所在场景（默认当前场景）")
    p.add_argument("--overlay", action="append", default=[], metavar="正则=源名", help="命中正则就把源设为可见（可重复）")
    p.add_argument("--no-overlays", action="store_true")
    p.add_argument("--no-auto-hide", dest="auto_hide", action="store_false", default=True, help="不再自动收起贴片")
    p.add_argument("--hide-on-exit", action="store_true", default=True, help="退出前把弹出来的贴片收掉")
    p.add_argument("--no-hide-on-exit", dest="hide_on_exit", action="store_false")
    p.add_argument("--min-interval-ms", type=int, default=900)
    p.add_argument("--max-chars", type=int, default=42)
    p.add_argument("--timeout", type=float, default=6.0)
    p.add_argument("--start-record", action="store_true", help="开始时顺便开始录制")
    p.add_argument("--stop-record-on-exit", action="store_true", help="退出时停录制（危险，默认关）")
    p.add_argument("--demo-stdin", action="store_true", help="从 stdin 逐行读（默认行为，留着当显式开关）")
    cli = p.parse_args(argv)

    rules = []
    for raw in (cli.overlay or []):
        if "=" not in raw:
            sys.stderr.write("--overlay 需要 正则=源名 形式，忽略: %r\n" % raw)
            continue
        pat, name = raw.split("=", 1)
        rules.append((pat.strip(), name.strip()))
    if not cli.overlay:
        rules = list(DEFAULT_OVERLAYS)
    cli.parsed_overlays = rules

    client = None
    if cli.dry_run:
        client = DryRun()
    else:
        info, err = ac.ConnInfo.load(cli.conn_file)
        if err:
            sys.stderr.write("[配置] %s\n" % err)
            return 3
        try:
            client = ac.Client(info.host, info.port, token=info.token, timeout=cli.timeout)
            client.hello()
            if info.token:
                client.auth()
        except ac.NexusError as exc:
            sys.stderr.write("[连接] %s\n" % exc)
            return 2

    agent = Agent(client, cli)
    if cli.start_record:
        agent.record("start_record")
    # 开场先对一遍现场：源名不存在就直接说清楚，省得后面每行都报错刷屏
    if not cli.dry_run:
        listing = agent.send({"op": "source.list", "limit": 400, "fields": ["name", "type", "visible"]})
        have = set()
        if listing and listing.get("ok"):
            data = (listing.get("result") or {}).get("data") or {}

            def collect(rows):
                for row in rows or []:
                    if row.get("name"):
                        have.add(row["name"])
                    collect(row.get("children"))

            collect(data.get("sources"))
        need = [cli.subtitle_source] + ([] if cli.no_overlays else [name for _pat, name in cli.parsed_overlays])
        missing = sorted({n for n in need if n not in have}) if have else []
        if missing:
            sys.stderr.write(
                "[warn] 这些源在当前场景里找不到：%s\n"
                "       → 改名 / 把它们放进当前场景 / 用 --overlay 正则=真实源名 指定；找不到就跳过对应动作。\n"
                % ", ".join(missing)
            )
        if not have:
            sys.stderr.write("[warn] 读不到场景源列表（场景为空？），继续跑但可能全程报 SOURCE_NOT_FOUND\n")
    stopped = False
    try:
        for raw in sys.stdin:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            text = llm_rewrite(cli.llm_cmd, line)
            agent.subtitle(text)
            agent.apply_overlays(line)
            if HIDE_WORDS.search(line) and not cli.no_overlays:
                sys.stderr.write("[info] 收到结束词，已收起贴片%s\n" % ("（并停录制）" if cli.stop_record_on_exit else ""))
                if cli.stop_record_on_exit:
                    agent.record("stop_record")
                    stopped = True
    except KeyboardInterrupt:
        sys.stderr.write("[info] Ctrl-C，收尾\n")
    finally:
        agent.cleanup()
        if not cli.dry_run:
            try:
                client.close()
            except Exception:
                pass
    sys.stderr.write("[done] 发送了 %d 个请求\n" % agent.ops_sent)
    return 0


if __name__ == "__main__":
    sys.exit(main())
