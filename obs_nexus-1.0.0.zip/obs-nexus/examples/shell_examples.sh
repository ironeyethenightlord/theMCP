#!/usr/bin/env bash
# OBS Nexus 的 shell 侧用法速查（可直接抄进你的脚本）。
# 说明：这里既给 agent_client.py 的写法（推荐），也给一段纯 nc 的写法（应急排查用）。
set -uo pipefail
# 故意不加 -e：示例里某个 op 失败（比如你的工程没有「背景音乐」这个源）不该把整段演示打断。
# 想要「一错就停」就自己加一行 set -e。

CLI="python3 $(dirname "$0")/../src/agent_client.py"

echo "== 1. 现场快照（先看再说）"
$CLI --op system.overview --data-only --compact | head -c 600; echo

echo "== 2. 有哪些场景 / 场景里有什么源"
$CLI --op scene.list --data-only --compact
$CLI --op source.list --set limit=40 --data-only --compact | head -c 400; echo

echo "== 3. 写字幕（AI 解说最常见的一条）"
$CLI --op text.set --set source=字幕 --set text="这波打得漂亮" --data-only --compact

echo "== 4. 弹 / 收贴片"
$CLI --op source.visibility --set source=关注提示 --set visible=true --data-only --compact
$CLI --op source.visibility --set source=关注提示 --set toggle=true --data-only --compact   # 直接翻转

echo "== 5. 录制：开始 / 暂停 / 继续 / 停止（停止要 confirm）"
$CLI --op stream.control --json '{"action":"start_record","wait":true}' --data-only --compact
$CLI --op stream.control --json '{"action":"stop_record","wait":true}' --data-only --compact

echo "== 6. 批量（一次往返做完；遇错即停，可加 --continue-on-error）"
$CLI --batch-file "$(dirname "$0")/batch_startup.json" --continue-on-error --data-only --compact

echo "== 7. 截图存文件（别让 base64 糊终端）"
$CLI --op canvas.snapshot --json '{"format":"jpeg","quality":80}' --snapshot-out /tmp/obs_nexus_snap.jpg --data-only --compact

echo "== 8. 事件驱动（等下一次场景切换，最多 30s）"
timeout 30 $CLI --wait-event scene.changed --events scene.changed --compact || echo "(超时没等到)"

echo "== 9. 常驻管道：每行一个请求，每行一个响应"
printf '%s\n' '{"id":"a","op":"system.ping"}' '{"id":"b","op":"scene.list"}' | $CLI --ndjson --data-only

echo
echo "== 10. 应急：没有 python 客户端时用 nc（手动鉴权 + 手打一行 JSON）"
CONN="${OBS_NEXUS_DIR:-$HOME/.obs_nexus}/connection.json"
PORT=$(python3 -c "import json,os,sys;print(json.load(open(sys.argv[1]))['port'])" "$CONN")
TOK=$(python3 -c "import json,os,sys;print(json.load(open(sys.argv[1])).get('token') or '')" "$CONN")
# 一行内完成：先 auth 再发 op（服务端按行读取，两行连着发没问题）
printf '{"t":"auth","id":"1","token":"%s"}\n{"id":"2","op":"system.health"}\n' "$TOK" \
  | timeout 5 nc 127.0.0.1 "$PORT" || echo "(nc 不可用？装个 ncat/ncat，或直接用上面的 agent_client.py)"

echo
echo "== 11. 纯 curl（要先起 examples/http_bridge.py）"
echo '   python3 examples/http_bridge.py &  然后：'
echo '   curl -s localhost:45300/healthz'
echo '   curl -s -XPOST localhost:45300/rpc -H "content-type: application/json" -d "{\"op\":\"text.set\",\"source\":\"字幕\",\"text\":\"来自 curl\"}"'

echo
echo "全部示例执行完毕。注意：源名（字幕/关注提示/背景音乐…）是按常见中文工程写的，"
echo "你的工程里没有的话会返回 SOURCE_NOT_FOUND —— 这正是期望行为：明确报错而不是静默改错东西。"
exit 0
