#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""http_bridge.py —— 把 OBS Nexus 的 TCP 协议包成本地 HTTP，给只会发 HTTP 的工具用。

典型场景：浏览器的用户脚本、Node/Go/Rust 写的服务、或直接在浏览器控制台里 fetch。
OBS Nexus 是「一行 JSON over TCP」，有些运行时搞不定裸 socket，这个桥只做最小转换：

    POST /rpc            body = {"op":"text.set","source":"字幕","text":"hi"}   （或 {"ops":[...]}）
    GET  /healthz        服务在不在、连接数、队列水位（走 system.health）
    GET  /               连接信息摘要（不含 token）
    GET  /events         一次性拉取最近事件？—— 不，SSE 在下面
    GET  /sse            Server-Sent Events：订阅后持续推送 OBS 事件（浏览器用 EventSource 最顺手）

安全：只绑 127.0.0.1；token 从 connection.json 自动读，或由你带 `Authorization: Bearer`。
不对外网开放，也不要把它放到反代后面。

    python3 examples/http_bridge.py --port 45300
    curl -s localhost:45300/healthz
    curl -s -XPOST localhost:45300/rpc -H 'content-type: application/json' \
         -d '{"op":"text.set","source":"字幕","text":"来自 HTTP"}'

批量与截断语义完全交给 OBS Nexus，桥本身不加策略（除了一条响应上限）。
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import agent_client as ac  # noqa: E402

MAX_BODY = 1 << 20  # 与 Nexus 的单行上限一致
MAX_RESPONSE = 8 << 20


class Bridge(object):
    """一条到 Nexus 的长连接 + 一把锁（Nexus 同一连接串行，桥这边排队即可）。"""

    def __init__(self, conn_file=None, timeout=10.0, sse_events=None):
        self.conn_file = conn_file
        self.timeout = timeout
        self.sse_events = sse_events or ["scene.changed", "record.started", "record.stopped", "text.updated"]
        self.lock = threading.Lock()
        self.client = None
        self.info = None

    def connect(self):
        info, err = ac.ConnInfo.load(self.conn_file)
        if err:
            raise ac.NexusError("config", err, 3)
        self.info = info
        c = ac.Client(info.host, info.port, token=info.token, timeout=self.timeout)
        c.hello()
        if info.token:
            c.auth()
        self.client = c
        return c

    def ensure(self):
        if self.client is None:
            return self.connect()
        return self.client

    def close(self):
        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass
            self.client = None

    def request(self, obj):
        """带一次重连：OBS 重启/脚本重载之后桥要能自己活过来。"""
        with self.lock:
            for attempt in (0, 1):
                try:
                    self.ensure()
                    return self.client.request(obj, timeout=self.timeout)
                except ac.NexusError as exc:
                    if attempt or exc.code in ("bad_json", "too_large", "config", "auth_failed"):
                        raise
                    self.close()
            raise ac.NexusError("unreachable", "不该走到这里")

    def sse(self, stop_flag):
        """订阅事件并把它们 yield 成 SSE 记录。"""
        c = self.ensure()
        r = c.request({"op": "conn.subscribe", "events": self.sse_events})
        if not r.get("ok"):
            raise ac.NexusError("subscribe", json.dumps(r.get("error"), ensure_ascii=False))
        yield "retry: 2000\n\n"
        while not stop_flag.is_set():
            e = c.next_event(None, timeout=5.0)
            if e is None:
                yield ": keep-alive %d\n\n" % int(time.time())
                continue
            yield "event: %s\ndata: %s\n\n" % (e.get("event"), json.dumps(e.get("data"), ensure_ascii=False))


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    bridge = None  # 由 main 注入
    stop_flag = threading.Event()

    # ---- 小工具 ----
    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body[:MAX_RESPONSE])
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, fmt, *args):  # 静音默认 access log，改成一行摘要
        if self.server.verbose:
            sys.stderr.write("[http] %s %s\n" % (self.address_string(), fmt % args))

    # ---- 路由 ----
    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/healthz"):
            try:
                health = self.bridge.request({"op": "system.health"})
            except ac.NexusError as exc:
                return self._json(502, {"ok": False, "error": str(exc)})
            data = (health.get("result") or {}).get("data") if health.get("ok") else None
            return self._json(
                200 if health.get("ok") else 502,
                {
                    "ok": bool(health.get("ok")),
                    "endpoint": "%s:%s" % (self.bridge.info.host, self.bridge.info.port) if self.bridge.info else None,
                    "obs_version": getattr(self.bridge.info, "obs_version", None) if self.bridge.info else None,
                    "health": data,
                },
            )
        if path == "/sse":
            return self.do_sse()
        if path == "/favicon.ico":
            return self._json(404, {"ok": False, "error": "nope"})
        return self._json(404, {"ok": False, "error": "未知路径", "endpoints": ["/rpc", "/healthz", "/sse"]})

    def do_sse(self):
        self.send_response(200)
        self.send_header("content-type", "text/event-stream; charset=utf-8")
        self.send_header("cache-control", "no-store")
        self.send_header("connection", "close")
        self.end_headers()
        try:
            for chunk in self.bridge.sse(self.stop_flag):
                self.wfile.write(chunk.encode("utf-8"))
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ac.NexusError, OSError):
            pass
        finally:  # 浏览器关掉就走人，别把桥卡住
            self.close_connection = True

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        if path != "/rpc":
            return self._json(404, {"ok": False, "error": "只有 /rpc"})
        try:
            n = int(self.headers.get("content-length") or 0)
        except ValueError:
            n = 0
        if n <= 0:
            return self._json(400, {"ok": False, "error": "body 必须是 JSON（一行也可）"})
        if n > MAX_BODY:
            return self._json(413, {"ok": False, "error": "body 超过 %d 字节" % MAX_BODY})
        raw = self.rfile.read(n)
        try:
            obj = json.loads(raw.decode("utf-8", "replace"))
        except ValueError as exc:
            return self._json(400, {"ok": False, "error": "不是合法 JSON: %s" % exc})
        if not isinstance(obj, dict):
            return self._json(400, {"ok": False, "error": "顶层应该是对象：{\"op\":...} 或 {\"ops\":[...]}"})
        # 允许 ?op=text.set 这种写法：query 里给 op，body 只放参数
        qs = self.path.split("?", 1)[1] if "?" in self.path else ""
        for part in qs.split("&"):
            if part.startswith("op=") and "op" not in obj and "ops" not in obj:
                obj["op"] = part[3:]
        # 注意：鉴权由桥自己用 connection.json 的 token 完成，浏览器侧不需要带凭据
        # （反正 HTTP 桥只监听 127.0.0.1，能连到它就等于能读你家的连接文件）。
        try:
            resp = self.bridge.request(obj)
        except ac.NexusError as exc:
            code = 504 if exc.code in ("timeout",) else (400 if exc.code in ("bad_json", "too_large") else 502)
            return self._json(code, {"ok": False, "error": str(exc), "code": exc.code})
        # 图片 base64 太大时给它个可选落盘
        data = ((resp.get("result") or {}).get("data") or {}) if isinstance(resp, dict) else {}
        if isinstance(data, dict) and data.get("image_data") and self.headers.get("x-save-snapshot"):
            try:
                blob = base64.b64decode(data["image_data"])
                out = os.path.abspath(os.path.expanduser(self.headers["x-save-snapshot"]))
                with open(out, "wb") as fh:
                    fh.write(blob)
                data.pop("image_data")
                data["saved_to"] = out
                data["size"] = len(blob)
            except Exception as exc:
                data["image_save_error"] = repr(exc)
        return self._json(200 if resp.get("ok") else 422, resp)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    verbose = False

    def handle_error(self, request, client_address):  # 浏览器提前断开很常见，别刷栈
        exc = sys.exc_info()[1]
        if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
            return
        ThreadingHTTPServer.handle_error(self, request, client_address)


def main(argv=None):
    p = argparse.ArgumentParser(description="OBS Nexus 的 HTTP 桥（只监听 127.0.0.1）")
    p.add_argument("--port", type=int, default=45300)
    p.add_argument("--host", default="127.0.0.1", help="只允许 127.0.0.1/::1；填别的会被拒（防呆）")
    p.add_argument("--conn-file", help="connection.json 路径")
    p.add_argument("--timeout", type=float, default=10.0)
    p.add_argument("--events", help="SSE 要订阅的事件（逗号分隔）")
    p.add_argument("--verbose", action="store_true")
    cli = p.parse_args(argv)

    if cli.host not in ("127.0.0.1", "localhost", "::1"):
        sys.stderr.write(
            "拒绝绑定 %s：HTTP 桥不做访问控制，暴露到局域网等于把 OBS 交给整个网段。\n"
            "确实要跨机器请用 SSH 端口转发（ssh -L 45300:127.0.0.1:45300 ...）。\n" % cli.host
        )
        return 3
    bridge = Bridge(conn_file=cli.conn_file, timeout=cli.timeout, sse_events=ac.norm_events(cli.events))
    Handler.bridge = bridge
    Handler.stop_flag = threading.Event()
    Server.verbose = cli.verbose
    try:
        bridge.connect()
    except ac.NexusError as exc:
        sys.stderr.write("[warn] 现在连不上 OBS Nexus（%s）——桥照样起，等 OBS 上线后自动恢复\n" % exc)
    httpd = Server((cli.host, cli.port), Handler)
    print("HTTP 桥已启动: http://%s:%d  →  OBS Nexus %s:%s" % (cli.host, cli.port, bridge.info.host if bridge.info else "?", bridge.info.port if bridge.info else "?"))
    print("  POST /rpc   GET /healthz   GET /sse")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n收到 Ctrl-C，关闭")
    finally:
        Handler.stop_flag.set()
        httpd.shutdown()
        httpd.server_close()
        bridge.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
