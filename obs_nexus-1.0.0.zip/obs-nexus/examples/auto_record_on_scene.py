#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""auto_record_on_scene.py —— 事件驱动的自动化：切到某个场景就自动做动作。

不轮询。它订阅事件（同一条 TCP 连接里收 type=event），命中策略才动手，
所以空转时对 OBS 主线程零负担 —— 这是把 LLM/脚本挂在 OBS 上最省资源的方式。

    # 默认策略：进「直播」场景开始录制，进「下播」场景停止
    python3 examples/auto_record_on_scene.py

    # 自定义策略（JSON）：
    python3 examples/auto_record_on_scene.py --policy policy.json --verbose

policy.json 例子：
    {
      "on_scene": {
        "开场": [{"op": "stream.control", "action": "start_record"}],
        "收尾": [{"op": "stream.control", "action": "stop_record", "confirm": true}]
      },
      "on_event": {
        "record.started": [{"op": "text.set", "source": "字幕", "text": "● REC"}]
      },
      "startup": [{"op": "scene.switch", "scene": "待机"}]
    }

退出：Ctrl-C，或 --max-actions N / --duration 60。
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import agent_client as ac  # noqa: E402

DEFAULT_POLICY = {
    "on_scene": {
        "直播": [{"op": "stream.control", "action": "start_record"}],
        "下播": [{"op": "stream.control", "action": "stop_record", "confirm": True}],
    },
    "on_event": {},
}


class Watcher(object):
    def __init__(self, client, policy, verbose=False, dry=False):
        self.c = client
        self.policy = policy
        self.verbose = verbose
        self.dry = dry
        self.actions_done = 0
        self.seen = 0
        self.last_trigger = {}
        self.running = True

    def events_of_interest(self):
        want = {"scene.changed"}
        for name in (self.policy.get("on_event") or {}):
            want.add(name)
        return sorted(want)

    def run(self, max_actions, duration):
        r = self.c.request({"op": "conn.subscribe", "events": self.events_of_interest()})
        if not r.get("ok"):
            sys.stderr.write("[订阅失败] %s\n" % json.dumps(r.get("error"), ensure_ascii=False))
            return 2
        if self.verbose:
            print("[ready] 订阅: %s" % ", ".join(self.events_of_interest()), flush=True)
        for op in self.policy.get("startup") or []:
            self.do([op], "startup")
        t0 = time.time()
        while self.running:
            if duration and time.time() - t0 > duration:
                if self.verbose:
                    print("[done] 到达 --duration", flush=True)
                return 0
            e = self.c.next_event(None, timeout=5.0)
            if e is None:
                continue
            self.seen += 1
            name = e.get("event")
            data = e.get("data") or {}
            if name == "scene.changed":
                scene = data.get("current_scene")
                ops = (self.policy.get("on_scene") or {}).get(scene)
                if ops:
                    if self.throttled("scene:" + str(scene)):
                        continue
                    self.do(ops, "进入场景 %s" % scene)
            ops = (self.policy.get("on_event") or {}).get(name)
            if ops and not self.throttled("event:" + name):
                self.do(ops, "事件 %s" % name)
            if max_actions and self.actions_done >= max_actions:
                if self.verbose:
                    print("[done] 完成 %d 组动作" % self.actions_done, flush=True)
                return 0

    def throttled(self, key):
        """同一触发源 1.5 秒内只响应一次：OBS 拖场景时会连发 scene.changed。"""
        now = time.time()
        if now - self.last_trigger.get(key, 0.0) < 1.5:
            return True
        self.last_trigger[key] = now
        return False

    def do(self, ops, why):
        if not ops:
            return
        if self.dry:
            print("[dry-run] %s -> %s" % (why, json.dumps(ops, ensure_ascii=False)), flush=True)
            self.actions_done += 1
            return
        r = self.c.request({"ops": list(ops), "continue_on_error": True})
        self.actions_done += 1
        ok = bool(r.get("ok"))
        line = "[%s] %s (%s)" % (time.strftime("%H:%M:%S"), "OK " if ok else "ERR", why)
        errs = [x.get("error") for x in (r.get("results") or []) if not x.get("ok")]
        if errs:
            line += " 失败: " + json.dumps(errs[:2], ensure_ascii=False)[:220]
        print(line, flush=True)


def main(argv=None):
    p = argparse.ArgumentParser(description="按场景/事件自动操作 OBS")
    p.add_argument("--conn-file")
    p.add_argument("--policy", help="策略 JSON 文件；不传用内置的「直播/下播」策略")
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--max-actions", type=int, default=0, help="做满 N 组动作就退出（0=不限）")
    p.add_argument("--duration", type=float, default=0, help="最多跑多少秒（0=一直跑）")
    p.add_argument("--timeout", type=float, default=8.0)
    cli = p.parse_args(argv)

    policy = dict(DEFAULT_POLICY)
    if cli.policy:
        try:
            with open(os.path.expanduser(cli.policy), "r", encoding="utf-8") as fh:
                loaded = json.load(fh)
        except (OSError, ValueError) as exc:
            sys.stderr.write("[配置] 读不了 %s: %s\n" % (cli.policy, exc))
            return 3
        if not isinstance(loaded, dict):
            sys.stderr.write("[配置] 策略文件顶层应该是对象\n")
            return 3
        policy.update(loaded)

    if cli.dry_run:  # 不连 OBS 也能验证策略写得对不对

        class Dummy(object):
            def request(self, obj, **kw):
                return {"ok": True, "results": [{"ok": True, "op": o.get("op")} for o in (obj.get("ops") or [])]}

            def next_event(self, name=None, timeout=3.0):
                time.sleep(min(0.5, timeout))
                return None

            def close(self):
                pass

        client = Dummy()
    else:
        info, err = ac.ConnInfo.load(cli.conn_file)
        if err:
            sys.stderr.write("[配置] %s\n" % err)
            return 3
        try:
            client = ac.Client(info.host, info.port, token=info.token, timeout=cli.timeout)
            client.hello()
            if info.token:
                client.auth()
        except ac.NexusError as exc:
            sys.stderr.write("[连接] %s\n" % exc)
            return 2

    w = Watcher(client, policy, verbose=cli.verbose, dry=cli.dry_run)

    def stop(_sig, _frm):
        w.running = False

    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        sig = getattr(signal, name, None)
        if sig is not None:
            try:
                signal.signal(sig, stop)
            except (ValueError, OSError):
                pass
    try:
        return w.run(cli.max_actions, cli.duration)
    except KeyboardInterrupt:
        return 0
    except ac.NexusError as exc:
        sys.stderr.write("[断开] %s\n" % exc)
        return 2
    finally:
        try:
            client.close()
        except Exception:
            pass
        if cli.verbose:
            print("[exit] 看到 %d 个事件，做了 %d 组动作" % (w.seen, w.actions_done))


if __name__ == "__main__":
    sys.exit(main())
