# OBS Nexus —— 让大模型直接操作 OBS Studio 的 Python 脚本桥

一个单文件 OBS 脚本（obspython），在 OBS 进程内起一个**只监听 127.0.0.1** 的行式 JSON TCP 服务，
把「切场景、显隐贴片、写字幕、调音量、开始/暂停录制、抓画面」等动作暴露给外部 LLM Agent / 自动化脚本。

面向的场景：AI 直播导播 —— 模型看完画面/听完弹幕之后，**动手改 OBS**，而不只是输出一段文字。

- 目标版本：**OBS Studio 32.2+**（32.x/33.x 实测语义；对老版本用 `getattr` 优雅降级，不会导入即崩）
- 零第三方依赖（有 Pillow 就顺手把截图转 JPEG/缩放，没有就原样回 PNG）
- 全部 libobs 调用都在 **OBS 主线程**执行；网络线程只做 socket + 纯 Python
- 232 项离线回归（假 obspython，带真实引用计数语义）+ 34 项客户端实测 + 29 项 examples 实测

```
        LLM / 自动化脚本                OBS Studio 进程
┌───────────────────────────┐   TCP    ┌──────────────────────────────────────┐
│ agent_client.py / 你的客户端│ ──127.0.0.1:45120-45219──▶│ NetServer(selector, 后台线程)│
│  · 读 ~/.obs_nexus/        │          └───────────────┬──────────────────────┘
│    connection.json         │                          │ queue.Queue
│  · 一行 JSON ⇄ 一行 JSON    │                          ▼
└───────────────────────────┘          obs.timer_add(pump, 10ms) → 主线程泵
                                        在这里、也只有在这里调 libobs / frontend API
```

---

## 目录

```
obs-nexus/
├── src/obs_nexus.py          ★ 交付物：单文件 OBS 脚本（直接拖进 工具→脚本）
├── src/agent_client.py       ★ 交付物：独立命令行客户端（只用标准库）
├── examples/                 可运行示例：LLM 工具定义生成、导播 Agent、事件策略、HTTP 桥、shell 用法
├── parts/nexus_0*.py         上面那个 6.1k 行单文件的**源码**（分段维护，拼装生成 src/obs_nexus.py）
├── tests/                    假 OBS（真实引用计数 + 所有权模型）+ 三套测试（334 项断言）
├── build.sh                  拼装 + 静态检查（改 parts/ 后必跑）
└── run_checks.sh             一条命令跑完全部检查
```

`src/obs_nexus.py` 是产物，不要直接改；改 `parts/*` 之后：

```bash
cd obs-nexus && ./build.sh          # 拼装 + 语法检查 + 名字检查 + 全局声明检查
```

---

## 5 分钟跑起来

### 1) 确认 OBS 有 Python 环境

OBS 32.x 在 Windows/macOS 安装包里自带 Python；Linux 需要发行版的 `python3-obspython`（或按 OBS 文档
把 `obspython.pyd/so` 放进脚本目录的 Python 路径）。Tools → Scripts 面板能打开就说明有。

> 需要能 `import obspython`。如果面板报「找不到 Python」，先解决 OBS 的 Python 设置（设置→脚本→Python 安装路径），
> 与本项目无关。

### 2) 装脚本

把 `src/obs_nexus.py` 拷到 OBS 脚本目录（Windows 默认 `%APPDATA%\obs-studio\scripts\`），然后
**工具(Tools) → 脚本(Scripts) → ＋（浏览）** 选中它。面板里会出现一列属性，勾着
「OBS 启动时自动开启服务」，加载完就该监听了。

### 3) 拿连接信息

脚本会自动写 `~/.obs_nexus/connection.json`（Windows：`%USERPROFILE%\.obs_nexus\connection.json`）：

```json
{
  "app": "obs-nexus", "proto": 1, "nexus_version": "1.0.0",
  "host": "127.0.0.1", "port": 45166,
  "token": "32字节随机 hex…",
  "pid": 12345, "obs_version": "32.2.2",
  "updated_at": 1792037418.512
}
```

目录 0700、文件 0600，先写临时文件 + `fsync` 再 `os.replace`，所以不会有客户端读到半截 JSON。

### 4) 验证

```bash
python3 src/agent_client.py --discover
```

看到 `"ok": true` 和当前场景名就通了。客户端自己找连接文件，不用你填端口和 token。

### 5) 让模型动手

```bash
python3 src/agent_client.py --op text.set --set source=字幕 --set text="这波打得漂亮"
python3 src/agent_client.py --op source.visibility --set source=关注提示 --set toggle=true
python3 src/agent_client.py --op stream.control --json '{"action":"start_record","wait":true}'
```

把工具定义喂给模型（**从运行中的 OBS 实时生成**，不手写）：

```bash
python3 examples/gen_tool_spec.py --out examples/llm_tool_spec.json
```

---

## 协议

### 帧

- 一行一条 UTF-8 JSON，`\n` 结尾；单行上限 **1 MiB**（超了直接 `PROTOCOL_ERROR` 并断开，防内存放大）
- 服务端每一行输出同样以 `\n` 结尾（包括事件），客户端按行读即可
- 一条连接同一时刻只跑一个请求（串行）；要并发就开多条连接（上限见 `max_connections`）

### 握手与鉴权

连接建立后服务端先推一行 `hello`：

```json
{"v":1,"type":"hello","proto":1,"app":"obs-nexus","nexus_version":"1.0.0",
 "auth_required":true,"auth_scheme":"nexus-token-v1","auth_deadline_ms":10000,
 "limits":{"max_line_bytes":1048576,"max_batch_ops":64},
 "auth_hint":"发送 {\"t\":\"auth\",\"token\":\"…\"}，token 见 ~/.obs_nexus/connection.json"}
```

未鉴权时 `hello` 不含 token、不含 OBS 版本、不含场景信息；此时只允许 `{"t":"auth",...}` 和 `{"t":"ping"}`。
鉴权用 `hmac.compare_digest` 常量时间比较；连续失败 8 次会在日志里点名并断开；空 token 只有在你显式关掉
鉴权（`require_auth=false`）时才放行。

`auth` 成功响应里带 `ops[]` / `events[]` / `limits`，客户端可以直接以它为唯一事实来源：

```json
{"v":1,"type":"auth","request_id":"auth-1","ok":true,"obs_version":"32.2.2","advanced":false,
 "ops":["audio.mute","…","text.set"],"events":["scene.changed","…"],"limits":{"max_line_bytes":1048576,…},
 "note":"已鉴权。发送 {\"op\":\"...\"} 或 {\"ops\":[...]}，一行一条。"}
```

### 请求

```jsonc
// 单 op（参数平铺）
{"id":"1","op":"text.set","source":"字幕","text":"你好"}

// 单 op（参数打包）—— 两种写法都认
{"id":"2","op":"text.set","args":{"source":"字幕","text":"你好"}}

// 批量：一次往返做完一组动作，默认遇错即停
{"id":"3","ops":[{"op":"scene.switch","scene":"游戏"},{"op":"stream.control","action":"start_record"}],
 "continue_on_error":false, "deadline_ms":1500}
```

兼容别名（方便接各种现成客户端）：`op|method|action|cmd|name`、`ops|batch|commands`、`args|params|p|data`。
`ops` 给了非数组会明确报 `PROTOCOL_ERROR` 而不是「未知 op」。

### 响应

```jsonc
{
  "v": 1, "type": "response", "request_id": "1",
  "ok": true,
  "elapsed_ms": 1.64,
  "result": {"ok": true, "op": "text.set", "data": {…}, "ms": 0.25},
  "results": [ … ],                      // 批量时逐步结果
  "batch": {"index":1,"count":2,"executed":2,"aborted":false,"continue_on_error":false},
  "error": null                          // 或 {code,message,details,hint,retryable}
}
```

`error.hint` 是写给模型看的「下一步该怎么做」，不是套话：比如 `SOURCE_NOT_FOUND` 会告诉你先跑 `source.list`，
`canvas.snapshot` 放错位置会告诉你它必须是最后一个。

### 事件

同一条连接上推，`type=event`；订阅即 `conn.subscribe`：

```jsonc
{"v":1,"type":"event","seq":12,"event":"scene.changed","ts":1792037418.5,"data":{"current_scene":"游戏"}}
```

| 事件 | 触发 | data |
| --- | --- | --- |
| `scene.changed` | 活动场景变了（手动切、脚本切都算） | `current_scene` |
| `scene_list.changed` | 场景增删/重命名 | `current_scene`、`scenes`（≤200 个名字） |
| `transition.changed` | 转场开始/结束 | `current_scene` |
| `profile.changed` | 切换配置文件 | `current_scene` |
| `stream.starting/started/stopping/stopped` | 推流状态机 | `streaming`（`active`/`pending`/`stopping`） |
| `record.starting/started/paused/unpaused/stopping/stopped` | 录制状态机 | `recording`（`active`/`paused`/`path`） |
| `text.updated` | `text.set` 且**内容真的变了** | `scene`、`source`、`field`、`chars`、`text`、`by:"op"` |
| `source.visibility` | `source.visibility` 且**可见性真的变了** | `scene`、`source`、`visible`、`by:"op"` |
| `connection.ready` | 本连接鉴权完成 | `peer`、`port` |
| `nexus.config_changed` | 属性面板改了设置 / 执行了 `nexus.reload` | `changed`（键名列表）、`restarted` |
| `nexus.error` | **服务端内部异常**（泵里炸了、引用审计报警），2s 内同名去抖 | `where`、`detail` |
| `frontend_event` | 未识别的 OBS 前端事件（要先勾 `verbose_events`） | `event_id` |
| `obs_shutdown` / `obs.exit` | **不推送**：收到即开始优雅退出（关监听、删连接文件、刷日志） | — |

`text.updated` / `source.visibility` 是给**多 Agent 协作**用的：一个 Agent 弹字幕，另一个 Agent（或 OBS 里另一支脚本）
能直接看见，不必轮询 `source.list`。op 参数带 `"silent":true` 就不广播（自己既是生产者又是消费者时用，避免自激）；
写入值与当前一致时本来也不广播。

默认订阅集：`scene.changed`、`record.started`、`record.stopped`、`record.paused`、`record.unpaused`、
`stream.started`、`stream.stopped`。`conn.subscribe {"events":[]}` = 全关；不带 `events` = 恢复默认。
**别轮询**：轮询是把 OBS 主线程当沙袋，订阅事件才是零负担。

### 资源防御（给 LLM 用的，比给人用的更重要）

| 限制 | 默认 | 说明 |
| --- | --- | --- |
| `max_line_bytes` | 1 MiB | 单行请求上限，超了断连 |
| `rate_per_sec` | 200 | 每连接每秒行数；连续 20 次超限 → `OVERLOADED` + 断连 |
| `max_batch_ops` | 64 | 一个请求最多几个 op |
| `max_connections` | 8 | 超了直接拒（返回 `OVERLOADED` 行后关闭） |
| `max_list_items` | 80 | `source.list` 之类默认返回条数（分页 `offset`/`limit`，带 `total`/`truncated`） |
| `max_result_bytes` | 8 MiB | 单响应体积上限 |
| `max_text_bytes` | 32 KiB | `text.set` 单次写入 |
| `max_snapshot_bytes` | 1.5 MiB | 截图 base64 之前的字节上限 |
| `idle_timeout_ms` | 300000 | 空闲 5 分钟自动断开（`bye` 帧先行） |
| `deadline_ms` / `request_timeout_max_ms` | 请求内 / 30000 | 服务端执行预算，超了填 `TIMEOUT` 并 `aborted` |
| `max_batch_exec_ms` | 250 | 单个请求每 tick 最多占用主线程多久，超了就下个 tick 继续（OBS UI 不掉帧） |

---

## op 全表（29 个，含参数）

凡是操作**场景项**的 op（`source.visibility/lock/move/transform`）都接受 `index`：一个场景里允许出现
同名源项（同一个源加两次也算），Nexus 会先数一遍同名项，>1 且你没给 `index` 就返回 `SOURCE_AMBIGUOUS`
并在 `details.candidates` 里列出候选（`item_id`/`layer`/`depth`）—— 因为「改错另一个贴片」比「报错」难查得多。
`index:0` 是 z 序最上那个（与 OBS 命中顺序一致）。源级 op（`text.set`、`audio.*`、`settings_*`）不受影响。

`execution` = 在主线程执行（碰 libobs）还是在网络线程执行（只读缓存/纯计算）；
`需 advanced` = 必须在脚本属性里勾选「允许高级控制」才放行，否则返回 `FORBIDDEN`。

| op | 说明 | 参数 | 备注 |
| --- | --- | --- | --- |
| `system.overview` | 总览：OBS 版本、活动场景、推流/录制/虚拟摄像头、活动音轨、Nexus 指标 | `include_stats` — 附带 `obs_frontend_get_stats()` 文本（长，默认关） | 只读；**Agent 第一步该干的活**。`audio_tracks` 读的是推流输出，没在推流时是 `[]`（不是错误） |
| `system.health` | 定时器是否活着、队列深度、引用审计、错误统计 | — | 排障首选 |
| `system.ping` | 走一趟主线程泵的往返测试 | `echo` — 原样回带 | 判断「OBS 卡了」还是「网络卡了」 |
| `system.usage` | 本连接限流水位 + 全局计数 | — | 网络线程 |
| `system.log_tail` | 读 Nexus 日志尾部 | `lines`（默认 80，最多 400） | 需 advanced（日志可能含工程信息） |
| `scene.list` | 所有场景 + 当前/预览 + 每个场景源数 | `counts`、`limit` | 只读 |
| `scene.switch` | 切场景 | `scene`*、`mode`(cut/transition)、`transition_duration_ms` | `mode=transition` 临时借转场时长实现平滑切换，之后原值恢复 |
| `scene.create` | 新建场景 | `scene`*、`set_current`、`reuse` | 需 advanced + 写操作 |
| `scene.remove` | 删除场景 | `scene`*、`confirm:"DELETE"`* | 需 advanced；**不传 `confirm` 字面量 `DELETE` 直接 `PRECONDITION_FAILED`**；活动场景禁止删除 |
| `source.list` | 场景内源清单（名称/类型/可见/锁定/层级，组内递归） | `scene`、`limit`、`offset`、`recursive`、`flatten`、`fields`、`detailed` | 默认层级化：组内子项只出现在父行 `children` 里，不重复出现；`flatten:true` 才拉平 |
| `source.get` | 单个源详情（设置被过滤/截断/脱敏） | `source`*、`scene`、`settings`、`keys`、`filter` | `keys` 能省掉一大截 token |
| `source.visibility` | 显隐（AI 弹窗的基础动作） | `source`*、`scene`、`visible`、`toggle`、`silent`、`index` | `visible`/`toggle` 二选一，都给 → `INVALID_PARAMS`；变化会广播，`silent:true` 关闭 |
| `source.lock` | Nexus 锁定标记（多 Agent 互斥用） | `source`*、`scene`、`locked`、`index` | 写进源私有设置 `nexus_locked`，不是 OBS 的 UI 锁定 |
| `source.move` | 层级顺序 | `source`*、`scene`、`to`(top/bottom)、`layer`、`direction`(up/down)、`steps`、`index` | 绝对层号或相对步数都行 |
| `source.transform` | 位置/缩放/旋转/边界/裁剪 | `source`*、`scene`、`pos`、`scale`、`scale_uniform`、`rot`、`alignment`、`bounds_type`、`bounds_size`、`crop`、`index` | 读-改-写，没给的字段不动 |
| `source.settings_get` | 读源设置 | `source`*、`scene`、`keys`、`max_items` | 需 advanced |
| `source.settings_merge` | `obs_source_update` 浅合并 | `source`*、`settings`*、`confirm:true`* | 需 advanced；必须 `confirm:true`；单值 >2048B 报 `TOO_LARGE`（长文本走 `text.set`）；非法规则的 key 进 `skipped` 而不是写进工程 |
| `text.set` | **写文本源**（GDI+ / FreeType2 / 文本浏览器 / 文本过滤器） | `source`*、`text`、`file`、`filter`、`append`、`clear`、`scene`、`force`、`override_read_from_file`、`refresh_properties`、`silent` | AI 解说字幕核心；见下节 |
| `text.get` | 读文本源当前内容 | `source`*、`scene`、`filter` | 写完自检用 |
| `audio.status` | 音量(dB/%)、静音、同步偏移、监听方式 | `source`、`scene`、`all` | `all:true` 一次读全部（含「桌面音频/麦克风」全局源）；不给 `source` 也不给 `all` → 提示 |
| `audio.mute` | 静音/取反 | `source`*、`muted`、`toggle`、`scene` | |
| `audio.volume` | 音量 | `source`*、`percent`(0-200)、`db`(-100..+6)、`delta_db`、`delta_percent`、`scene` | OBS 内部是线性 0..1，四种写法都支持，返回前后 percent+dB+raw |
| `stream.control` | 推流/录制/虚拟摄像头 | `action`*(`start_stream`/`stop_stream`/`start_record`/`stop_record`/`pause_record`/`unpause_record`/`split_file`/`add_chapter`/`start_virtualcam`/`stop_virtualcam`/`status`)、`wait`、`wait_ms`、`chapter`、`confirm` | `stop_stream` 必须 `confirm:true`；已在目标状态 → `{skipped:…}`；`wait:true` 跨 tick 轮询到状态真变了才回 |
| `canvas.snapshot` | 抓画布/指定源的画面，Base64 回传 | `source`、`scene`、`format`(jpeg/png/file)、`width`、`quality`、`max_bytes`、`mode`、`timeout_ms`、`save_copy` | **必须是批量最后一个 op**（异步收尾，见架构）；`format:file` 只回路径最省 token |
| `conn.status` | 服务端状态：连接数、队列、水位、引用审计 | — | 网络线程 |
| `conn.capabilities` | 自描述：全部 op + 参数 + limits + 响应形状 | — | 网络线程；`examples/gen_tool_spec.py` 就是吃这个 |
| `conn.subscribe` | 订阅事件 | `events`、`min_interval_ms` | |
| `nexus.reload` | 重读 `config.json` 并热应用（端口变化自动重启服务端） | — | 需 advanced |
| `nexus.stop` | 临时停掉网络服务（OBS 不退出，可再从面板启动） | `reason` | 需 advanced；延迟 150ms 执行，保证响应先发出去 |

`*` = 必填。

### `text.set` 的几个决定

- 目标 key 按源类型选：`text_gdiplus*` → `text`，`text_ft2*` → `text_freetype`，文本浏览器 → `text`；
  类型不认识时报 `WRONG_SOURCE_TYPE`，除非 `force:true`（然后走 `text` 试一次）。这样避免「写进去了但 OBS 上没变」。
- 源勾了「读取文件」时直接写文本字段会被 OBS 忽略 → 返回 `PRECONDITION_FAILED` + `details.read_from_file` +
  该文件路径，并告诉你传 `override_read_from_file:true` 可以顺手把这个模式关掉。
- 写完会**重新读一次**并回 `verified: true/false`；不一致时附 `warning`，不用你猜。
- `append:true` 先读后拼；`clear:true` 且没给 `text` 时清空。
- 长文案用 `file` + `read_from_file` 语义（服务端读文件、按 `max_text_bytes` 截断），别把 200KB 台词塞进 JSON。

---

## 脚本属性面板

| 键 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `autostart` | bool | `true` | OBS 启动时自动开启服务 |
| `port` | int | `0` | 0 = 在 `port_lo..port_hi` 区间里挑可用端口 |
| `port_lo` / `port_hi` | int | 45120 / 45219 | 随机端口区间（100 个口，避开常用端口） |
| `require_auth` | bool | `true` | Token 鉴权。**关掉等于把 OBS 交给本机任意进程** |
| `allow_lan` | bool | `false` | ⚠️ 允许非回环绑定；勾了也只允许 0.0.0.0/防火墙后，代码里会打警告 |
| `rate_per_sec` | int | 200 | 每连接行速率上限 |
| `max_batch_ops` | int | 64 | 单请求 op 数上限 |
| `max_connections` | int | 8 | 并发连接上限 |
| `max_list_items` | int | 80 | 列表类默认条数 |
| `max_text_bytes` | int | 32768 | `text.set` 上限 |
| `max_snapshot_bytes` | int | 1572864 | 截图字节上限 |
| `snapshot_mode` | list | `auto` | `auto/native/file/dir/command/off`（见「截图」） |
| `snapshot_dir` | str | 空 | 兜底目录；空 = 自动探测 OBS 截图目录 + `~/.obs_nexus/snapshots` |
| `snapshot_quality` | int | 82 | JPEG 质量（需 Pillow） |
| `snapshot_timeout_ms` | int | 2500 | 等 OBS 落盘的超时 |
| `snapshot_command` | str | 空 | 外部截图命令（advanced；占位符 `{output}` `{source}`） |
| `echo_text` | bool | `true` | `text.set` 回显写入后的文本 |
| `verbose_events` | bool | `false` | 把所有前端事件都转发（默认只转状态相关的） |
| `keep_conn_file` | bool | `true` | 退出时删掉 `connection.json`（保持勾选更安全） |
| `advanced` | bool | `false` | ⚠️ 高级控制总开关（settings_merge / 场景增删 / 热重载 / 日志） |
| `audit_refs` | bool | `true` | 引用计数审计 |
| `max_batch_exec_ms` | int | 250 | 单请求每 tick 的主线程预算 |
| `rotate_token` | bool | `false` | 下次启动重新生成 token |

面板里还有 5 个按钮：**`▶ / ⏹ 启动或停止服务`**、**`📝 写入连接文件 connection.json`**、**`🔑 重新生成 Token 并覆盖连接文件`**、**`📄 导出 ops 能力清单 capabilities.json`**、**`📁 打开 ~/.obs_nexus 目录`**（导出那份 JSON 后可以直接喂给 LLM 当 function schema）。
改了端口、限流、连接数这类会立刻 `restart()` 监听（不断 OBS）；其余字段 `script_update` 即生效。
设置同时持久化到 `~/.obs_nexus/config.json`，重启 OBS 后仍然有效。

---

## 架构与纪律（为什么这么写）

### 1. 所有 libobs 调用只发生在主线程

网络线程收到请求后，**不执行**，只把请求对象塞进 `queue.Queue`，然后 `socket.socketpair` 写一个字节叫醒自己
（保证下一次 select 立刻返回）。OBS 侧用原生定时器：

```python
obs.timer_add(self._pump, 10)     # script_load 里注册，script_unload 里 timer_remove
```

`_pump(seconds)` 每 tick 最多做 64 个 job / `max_batch_exec_ms` 毫秒（`TIMER_INTERVAL_MS=10`），做完写回结果。
注意 OBS 的回调签名是 `cb(float 秒)` —— 处理器必须接受这个参数，否则每次 tick 都在 `PyObject_CallFunction` 里炸。

`require_main_thread()` 在每个入口断言线程 id；断言失败是 `INTERNAL_ERROR`，不会静默地在错误线程调 libobs。
测试里有一条红线组（`t_threading`）：静态扫描产物，凡是能在网络线程被调用到的路径里出现 `obs_` 直接失败。

### 2. 引用配对，而且要能证明

obspython 是**裸指针**：SWIG 层（`shared/obs-scripting/obspython/obspython.i`）没有任何针对
`obs_source_t` / `obs_scene_t` / `obs_sceneitem_t` 的 addref/release typemap，只有少数函数用
`%newobject` 管 `char*`。也就是说**引用全靠脚本自己配平**：少 release 是泄漏，多 release 是
use-after-free（OBS 直接崩，而且往往崩在别的模块里，看起来像别人的 bug）。

所以第一步不是「记得 release」，而是**把每个 API 的所有权分对**。下表逐行对着
obs-studio 32.2.2 的 C 源码核过（不是抄文档，文档在这一层是含糊的）：

| 取对象的方式 | 所有权 | Nexus 的做法 |
| --- | --- | --- |
| `obs_get_source_by_name` | **新引用**（内部 `obs_source_addref_safe_`） | `refs.track(src,"obs_source_release")` |
| `obs_frontend_get_scenes` / `get_current_scene` / `get_current_preview_scene` / `get_*_output` | **新引用** | 同上；`get_scenes` 的列表整体交回 `obs_frontend_source_list_release`，不逐个 release |
| `obs_source_get_settings` / `obs_source_get_private_settings` / `obs_data_create` | **新引用**（内部 `obs_data_addref`） | `refs.track(data,"obs_data_release")` |
| `obs_source_get_filter_by_name` | **新引用**（`obs_source_get_ref`） | 同 source |
| `obs_scene_find_source` / `obs_scene_find_source_recursive` | **借用**（源码就是 `return item;`，不加引用） | 先 `obs_sceneitem_addref()` 再 track —— 见 `_own_item()` |
| `obs_scene_from_source` | **借用**（`return source->context.data;`） | 先 `obs_scene_get_ref()` 再 track —— 见 `_scene_of()` |
| `obs_sceneitem_get_source` / `obs_scene_get_source` / `obs_output_get_audio_encoder` | **借用** | 只在 op 期间用，**绝不** release |
| `obs_scene_enum_items` 回调里的 item | 借用（enum 在回调前后各 addref/release 一次） | 快照成纯 python；要留到回调外必须自己 addref |
| `obs_scene_add` / `obs_source_create` | **新引用**（`item->ref = 1` 后返回） | track + release；`obs_frontend_add_source` 会再替前端加一份 |

规矩写成了代码，而不只是注释：

- 所有新引用统一进 `Refs.track(obj, "obs_xxx_release")`；`Refs` 是 per-request 栈，退出时 **LIFO** 释放
  （场景项必须先于场景/源释放，否则 OBS 会在父对象已死时被访问）
- 借用 → 自有的转换只允许走 `_own_item()` / `_scene_of()` / `_borrow_to_ref()` 三个助手；
  对应 `addref` 不存在时它们退化成「只借用、不 release」，而不是硬来
- 提前释放用 `refs.drop(obj)`（同时摘栈）。手工 `_release()` 一次 + `release_all()` 再一次，
  在真 OBS 里不是「计数少 1 这么礼貌」，是崩
- `RefAudit` 按 `id(obj)` 维护**栈**（同一对象可被合法持有多次），统计
  `gets/releases/outstanding/double_release`；`system.health`、`conn.status`、`script_unload` 都会报告，
  异常时推 `nexus.error` 事件
- **测试端有哨兵**：假 OBS 给每类对象记 `owner_refs`（世界自己占几份）。`_release()` 把计数压到基线
  以下 → 写进 `W.violations`；三个 suite 的 `check()` 每次都把违规转成断言失败；对象归零后再被访问
  直接抛 `use-after-free: sceneitem('贴图') …`。上面「借用」那两行哪天被改错（比如有人顺手给
  `obs_scene_find_source` 的结果加了 track），套件会当场炸给他看

压测断言：60×7 op + 120 次连接抖动之后 `gets == releases`、`outstanding == 0`、`double_release == 0`、
fake 层零悬挂对象、fd/线程数不涨。

### 3. 批量是「两阶段」的，不是 for 循环

`RequestState.step()` 在主线程按 tick 推进：遇到 `deadline_ms` 就把剩余步骤填成 `TIMEOUT` + `aborted`；
返回 `Async(poll, …)` 的 op（如 `stream.control wait:true`）每 tick 轮询一次，**绝不 sleep**。
`continue_on_error` 只影响是否继续推进，不影响语义：每步都有独立 `results[i]`。

### 4. 截图为什么绕一圈

OBS 的截图是异步的：`obs_frontend_take_screenshot()` / `obs_frontend_take_source_screenshot(src)` 是 **void**，
图落在「设置→高级→截图」目录里；`obs_frontend_get_last_screenshot()` 返回 char*。SWIG 也拿不到 GPU 纹理
（`gs_stagesurface_map` 的 `uint8_t**` 解不了引用），obs-websocket 那条 WS 路又要引入第三方依赖。
所以：主线程只负责**触发**（记录触发前已存在的图片文件集合，防止把上一次截图当这次的），
**等待新文件出现 + 体积稳定 + 编码 + Base64** 全部在网络线程做，回复由 `("reply", conn_id, payload, capture)`
投递。副作用：`canvas.snapshot` 必须是批量最后一个 op —— 这不是洁癖，是顺序语义，服务端会直接拒绝并解释。

`format:"file"` 只回路径（`details.recording_path` 之类同理），高频抓帧强烈建议用它 + 自己 watch 目录。

### 5. 优雅退出

`script_unload`：停 timer → 摘前端事件回调 → `NetServer.stop()`（关监听 → 排空 outbox →
`shutdown(SHUT_RDWR)` → 关 fd → join 线程）→ 清队列 → 删 `connection.json` → 打印引用审计 → `_LOG.close()`。
OBS 自己快退出时（`OBS_FRONTEND_EVENT_EXIT`/`_SCRIPT_STOPping`）也会 `post_deferred(0, rt.stop)`，
避免「OBS 走了，端口还占着、连接文件还写着死 pid」。

---

## 安全模型

| 层 | 做法 |
| --- | --- |
| 网络 | 强制 127.0.0.1（`allow_lan` 勾了也只允许回环，其它 host 直接忽略并告警）；随机高端口 |
| 凭据 | 32 字节随机 token（`os.urandom`），`hmac.compare_digest` 比较；文件 0600 / 目录 0700 |
| 泄露面 | 日志、`hello`、错误消息里都不出现 token 值（测试断言 token 值不在日志里） |
| 危险动作 | `settings_merge`/场景增删/热重载/日志 需 `advanced`；`stop_stream` 需 `confirm:true`；`scene.remove` 需 `confirm:"DELETE"`；`text.set` 的读文件模式冲突要显式 `override_read_from_file` |
| 上下文 | 所有列表默认截断 + `total/truncated` + `hint`；`fields`/`keys` 可裁剪；截图默认建议 `format:"file"` |
| 洪水 | 行速率、行数、体积、连接数、批量大小、空闲超时、in-flight=1、outbox 64 MiB 上限 |
| 审计 | 连续鉴权失败写日志；引用审计；`system.log_tail` 只有 advanced 才给 |

跨机器访问请走 SSH 隧道，**不要**打开 `allow_lan`：

```bash
ssh -N -L 45166:127.0.0.1:45166 user@obs-box   # 远端把端口写进它的 connection.json
OBS_NEXUS_DIR=/tmp/tunnel python3 src/agent_client.py --op system.overview
```

---

## agent_client.py

只用 `socket/json/argparse`，Python 3.8+；自动读 `~/.obs_nexus/connection.json`（`--conn-file` /
`OBS_NEXUS_DIR` 覆盖），并检查里面的 `pid` 是否还活着（陈旧文件直接拒绝，`--ignore-stale` 可跳过）。

```bash
--op NAME [--json '{}' | --json-file F | --set k=v ...]   # 单 op；--set 的值按 JSON 解析
--batch '[{"op":…}]' | --batch-file F [--continue-on-error]
--ndjson                        # stdin 每行一个请求 → stdout 每行一个响应（常驻 agent 循环）
--watch [--events a,b]          # 订阅并流式打印事件
--wait-event scene.changed      # 等一个事件就退出（脚本里很好用）
--snapshot-out /tmp/x.jpg       # 把 canvas.snapshot 的 base64 落盘（默认从输出里剥掉！）
--discover / --ping / --capabilities / --raw '{"t":"ping"}'
--data-only                     # 只打 result.data，省 token
--compact / --pretty / --quiet  --timeout S  --retries N  --deadline-ms N
--host/--port/--token 覆盖连接文件
```

按 `request_id` 匹配响应，事件另存队列（所以事件不会打乱请求-响应对）。**退出码**给脚本判断用：

| 码 | 含义 |
| --- | --- |
| 0 | 成功 |
| 1 | 连上了，但 op 报错（含批量某步失败） |
| 2 | 传输层：连不上 / 被断开 / 超时 / 帧坏了 |
| 3 | 配置层：找不到连接文件、token 不对、OBS 进程已退出、参数不合法 |

---

## examples

| 文件 | 干什么 |
| --- | --- |
| `gen_tool_spec.py` | 从**运行中的**服务拉 `conn.capabilities`，生成 OpenAI / Anthropic 工具定义（`--style both/openai/anthropic`、`--only`）。OBS 升级后重跑一次就同步，永不脱节 |
| `llm_tool_spec.json` | 上面生成好的成品（含 29 个 op 的枚举 + 每个 op 的参数说明） |
| `ai_overlay_agent.py` | 「LLM 当导播」最小实现：字幕写入（带节流+长度裁剪）、关键词弹贴片、命中结束词自动收起、`--llm-cmd` 挂任意「一行进一行出」的模型 CLI、`--dry-run` 先验证策略 |
| `auto_record_on_scene.py` | 事件驱动策略引擎（零轮询）：进某场景做某组 op，命中事件做某组 op，带 1.5s 触发节流与 `--dry-run` |
| `http_bridge.py` | 把 TCP 协议包成本地 HTTP（`POST /rpc`、`GET /healthz`、`GET /sse`），给只会发 HTTP 的运行时用；只绑回环，且**拒绝**你传非回环 host |
| `batch_startup.json` | 一个「开播」批量样例（注意 snapshot 在最后） |
| `shell_examples.sh` | 11 段可直接抄的 shell 用法，含 `nc` 应急手搓协议 |

---

## 排障

| 现象 | 先看 | 处理 |
| --- | --- | --- |
| `找不到 ~/.obs_nexus/connection.json` | 脚本面板有没有报错 | 脚本没加载/加载即失败；`autostart` 勾上；看面板日志 |
| `连不上 127.0.0.1:45166` | `--discover`；OBS 还开着吗 | OBS 关了但连接文件是旧的 → 重新加载脚本；端口区间被占 → 改 `port_lo/port_hi` |
| `token 校验失败` | 是不是刚点过「重新生成 Token」 | 重读 `connection.json`（客户端每次都读，除非你缓存了） |
| 一直 `TIMEOUT`，`system.ping` 很慢 | `system.health` 的 `pump_age_ms`、`pump_over_budget` | `pump_age_ms` 大 = OBS 主线程被别的东西卡住（插件/渲染）；Nexus 是受害者不是凶手 |
| 字幕写了但 OBS 上不变 | `text.set` 的 `verified` 字段 | `verified:false` + 源勾了「读取文件」→ 用 `override_read_from_file:true`，或改那个文件 |
| `SOURCE_NOT_FOUND` | `source.list`（组内源用 `recursive`/`flatten` 看全） | 源名必须**完全一致**（含空格）；`details.did_you_mean` 给了相近名 |
| `SOURCE_AMBIGUOUS` | 错误的 `details.candidates`（每个同名项的 `item_id`/`layer`/`depth`） | 一个场景里有两个同名源项（同一个源加两次也算）。加 `index:0..n` 指定第几个，或先在 OBS 里改名 |
| `SHUTTING_DOWN` | OBS 正在退出（关程序 / `nexus.stop` / `obs.exit`） | **别重试**：已排队但没执行的请求会拿到这个码，进程马上就没了 |
| 截图超时 | `canvas.snapshot` 的 `details.dirs`、`snapshot_mode` | OBS 没开截图目录权限/磁盘满；或改 `snapshot_mode=file`/`dir`；`timeout_ms` 加大 |
| 想让 OBS 别掉帧 | `max_batch_exec_ms`、`max_batch_ops` | 调小（比如 8ms/16 op），代价是大批量分多个 tick |
| 端口每次变，防火墙/转发麻烦 | 把 `port` 设成固定值（如 45120） | 仍只绑回环 |
| 大模型输出爆 token | `--data-only`、`format:"file"`、`fields`/`keys`、`limit` | 服务端已经默认截断了，再让它自己选字段 |

诊断三件套：`--discover` → `--op system.health` → `--op system.log_tail`（后者需 advanced）。

---

## 测试

```bash
./build.sh                           # 拼装 + 4 项静态检查（3.8 语法/顶层重名/未定义名/缺 global）
python3 tests/run_tests.py           # 服务端 26 组 / 271 项：假 OBS（真引用计数），真协议、真 socket
python3 tests/run_client_tests.py    # 客户端 34 项：真子进程跑 agent_client.py
python3 tests/run_examples_tests.py  # examples 29 项：含 HTTP 桥 + SSE + 并发
```

覆盖点（都有断言，不是「应该没问题」）：生命周期与连接文件权限/原子性、鉴权失败与拉黑、超长行、限流、
连接数上限、协议别名与坏 JSON、分页与字段裁剪、平滑切换与时长恢复、可见性/层级/锁定/变换、
文本读写与读文件模式冲突、音频（含全局源）、推流录制（含 pause/split/chapter/虚拟摄像头、`stop_stream` 确认）、
批量遇错停止/继续、`deadline_ms` 超时填充、截图（native/dir/command/超时/过大/必须末尾）、事件订阅与多连接分发、
引用计数（含 double-release）、主线程红线静态扫描、多连接并发压测、长时压测后 fd/线程/队列零增长、
端口变更热重启、OBS 退出优雅清理、陈旧连接文件接管、`script_defaults` 不覆盖用户设置。

假 OBS（`tests/fake_obs.py`）刻意实现的是**真语义**：`_acquire/_release` 计数、enum 回调的借用引用、
`set_order` 的层级语义、场景删除后按名查不到。它把「实现错但测试过」的空间压得很小。

---

## 设计取舍 / 已知限制

- **不基于 obs-websocket**：obspython 环境里没有 WebSocket 客户端，硬搓 RFC6455 是给自己挖坑；
  obs-websocket 也没有「文本源写入 + 组内子项 + 平滑切换 + 锁定标记」这种组合的顺手路径，且它默认端口 4455 的
  鉴权/白名单语义与「本机 token 文件」不同。本项目选原生 libobs + frontend API，换来：零依赖、进程内主线程
  调度、单文件部署。
- **截图不是像素级实时**：走 OBS 原生落盘管线，1080p 单帧典型 30–120ms（含等待），别拿它当录屏回放的替代。
  要高频就 `format:"file"` + 自己读目录。
- **不碰 `config_t`**：`obs_frontend_get_global_config` 在 31.0 起废弃，且 `config_t*` 在 SWIG 里难缠；
  本项目自己 `read/write` INI/JSON，不做 OBS 配置的写者。
- `source.lock` 是 **Nexus 自己的**互斥标记（写在源私有设置里），不是 OBS「选择锁定」；两者语义不同，别混。
- 版本兼容用 `getattr(obs, name, None)` + 结构化 `UNSUPPORTED`，OBS 改名不会导致脚本加载即崩，
  但**新 API 的能力也不会自动出现**。
- 多 OBS 实例：每个实例各占一个端口、各写一份 `connection.json`（后写的赢）。要并行控制就在
  第二个实例上固定 `port`，客户端用 `--port` 指定，或给第二个实例设 `OBS_NEXUS_DIR`。

## License / 免责

MIT。它会真去改你的 OBS 工程（写字幕、切场景、开录制）。让模型动手之前，先给它一个测试场景。
