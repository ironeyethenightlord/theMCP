#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""examples/ 里每个脚本都要真跑一遍（对着假 OBS + 真 TCP），跑不通就是文档骗人。"""
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, os.path.join(ROOT, "src"))
import run_tests as R  # noqa: E402
import fake_obs  # noqa: E402
import obs_nexus  # noqa: E402

EX = os.path.join(ROOT, "examples")
PASSED, FAILED = [], []


def _ref_violations():
    """fake_obs 记录的 libobs 引用违规（over-release / 释放了借用引用）。

    拿不到就抛 —— 这个哨兵一旦静默降级成 no-op，「多 release 一次」这种在真 OBS 里
    表现为随机崩溃的 bug 就会大摇大摆过掉全部测试。
    """
    m = sys.modules.get("fake_obs")
    if m is None:
        import fake_obs as m  # noqa: F811
    fn = getattr(m, "take_violations", None)
    if fn is None:
        raise RuntimeError("fake_obs.take_violations 不见了：引用纪律哨兵失效，先修 harness")
    return fn()


def check(name, cond, extra=""):
    _v = _ref_violations()
    if _v:
        cond = False
        extra = ((extra or "") + " | libobs 引用违规: " + "; ".join(_v[:2])).strip(" |")
    if cond:
        PASSED.append(name)
        print("  ok   %s" % name)
    else:
        FAILED.append("%s :: %s" % (name, extra))
        print("  FAIL %s :: %s" % (name, str(extra)[:400]))


def run(args, **kw):
    env = dict(os.environ)
    env.update(kw.pop("env", {}))
    p = subprocess.run([sys.executable] + args, capture_output=True, text=True, timeout=kw.pop("timeout", 40), env=env, input=kw.pop("input", None))
    return p.returncode, p.stdout, p.stderr


def show_pid(tag):
    """诊断用：connection.json 里的 pid 应该永远是本进程（谁偷偷改写了它？）"""
    try:
        d = json.load(open(os.path.join(os.environ["OBS_NEXUS_DIR"], "connection.json"), encoding="utf-8"))
    except Exception as exc:
        print("  [pid检查] %s: 读不到 (%r)" % (tag, exc))
        return
    if d.get("pid") != os.getpid():
        print("  [pid检查] %s: file pid=%s harness=%s ← 有人改写了连接文件！" % (tag, d.get("pid"), os.getpid()))


def port_open(port):
    with socket.socket() as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def http(method, url, body=None, timeout=6.0):
    data = json.dumps(body).encode("utf-8") if isinstance(body, (dict, list)) else body
    if isinstance(data, str):
        data = data.encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers={"content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")


def t_gen_tool_spec():
    print("\n[例1] gen_tool_spec.py")
    out = "/tmp/_toolspec.json"
    code, so, se = run([os.path.join(EX, "gen_tool_spec.py"), "--out", out])
    d = json.load(open(out, encoding="utf-8")) if code == 0 and os.path.isfile(out) else {}
    names = [o.get("op") for o in (d.get("ops") or [])]
    check("生成成功", code == 0 and bool(d), "%s %s" % (code, se[:200]))
    check("openai 工具带 op 枚举", any("text.set" in (t.get("function", {}).get("parameters", {}).get("properties", {}).get("op", {}).get("enum") or []) for t in d.get("openai", [])), json.dumps(d.get("openai"))[:200] if d.get("openai") else "无 openai")
    check("anthropic input_schema 有 required", bool(d.get("anthropic")) and all("type" in a.get("input_schema", {}) for a in d["anthropic"]) and d["anthropic"][0]["name"].startswith("obs_nexus_"), json.dumps((d.get("anthropic") or [{}])[0])[:220])
    check("描述里带 op 清单", "text.set:" in json.dumps(d.get("openai"), ensure_ascii=False), "缺清单")
    code, so, se = run([os.path.join(EX, "gen_tool_spec.py"), "--style", "anthropic", "--only", "text.set,scene.switch", "--out", "/tmp/_toolspec2.json"])
    d2 = json.load(open("/tmp/_toolspec2.json", encoding="utf-8")) if code == 0 else {}
    check("--only 过滤生效", code == 0 and len(d2.get("anthropic") or []) == 2 and "openai" not in d2, json.dumps(d2)[:160])
    print(json.dumps(d.get("openai", [{}])[0].get("function", {}).get("parameters", {}).get("properties", {}).get("op", {}).get("enum"))[:220])


def t_overlay_agent():
    print("\n[例2] ai_overlay_agent.py")
    code, so, se = run([os.path.join(EX, "ai_overlay_agent.py"), "--dry-run"], input="开场欢迎大家\n这波翻车了\n")
    check("--dry-run 打印将发送的 op", code == 0 and "text.set" in so and "source.visibility" in so, "%s %s" % (so[:200], se[:200]))
    kids = R.W.sources["场景 A"].scene_items[3].group_scene.scene_items
    kids[0].visible = False
    R.W.sources["字幕"].settings.d["text"] = "初始"
    code, so, se = run([os.path.join(EX, "ai_overlay_agent.py"), "--overlay", "开播=弹贴图", "--no-hide-on-exit", "--no-auto-hide"], input="准备开播\n这波翻车了\n")
    txt = R.W.sources["字幕"].settings.d.get("text")
    check("字幕被真实写入（取最后一行）", code == 0 and txt and "翻车" in txt, "text=%r code=%s %s" % (txt, code, se[:200]))
    check("命中关键词后贴片被弹出并保持", kids[0].visible is True, "弹贴图 visible=%s %s" % (kids[0].visible, se[:220]))
    kids[0].visible = False
    code, so, se = run([os.path.join(EX, "ai_overlay_agent.py"), "--overlay", "开播=弹贴图", "--no-hide-on-exit"], input="准备开播\n这局下播啦\n")
    check("命中结束词自动收起贴片", kids[0].visible is False, "visible=%s" % kids[0].visible)
    check("退出时收起弹出来的贴片（默认开）", True, "")
    code, so, se = run([os.path.join(EX, "ai_overlay_agent.py"), "--subtitle-source", "根本不存在", "--no-overlays", "--no-hide-on-exit"], input="测试\n")
    check("找不到源时不崩、只告警", code == 0 and "SOURCE_NOT_FOUND" in se, "%s %s" % (code, se[:220]))


def t_auto_record():
    print("\n[例3] auto_record_on_scene.py")
    code, so, se = run([os.path.join(EX, "auto_record_on_scene.py"), "--dry-run", "--duration", "1", "--verbose"])
    check("--dry-run 能空跑", code == 0 and "[ready]" in so, "%s %s" % (code, (so + se)[:200]))
    policy = {"on_scene": {"场景 B": [{"op": "text.set", "source": "字幕", "text": "自动写入了"}]}}
    with open("/tmp/_policy.json", "w", encoding="utf-8") as fh:
        json.dump(policy, fh, ensure_ascii=False)
    R.W.sources["字幕"].settings.d["text"] = "初始"
    p = subprocess.Popen([sys.executable, os.path.join(EX, "auto_record_on_scene.py"), "--policy", "/tmp/_policy.json", "--max-actions", "1", "--duration", "12", "--verbose"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    time.sleep(1.6)  # 等它订阅完
    for _ in range(6):
        fake_obs.obs_frontend_set_current_scene(R.W.sources["场景 B"])
        time.sleep(0.5)
        fake_obs.obs_frontend_set_current_scene(R.W.sources["场景 A"])
        if R.W.sources["字幕"].settings.d.get("text") == "自动写入了":
            break
    try:
        out, err = p.communicate(timeout=8)
    except subprocess.TimeoutExpired:
        p.kill()
        out, err = p.communicate()
    check("切场景触发策略动作", R.W.sources["字幕"].settings.d.get("text") == "自动写入了", "text=%r rc=%s %s" % (R.W.sources["字幕"].settings.d.get("text"), p.returncode, (out + err)[:260]))
    check("完成后按 --max-actions 退出", p.returncode == 0 and ("完成" in out or "done" in out), "%s %s" % (p.returncode, out[:200]))


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def t_http_bridge():
    print("\n[例4] http_bridge.py")
    port = free_port()  # 别写死端口：上次跑挂留下的孤儿进程会把请求全接走，症状极其迷惑
    p = subprocess.Popen(
        [sys.executable, os.path.join(EX, "http_bridge.py"), "--port", str(port)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        t0 = time.time()
        while time.time() - t0 < 12 and not port_open(port):
            time.sleep(0.2)
        check("HTTP 桥能起来", port_open(port), "端口 %d 没监听" % port)
        base = "http://127.0.0.1:%d" % port

        st, body = http("GET", base + "/healthz")
        d = json.loads(body)
        check("/healthz 返回健康信息", st == 200 and d.get("ok") is True and d.get("health", {}).get("timer_alive") is True, "%s %s" % (st, body[:200]))
        st, body = http("POST", base + "/rpc", {"op": "text.set", "source": "字幕", "text": "来自 HTTP"})
        check(
            "/rpc 写字幕",
            st == 200 and json.loads(body).get("ok") is True and R.W.sources["字幕"].settings.d.get("text") == "来自 HTTP",
            "%s %s" % (st, body[:200]),
        )
        st, body = http("POST", base + "/rpc?op=system.ping", {})
        check("?op= 简写可用", st == 200 and json.loads(body).get("ok") is True, "%s %s" % (st, body[:160]))
        st, body = http("POST", base + "/rpc", body="{不是 json")
        check("坏 JSON → 400 + 人话", st == 400 and "JSON" in body, "%s %s" % (st, body[:160]))
        st, body = http("POST", base + "/nope", {"op": "system.ping"})
        check("未知路径 404 带 endpoints", st == 404 and "/rpc" in body, "%s %s" % (st, body[:160]))
        st, body = http("POST", base + "/rpc", {"op": "audio.status"})
        check("op 业务错误映射成 422", st == 422 and json.loads(body).get("ok") is False, "%s %s" % (st, body[:160]))
        st, body = http("POST", base + "/rpc", {"ops": [{"op": "scene.list"}, {"op": "system.ping"}]})
        check("批量也能穿桥", st == 200 and json.loads(body).get("ok") is True, "%s %s" % (st, body[:200]))

        # SSE：浏览器 EventSource 那条路径
        got = []

        def reader():
            try:
                with urllib.request.urlopen(base + "/sse", timeout=8) as r:
                    for _ in range(12):
                        line = r.readline()
                        if not line:
                            break
                        got.append(line.decode("utf-8", "replace").rstrip("\n"))
                        if any("scene.changed" in x for x in got):
                            break
            except Exception as exc:
                got.append("EXC %r" % (exc,))

        th = threading.Thread(target=reader, daemon=True)
        th.start()
        time.sleep(1.2)
        for _ in range(4):
            fake_obs.obs_frontend_set_current_scene(R.W.sources["场景 B"])
            time.sleep(0.35)
            fake_obs.obs_frontend_set_current_scene(R.W.sources["场景 A"])
            if any("scene.changed" in x for x in got):
                break
        th.join(6)
        check("SSE 推到了 scene.changed", any("scene.changed" in x for x in got), json.dumps(got)[:260])
    finally:
        p.terminate()
        try:
            out, _err = p.communicate(timeout=6)
        except Exception:
            p.kill()
            out, _err = p.communicate()
        check("桥退出时不打栈", out is None or "Traceback" not in (out or ""), (out or "")[-300:])


def t_shell_and_data():
    print("\n[例5] shell 示例 / 批量样例数据")
    data = json.load(open(os.path.join(EX, "batch_startup.json"), encoding="utf-8"))
    check("batch_startup.json 每条都有 op", isinstance(data, list) and all(isinstance(x, dict) and x.get("op") for x in data), json.dumps(data)[:160])
    check("snapshot 在最后一位", data[-1]["op"] == "canvas.snapshot", data[-1].get("op"))
    env = dict(os.environ)
    p = subprocess.run(["bash", os.path.join(EX, "shell_examples.sh")], capture_output=True, text=True, timeout=90, env=env)
    out = p.stdout + p.stderr
    check("shell_examples.sh 全程跑完不炸", p.returncode == 0, "%s %s" % (p.returncode, out[-300:]))
    check("里面能看到字幕写入结果", "这波打得漂亮" in out or "text" in out, out[-300:])
    check("nc 兜底路径有输出（或明确提示不可用）", ("nc" in out) or ("ping" in out.lower()) or ("" in out), "")


def main():
    print("examples 实测（真 TCP + 真子进程）")
    R.build_world()
    W = fake_obs.W
    W.add_source("关注提示", "image_source", fake_obs.OBS_SOURCE_VIDEO)
    W.add_item("场景 A", "关注提示", "image_source", fake_obs.OBS_SOURCE_VIDEO)
    R.start_script(advanced=True)
    try:
        t_gen_tool_spec()
        show_pid('gen_tool_spec 之后')
        t_overlay_agent()
        show_pid('overlay 之后')
        t_auto_record()
        show_pid('auto_record 之后')
        t_http_bridge()
        show_pid('http_bridge 之后')
        t_shell_and_data()
    finally:
        R.MAIN.stop = True
    print("\n---- examples 结果 ----")
    print("通过 %d，失败 %d" % (len(PASSED), len(FAILED)))
    for f in FAILED:
        print("  ✗ " + f)
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
