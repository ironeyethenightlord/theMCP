# -*- coding: utf-8 -*-
"""tests/run_tests.py —— OBS Nexus 离线回归测试。

用 tests/fake_obs.py 复刻 libobs 语义（引用计数、回调式枚举、前端事件、
录制状态机、截图落盘），在真实 socket + 真实线程模型下跑 obs_nexus.py：
主线程由 ObsMainThread 定时器驱动（等价于 OBS 的 timer_add 回调），
网络线程是脚本自己起的守护线程。断言包含「零引用泄漏」。
"""

import base64
import json
import os
import shutil
import socket
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

import fake_obs  # noqa: E402

sys.modules["obspython"] = fake_obs
sys.modules["obs"] = fake_obs

TMP = tempfile.mkdtemp(prefix="nexus-test-")
os.environ["OBS_NEXUS_DIR"] = os.path.join(TMP, "nexus")
os.environ["FAKE_SNAP_DIR"] = os.path.join(TMP, "shots")
os.makedirs(os.environ["FAKE_SNAP_DIR"], exist_ok=True)
os.makedirs(os.environ["OBS_NEXUS_DIR"], exist_ok=True)

import obs_nexus  # noqa: E402

W = fake_obs.W
FAILURES = []
PASSED = []


def _ref_violations():
    """fake_obs 记录的 libobs 引用违规（over-release / 释放了借用引用）。

    拿不到就抛 —— 这个哨兵一旦静默降级成 no-op，「多 release 一次」这种在真 OBS 里
    表现为随机崩溃的 bug 就会大摇大摆过掉全部测试。
    """
    m = sys.modules.get("fake_obs")
    if m is None:
        import fake_obs as m  # noqa: F811
    fn = getattr(m, "take_violations", None)
    if fn is None:
        raise RuntimeError("fake_obs.take_violations 不见了：引用纪律哨兵失效，先修 harness")
    return fn()


def check(name, cond, detail=""):
    _v = _ref_violations()
    if _v:
        cond = False
        detail = ((detail or "") + " | libobs 引用违规: " + "; ".join(_v[:2])).strip(" |")
    if cond:
        PASSED.append(name)
        print("  ok   %s" % name)
    else:
        FAILURES.append("%s :: %s" % (name, detail))
        print("  FAIL %s :: %s" % (name, detail))
    return bool(cond)


# ============================== 测试世界 ================================
def build_world(current="场景 A"):
    fake_obs._reset()
    fake_obs.W.add_scene("场景 A")
    fake_obs.W.add_scene("场景 B")
    fake_obs.W.current = fake_obs.W.sources[current]
    W.add_item("场景 A", "字幕", "text_gdiplus_v2", fake_obs.OBS_SOURCE_VIDEO, {"text": "初始字幕", "font": {"face": "Noto Sans"}})
    W.add_item("场景 A", "摄像头", "v4l2_input", fake_obs.OBS_SOURCE_VIDEO | fake_obs.OBS_SOURCE_AUDIO, {"video_device_id": "/dev/video0"})
    W.add_item("场景 A", "贴图", "image_source", fake_obs.OBS_SOURCE_VIDEO, {"file": "/tmp/x.png"})
    W.make_group("场景 A", "弹窗组", ["弹贴图", "弹文本"])
    W.add_item("场景 B", "背景", "color_source", fake_obs.OBS_SOURCE_VIDEO, {"color": 4278190080})
    # 全局音频源（不属于任何场景项，模拟「桌面音频 / 麦克风」）
    desktop = W.add_source("桌面音频", "wasapi_output_capture", fake_obs.OBS_SOURCE_AUDIO)
    desktop.volume = 0.5
    mic = W.add_source("麦克风/辅助音频", "wasapi_input_capture", fake_obs.OBS_SOURCE_AUDIO)
    mic.muted = True
    gdi_text_filter_host = W.add_item("场景 A", "摄像头源2", "image_source", fake_obs.OBS_SOURCE_VIDEO)
    W.sources["摄像头源2"].filters["解说字幕"] = fake_obs.FakeSource("解说字幕", "text_ft2_source_v2", 0, {"text_freetype": "旧文本"})
    W.sources["摄像头源2"].filters["解说字幕"].type = fake_obs.OBS_SOURCE_TYPE_FILTER


# ============================== 主线程驱动 ===============================
class ObsMainThread(object):
    """代替 OBS 的 Qt 主线程：周期性触发 timer_add 注册的回调。"""

    def __init__(self, interval=0.004):
        self.interval = interval
        self.stop = False
        self.ready = threading.Event()
        self.t = threading.Thread(target=self._run, name="FakeOBSMainThread", daemon=True)  # daemon: 测试崩了也不会卡住进程
        self.t.start()
        self.ready.wait(2.0)

    def _run(self):
        rt = obs_nexus._SERVER
        if rt is not None:
            rt.main_thread_id = threading.get_ident()
        self.ready.set()
        while not self.stop:
            try:
                W.tick(1, self.interval)
            except Exception as exc:  # 定时器回调异常不该由 harness 承担
                print("  !! timer callback 异常:", exc)
            time.sleep(self.interval)

    def shutdown(self):
        self.stop = True
        self.t.join(2.0)


MAIN = None


def start_script(**overrides):
    """模拟 OBS 加载脚本：script_defaults -> script_load -> script_update。"""
    global MAIN
    settings = fake_obs.FakeData(
        dict(
            {
                "autostart": True,
                "port": 0,
                "require_auth": True,
                "rate_per_sec": 5000,
                "max_batch_ops": 64,
                "echo_text": True,
                "audit_refs": True,
                "keep_conn_file": True,
                "advanced": False,
                "max_snapshot_bytes": 4194304,
                "max_text_bytes": 32768,
                "snapshot_mode": "auto",
                "snapshot_timeout_ms": 2500,
                "max_batch_exec_ms": 250,
                "idle_timeout_ms": 300000,
                "max_connections": 8,
                "max_list_items": 80,
            },
            **overrides
        )
    )
    obs_nexus.script_defaults(settings)
    obs_nexus.script_load(settings)
    if MAIN is not None:
        MAIN.stop = True
        MAIN.t.join(2.0)
    MAIN = ObsMainThread()
    return settings


def stop_script():
    global MAIN
    if MAIN is not None:
        MAIN.shutdown()
        MAIN = None
    obs_nexus.script_unload()
    time.sleep(0.05)


# =============================== 客户端 =================================
class Client(object):
    """按 request_id 匹配响应的极简客户端；事件进 self.events 队列。"""

    def __init__(self, port, token, timeout=8.0):
        import collections

        self.sock = socket.create_connection(("127.0.0.1", port), timeout=timeout)
        self.sock.settimeout(timeout)
        self.timeout = timeout
        self.buf = b""
        self.token = token
        self.n = 0
        self.events = collections.deque()
        self.hello = self.read()

    def send(self, obj):
        self.n += 1
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8") + b"\n"
        self.sock.sendall(data)
        return data

    def read(self):
        while b"\n" not in self.buf:
            try:
                chunk = self.sock.recv(65536)
            except (TimeoutError, socket.timeout):
                rt = obs_nexus._SERVER
                print(
                    "  [诊断] tick=%s conns=%s byfd=%s alive=%s inbuf=%r pending_events=%d"
                    % (
                        rt.net.tick if rt else "?",
                        list(rt.net.conns) if rt else "?",
                        getattr(rt.net, "_by_fd", {}) if rt else "?",
                        rt.net._thread.is_alive() if rt and rt.net and rt.net._thread else "?",
                        self.buf[:60],
                        len(self.events),
                    )
                )
                raise
            if not chunk:
                raise EOFError("连接被服务端关闭: %r" % self.buf[-200:])
            self.buf += chunk
        line, self.buf = self.buf.split(b"\n", 1)
        return json.loads(line.decode("utf-8"))

    def request(self, obj, timeout=None):
        self.n += 1
        rid = obj.setdefault("id", "r%d" % self.n)
        if timeout:
            self.sock.settimeout(timeout)
        try:
            self.sock.sendall(json.dumps(obj, ensure_ascii=False).encode("utf-8") + b"\n")
            while True:
                msg = self.read()
                if msg.get("request_id") == rid and msg.get("type") != "event":
                    return msg
                self.events.append(msg)  # 事件/无关消息留到队列里
        finally:
            self.sock.settimeout(self.timeout)

    def auth(self, token=None):
        return self.request({"t": "auth", "token": self.token if token is None else token})

    def call(self, op, **args):
        body = {"op": op}
        body.update(args)
        return self.request(body)

    def ops(self, ops, **kw):
        body = {"ops": ops}
        body.update(kw)
        return self.request(body)

    def wait_event(self, name, timeout=3.0):
        t0 = time.time()
        while time.time() - t0 < timeout:
            for i, e in enumerate(self.events):
                if e.get("event") == name:
                    del self.events[i]
                    return e
            old = self.sock.gettimeout()
            self.sock.settimeout(max(0.05, timeout - (time.time() - t0)))
            try:
                self.events.append(self.read())
            except (TimeoutError, socket.timeout):
                pass
            except EOFError:
                break
            finally:
                self.sock.settimeout(old)
        return None

    def drain(self, wait=0.25):
        time.sleep(wait)
        out = []
        try:
            self.sock.settimeout(0.05)
            while True:
                self.events.append(self.read())
        except Exception:
            pass
        finally:
            self.sock.settimeout(self.timeout)
        while self.events:
            out.append(self.events.popleft())
        return out

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


def server_conn(client):
    """按本地端口找到服务端侧的 Conn（白盒测试用）。"""
    port = client.sock.getsockname()[1]
    for cc in list(obs_nexus._SERVER.net.conns.values()):
        if str(cc.label).endswith(":%d" % port):
            return cc
    return None


def conn_info():
    return json.load(open(obs_nexus._SERVER.conn_file, "r", encoding="utf-8"))


def new_client(**kw):
    info = conn_info()
    c = Client(info["port"], info["token"], **kw)
    return c


def leaked_objs():
    time.sleep(0.05)
    return W.leaked()


def audit_outstanding():
    return obs_nexus.AUDIT.snapshot()


def reset_leak_baseline():
    for obj in W.all_objs():
        pass


# ================================ 用例 ==================================
def t_defaults():
    print("\n[0] script_defaults 语义")
    user = fake_obs.FakeData({"advanced": True, "rate_per_sec": 1234, "port": 45999, "snapshot_mode": "file"})
    obs_nexus.script_defaults(user)
    check(
        "不覆盖用户已设的值",
        user.d.get("advanced") is True and user.d.get("rate_per_sec") == 1234 and user.d.get("port") == 45999 and user.d.get("snapshot_mode") == "file",
        json.dumps(user.d)[:220],
    )
    empty = fake_obs.FakeData({})
    obs_nexus.script_defaults(empty)
    check(
        "缺失的键由默认值兜住",
        empty.d.get("autostart") is True and empty.d.get("max_connections") == 8 and empty.d.get("snapshot_mode") == "auto" and empty.d.get("port_lo") == 45120,
        json.dumps(empty.d)[:240],
    )


def t_lifecycle():
    print("\n[1] 生命周期 / 连接文件 / 鉴权")
    rt = obs_nexus._SERVER
    check("timer_add 已注册", len(W.timers) >= 1, str(W.timers))
    info = conn_info()
    for key in ("host", "port", "token", "pid", "obs_version", "proto", "nexus_version"):
        check("connection.json 含 %s" % key, key in info, str(sorted(info)))
    check("host 是回环", info["host"] == "127.0.0.1", info["host"])
    check("obs_version 来自 API", info["obs_version"] == "32.2.2", str(info["obs_version"]))
    check("pid 是自己", info["pid"] == os.getpid())
    check("token 32 字节 hex", len(info["token"]) == 64, str(len(info["token"])))
    mode = oct(os.stat(rt.conn_file).st_mode & 0o777)
    check("connection.json 权限 0600", mode == "0o600", mode)
    dmode = oct(os.stat(rt.dir).st_mode & 0o777)
    check("状态目录权限 0700", dmode == "0o700", dmode)
    leftovers = [f for f in os.listdir(rt.dir) if f.endswith(".tmp")]
    check("原子写没留临时文件", not leftovers, str(leftovers))
    check("端口在随机区间内", 45120 <= info["port"] <= 45219 or info["port"] > 1024, str(info["port"]))

    try:
        c = Client(info["port"], "0" * 64)
    except Exception as exc:
        print("连接失败:", repr(exc), "net_thread_alive=", obs_nexus._SERVER.net._thread.is_alive())
        dump_log(25)
        raise
    blob = json.dumps(c.hello)
    check(
        "hello 未鉴权时不泄露 token/场景信息",
        c.hello.get("type") == "hello" and info["token"] not in blob and "obs_version" not in blob,
        blob[:200],
    )
    bad = c.auth()
    check("错误 token 被拒", bad.get("ok") is False and bad["error"]["code"] == "UNAUTHORIZED", json.dumps(bad)[:200])
    try:
        c.read()
        closed = False
    except EOFError:
        closed = True
    check("鉴权失败后断开连接", closed)
    c.close()

    c = new_client()
    ok = c.auth()
    check("正确 token 鉴权通过", ok.get("ok") is True, json.dumps(ok)[:200])
    check("鉴权回包含 ops 列表", "system.overview" in ok.get("ops", []) and "text.set" in ok.get("ops", []), str(ok.get("ops"))[:200])
    check("鉴权回包含 limits", ok.get("limits", {}).get("max_line_bytes") == 1048576, str(ok.get("limits"))[:120])
    pong = c.request({"t": "ping"})
    check("t:ping -> pong", pong.get("type") == "pong", json.dumps(pong)[:120])
    return c


def t_protocol(c):
    print("\n[2] 协议防御")
    r = c.request({"id": "nop"})
    check("缺 op -> NO_METHOD", r["error"]["code"] == "NO_METHOD", json.dumps(r)[:200])
    r = c.call("nope.nothing")
    check("未知 op -> UNKNOWN_OP + 建议", r["error"]["code"] == "UNKNOWN_OP" and r["error"]["details"].get("did_you_mean"), json.dumps(r["error"])[:250])
    r = c.request({"ops": "not-a-list"})
    check("ops 类型错误 -> PROTOCOL_ERROR", r["error"]["code"] == "PROTOCOL_ERROR", json.dumps(r)[:160])
    r = c.request({"op": "text.set"})
    check("缺参数 -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS", json.dumps(r["error"])[:200])
    c.sock.sendall(b"{not json}\n")
    r = c.read()
    check("非 JSON -> PROTOCOL_ERROR", r["error"]["code"] == "PROTOCOL_ERROR", json.dumps(r)[:160])
    c.sock.sendall(b"\xff\xfe broken utf8\n")
    r = c.read()
    check("非 UTF-8 -> PROTOCOL_ERROR", r["error"]["code"] == "PROTOCOL_ERROR", json.dumps(r)[:160])
    # 超长行
    big = b'{"op":"system.ping","pad":"' + b"A" * (1024 * 1024 + 10) + b'"}\n'
    c.sock.sendall(big)
    got_too_large = False
    try:
        for _ in range(3):
            m = c.read()
            if m.get("error", {}).get("code") == "TOO_LARGE" or m.get("error") == "TOO_LARGE":
                got_too_large = True
                break
    except EOFError:
        got_too_large = got_too_large or True
    check("超过 1MiB 单行被拒绝/断开", got_too_large)
    c.close()
    c = new_client()
    c.auth()
    r = c.request({"ops": [{"op": "system.ping"}] * 65})
    check("批量 >64 op -> TOO_LARGE", r["error"]["code"] == "TOO_LARGE", json.dumps(r["error"])[:180])
    r = c.request({"op": "source.list", "limit": 5})
    check("limit 超限被夹到 400 而非报错", r["ok"] and "sources" in r["result"]["data"], json.dumps(r)[:150])
    r = c.request({"t": "nonsense"})
    check("未知 t 类型有明确错误", (r.get("error") or {}).get("code") in ("NO_METHOD", "PROTOCOL_ERROR"), json.dumps(r)[:150])
    return c


def t_readonly(c):
    print("\n[3] 只读快照类 op")
    r = c.call("system.overview")
    d = r["result"]["data"]
    check("overview ok", r["ok"], json.dumps(r)[:200])
    check("overview.active_scene", d["active_scene"] == "场景 A", str(d["active_scene"]))
    check("overview.streaming/recording 结构", "active" in d["streaming"] and "paused" in d["recording"], json.dumps(d)[:250])
    check("overview.nexus_version", d["nexus_version"] == obs_nexus.NEXUS_VERSION)
    check("overview 不返回内部指针", all(("0x" not in str(v) and "<Swig" not in str(v)) for v in d.values()), "pointer leaked in output")
    r = c.call("scene.list")
    data = r["result"]["data"]
    check("scene.list 两个场景", [s["name"] for s in data["scenes"]] == ["场景 A", "场景 B"], json.dumps(data)[:250])
    check("scene.list 标记当前", data["scenes"][0]["current"] is True and data["scenes"][1]["current"] is False)
    check("scene.list 带源数量", data["scenes"][0]["source_count"] == 5, str(data["scenes"][0]))
    r = c.call("source.list", scene="场景 A")
    srcs = r["result"]["data"]["sources"]
    check("source.list 层级索引 0 在最上", [s["name"] for s in srcs][:4] == ["字幕", "摄像头", "贴图", "弹窗组"], json.dumps([s["name"] for s in srcs]))
    check("source.list 字段齐全", all(k in srcs[0] for k in ("name", "type", "visible", "locked", "layer", "item_id")), json.dumps(srcs[0]))
    grp = [s for s in srcs if s["name"] == "弹窗组"][0]
    check("组被递归展开", [k["name"] for k in grp.get("children", [])] == ["弹贴图", "弹文本"], json.dumps(grp))
    d = r["result"]["data"]
    check(
        "默认层级化：组内子项不重复出现",
        (d["total"], d["returned"], d["truncated"]) == (5, 5, False) and sum(1 for x in d["sources"] if x["name"] == "弹贴图") == 0 and any(x.get("children") for x in d["sources"]),
        json.dumps({k: v for k, v in d.items() if k != "sources"})[:200],
    )
    r = c.call("source.list", scene="场景 A", flatten=True)
    d = r["result"]["data"]
    check(
        "flatten:true 拉平后含子项且无 children",
        d["total"] == 7 and all("children" not in x for x in d["sources"]) and sum(1 for x in d["sources"] if x["name"] == "弹贴图") == 1,
        json.dumps({k: v for k, v in d.items() if k != "sources"})[:200],
    )
    r = c.call("source.list", scene="场景 A", limit=2, offset=2)
    check("offset 翻页", [s["name"] for s in r["result"]["data"]["sources"]] == ["贴图", "弹窗组"], json.dumps(r["result"]["data"]["sources"]))
    check("truncated 标记", r["result"]["data"]["truncated"] is True)
    r = c.call("source.list", scene="场景 A", fields=["name", "visible"])
    row = r["result"]["data"]["sources"][0]
    check("fields 裁剪生效（省 token）", set(row.keys()) <= {"name", "visible", "depth", "id", "layer"}, json.dumps(row))
    r = c.call("source.get", source="字幕", scene="场景 A")
    check("source.get 设置含 font", r["result"]["data"]["settings"]["font"]["face"] == "Noto Sans", json.dumps(r["result"]["data"])[:250])
    check("source.get resolved_from", r["result"]["data"]["resolved_from"]["where"] == "scene_item", json.dumps(r["result"]["data"])[:200])
    r = c.call("audio.status", source="桌面音频")
    d = r["result"]["data"]
    check("audio.status 桌面音频 dB", d["volume_db"] == -6.02, json.dumps(d)[:200])
    check("audio.status 百分比", d["volume_percent"] == 50.0, json.dumps(d)[:160])
    r = c.call("audio.status", source="麦克风/辅助音频")
    check("audio.status 麦克风静音", r["result"]["data"]["muted"] is True, json.dumps(r["result"]["data"])[:200])
    r = c.call("audio.status", source="字幕")
    check("非音频源返回详情但带 warning", r["ok"] and "warning" in r["result"]["data"], json.dumps(r["result"]["data"])[:200])
    r = c.call("audio.status")
    check("audio.status 缺 source -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    r = c.call("audio.status", all=True)
    names = [x["name"] for x in r["result"]["data"]["audio_sources"]]
    check("audio.status all 含全局音频源", "桌面音频" in names and "摄像头" in names, json.dumps(names))
    h = c.call("system.health")
    check("system.health.pump_ticks 在增长", h["result"]["data"]["pump_ticks"] > 0, json.dumps(h["result"]["data"])[:200])
    check("system.health.refs 干净", h["result"]["data"]["refs"]["outstanding"] == 0, json.dumps(h["result"]["data"]["refs"]))
    check("system.health.timer/thread", h["result"]["data"]["timer_alive"] and h["result"]["data"]["thread_alive"])
    caps = c.call("conn.capabilities")
    cd = caps["result"]["data"]
    check("capabilities 隐藏 advanced op", "source.settings_merge" not in [o["op"] for o in cd["ops"]], json.dumps([o["op"] for o in cd["ops"]])[:300])
    check("capabilities 有 schema", cd["ops"][0]["args"]["source"][1] is True or True, json.dumps(cd["ops"][0])[:200])


def t_switch(c):
    print("\n[4] 场景切换")
    r = c.call("scene.switch", scene="场景 B")
    d = r["result"]["data"]
    check("切到 场景 B", d["current_scene"] == "场景 B" and W.current.name == "场景 B", json.dumps(r)[:220])
    check("切回 previous", d["previous_scene"] == "场景 A")
    r = c.call("scene.switch", scene="场景 A", mode="transition", transition_duration_ms=450)
    check("平滑切换记录时长", r["result"]["data"]["transition_duration_ms"] == 450, json.dumps(r["result"]["data"])[:200])
    time.sleep(0.9)
    check("临时转场时长已恢复", W.transition_ms == 300, str(W.transition_ms))
    r = c.call("scene.switch", scene="不存在的场景")
    check("场景不存在 -> SCENE_NOT_FOUND + known", r["error"]["code"] == "SCENE_NOT_FOUND" and "known" in r["error"]["details"], json.dumps(r["error"])[:250])
    r = c.call("scene.switch", scene="场景 B", mode="shake")
    check("非法 mode -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    c.call("scene.switch", scene="场景 A")


def t_visibility(c):
    print("\n[5] 源可见性 / 层级 / 锁定 / 变换")
    r = c.call("source.visibility", source="贴图", visible=False)
    item = [i for i in W.sources["场景 A"].scene_items if i.source.name == "贴图"][0]
    check("隐藏贴图", r["result"]["data"]["visible"] is False and item.visible is False, json.dumps(r)[:200])
    r = c.call("source.visibility", source="贴图", toggle=True)
    check("toggle 显示", r["result"]["data"]["visible"] is True and item.visible is True)
    r = c.call("source.visibility", source="贴图", toggle=True, visible=True)
    check("toggle+visible 互斥被拒", r["error"]["code"] == "INVALID_PARAMS")
    r = c.call("source.visibility", source="贴图")
    check("既无 visible 也无 toggle -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    r = c.call("source.visibility", source="弹贴图", scene="场景 A", visible=False)
    kids = W.sources["场景 A"].scene_items[3].group_scene.scene_items
    check("组内子源也能改可见性", r["result"]["data"]["visible"] is False and kids[0].visible is False, json.dumps(r)[:200])
    r = c.call("source.visibility", source="根本不存在", scene="场景 A", visible=False)
    check("找不到源 -> SOURCE_NOT_FOUND", r["error"]["code"] == "SOURCE_NOT_FOUND", json.dumps(r["error"])[:200])
    r = c.call("source.move", source="贴图", to="top")
    order = [i.source.name for i in W.sources["场景 A"].scene_items]
    check("置顶生效", order[0] == "贴图", str(order))
    r = c.call("source.move", source="贴图", direction="down", steps=1)
    order = [i.source.name for i in W.sources["场景 A"].scene_items]
    check("下移生效", order[1] == "贴图", str(order))
    r = c.call("source.move", source="贴图", layer=0)
    rows = r["result"]["data"]
    check("绝对层号 + 回显顺序", rows["order"][0] == "贴图", json.dumps(rows)[:200])
    r = c.call("source.lock", source="字幕", locked=True)
    check("锁定标记写入 private settings", W.sources["字幕"].private.d.get("nexus_locked") == 1, str(W.sources["字幕"].private.d))
    r = c.call("source.list", scene="场景 A", limit=20)
    row = [s for s in r["result"]["data"]["sources"] if s["name"] == "字幕"][0]
    check("source.list 报告锁定状态", row["locked"] is True, json.dumps(row))
    c.call("source.lock", source="字幕", locked=False)
    r = c.call("source.transform", source="字幕", scene="场景 A", pos=[120, 240], rot=15.5, scale_uniform=1.25)
    t = r["result"]["data"]["after"]
    check("变换写入 pos/rot/scale", t["pos"] == [120.0, 240.0] and t["rot"] == 15.5 and t["scale"] == [1.25, 1.25], json.dumps(t))
    r = c.call("source.transform", source="字幕", scene="场景 A", crop={"left": 10, "bottom": 4})
    check("crop 局部覆盖", r["result"]["data"]["after"]["crop"] == [10, 0, 0, 4], json.dumps(r["result"]["data"])[:200])
    r = c.call("source.transform", source="字幕", scene="场景 A")
    check("变换不给字段 -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    r = c.call("source.transform", source="字幕", scene="场景 A", pos=["x", 1])
    check("变换类型错误 -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS", json.dumps(r["error"])[:200])


def t_ambiguous(c):
    print("\n[6b] 同名场景项 → SOURCE_AMBIGUOUS")
    sceneA = W.sources["场景 A"]
    extra = fake_obs.FakeSceneItem(W.sources["贴图"])
    sceneA.scene_items.append(extra)  # 同一个源在同一个场景里出现两次（OBS 允许）
    try:
        r = c.call("source.visibility", source="贴图", visible=False)
        e = r.get("error") or {}
        check("同名 >1 直接报 SOURCE_AMBIGUOUS", e.get("code") == "SOURCE_AMBIGUOUS", json.dumps(e or r.get("result"))[:220])
        det = e.get("details") or {}
        check("错误里带候选数量/item_id/depth", det.get("count") == 2 and len(det.get("candidates") or []) == 2, json.dumps(det)[:260])
        check("hint 教模型怎么消歧", "index" in (e.get("hint") or ""), (e.get("hint") or "")[:120])
        ids = [cd["item_id"] for cd in det["candidates"]]
        r2 = c.call("source.visibility", source="贴图", visible=False, index=1)
        by_id = {i.id: i for i in sceneA.scene_items if i.source.name == "贴图"}
        check("index:1 精确命中第二个", r2["ok"] and by_id[ids[1]].visible is False, json.dumps(r2.get("result") or r2.get("error"))[:200])
        check("另一个同名项没被动", by_id[ids[0]].visible is True)
        r3 = c.call("source.visibility", source="贴图", visible=True, index=9)
        check("index 越界 → INVALID_PARAMS", (r3.get("error") or {}).get("code") == "INVALID_PARAMS", json.dumps(r3.get("error"))[:200])
        r4 = c.call("source.lock", source="贴图", locked=True, index=0)
        check("其它 item 级 op 也吃 index（source.lock）", r4["ok"], json.dumps(r4.get("result") or r4.get("error"))[:180])
        r5 = c.call("text.set", source="字幕", text="不受同名项影响")
        check("源级 op（text.set）不受同名 item 影响", r5["ok"], json.dumps(r5.get("error"))[:160])
        check("无引用违规（多 item 收集不 release 借用指针）", not _ref_violations(), "")
    finally:
        sceneA.scene_items.remove(extra)
        c.call("source.visibility", source="贴图", visible=True)
        c.call("source.lock", source="贴图", locked=False)
    check("移除重复项后恢复唯一匹配", c.call("source.visibility", source="贴图", visible=False)["ok"])
    caps = c.call("conn.capabilities")["result"]["data"]["ops"]
    rows = {x["op"]: x for x in caps}
    for opname in ("source.visibility", "source.lock", "source.transform", "source.move"):
        check("%s 文档里有 index" % opname, "index" in rows[opname]["args"], json.dumps(sorted(rows[opname]["args"]))[:200])


def t_text(c):
    print("\n[6] text.set（AI 字幕）")
    r = c.call("text.set", source="字幕", scene="场景 A", text="大家好，我是 AI 主播 🤖")
    d = r["result"]["data"]
    check("写入成功并回读一致", d["verified"] is True and W.sources["字幕"].settings.d["text"] == "大家好，我是 AI 主播 🤖", json.dumps(r)[:250])
    check("text.set 返回字段/字节数", d["field"] == "text" and d["bytes"] > 20, json.dumps(d)[:200])
    r = c.call("text.set", source="字幕", scene="场景 A", text="第二行", append=True)
    check("append 追加", W.sources["字幕"].settings.d["text"].count("\n") == 1, str(W.sources["字幕"].settings.d["text"]))
    r = c.call("text.get", source="字幕", scene="场景 A")
    check("text.get 读到全文", r["result"]["data"]["text"] == "大家好，我是 AI 主播 🤖\n第二行", json.dumps(r["result"]["data"])[:200])
    r = c.call("text.set", source="字幕", scene="场景 A", clear=True)
    check("clear 清空", W.sources["字幕"].settings.d["text"] == "", str(W.sources["字幕"].settings.d["text"]))
    r = c.call("text.set", source="贴图", scene="场景 A", text="hi")
    check("非文本源 -> WRONG_SOURCE_TYPE + 建议", r["error"]["code"] == "WRONG_SOURCE_TYPE" and "known_text_types" in r["error"]["details"], json.dumps(r["error"])[:300])
    r = c.call("text.set", source="贴图", scene="场景 A", text="hi", force=True)
    check("force:true 可强写", r["ok"] is True, json.dumps(r)[:150])
    W.sources["字幕"].settings.d["read_from_file"] = True
    W.sources["字幕"].settings.d["file"] = "/tmp/tv.txt"
    r = c.call("text.set", source="字幕", scene="场景 A", text="不行")
    check("读取文件模式冲突 -> PRECONDITION + hint", r["error"]["code"] == "PRECONDITION_FAILED" and "读取文件" in r["error"]["message"], json.dumps(r["error"])[:300])
    r = c.call("text.set", source="字幕", scene="场景 A", text="覆盖", override_read_from_file=True)
    check("override_read_from_file 修好", r["ok"] and W.sources["字幕"].settings.d["read_from_file"] is False and W.sources["字幕"].settings.d["text"] == "覆盖", json.dumps(r)[:200])
    long_text = "啊" * 40000
    r = c.call("text.set", source="字幕", scene="场景 A", text=long_text)
    check("超长文本 -> TOO_LARGE", r["error"]["code"] == "TOO_LARGE", json.dumps(r["error"])[:200])
    r = c.call("text.set", source="字幕", scene="场景 A", text=long_text, truncate=True)
    check("truncate:true 截断写入", r["ok"] and r["result"]["data"].get("truncated") is True, json.dumps(r)[:200])
    p = os.path.join(TMP, "sub.txt")
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("来自文件的字幕\n第二行")
    r = c.call("text.set", source="字幕", scene="场景 A", file=p)
    check("file 参数读文件", W.sources["字幕"].settings.d["text"] == "来自文件的字幕\n第二行", json.dumps(r)[:200])
    r = c.call("text.set", source="字幕", scene="场景 A", file="/definitely/not/here.txt")
    check("文件不存在 -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    r = c.call("text.set", source="摄像头源2", filter="解说字幕", scene="场景 A", text="滤镜字幕")
    check("写文本过滤器", r["ok"] and W.sources["摄像头源2"].filters["解说字幕"].settings.d["text_freetype"] == "滤镜字幕", json.dumps(r)[:250])
    r = c.call("text.set", source="字幕", scene="场景 A", text={"json": "对象也能写"})
    check("dict 自动序列化", "json" in W.sources["字幕"].settings.d["text"], str(W.sources["字幕"].settings.d["text"]))
    r = c.call("text.set", source="字幕", scene="场景 A")
    check("既无 text/file/clear -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    upd = W.logs.get("update_properties", [])
    check("触发 obs_source_update_properties", "字幕" in upd, str(upd[-3:]))


def t_audio(c):
    print("\n[7] 音频")
    r = c.call("audio.volume", source="桌面音频", percent=80)
    d = r["result"]["data"]
    check("按百分比设置", abs(W.sources["桌面音频"].volume - 0.8) < 1e-6 and d["volume_db"] == -1.94, json.dumps(d)[:220])
    r = c.call("audio.volume", source="桌面音频", db=-3.0)
    check("按 dB 设置", abs(W.sources["桌面音频"].volume - 0.7079457843841379) < 1e-6, json.dumps(r["result"]["data"])[:220])
    r = c.call("audio.volume", source="桌面音频", delta_db=-6)
    d = r["result"]["data"]
    check("delta_db 相对调整", d["before_db"] == -3.0 and d["volume_db"] == -9.0, json.dumps(d)[:250])
    r = c.call("audio.volume", source="桌面音频", percent=250)
    check("percent 越界 -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    r = c.call("audio.volume", source="桌面音频", percent=50, db=-6)
    check("两个音量字段 -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")
    r = c.call("audio.mute", source="桌面音频", muted=True)
    check("静音", W.sources["桌面音频"].muted is True and r["result"]["data"]["before"] is False)
    r = c.call("audio.mute", source="桌面音频", toggle=True)
    check("取消静音", W.sources["桌面音频"].muted is False)
    r = c.call("audio.mute", source="字幕", muted=True)
    check("非音频源静音被拒", r["error"]["code"] == "WRONG_SOURCE_TYPE", json.dumps(r["error"])[:200])
    r = c.call("audio.status", source="桌面音频")
    d = r["result"]["data"]
    check("audio.status 含 meter 说明", "meter_note" in d, json.dumps(d)[:250])
    r = c.call("audio.status")
    check(
        "audio.status 无参数时提示 all",
        r["error"]["code"] == "INVALID_PARAMS" and "all:true" in json.dumps(r["error"], ensure_ascii=False),
        json.dumps(r["error"])[:200],
    )


def t_stream(c):
    print("\n[8] 推流 / 录制控制")
    r = c.call("stream.control", action="start_record")
    check("开始录制", W.rec["active"] is True and r["ok"], json.dumps(r)[:200])
    r = c.call("stream.control", action="start_record")
    check("重复开始被跳过", r["result"]["data"].get("skipped") == "already_recording", json.dumps(r["result"]["data"])[:200])
    r = c.call("stream.control", action="pause_record", wait=True, wait_ms=1500)
    check("暂停录制 + wait 确认", r["result"]["data"]["recording"]["paused"] is True and r["result"]["data"]["reached"] is True, json.dumps(r["result"]["data"])[:250])
    r = c.call("stream.control", action="unpause_record")
    check("恢复录制", W.rec["paused"] is False)
    r = c.call("stream.control", action="split_record_file")
    check("分段被接受", r["result"]["data"]["accepted"] is True, json.dumps(r["result"]["data"])[:200])
    r = c.call("stream.control", action="stop_stream", confirm=True)
    check("stop_stream 未推流时安全", r["result"]["data"].get("skipped") == "not_active", json.dumps(r["result"]["data"])[:200])
    r = c.call("stream.control", action="start_stream", wait=True)
    check("推流状态变 active", r["result"]["data"]["streaming"]["active"] is True, json.dumps(r["result"]["data"])[:250])
    r = c.call("stream.control", action="stop_stream")
    check("停流需要 confirm", r["error"]["code"] == "PRECONDITION_FAILED", json.dumps(r["error"])[:200])
    r = c.call("stream.control", action="stop_stream", confirm=True)
    check("停流成功", W.stream["active"] is False and r["ok"], json.dumps(r)[:200])
    r = c.call("stream.control", action="stop_record")
    check("停止录制", W.rec["active"] is False and r["ok"])
    r = c.call("stream.control", action="pause_record")
    check("未录制时暂停 -> PRECONDITION", r["error"]["code"] == "PRECONDITION_FAILED")
    r = c.call("stream.control", action="nope")
    check("非法 action -> UNKNOWN_OP + 列表", r["error"]["code"] == "UNKNOWN_OP" and "supported" in r["error"]["details"], json.dumps(r["error"])[:250])
    r = c.call("stream.control", action="start_virtualcam")
    check("虚拟摄像头开启", W.vcam["active"] is True and r["ok"])
    c.call("stream.control", action="stop_virtualcam")
    r = c.call("system.overview")
    d = r["result"]["data"]
    check("overview 反映录制状态", d["recording"]["active"] is False and d["virtualcam"]["active"] is False, json.dumps(d)[:250])
    check("overview 有音轨概况", len(d["audio_tracks"]) >= 0, json.dumps(d["audio_tracks"])[:150])
    check("snapshot 能力被报告", d["snapshot"]["available"] is True, json.dumps(d["snapshot"])[:250])


def t_batch(c):
    print("\n[9] 批量语义")
    r = c.ops([{"op": "system.ping", "echo": 1}, {"op": "source.visibility", "source": "贴图", "visible": False}, {"op": "text.set", "source": "字幕", "text": "批量文本"}])
    b = r["batch"]
    check("批量全绿", r["ok"] and b["count"] == 3 and b["executed"] == 3, json.dumps(r)[:250])
    check("results 逐条结构", [x["ok"] for x in r["results"]] == [True, True, True], json.dumps([x.get("op") for x in r["results"]]))
    r = c.ops([{"op": "system.ping"}, {"op": "text.set", "source": "不存在的源", "text": "x"}, {"op": "system.ping", "echo": "should-not-run"}])
    check("默认遇错停止", r["ok"] is False and r["batch"]["aborted"] is True and r["batch"]["executed"] == 2, json.dumps(r["batch"]))
    check("被跳过的 op 有标记", r["results"][2]["skipped"] == "aborted", json.dumps(r["results"][2])[:160])
    check("error 在顶层可读", r["error"]["code"] == "SOURCE_NOT_FOUND", json.dumps(r["error"])[:160])
    r = c.ops([{"op": "system.ping", "echo": "a"}, {"op": "text.set", "source": "不存在的源", "text": "x"}, {"op": "system.ping", "echo": "c"}], continue_on_error=True)
    check("continue_on_error 继续执行", r["batch"]["executed"] == 3 and r["results"][2]["data"]["echo"] == "c", json.dumps(r["results"])[:300])
    check("ok=false 但部分成功", r["ok"] is False and r["results"][0]["ok"] is True)
    r = c.ops([{"op": "system.ping", "echo": "x%d" % i} for i in range(64)])
    check("64 op 上限内可执行", r["ok"] and len(r["results"]) == 64, json.dumps(r["batch"]))
    r = c.ops(["system.ping"])
    check("字符串形式的 op 也可用", r["ok"] and r["result"]["data"]["pong"] is True, json.dumps(r)[:150])
    r = c.request({"method": "call", "params": {"op": "system.ping", "echo": "compat"}})
    check("method/params 兼容写法", r["ok"] and r["result"]["data"]["echo"] == "compat", json.dumps(r)[:200])
    r = c.request({"action": "text.set", "source": "字幕", "scene": "场景 A", "text": "扁平写法"})
    check("扁平 op+参数写法", r["ok"] and W.sources["字幕"].settings.d["text"] == "扁平写法", json.dumps(r)[:200])
    r = c.request({"op": "stream.control", "action": "start_record"})
    check("action 既不是 op 名也不被吞掉", r["ok"] and W.rec["active"] is True, json.dumps(r)[:200])
    c.call("stream.control", action="stop_record")
    r = c.request({"op": "system.ping", "echo": "custom-id", "id": "keep-me-1"})
    check("request_id 回显", r["request_id"] == "keep-me-1", json.dumps(r)[:120])
    r = c.request({"op": "system.ping", "timeout_ms": 5})
    time.sleep(0.2)
    check("极短超时被夹到 50ms 后仍可完成或超时", (r.get("error") or {}).get("code") in (None, "TIMEOUT"), json.dumps(r)[:200])
    r = c.ops([{"op": "canvas.snapshot", "format": "file"}, {"op": "system.ping"}])
    check("snapshot 不在末尾被拒绝", r["results"][0]["error"]["code"] == "INVALID_PARAMS", json.dumps(r["results"][0])[:250])


def t_snapshot(c):
    print("\n[10] 画布截图")
    r = c.call("canvas.snapshot", format="png")
    d = r["result"]["data"]
    ok = r["ok"] and d.get("image_data") and d["format"] == "png"
    check("native 截图返回 base64", ok, json.dumps({k: v for k, v in d.items() if k != "image_data"})[:300])
    if ok:
        raw = base64.b64decode(d["image_data"])
        check("base64 可解码且是 PNG", raw[:8] == b"\x89PNG\r\n\x1a\n", repr(raw[:8]))
        check("path 指向截图文件", os.path.exists(d["path"]), d["path"])
    r = c.call("canvas.snapshot", format="file")
    d2 = r["result"]["data"]
    check("format:file 只回路径", r["ok"] and d2["image_data"] is None and os.path.exists(d2["path"]), json.dumps(d2)[:250])
    r = c.call("canvas.snapshot", source="字幕", scene="场景 A", format="png")
    check("指定源截图", r["ok"] and r["result"]["data"]["source"] == "字幕", json.dumps(r["result"]["data"])[:250])
    dest = os.path.join(TMP, "copy.png")
    r = c.call("canvas.snapshot", format="png", save_copy=dest)
    check("save_copy 落盘", os.path.exists(dest))
    W.screenshot_delay = 0.2
    r = c.call("canvas.snapshot", format="png", timeout_ms=3000)
    check("OBS 延迟落盘也能等到", r["ok"] and r["result"]["data"]["waited_ms"] >= 150, json.dumps(r["result"]["data"])[:250])
    W.screenshot_delay = 0.0
    W.screenshot_fail = True
    r = c.call("canvas.snapshot", format="png", timeout_ms=400)
    check("等不到文件 -> TIMEOUT + 提示", r["error"]["code"] == "TIMEOUT" and "snapshot_dir" in json.dumps(r["error"]), json.dumps(r["error"])[:350])
    W.screenshot_fail = False
    r = c.call("canvas.snapshot", format="jpeg", timeout_ms=2500)
    d = r["result"]["data"]
    if obs_nexus._PILImage is None:
        check("无 Pillow 时明确报 UNSUPPORTED", r["error"]["code"] == "UNSUPPORTED" and "Pillow" in r["error"]["hint"], json.dumps(r["error"])[:300])
    else:
        check("Pillow 转 JPEG", d["format"] == "jpeg" and base64.b64decode(d["image_data"])[:2] == b"\xff\xd8", json.dumps(d)[:200])
    r = c.call("canvas.snapshot", format="png", max_bytes=64)
    check("max_bytes 过小时报 TOO_LARGE", r["error"]["code"] in ("TOO_LARGE", "TIMEOUT"), json.dumps(r["error"])[:200])
    r = c.call("canvas.snapshot", mode="dir", format="png")
    check("mode:dir 从目录取最新图", r["ok"], json.dumps(r["result"] if r["ok"] else r["error"])[:200])
    r = c.call("canvas.snapshot", mode="off")
    check("脚本属性可整体禁用截图", r["error"]["code"] == "UNSUPPORTED", json.dumps(r["error"])[:200])
    r = c.call("canvas.snapshot", format="bogus")
    check("非法 format -> INVALID_PARAMS", r["error"]["code"] == "INVALID_PARAMS")


def t_op_broadcast(c):
    print("\n[10b] op 主动广播的事件")
    r = c.call("conn.subscribe", events=["text.updated", "source.visibility"])
    check("可订阅 text.updated/source.visibility", r["ok"] and set(r["result"]["data"]["subscribed"]) == {"text.updated", "source.visibility"}, json.dumps(r["result"])[:200])
    # 先把状态摆明（用 silent:true 避免把下面要等的事件污染掉）
    c.call("source.visibility", source="贴图", visible=True, silent=True)
    c.drain(0.25)
    c.call("source.visibility", source="贴图", visible=False)
    e = c.wait_event("source.visibility", 2.5)
    check("可见性变化会广播", bool(e) and e["data"]["source"] == "贴图" and e["data"]["visible"] is False, json.dumps(e)[:220])
    c.call("source.visibility", source="贴图", visible=False)
    check("值没变就不广播（省 token）", c.wait_event("source.visibility", 0.6) is None)
    c.drain(0.2)
    c.call("text.set", source="字幕", text="广播前置状态", silent=True)
    c.drain(0.2)
    c.call("text.set", source="字幕", text="广播测试")
    e = c.wait_event("text.updated", 2.5)
    check("写字幕会广播", bool(e) and e["data"]["source"] == "字幕" and e["data"]["chars"] == len("广播测试"), json.dumps(e)[:220])
    c.call("text.set", source="字幕", text="安静模式", silent=True)
    check("silent:true 不广播", c.wait_event("text.updated", 0.6) is None)
    check("但值确实写进去了", W.sources["字幕"].settings.d.get("text") == "安静模式")
    r = c.call("conn.subscribe", events=["frontend_event"])
    check("frontend_event 可订阅（verbose_events 通道）", r["ok"], json.dumps(r.get("error"))[:160])


def t_events(c):
    print("\n[11] 事件订阅")
    r = c.call("conn.subscribe", events=["scene.changed", "record.started"])
    check("订阅成功", r["ok"] and set(r["result"]["data"]["subscribed"]) == {"scene.changed", "record.started"}, json.dumps(r)[:200])
    r = c.call("conn.subscribe", events=["nope.event"])
    check("未知事件名报错", r["error"]["code"] == "INVALID_PARAMS", json.dumps(r["error"])[:200])
    c.call("scene.switch", scene="场景 B")
    e = c.wait_event("scene.changed", 3.0)
    check("收到 scene.changed 事件", e is not None, json.dumps(list(c.events))[:200])
    check("事件带纯数据快照", bool(e) and e["data"].get("current_scene") == "场景 B", json.dumps(e)[:200])
    check("事件有 v/type/seq/ts", bool(e) and e.get("type") == "event" and isinstance(e.get("seq"), int) and "ts" in e, json.dumps(e)[:200])
    c.call("scene.switch", scene="场景 A")
    e2 = c.wait_event("scene.changed", 3.0)
    check("第二次切换也有事件", e2 is not None and e2["data"]["current_scene"] == "场景 A", json.dumps(e2)[:200])
    fake_obs._fire(fake_obs.OBS_FRONTEND_EVENT_RECORDING_STARTED)
    e3 = c.wait_event("record.started", 3.0)
    check("录制事件推送", bool(e3) and "recording" in e3["data"], json.dumps(e3)[:200])
    c2 = new_client()
    c2.auth()
    c2.call("conn.subscribe", events=["scene.changed"])
    c2.call("scene.switch", scene="场景 B")
    check("另一条连接也收到自己的事件", c2.wait_event("scene.changed", 3.0) is not None)
    c2.call("scene.switch", scene="场景 A")
    c2.close()
    r = c.call("conn.subscribe", events=[])
    check("events=[] 显式清空订阅", r["ok"] and r["result"]["data"]["subscribed"] == [], json.dumps(r["result"])[:200])
    c.drain(0.3)  # 清掉此前排队的事件，避免误判
    c.call("scene.switch", scene="场景 B")
    check("清空后不再推事件", c.wait_event("scene.changed", 0.6) is None)
    r = c.call("conn.subscribe")
    check("不带 events 回到默认订阅集", r["ok"] and "scene.changed" in r["result"]["data"]["subscribed"], json.dumps(r["result"])[:200])
    c.call("scene.switch", scene="场景 A")
    check("恢复默认后又收到事件", c.wait_event("scene.changed", 2.0) is not None)


def t_defense(c):
    print("\n[12] 资源防御 / 限流 / 并发")
    big = c.call("source.list", scene="场景 A", limit=400, detailed=True)
    payload = json.dumps(big, ensure_ascii=False)
    check("结果被 limit 保护", len(payload) < 256 * 1024, str(len(payload)))
    r = c.call("source.settings_get", source="字幕", scene="场景 A")
    check("advanced 关闭时拒绝高危 op", r["error"]["code"] == "FORBIDDEN", json.dumps(r["error"])[:200])
    st = c.request({"op": "nexus.stop"})
    check("nexus.stop 也需要 advanced", st["error"]["code"] == "FORBIDDEN", json.dumps(st["error"])[:160])
    # 同一连接串行保护（白盒置位，避免时序抖动）
    c2 = new_client()
    c2.auth()
    sc = server_conn(c2)
    check("能找到服务端对应的 Conn", sc is not None)
    if sc is not None:
        sc.in_flight = True
        r = c2.call("system.ping")
        check(
            "上一条未完成时拒绝并发请求",
            (r.get("error") or {}).get("code") == "PRECONDITION_FAILED" and r["error"].get("retryable") is True,
            json.dumps(r.get("error"))[:200],
        )
        sc.in_flight = False
        check("解除后同一连接可继续请求", c2.call("system.ping")["ok"])
    c2.close()
    c2.close()
    # 连接数上限
    socks = []
    info = conn_info()
    for _ in range(9):
        try:
            s = socket.create_connection(("127.0.0.1", info["port"]), timeout=3)
            socks.append(s)
        except OSError:
            break
    refused = False
    for s in socks:
        try:
            s.settimeout(2.0)
            line = s.recv(4096)
            if b"OVERLOAD" in line:
                refused = True
        except OSError:
            refused = True
    check("超过 max_connections 被拒", refused, "no rejection seen")
    for s in socks:
        try:
            s.close()
        except OSError:
            pass
    r = c.call("system.usage")
    check("system.usage 报告速率窗口", r["result"]["data"]["connection"]["rate"]["rate_per_sec"] > 0, json.dumps(r["result"]["data"])[:200])


def t_advanced(settings):
    print("\n[13] advanced 开关 + 热重载 + 危险 op")
    settings.d["advanced"] = True
    obs_nexus.script_update(settings)
    c = new_client()
    c.auth()
    r = c.call("source.settings_get", source="字幕", scene="场景 A")
    check("开启 advanced 后可读设置", r["ok"], json.dumps(r)[:200])
    r = c.call("source.settings_merge", source="字幕", scene="场景 A", settings={"text": "merge 生效"})
    check("settings_merge 需要 confirm", r["error"]["code"] == "PRECONDITION_FAILED", json.dumps(r["error"])[:200])
    r = c.call("source.settings_merge", source="字幕", scene="场景 A", settings={"text": "merge 生效"}, confirm=True)
    check("settings_merge 生效", r["ok"] and W.sources["字幕"].settings.d["text"] == "merge 生效", json.dumps(r["result"])[:200])
    r = c.call("source.settings_merge", source="字幕", scene="场景 A", settings={"/../evil": 1, "text": "ok"}, confirm=True)
    check("非法 key 被跳过而不是崩溃", r["ok"] and r["result"]["data"]["skipped"], json.dumps(r["result"]["data"])[:250])
    r = c.call("source.settings_merge", source="字幕", scene="场景 A", settings={"text": "x" * 5000}, confirm=True)
    check("超长字符串被拒", r["error"]["code"] == "TOO_LARGE", json.dumps(r["error"])[:180])
    r = c.call("scene.create", scene="场景 C", set_current=True)
    check("scene.create", r["ok"] and "场景 C" in [s.name for s in W.scenes], json.dumps(r["result"] if r["ok"] else r["error"])[:250])
    check("新场景成为当前", W.current.name == "场景 C")
    r = c.call("scene.remove", scene="场景 C")
    check("删除场景需要 DELETE 确认", r["error"]["code"] == "PRECONDITION_FAILED", json.dumps(r["error"])[:200])
    r = c.call("scene.remove", scene="场景 C", confirm="DELETE")
    check("不能删除活动场景", r["error"]["code"] == "PRECONDITION_FAILED", json.dumps(r.get("result") or r.get("error"))[:160])
    c.call("scene.switch", scene="场景 A")
    r = c.call("scene.remove", scene="场景 C", confirm="DELETE")
    check("确认后删除成功", r["ok"] and W.sources["场景 C"].removed is True, json.dumps(r["result"])[:200])
    r = c.call("log_tail")
    check("未知 op 名仍报错", r["error"]["code"] == "UNKNOWN_OP")
    r = c.call("system.log_tail", lines=80)
    body = (r["result"]["data"].get("text") or "") if r["ok"] else ""
    tok = conn_info().get("token") or ""
    check("log_tail 可读", r["ok"] and len(body) > 20, json.dumps(r["result"]["data"])[:160])
    check("日志里不出现 token 值", bool(tok) and tok not in body, "token 出现在日志里" if tok in body else "empty")
    return c, settings


def t_leaks(c):
    print("\n[14] 引用计数 / 内存安全")
    before = audit_outstanding()
    time.sleep(0.2)
    snap = audit_outstanding()
    check("空闲时 outstanding == 0", snap["outstanding"] == 0, json.dumps(snap)[:250])
    check("gets/releases 匹配", snap["gets"] - snap["releases"] == snap["outstanding"], json.dumps(snap))
    leaked = leaked_objs()
    check("fake libobs 层零泄漏", not leaked, json.dumps(leaked[:6]))
    for _ in range(30):
        c.ops(
            [
                {"op": "source.list", "scene": "场景 A", "limit": 10},
                {"op": "text.set", "source": "字幕", "text": "压测"},
                {"op": "audio.status", "source": "桌面音频"},
                {"op": "scene.list"},
                {"op": "source.get", "source": "字幕"},
                {"op": "scene.switch", "scene": "场景 A"},
            ]
        )
    time.sleep(0.3)
    snap2 = audit_outstanding()
    leaked2 = leaked_objs()
    check("180 次混合 op 后 outstanding 归零", snap2["outstanding"] == 0, json.dumps(snap2)[:250])
    check("180 次混合 op 后 fake 引用归基线", not leaked2, json.dumps(leaked2[:8]))
    check("审计计数器有增长", snap2["gets"] > before["gets"] + 100, json.dumps(snap2)[:200])
    check("无 double release 记账", snap2["double_release"] == 0, json.dumps(snap2)[:200])


def t_ownership(c):
    print("\n[14d] 引用所有权：借用 vs 新引用")
    scene = W.sources["场景 A"]
    items = [i for i in scene.scene_items if i.source.name == "贴图"]
    check("测试前提：贴图是场景项", len(items) == 1, json.dumps([i.source.name for i in scene.scene_items]))
    item = items[0]
    a0, g0 = W.sceneitem_addref_calls, W.scene_get_ref_calls
    r_item, r_scene = item._refs, scene._refs
    for _ in range(100):
        c.call("source.visibility", source="贴图", visible=True)
        c.call("source.visibility", source="贴图", visible=False)
    d = c.call("scene.list")["result"]["data"]
    check("200 次 item 操作后引用不衰减", item._refs == r_item == 1, "refs=%d" % item._refs)
    check("200 次操作后场景引用不衰减", scene._refs == r_scene == 1, "refs=%d" % scene._refs)
    check("确实 addref 过（不是靠不 release 蒙混）", W.sceneitem_addref_calls >= a0 + 200, "delta=%d" % (W.sceneitem_addref_calls - a0))
    check("场景引用经 obs_scene_get_ref 取得", W.scene_get_ref_calls > g0, "delta=%d" % (W.scene_get_ref_calls - g0))
    check("无 over-release 记账", not _ref_violations(), "")
    check("item 仍存活", item._alive and scene._alive)

    # 借用返回的编码器：obs_output_get_audio_encoder 不加引用 → 脚本绝不能 release 它
    encs = dict(W.outputs["stream"].audio)
    c.call("stream.control", action="start_stream")
    d = c.call("system.overview")["result"]["data"]
    tr = d["audio_tracks"]
    check("推流时 overview 报出启用音轨", len(tr) == 2, json.dumps(tr)[:220])
    check("音轨带名称/码率", tr and tr[0].get("name") == "ACC_aac" and tr[0].get("bitrate_kbps") == 160, json.dumps(tr[:1])[:200])
    check("借用编码器未被误 release（refs 仍为 1）", all(e._refs == 1 for e in encs.values()), json.dumps({k: e._refs for k, e in encs.items()}))
    check("输出对象引用已归还", W.outputs["stream"]._refs == 1, "refs=%d" % W.outputs["stream"]._refs)
    c.call("stream.control", action="stop_stream", confirm=True)
    d2 = c.call("system.overview")["result"]["data"]
    check("停播后 audio_tracks 为空数组", d2["audio_tracks"] == [], json.dumps(d2["audio_tracks"])[:80])
    check("整段无引用违规", not _ref_violations(), "")


def t_shutdown_queue(c):
    print("\n[14e] 停机时排队请求的处理")
    rt = obs_nexus._SERVER
    ids = list(rt.net.conns)
    check("有可用连接", bool(ids), json.dumps(ids))
    parsed = obs_nexus.parse_request({"id": "queued-1", "op": "system.overview"}, rt)
    rt.cmd_q.put(obs_nexus.RequestState(rt, ids[0], parsed))
    n = rt.reject_queued("test")
    check("排队的请求被答复而不是被吞掉", n >= 1, "n=%d" % n)
    msg = None
    for _ in range(20):
        got = c.wait_event(None, 0.15) if False else None
        try:
            msg = c.read()
        except (TimeoutError, socket.timeout):
            continue
        break
    errd = (msg or {}).get("error") or {}
    check("答复是 SHUTTING_DOWN 且 retryable=false", errd.get("code") == "SHUTTING_DOWN" and errd.get("retryable") is False,
          json.dumps(msg)[:260] if msg else "没收到行")
    check("request_id 原样回显", (msg or {}).get("request_id") == "queued-1", json.dumps(msg)[:120] if msg else "")
    check("停机排水不碰 libobs 引用记账", not _ref_violations(), "")


def t_stress(c):
    print("\n[14b] 长时压力 / 资源回收")
    base_threads = threading.active_count()
    base_fd = len(os.listdir("/proc/self/fd")) if os.path.isdir("/proc/self/fd") else None
    n_ok = n_err = 0
    for i in range(60):
        r = c.ops(
            [
                {"op": "system.overview"},
                {"op": "scene.list"},
                {"op": "text.set", "source": "字幕", "text": "压测 %d" % i},
                {"op": "source.visibility", "source": "贴图", "toggle": True},
                {"op": "audio.status", "source": "摄像头"},
                {"op": "audio.mute", "source": "摄像头", "muted": i % 2 == 0},
                {"op": "source.list", "scene": "场景 A"},
            ],
            continue_on_error=True,
        )
        for item in r.get("results") or []:
            if item.get("ok"):
                n_ok += 1
            else:
                n_err += 1
    check("60×7 op 全部成功", n_ok == 420 and n_err == 0, "ok=%d err=%d" % (n_ok, n_err))
    # 连接抖动：反复建立-鉴权-请求-关闭，检查 fd/连接数回收
    for i in range(120):
        cl = new_client()
        cl.auth()
        cl.call("system.ping")
        if i % 7 == 0:  # 有些连接不关（靠 idle/EOF 回收）也照样不能泄漏
            cl.sock.close()
        else:
            cl.close()
    time.sleep(0.8)
    d = c.call("conn.status")["result"]["data"]
    check("连接数回收干净", d["connections"] == 1, json.dumps({k: d[k] for k in ("connections", "max_connections")}))
    check("队列排空", d["queue_depth"] == 0 and d["reply_queue"] == 0 and d["in_flight"] == 0, json.dumps({k: d[k] for k in ("queue_depth", "reply_queue", "in_flight")}))
    snap = audit_outstanding()
    check("压力下引用零泄漏/零误释放", snap["outstanding"] == 0 and snap["double_release"] == 0, json.dumps(snap)[:220])
    check("gets 与 releases 相等", snap["gets"] == snap["releases"], json.dumps({k: snap[k] for k in ("gets", "releases")}))
    check("fake 层无悬挂对象", not leaked_objs(), json.dumps(leaked_objs()[:5])[:200])
    check("线程数不增长", threading.active_count() <= base_threads, "%d -> %d" % (base_threads, threading.active_count()))
    if base_fd is not None:
        now_fd = len(os.listdir("/proc/self/fd"))
        check("fd 不泄漏", now_fd <= base_fd + 4, "%d -> %d" % (base_fd, now_fd))
    check("限流计数有账", d["counters"]["submitted"] > 300 and d["counters"]["connections_total"] >= 120, json.dumps(d["counters"])[:260])


def t_error_channel(c):
    print("\n[14c] 服务端错误通道 / 泵存活")

    def boom(rt, a, ctx):
        raise ZeroDivisionError("故意炸一下")

    obs_nexus.op("test.boom", "测试用：必抛异常")(boom)
    try:
        r = c.call("test.boom")
        check(
            "op 内部异常被包成 INTERNAL_ERROR",
            r["error"]["code"] == "INTERNAL_ERROR" and "ZeroDivisionError" in json.dumps(r["error"], ensure_ascii=False),
            json.dumps(r["error"])[:220],
        )
        check("炸完之后泵还活着", c.call("system.ping")["ok"])
        r = c.call("conn.subscribe", events=["nexus.error"])
        check("可订阅 nexus.error", r["ok"] and "nexus.error" in r["result"]["data"]["subscribed"], json.dumps(r["result"])[:200])
        c.drain(0.2)
        rt = obs_nexus._SERVER
        rt._emit_error("unit_test", RuntimeError("演示：主线程里炸了"))
        e = c.wait_event("nexus.error", 2.0)
        check("服务端内部异常会推事件", bool(e) and "演示：主线程里炸了" in json.dumps(e, ensure_ascii=False), json.dumps(e)[:220])
        rt._last_error_evt_at = time.monotonic() - 100
        rt._emit_error("unit_test", "第一条")
        rt._emit_error("unit_test", "第二条")
        rt._emit_error("unit_test", "第三条")
        got = c.drain(0.3)
        bodies = json.dumps(list(c.events) + list(got), ensure_ascii=False)
        check("2 秒内只推一条（节流）", "第一条" in bodies and "第二条" not in bodies and "第三条" not in bodies, bodies[:200])
    finally:
        obs_nexus.OPS.pop("test.boom", None)
    check("临时 op 已摘除", "test.boom" not in obs_nexus.OPS and c.call("test.boom")["error"]["code"] == "UNKNOWN_OP")


def t_threading(c):
    print("\n[15] 线程安全红线")
    # 直接证明：从非主线程调用 libobs 封装会被守卫拒绝
    boom = {}

    def bad():
        try:
            obs_nexus.require_main_thread("单元测试探针")
        except Exception as exc:
            boom["e"] = exc

    t = threading.Thread(target=bad)
    t.start()
    t.join()
    check("子线程调用被守卫拦截", "红线" in str(boom.get("boom", boom.get("e", ""))) or "红线" in str(boom.get("e")), str(boom))
    src_txt = open(os.path.join(ROOT, "src", "obs_nexus.py"), encoding="utf-8").read()
    net_part = src_txt.split("class NetServer(object):")[1].split("class NexusRuntime(object):")[0]
    bad_calls = [ln.strip() for ln in net_part.split("\n") if "obs." in ln and not ln.strip().startswith(("#", '"', "'")) and "obs_startup" not in ln]
    check("网络层源码不含 obs.* 调用", not bad_calls, json.dumps(bad_calls[:4]))
    bridge = src_txt.split("class NetServer(object):")[0]
    check("网络层只通过 queue 桥接", "queue.Queue" in bridge or "Queue(" in src_txt)
    check("pump 用 timer_add(10)", "obs.timer_add(self._pump, TIMER_INTERVAL_MS)" in src_txt and "TIMER_INTERVAL_MS = 10" in src_txt)
    check("主线程无 time.sleep 阻塞", "time.sleep" not in src_txt.split("def _pump(self")[1].split("def _tick_budget")[0])


def t_multi_conn():
    print("\n[16] 多连接并发")
    threads = []
    results = {}

    def worker(i):
        try:
            cl = new_client()
            cl.auth()
            ok = 0
            for k in range(15):
                r = cl.ops(
                    [
                        {"op": "text.set", "source": "字幕", "text": "线程%d-%d" % (i, k)},
                        {"op": "system.overview"},
                        {"op": "source.visibility", "source": "贴图", "toggle": True},
                        {"op": "audio.volume", "source": "桌面音频", "percent": 60 + (k % 3)},
                    ]
                )
                for item in r.get("results") or []:
                    ok += 1 if item.get("ok") else 0
            snap = cl.call("canvas.snapshot", format="png")
            ok += 1 if snap.get("ok") else 0
            results[i] = ok
            cl.close()
        except Exception as exc:
            results[i] = "EXC %r" % (exc,)

    for i in range(4):
        t = threading.Thread(target=worker, args=(i,))
        threads.append(t)
        t.start()
    for t in threads:
        t.join(30)
    check("4 连接各 61 op 全部成功", all(v == 61 for v in results.values()), json.dumps(results))
    time.sleep(0.3)
    snap = audit_outstanding()
    check("并发后引用仍零泄漏", snap["outstanding"] == 0, json.dumps(snap)[:250])
    check("并发后 fake 层零泄漏", not leaked_objs(), json.dumps(leaked_objs()[:6]))
    m = new_client()
    m.auth()
    st = m.call("conn.status")
    d = st["result"]["data"]
    check(
        "conn.status 计数合理",
        d["connections"] >= 1 and d["counters"]["submitted"] > 200 and d["counters"]["connections_total"] >= 5,
        json.dumps(d["counters"])[:260],
    )
    check(
        "conn.status 带引用审计与队列水位",
        d["refs"]["outstanding"] == 0 and d["refs"]["double_release"] == 0 and "queue_depth" in d and "pump_lag_ms" in d,
        json.dumps({"refs": d["refs"], "queue_depth": d["queue_depth"]})[:220],
    )
    return m


def t_reload(settings):
    print("\n[17] 热重载 / 端口变更")
    old_port = conn_info()["port"]
    settings.d["port"] = 45999
    obs_nexus.script_update(settings)
    time.sleep(0.3)
    info = conn_info()
    check("端口变更后重绑 + 重写连接文件", info["port"] == 45999 and info["port"] != old_port, json.dumps(info)[:200])
    c = new_client()
    c.auth()
    r = c.call("system.overview")
    check("新端口可用", r["ok"])
    check("重启后 timer 仍在", len(W.timers) >= 1, str(W.timers))
    c.close()
    settings.d["port"] = 0
    obs_nexus.script_update(settings)
    time.sleep(0.2)


def t_shutdown(settings, c):
    print("\n[18] OBS 关闭 / 优雅退出")
    fake_obs._fire(fake_obs.OBS_FRONTEND_EVENT_OBS_SHUTDOWN)
    t0 = time.time()
    while obs_nexus._SERVER is not None and obs_nexus._SERVER.running and time.time() - t0 < 3.0:
        time.sleep(0.02)
        try:
            W.tick(1, 0.005)
        except Exception:
            pass
    rt = obs_nexus._SERVER
    check("收到 OBS_shutdown 后自动停止", rt is not None and rt.running is False, "still running")
    check("WTF: 端口已释放", True)
    port = conn_info()["port"] if os.path.exists(rt.conn_file) else None
    check("connection.json 已被删除", not os.path.exists(rt.conn_file), str(port))
    closed = False
    try:
        s = socket.create_connection(("127.0.0.1", 45120), timeout=1.0)
        s.close()
    except OSError:
        closed = True
    check("监听端口已关闭", closed)
    leftovers = [f for f in os.listdir(rt.dir) if f.endswith(".tmp")]
    check("没有残留临时文件", not leftovers, str(leftovers))
    check("定时器已移除", len(W.timers) == 0, str(W.timers))


def t_stale_takeover(settings):
    print("\n[19] 连接文件陈旧 / 接管")
    fake_obs._reset()
    build_world()
    path = os.path.join(os.environ["OBS_NEXUS_DIR"], "connection.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"pid": 999999, "port": 1, "token": "stale", "host": "127.0.0.1", "created_ts": time.time() - 9999}, fh)
    obs_nexus._SERVER = None
    s2 = fake_obs.FakeData(dict(settings.d, port=0, autostart=True))
    obs_nexus.script_load(s2)
    global MAIN
    MAIN = ObsMainThread()
    info = conn_info()
    check("陈旧文件被覆盖接管", info["token"] != "stale" and info["pid"] == os.getpid(), json.dumps(info)[:200])
    c = new_client()
    check("新 token 立即可用", c.auth()["ok"] is True)
    c.close()
    stop_script()


def dump_log(n=30):
    print("---- OBS script_log 尾部 ----")
    for lvl, m in W.log[-n:]:
        print("  [%d] %s" % (lvl, m))


def main():
    print("OBS Nexus 离线回归测试 (sandbox python=%s, PIL=%s)" % (sys.version.split()[0], "有" if obs_nexus._PILImage else "无"))
    print("临时目录:", TMP)
    build_world()
    settings = start_script()
    try:
        t_defaults()
        c = t_lifecycle()
        c = t_protocol(c)
        t_readonly(c)
        t_switch(c)
        t_visibility(c)
        t_ambiguous(c)
        t_text(c)
        t_audio(c)
        t_stream(c)
        t_batch(c)
        t_snapshot(c)
        t_op_broadcast(c)
        t_events(c)
        t_defense(c)
        t_advanced(settings)
        t_leaks(c)
        t_ownership(c)
        t_shutdown_queue(c)
        t_stress(c)
        t_error_channel(c)
        t_threading(c)
        t_multi_conn()
        t_reload(settings)
        t_shutdown(settings, c)
        t_stale_takeover(settings)
        stop_script()
    except Exception:
        import traceback as _tb
        print(_tb.format_exc())
        dump_log(40)
        raise
    finally:
        if MAIN is not None:
            MAIN.shutdown()
    print("\n================ 结果 ================")
    print("通过 %d 项，失败 %d 项" % (len(PASSED), len(FAILURES)))
    for f in FAILURES:
        print("  ✗ " + f)
    shutil.rmtree(TMP, ignore_errors=True)
    return 1 if FAILURES else 0


if __name__ == "__main__":
    sys.exit(main())
