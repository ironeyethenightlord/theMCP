#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""真进程跑一遍 agent_client.py：走 TCP、解析、退出码，全部实测。"""
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, os.path.join(ROOT, "src"))

import run_tests as R  # noqa: E402
import obs_nexus  # noqa: E402

CLI = [sys.executable, os.path.join(ROOT, "src", "agent_client.py")]
PASSED = []
FAILED = []


def _ref_violations():
    """fake_obs 记录的 libobs 引用违规（over-release / 释放了借用引用）。

    拿不到就抛 —— 这个哨兵一旦静默降级成 no-op，「多 release 一次」这种在真 OBS 里
    表现为随机崩溃的 bug 就会大摇大摆过掉全部测试。
    """
    m = sys.modules.get("fake_obs")
    if m is None:
        import fake_obs as m  # noqa: F811
    fn = getattr(m, "take_violations", None)
    if fn is None:
        raise RuntimeError("fake_obs.take_violations 不见了：引用纪律哨兵失效，先修 harness")
    return fn()


def check(name, cond, extra=""):
    _v = _ref_violations()
    if _v:
        cond = False
        extra = ((extra or "") + " | libobs 引用违规: " + "; ".join(_v[:2])).strip(" |")
    if cond:
        PASSED.append(name)
        print("  ok   %s" % name)
    else:
        FAILED.append("%s :: %s" % (name, extra))
        print("  FAIL %s :: %s" % (name, extra))


def run(*args, **kw):
    env = dict(os.environ)
    env.update(kw.pop("env", {}))
    inp = kw.pop("input", None)
    t0 = time.time()
    p = subprocess.run(CLI + list(args), capture_output=True, text=True, timeout=kw.pop("timeout", 30), env=env, input=inp)
    return p.returncode, p.stdout, p.stderr, round(time.time() - t0, 2)


def jout(stdout):
    try:
        return json.loads(stdout)
    except ValueError:
        return None


def main():
    R.build_world()
    R.start_script()
    info = json.load(open(os.path.join(os.environ["OBS_NEXUS_DIR"], "connection.json"), encoding="utf-8"))
    tok = info["token"]

    print("\n[A] 发现 / 元信息")
    code, so, se, dt = run("--discover", "--compact")
    d = jout(so)
    check("--discover 退出码 0 且带快照", code == 0 and isinstance(d, dict) and d.get("ok") is True and d["obs_pid_alive"] is True, "%s %s" % (so[:200], se[:200]))
    check("--discover 不泄露 token", "token" not in so, so[:200])
    code, so, se, _ = run("--capabilities", "--compact")
    d = jout(so)
    check("--capabilities 列出 op 表", code == 0 and isinstance(d, dict) and "text.set" in [o.get("op") for o in d.get("ops", [])] and d.get("limits"), so[:160])
    code, so, se, _ = run("--ping", "--compact")
    d = jout(so)
    check("--ping 给出两段延迟", code == 0 and d["transport_rtt_ms"] >= 0 and d["op_roundtrip_ms"] > 0, so[:200])

    print("\n[B] 单 op / 参数拼装")
    code, so, se, _ = run("--op", "system.overview", "--data-only", "--compact")
    d = jout(so)
    check("--data-only 只回 data", code == 0 and d and d.get("active_scene") == "场景 A", so[:200])
    code, so, se, _ = run("--op", "text.set", "--set", "source=字幕", "--set", "text=客户端写入", "--compact")
    d = jout(so)
    check("--set 传参生效", code == 0 and R.W.sources["字幕"].settings.d.get("text") == "客户端写入", so[:200])
    code, so, se, _ = run("--op", "text.set", "--json", '{"source":"字幕","text":"来自 --json"}', "--data-only", "--compact")
    check("--json 传参生效", code == 0 and R.W.sources["字幕"].settings.d.get("text") == "来自 --json", so[:200])
    code, so, se, _ = run("--op", "source.visibility", "--set", "source=贴图", "--set", "visible=false", "--data-only", "--compact")
    d = jout(so)
    item = [i for i in R.W.sources["场景 A"].scene_items if i.source.name == "贴图"][0]
    check("--set 布尔按 JSON 解析", code == 0 and d.get("visible") is False and item.visible is False, "%s %s" % (so[:200], item.visible))
    code, so, se, _ = run("--op", "source.visibility", "--set", "source=贴图", "--set", "toggle=true", "--data-only", "--compact")
    check("--set 值 true 也被解析成布尔", code == 0 and item.visible is True, so[:200])
    code, so, se, _ = run("--op", "audio.status", "--compact")
    d = jout(so)
    check("op 报错时退出码 1", code == 1 and d["error"]["code"] == "INVALID_PARAMS", "%s %s" % (code, so[:200]))
    code, so, se, _ = run("--op", "text.sEt", "--set", "source=字幕", "--compact")
    check("未知 op 给 UNKNOWN_OP + 建议", code == 1 and jout(so)["error"]["code"] == "UNKNOWN_OP", so[:200])

    print("\n[C] 批量")
    batch = json.dumps(
        [
            {"op": "scene.switch", "scene": "场景 B"},
            {"op": "text.set", "source": "字幕", "text": "批量里的一步"},
            {"op": "audio.status"},
            {"op": "source.visibility", "source": "贴图", "toggle": True},
        ],
        ensure_ascii=False,
    )
    code, so, se, _ = run("--batch", batch, "--compact")
    d = jout(so)
    check("批量默认遇错停止", code == 1 and d["batch"]["aborted"] is True and d["batch"]["executed"] == 3 and d["results"][3].get("skipped"), json.dumps(d.get("batch"))[:200])
    code, so, se, _ = run("--batch", batch, "--continue-on-error", "--compact")
    d = jout(so)
    check("--continue-on-error 跑完全部", code == 1 and d["batch"]["executed"] == 4 and d["batch"]["aborted"] is False, json.dumps(d.get("batch"))[:200])
    with open("/tmp/_batch.json", "w", encoding="utf-8") as fh:
        fh.write(batch)
    code, so, se, _ = run("--batch-file", "/tmp/_batch.json", "--continue-on-error", "--data-only", "--compact")
    d = jout(so)
    check("--batch-file 可读", code == 1 and len(d["results"]) == 4, so[:200])

    print("\n[D] 截图落盘")
    out_path = "/tmp/_snap.jpg"
    if os.path.exists(out_path):
        os.unlink(out_path)
    code, so, se, _ = run("--op", "canvas.snapshot", "--json", '{"format":"png"}', "--snapshot-out", out_path, "--compact")
    d = jout(so)
    ok = code == 0 and os.path.isfile(out_path) and os.path.getsize(out_path) > 100
    check("截图写进文件且输出里不含 base64", ok and "image_data" not in so, "%s %s size=%s" % (code, so[:200], os.path.getsize(out_path) if os.path.exists(out_path) else "-"))
    check("输出里保留元信息", bool(d) and (d.get("result") or {}).get("data", {}).get("path"), so[:200])
    code, so, se, _ = run("--op", "canvas.snapshot", "--json", '{"format":"png"}', "--keep-inline-image", "--compact")
    check("--keep-inline-image 保留 base64", code == 0 and "image_data" in so)

    print("\n[E] 事件")
    def delayed_switch(delay):
        import fake_obs

        time.sleep(delay)
        fake_obs.obs_frontend_set_current_scene(R.W.scenes[1])
        time.sleep(0.2)
        fake_obs.obs_frontend_set_current_scene(R.W.scenes[0])

    import threading

    t = threading.Thread(target=delayed_switch, args=(0.9,), daemon=True)
    t.start()
    code, so, se, _ = run("--wait-event", "scene.changed", "--events", "scene.changed", "--timeout", "6", "--compact", timeout=20)
    d = jout(so)
    check("--wait-event 抓到事件", code == 0 and isinstance(d, dict) and d.get("event") == "scene.changed", "%s %s %s" % (code, so[:200], se[:200]))
    t.join(3)
    code, so, se, _ = run("--wait-event", "no.such.event", "--timeout", "1.2", "--compact", timeout=20)
    check("等不到事件退出码 2", code == 2 and "没等到" in (se or ""), "%s %s" % (code, se[:160]))

    print("\n[F] 管道模式 --ndjson")
    lines = "\n".join(
        [
            json.dumps({"id": "1", "op": "system.ping"}),
            json.dumps({"id": "2", "op": "text.set", "source": "字幕", "text": "管道"}),
            "这不是 JSON",
            json.dumps({"id": "3", "op": "audio.status"}),
        ]
    )
    code, so, se, _ = run("--ndjson", "--data-only", input=lines + "\n")
    rows = [json.loads(x) for x in so.strip().splitlines() if x.strip()]
    check("--ndjson 每行一个响应", code == 1 and len(rows) == 4, "%s %s" % (code, so[:240]))
    check("--ndjson 正常行返回 data", isinstance(rows[1], dict) and rows[1].get("text") == "管道", json.dumps(rows[1])[:160])
    check("--ndjson 坏 JSON 不中断后续", isinstance(rows[2], dict) and "bad_json" in json.dumps(rows[2]) and isinstance(rows[3], dict) and rows[3].get("error", {}).get("code") == "INVALID_PARAMS", json.dumps(rows[2:4])[:240])

    print("\n[G] 配置 / 故障路径")
    code, so, se, _ = run("--port", str(int(info["port"]) + 1), "--op", "system.ping", "--timeout", "2", "--compact")
    check("端口错 → 退出码 2", code == 2 and "连不上" in (se or ""), "%s %s" % (code, se[:200]))
    code, so, se, _ = run("--token", "deadbeef", "--op", "system.ping", "--compact")
    check("token 错 → 退出码 3", code == 3 and "token" in (se or "").lower(), "%s %s" % (code, se[:200]))
    bogus = {"host": "127.0.0.1", "port": 1, "token": None, "pid": 999999, "obs_version": "0"}
    os.makedirs("/tmp/_nexus_bogus", exist_ok=True)
    with open("/tmp/_nexus_bogus/connection.json", "w", encoding="utf-8") as fh:
        json.dump(bogus, fh)
    code, so, se, _ = run("--conn-file", "/tmp/_nexus_bogus/connection.json", "--op", "system.ping", "--compact")
    check("pid 陈旧 → 退出码 3 且提示", code == 3 and "陈旧" in (se or ""), "%s %s" % (code, se[:220]))
    code, so, se, _ = run("--conn-file", "/tmp/_nexus_bogus/nope.json", "--op", "system.ping", "--compact")
    check("连接文件缺失 → 退出码 3", code == 3 and "找不到" in (se or ""), "%s %s" % (code, se[:200]))
    code, so, se, _ = run("--op", "system.ping", "--json", "{oops", "--compact")
    check("--json 语法错 → 退出码 3 + 人话", code == 3 and "JSON" in (so + se), "%s %s" % (code, (so + se)[:200]))
    code, so, se, _ = run("--compact")
    check("什么都不给 → 打帮助 + 退出码 3", code == 3 and "usage" in (so + se).lower(), "%s %s" % (code, (so + se)[:120]))
    code, so, se, _ = run("--op", "system.ping", "--ping", "--compact")
    check("同时给两个模式被拒", code == 3, "%s %s" % (code, (so + se)[:160]))

    print("\n[H] 大结果 / 慢请求不炸")
    code, so, se, _ = run("--op", "source.list", "--set", "scene=场景 A", "--set", "detailed=true", "--set", "limit=400", "--data-only", "--compact")
    d = jout(so)
    check(
        "--data-only 大列表正常且退出码为 0",
        code == 0 and isinstance(d, dict) and d.get("total") == 5 and any(x.get("transform") for x in d["sources"]),
        "%s %s" % (code, so[:200]),
    )
    code, so, se, dt = run("--op", "system.overview", "--timeout", "0.35", "--compact")
    check("超时给明确错误码", code in (0, 2) and (code == 0 or "超时" in se), "%s %s %.2fs" % (code, se[:160], dt))
    big = {"op": "text.set", "source": "字幕", "text": "x" * 2_000_000}
    with open("/tmp/_big.json", "w", encoding="utf-8") as fh:
        json.dump(big, fh, ensure_ascii=False)
    code, so, se, _ = run("--op", "text.set", "--json-file", "/tmp/_big.json", "--compact")
    check("超长请求本地就拦下", code == 3 and "超过上限" in (so + se), "%s %s" % (code, (so + se)[:200]))

    print("\n[I] 多进程并发（4 个客户端同时改 OBS）")
    procs = []
    for i in range(4):
        procs.append(subprocess.Popen(CLI + ["--batch", json.dumps([{"op": "text.set", "source": "字幕", "text": "并发%d" % i}] * 20, ensure_ascii=False), "--continue-on-error", "--compact"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True))
    outs = [p.communicate(timeout=40) for p in procs]
    codes = [p.returncode for p in procs]
    ok_all = all(c == 0 for c in codes)
    check("4 个并发客户端全部成功", ok_all, "codes=%s %s" % (codes, outs[0][0][:150] if outs else ""))
    snap = obs_nexus.AUDIT.snapshot()
    check("并发后引用零泄漏", snap["outstanding"] == 0 and snap["double_release"] == 0, json.dumps(snap)[:200])

    print("\n[J] --raw 逃生口")
    code, so, se, _ = run("--raw", '{"t":"ping"}', "--compact")
    d = jout(so)
    check("--raw 能发非 op 帧（pong）且退出码 0", code == 0 and isinstance(d, dict) and d.get("type") == "pong", "%s %s" % (code, (so + se)[:200]))
    code, so, se, _ = run("--raw", '{"id":"keep-me","op":"nope"}', "--compact")
    d = jout(so)
    check("--raw 保留调用方自己给的 id", code == 1 and isinstance(d, dict) and d.get("request_id") == "keep-me", "%s %s" % (code, so[:220]))
    code, so, se, _ = run("--raw", "{oops", "--compact")
    check("--raw 坏 JSON → 退出码 3 + bad_json", code == 3 and "bad_json" in (so + se), "%s %s" % (code, (so + se)[:160]))
    code, so, se, _ = run("--raw", '"字符串不是对象"', "--compact")
    check("--raw 顶层不是对象 → 退出码 3", code == 3 and "对象" in (so + se), "%s %s" % (code, (so + se)[:160]))

    print("\n---- agent_client 结果 ----")
    print("通过 %d，失败 %d" % (len(PASSED), len(FAILED)))
    for f in FAILED:
        print("  ✗ " + f)
    R.MAIN.stop = True
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
