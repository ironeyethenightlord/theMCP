# -*- coding: utf-8 -*-
"""tests/fake_obs.py —— 供离线回归测试使用的 obspython 桩。

它不是「mock 掉逻辑」，而是**复刻 libobs 的关键语义**，用来真正跑通
obs_nexus.py 的代码路径：
  * 引用计数：get/find/create 返回新引用，release 归还；泄漏会被断言抓住
  * obs_scene_enum_items / obs_frontend_get_scenes 的**回调式** API
  * obs_frontend_source_list_free 会 release 列表持有的引用
  * 主线程限定（timer 回调）+ 前端事件 + 录制/推流状态机 + 截图落盘
测试通过 sys.modules["obspython"] = fake 注入到脚本里。
"""

import os
import threading
import time

LOG_DEBUG, LOG_INFO, LOG_WARNING, LOG_ERROR = 0, 1, 2, 3
OBS_DEBUG, OBS_INFO, OBS_WARNING, OBS_ERROR = 0, 1, 2, 3
OBS_SOURCE_VIDEO, OBS_SOURCE_AUDIO, OBS_SOURCE_COMPOSITE, OBS_SOURCE_ASYNC = 1, 2, 4, 8
OBS_SOURCE_TYPE_INPUT, OBS_SOURCE_TYPE_FILTER, OBS_SOURCE_TYPE_TRANSITION = 0, 1, 2
OBS_FRONTEND_SOURCE_FLAG_FILTER_ONLY = 1
OBS_FRONTEND_SOURCE_FLAG_UNFILTERED = 2
OBS_FRONTEND_SOURCE_FLAG_AUDIO = 4
OBS_FRONTEND_SOURCE_FLAG_GLOBAL = 8
OBS_ORDER_MOVE_TOP, OBS_ORDER_MOVE_BOTTOM, OBS_ORDER_MOVE_UP, OBS_ORDER_MOVE_DOWN = 0, 1, 2, 3
OBS_ORDER_VISUAL_TOP, OBS_ORDER_INPUT_BOTTOM = 0, 1
OBS_COMBO_TYPE_LIST, OBS_COMBO_TYPE_EDITABLE = 0, 1
OBS_COMBO_FORMAT_STRING, OBS_COMBO_FORMAT_INT = 0, 1
OBS_PROPERTY_TEXT, OBS_PROPERTY_PATH = 0, 15
OBS_FRONTEND_EVENT_SCENE_CHANGED = 0
OBS_FRONTEND_EVENT_SCENE_LIST_CHANGED = 1
OBS_FRONTEND_EVENT_TRANSITION_CHANGED = 2
OBS_FRONTEND_EVENT_PROFILE_CHANGED = 6
OBS_FRONTEND_EVENT_STREAMING_STARTING = 9
OBS_FRONTEND_EVENT_STREAMING_STARTED = 10
OBS_FRONTEND_EVENT_STREAMING_STOPPING = 11
OBS_FRONTEND_EVENT_STREAMING_STOPPED = 12
OBS_FRONTEND_EVENT_RECORDING_STARTING = 13
OBS_FRONTEND_EVENT_RECORDING_STARTED = 14
OBS_FRONTEND_EVENT_RECORDING_STOPPING = 15
OBS_FRONTEND_EVENT_RECORDING_STOPPED = 16
OBS_FRONTEND_EVENT_RECORDING_PAUSED = 17
OBS_FRONTEND_EVENT_RECORDING_UNPAUSED = 18
OBS_FRONTEND_EVENT_OBS_SHUTDOWN = 8
OBS_FRONTEND_EVENT_EXIT = 20
OBS_FRONTEND_EVENT_FINISHED_LOADING = 19


class ObsError(Exception):
    pass


class Obj(object):
    """带引用计数的 OBS 对象基类（Scene/Source/SceneItem/Encoder/Data）。"""

    def __init__(self, kind, owner_refs=1):
        object.__setattr__(self, "_kind", kind)
        # owner_refs：这个世界（场景表 / item 链表 / 滤镜表 / 输出）自己占了几份引用。
        # 函数若「返回新引用」，实现里要先 _acquire()；脚本 release 之后应回到 owner_refs。
        object.__setattr__(self, "_owner_refs", owner_refs)
        # owner_refs=0 = 「创建者独占」的对象（obs_data_create / *_create_private）：
        # 创建时就带着调用者那一份引用，脚本 release 之后归零是**正常析构**，不是违规。
        object.__setattr__(self, "_refs", owner_refs or 1)
        object.__setattr__(self, "_alive", True)

    def _acquire(self):
        object.__setattr__(self, "_refs", self._refs + 1)
        return self

    def _release(self):
        n = self._refs - 1
        object.__setattr__(self, "_refs", n)
        base = object.__getattribute__(self, "_owner_refs")
        if n <= 0:
            # 真实 OBS 里这一刻对象就被 free 了：任何后续访问都是 use-after-free。
            object.__setattr__(self, "_alive", False)
        if n < base:
            try:
                label = object.__getattribute__(self, "name") or id(self)
            except AttributeError:
                label = id(self)
            kind = object.__getattribute__(self, "_kind")
            import traceback as _tb

            frames = [l.strip() for l in _tb.format_stack() if "fake_obs.py" not in l][-3:]
            W.violations.append(
                "over-release: %s %r refs=%d < 所有者基线 %d（多 release / 释放了借用引用）\n      调用栈: %s"
                % (kind, label, n, base, " <- ".join(f.split("File ")[-1].replace('", line ', ':') for f in frames))
            )
        return n

    def __getattribute__(self, name):
        # release 归零之后再访问 = 真实 OBS 里的段错误，这里换成显式异常（注意不能用 getattr，
        # 否则 __getattribute__ 自己会递归）
        if name[:1] == "_":
            return object.__getattribute__(self, name)
        try:
            alive = object.__getattribute__(self, "_alive")
        except AttributeError:
            return object.__getattribute__(self, name)
        if alive is False:
            def _peek(attr, default=None):
                try:
                    return object.__getattribute__(self, attr)
                except AttributeError:
                    return default

            raise ObsError(
                "use-after-free: %s(%r) 已被 release 归零后仍被访问（多 release / 释放了借用的引用）"
                % (_peek("_kind", "?"), _peek("name", id(self)))
            )
        return object.__getattribute__(self, name)


class FakeData(Obj):
    def __init__(self, initial=None, owner_refs=1):
        Obj.__init__(self, "data", owner_refs)
        object.__setattr__(self, "d", dict(initial or {}))
        object.__setattr__(self, "_keys", list(self.d.keys()))
        object.__setattr__(self, "_i", -1)

    def _sync(self):
        for k in list(self.d.keys()):
            if k not in self._keys:
                self._keys.append(k)


class FakeSource(Obj):
    def __init__(self, name, sid="text_gdiplus_v2", flags=OBS_SOURCE_VIDEO, settings=None):
        Obj.__init__(self, "source")
        self.name = name
        self.sid = sid
        self.unversioned = sid.replace("_v2", "").replace("_v3", "")
        self.flags = flags
        self.settings = FakeData(settings or {})
        self.private = FakeData({})
        self.muted = False
        self.volume = 1.0
        self.sync = 0.0
        self.monitoring = 0
        self.channel = 2
        self.width = 1920
        self.height = 1080
        self.filters = {}
        self.removed = False
        self.type = OBS_SOURCE_TYPE_INPUT
        self.scene_items = None
        self._kind_scene = False

    def as_scene(self):
        self._kind_scene = True
        self.scene_items = []
        return self


class FakeSceneItem(Obj):
    _ids = iter(range(1000, 99999))

    def __init__(self, source):
        Obj.__init__(self, "sceneitem")
        self.source = source
        self.visible = True
        self.selected = False
        self.id = next(FakeSceneItem._ids)
        self.info = {
            "pos": (0.0, 0.0),
            "scale": (1.0, 1.0),
            "alignment": (0.0, 0.0),
            "bounds": (0.0, 0.0),
            "rot": 0.0,
            "bounds_type": 0,
            "bounds_alignment": 0,
            "bounds_flags": 0,
            "cropped": False,
            "crop_left": 0,
            "crop_right": 0,
            "crop_top": 0,
            "crop_bottom": 0,
        }
        self.group_scene = None  # FakeSource(scene)


class FakeInfo(object):
    class V(object):
        def __init__(self, t):
            self.x = t[0]
            self.y = t[1]

    def __init__(self, src_info=None):
        self._d = dict(src_info or {})
        self.pos = self.V(self._d.get("pos", (0.0, 0.0)))
        self.scale = self.V(self._d.get("scale", (1.0, 1.0)))
        self.alignment = self.V(self._d.get("alignment", (0.0, 0.0)))
        self.bounds = self.V(self._d.get("bounds", (0.0, 0.0)))
        self.rot = self._d.get("rot", 0.0)
        self.bounds_type = self._d.get("bounds_type", 0)
        self.bounds_alignment = self._d.get("bounds_alignment", 0)
        self.bounds_flags = self._d.get("bounds_flags", 0)
        self.cropped = self._d.get("cropped", False)
        self.crop_left = self._d.get("crop_left", 0)
        self.crop_right = self._d.get("crop_right", 0)
        self.crop_top = self._d.get("crop_top", 0)
        self.crop_bottom = self._d.get("crop_bottom", 0)

    def snapshot(self):
        return {
            "pos": (float(self.pos.x), float(self.pos.y)),
            "scale": (float(self.scale.x), float(self.scale.y)),
            "alignment": (float(self.alignment.x), float(self.alignment.y)),
            "bounds": (float(self.bounds.x), float(self.bounds.y)),
            "rot": float(self.rot),
            "bounds_type": int(self.bounds_type),
            "bounds_alignment": int(self.bounds_alignment),
            "bounds_flags": int(self.bounds_flags),
            "cropped": bool(self.cropped),
            "crop_left": int(self.crop_left),
            "crop_right": int(self.crop_right),
            "crop_top": int(self.crop_top),
            "crop_bottom": int(self.crop_bottom),
        }


class FakeSourceList(object):
    def __init__(self):
        self._list = []

    def get_sources(self):
        return list(self._list)

    def release(self):
        for s in self._list:
            s._release()
        del self._list[:]


class FakeProps(object):
    def __init__(self):
        self.items = []

    def add(self, kind, id_, desc):
        p = FakeProp(kind, id_, desc)
        self.items.append(p)
        return p


class FakeProp(object):
    def __init__(self, kind, id_, desc):
        self.kind = kind
        self.id = id_
        self.desc = desc
        self.list_items = []
        self.long_desc = None
        self.enabled = True

    def list_add_string(self, name, value):
        self.list_items.append((name, value))
        return True


class FakeOutput(Obj):
    """推流/录制输出：mixer 0..5 各挂一个音频编码器（可能多个串联，用 next_enc 表示）。"""

    def __init__(self, name, world_flag):
        Obj.__init__(self, "output")
        self.name = name
        self.world_flag = world_flag  # 指向 W.stream / W.rec 的字典
        self.audio = {}
        self.video = None

    def active_flag(self):
        return bool(self.world_flag.get("active"))

    def get_flags(self):
        return 0


class FakeEncoder(Obj):
    def __init__(self, idx, name, bitrate, track):
        Obj.__init__(self, "encoder")
        self.idx = idx
        self.name = name
        self.bitrate = bitrate
        self.track = track
        self.next_enc = None


class FakeWorld(object):
    def __init__(self):
        self.lock = threading.RLock()
        self.reset()

    def reset(self):
        self.sources = {}
        self.scenes = []
        self.current = None
        self.preview = None
        self.timers = []
        self.event_cbs = []
        self.log = []
        self.logs = {}
        self.violations = []
        # 「借用 → 自有」必须显式 addref；这两个计数器用来断言脚本真的加过引用
        # （只靠「不 release」也能让引用数不掉，但那是错的：跨回调/跨 op 持有必须自己持有引用）
        self.sceneitem_addref_calls = 0
        self.scene_get_ref_calls = 0
        self.stream = {"active": False, "pending": False, "stopping": False}
        self.rec = {"active": False, "paused": False, "path": "/tmp/rec/obs-001.mkv"}
        self.vcam = {"active": False}
        self.replay = {"active": False}
        self.transition_ms = 300
        self.screenshot_dir = None
        self.last_shot = None
        self.screenshot_delay = 0.0
        self.screenshot_fail = False
        self.version = "32.2.2"
        self.base_refs = None
        self.ticks = 0
        self.properties_created = 0
        self.outputs = {"stream": FakeOutput("stream_output", self.stream), "rec": FakeOutput("record_output", self.rec)}
        # 典型 OBS 配置：推流用音轨 1（桌面）+ 音轨 2（麦克），每轨一个 AAC 编码器
        for mix, (nm, kbps) in enumerate((("ACC_aac", 160), ("Mic_AAC", 128))):
            enc = FakeEncoder(mix, nm, kbps, mix)
            self.outputs["stream"].audio[mix] = enc
        self.applied_settings = []
        self.global_sources = {}

    # ---------------- 构造辅助 ----------------
    def add_source(self, name, sid="image_source", flags=OBS_SOURCE_VIDEO, settings=None):
        s = FakeSource(name, sid, flags, settings)
        self.sources[name] = s
        return s

    def add_scene(self, name, current=False):
        s = FakeSource(name, "scene", OBS_SOURCE_VIDEO | OBS_SOURCE_COMPOSITE).as_scene()
        self.sources[name] = s
        self.scenes.append(s)
        if current or self.current is None:
            self.current = s
        return s

    def add_item(self, scene_name, source_name, sid="image_source", flags=OBS_SOURCE_VIDEO, settings=None, visible=True):
        scene = self.sources[scene_name]
        src = self.add_source(source_name, sid, flags, settings)
        item = FakeSceneItem(src)
        item.visible = visible
        scene.scene_items.append(item)
        return item

    def make_group(self, scene_name, group_name, child_names):
        g = self.add_source(group_name, "group", OBS_SOURCE_VIDEO | OBS_SOURCE_COMPOSITE)
        gs = FakeSource(group_name + "_scene", "scene", OBS_SOURCE_VIDEO).as_scene()
        g.scene_items = gs.scene_items
        item = FakeSceneItem(g)
        item.group_scene = gs
        self.sources[scene_name].scene_items.append(item)
        for cn in child_names:
            child = self.add_source(cn, "image_source", OBS_SOURCE_VIDEO)
            ci = FakeSceneItem(child)
            gs.scene_items.append(ci)
        return item

    # ---------------- 测试辅助 ----------------
    def tick(self, times=1, interval=0.01):
        """模拟 OBS 主线程定时器：手动驱动 timer_add 注册的回调。"""
        for _ in range(times):
            self.ticks += 1
            for cb in list(self.timers):
                cb(interval)

    def tick_until(self, predicate, timeout=2.0, interval=0.01):
        t0 = time.time()
        while time.time() - t0 < timeout:
            self.tick(1, interval)
            time.sleep(interval)
            if predicate():
                return True
        return False

    def outstanding_refs(self):
        n = 0
        for obj in list(self.sources.values()):
            n += max(0, obj._refs - 1)
        for s in list(self.all_objs()):
            n += max(0, s._refs - (1 if s in self.sources.values() else 0))
        return n

    def all_objs(self):
        seen = []
        for s in list(self.sources.values()):
            seen.append(s)
            for item in (s.scene_items or []):
                seen.append(item)
                if item.group_scene is not None:
                    for gi in item.group_scene.scene_items:
                        seen.append(gi)
                        seen.append(gi.source)
        return seen

    def leaked(self):
        """返回 refcount 高于基线的对象（= 脚本拿了没还）。"""
        out = []
        for o in self.all_objs():
            base = 1
            if o._refs > base:
                out.append((getattr(o, "_kind", "?"), getattr(o, "name", None) or id(o), o._refs - base))
        return out

    def screenshot_count(self):
        return len(self.logs.get("screenshot", []))


W = FakeWorld()


def take_violations():
    """取走并清空「libobs 引用纪律」违规记录（over-release / 释放了借用引用）。

    fake 只能记账，测试必须查账：三个 suite 的 check() 每次都调它，一旦有
    「多 release」就当场失败。真机上这种情况不是泄漏，是 use-after-free 崩溃。
    """
    out = list(W.violations)
    del W.violations[:]
    return out


def _reset():
    W.reset()
    W.screenshot_dir = os.environ.get("FAKE_SNAP_DIR") or os.getcwd()


# ============================ 定时器 / 日志 ==============================
def timer_add(cb, ms):
    if cb not in W.timers:
        W.timers.append(cb)


def timer_remove(cb):
    if cb in W.timers:
        W.timers.remove(cb)


def script_log(level, msg):
    W.log.append((level, msg))


def script_get_path():
    return os.path.abspath(__file__)


def script_get_data_path(rel):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), rel or "")


# =============================== 版本 ====================================
def obs_frontend_get_version():
    return W.version


def obs_get_version_string():
    return W.version


def obs_get_version():
    major, minor, patch = [int(x) for x in W.version.split(".")[:3]]
    return (major << 16) | (minor << 8) | patch


def obs_get_locale():
    return "zh-CN"


# ============================== 源 / 场景 ================================
def obs_get_source_by_name(name):
    for s in list(W.sources.values()):
        if s.name == name and not getattr(s, "removed", False):
            return s._acquire()
    return None


def obs_source_get_name(src):
    return getattr(src, "name", "")


def obs_source_set_name(src, name):
    old = src.name
    src.name = name
    W.sources.pop(old, None)
    W.sources[name] = src


def obs_source_get_id(src):
    return getattr(src, "sid", "")


def obs_source_get_unversioned_id(src):
    return getattr(src, "unversioned", "")


def obs_source_get_type(src):
    return getattr(src, "type", OBS_SOURCE_TYPE_INPUT)


def obs_source_get_width(src):
    return getattr(src, "width", 0)


def obs_source_get_height(src):
    return getattr(src, "height", 0)


def obs_source_get_output_flags(src):
    return getattr(src, "flags", 0)


def obs_source_get_icon():
    return None


def obs_source_release(src):
    if src is not None:
        src._release()


def obs_source_addref(src):
    if src is not None:
        src._acquire()


def obs_source_get_ref(src):
    return src._acquire() if src is not None else None


def obs_source_muted(src):
    return src.muted


def obs_source_set_muted(src, m):
    src.muted = bool(m)


def obs_source_get_volume(src):
    return src.volume


def obs_source_set_volume(src, v):
    src.volume = float(v)


def obs_source_get_audio_sync(src):
    return src.sync


def obs_source_set_audio_sync(src, v):
    src.sync = float(v)


def obs_source_get_monitoring_type(src):
    return src.monitoring


def obs_source_get_channel(src):
    return src.channel


def obs_source_push_to_mute_enabled(src):
    return False


def obs_source_get_settings(src):
    # 真 libobs 是对 source->settings 加引用后返回；fake 用「调用者独占的拷贝」近似，
    # 关键是让「脚本必须 release」这件事可被计数验证（release 后归零 = 正常）。
    return FakeData(src.settings.d, owner_refs=0)


def obs_source_get_private_settings(src):
    return src.private._acquire()


def obs_source_update(src, data):
    if not isinstance(data, FakeData):
        raise ObsError("obs_source_update: bad data")
    for k, v in data.d.items():
        src.settings.d[k] = v
    src.settings._sync()


def obs_source_update_properties(src):
    W.logs.setdefault("update_properties", []).append(src.name)


def obs_source_remove(src):
    """从场景集合里移除：之后按名字再也找不到，但对象仍可被已持有的引用访问。"""
    src.removed = True
    try:
        W.scenes.remove(src)
    except ValueError:
        pass


def obs_source_create(sid, name, settings, hotkey_data):
    if sid != "scene":
        raise ObsError("fake: 只支持创建 scene")
    s = FakeSource(name, "scene", OBS_SOURCE_VIDEO | OBS_SOURCE_COMPOSITE).as_scene()
    # 真实语义：obs_source_create 返回的对象此时**只有创建者**一份引用（owner_refs=0），
    # 要挂进前端场景列表必须 obs_frontend_add_source()，那才会再加一份。
    object.__setattr__(s, "_owner_refs", 0)
    W.sources[name] = s
    W.scenes.append(s)
    return s


def obs_source_create_private(sid, name, settings):
    src = FakeSource(name, sid, OBS_SOURCE_VIDEO, settings)
    object.__setattr__(src, "_owner_refs", 0)  # 不进全局表：调用者独占创建时那一份
    return src


def obs_source_get_filter_by_name(src, name):
    f = getattr(src, "filters", {}).get(name)
    return f._acquire() if f is not None else None


def obs_source_add_filter(src, name, sid, settings, rerender):
    f = FakeSource(name, sid, OBS_SOURCE_AUDIO)
    f.type = OBS_SOURCE_TYPE_FILTER
    src.filters[name] = f
    return f


# =============================== 场景 API ================================
def obs_scene_from_source(src):
    # 借用！libobs 里就是 `return source->context.data;`，要自己 obs_scene_get_ref 才持有引用
    if src is None or not getattr(src, "_kind_scene", False):
        return None
    return src


def obs_scene_get_ref(scene):
    """obs_scene_get_ref：只有底层 scene source 还活着才给引用（照抄 libobs 语义）。"""
    if scene is None:
        return None
    if not scene._alive:
        return None
    W.scene_get_ref_calls += 1
    return scene._acquire()


def obs_scene_get_source(scene):
    return scene


def obs_scene_create(sid):
    return FakeSource("Untitled", "scene", OBS_SOURCE_VIDEO).as_scene()


def obs_scene_release(scene):
    if scene is not None:
        scene._release()


def obs_scene_add(scene, src):
    item = FakeSceneItem(src)
    scene.scene_items.append(item)
    return item


def _scene_items(scene):
    return scene.scene_items or []


# 注意：这两个函数在 libobs 里是直接返回链表节点，**不加引用**（obs-scene.c
# 32.2.2: `return item;`），所以这里也必须返回借用指针 —— 谁 release 谁就是 bug。
def obs_scene_find_source(scene, name):
    for it in _scene_items(scene):
        if it.source.name == name:
            return it
    return None


def obs_scene_find_source_recursive(scene, name):
    for it in _scene_items(scene):
        if it.source.name == name:
            return it
        if it.group_scene is not None:
            for sub in _scene_items(it.group_scene):
                if sub.source.name == name:
                    return sub


def obs_scene_enum_items(scene, cb, param):
    # 与 libobs 一致：每个 item 回调前 addref、回调后 release；回调返回 False 提前结束同样 release。
    # 也就是说回调里拿到的是「借用的、但当场有效」的指针，想留到回调外必须自己 addref。
    items = list(_scene_items(scene))
    for it in items:
        it._acquire()
        keep = cb(scene, it, param)
        it._release()
        if not keep:
            break
    return True


def obs_sceneitem_get_scene(item):
    for sc in W.scenes:
        if item in _scene_items(sc):
            return sc
    return None


def obs_sceneitem_get_source(item):
    return item.source


def obs_sceneitem_get_id(item):
    return item.id


def obs_sceneitem_visible(item):
    return item.visible


def obs_sceneitem_set_visible(item, v):
    item.visible = bool(v)


def obs_sceneitem_selected(item):
    return item.selected


def obs_sceneitem_set_selected(item, v):
    item.selected = bool(v)


def obs_sceneitem_release(item):
    if item is not None:
        item._release()


def obs_sceneitem_addref(item):
    if item is not None:
        W.sceneitem_addref_calls += 1
        item._acquire()


def obs_sceneitem_get_order_position(item):
    for sc in W.scenes:
        items = _scene_items(sc)
        if item in items:
            return items.index(item)
    return -1


def obs_sceneitem_set_order(item, order):
    for sc in W.scenes:
        items = sc.scene_items
        if item in items:
            items.remove(item)
            if order == OBS_ORDER_MOVE_TOP:
                items.insert(0, item)
            elif order == OBS_ORDER_MOVE_BOTTOM:
                items.append(item)
            elif order == OBS_ORDER_MOVE_UP:
                items.insert(max(0, 0), item)
            else:
                items.insert(min(len(items), 1), item)
            return
    if item.group_scene is not None:
        items = item.group_scene.scene_items
        if item in items:
            items.remove(item)


def obs_sceneitem_is_group(item):
    return item.group_scene is not None


def obs_sceneitem_group_get_scene(item):
    return item.group_scene


def obs_sceneitem_group_count_items(item):
    return len(_scene_items(item.group_scene)) if item.group_scene else 0


def obs_sceneitem_info_create():
    return FakeInfo()


def obs_sceneitem_get_info(item, info):
    cur = FakeInfo(item.info)
    # 结构体是「按值拷贝进出」的：先把当前值灌给调用方对象
    for k in ("pos", "scale", "alignment", "bounds"):
        getattr(info, k).x, getattr(info, k).y = getattr(cur, k).x, getattr(cur, k).y
    for k in ("rot", "bounds_type", "bounds_alignment", "bounds_flags", "cropped"):
        setattr(info, k, getattr(cur, k))
    for k in ("crop_left", "crop_right", "crop_top", "crop_bottom"):
        setattr(info, k, getattr(cur, k))


def obs_sceneitem_set_info(item, info):
    if isinstance(info, FakeInfo):
        item.info = info.snapshot()


def obs_sceneitem_set_pos(item, pos):
    item.info["pos"] = (pos.x, pos.y)


def obs_sceneitem_set_rot(item, rot):
    item.info["rot"] = rot


# ============================== 前端 API ================================
def obs_frontend_get_scenes(out_list):
    for sc in W.scenes:
        out_list._list.append(sc._acquire())


def obs_frontend_source_list_create():
    return FakeSourceList()


def obs_frontend_source_list_free(lst):
    lst.release()


def obs_frontend_get_scene_names():
    return [sc.name for sc in W.scenes] + [None]


def obs_frontend_get_current_scene():
    return W.current._acquire() if W.current else None


def obs_frontend_set_current_scene(src):
    if src not in W.scenes:
        raise ObsError("set_current_scene: 不是场景")
    W.current = src
    _fire(OBS_FRONTEND_EVENT_SCENE_CHANGED)


def obs_frontend_get_current_preview_scene():
    return W.preview._acquire() if W.preview else None


def obs_frontend_set_current_preview_scene(src):
    W.preview = src


def obs_frontend_preview_program_mode_active():
    return False


def obs_frontend_get_transition_duration():
    return W.transition_ms


def obs_frontend_set_transition_duration(ms):
    W.transition_ms = int(ms)


def obs_frontend_add_event_callback(cb, data):
    W.event_cbs.append(cb)


def obs_frontend_remove_event_callback(cb, data):
    if cb in W.event_cbs:
        W.event_cbs.remove(cb)


def obs_frontend_add_source(src):
    """真实 OBS：前端会为列表自己持有一份引用（所以脚本 release 自己那份之后，
    源仍然活着）。fake 必须照做，否则「创建 + 登记 + 释放」这条链的引用账就对不上。"""
    W.sources[src.name] = src
    if getattr(src, "_kind_scene", False) and src not in W.scenes:
        W.scenes.append(src)
    src._acquire()


def obs_frontend_remove_source(name):
    src = W.sources.get(name)
    if src is not None:
        obs_source_remove(src)


def obs_frontend_get_stats():
    return "CPU: 4.1%%  内存: 512.0 MB  丢帧: 0/12000 (0.0%%)  FPS: 60.00"


def obs_frontend_get_current_record_output_path():
    return W.rec["path"]


def obs_frontend_get_last_screenshot():
    return W.last_shot


def _write_screenshot(src=None):
    if W.screenshot_fail:
        return None
    stamp = "%d-%06d" % (time.time(), int(time.time() * 1e6) % 1000000)
    name = "obs-screenshot-%s.png" % stamp
    path = os.path.join(W.screenshot_dir or os.getcwd(), name)
    w, h = (src.width, src.height) if src is not None else (1920, 1080)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # 最小合法 PNG（1x1 灰色），外加填充以满足尺寸差异测试
    png = bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4"
        "890000000a49444154789c6360000002000100ffff03000006000557bf1f6f0000"
        "000049454e44ae426082"
    )
    body = b""
    try:  # 尽量写成真正可解码的 PNG（体积也接近真实截图），否则退化成裸 PNG + 填充
        from io import BytesIO

        from PIL import Image

        buf = BytesIO()
        Image.new("RGBA", (8, 8), (12, 34, 56, 255)).save(buf, format="PNG")
        body = buf.getvalue()
    except Exception:
        body = png
    with open(path, "wb") as fh:
        fh.write(body)
        fh.write(b"\0" * 60000)  # 模拟 MB 级截图，用于验证字节上限
    W.last_shot = path
    W.logs.setdefault("screenshot", []).append(path)
    return path


def obs_frontend_take_screenshot():
    if W.screenshot_delay:
        t = W.screenshot_delay

        def later():
            time.sleep(t)
            _write_screenshot(None)

        threading.Thread(target=later, daemon=True).start()
        return None
    return _write_screenshot(None)


def obs_frontend_take_source_screenshot(src):
    if W.screenshot_delay:
        t = W.screenshot_delay

        def later():
            time.sleep(t)
            _write_screenshot(src)

        threading.Thread(target=later, daemon=True).start()
        return None
    return _write_screenshot(src)


def obs_frontend_get_recordings_folder():
    return W.screenshot_dir or os.getcwd()


def obs_frontend_get_current_profile():
    return "测试配置文件"


def obs_frontend_get_current_scene_collection():
    return "nexus-test"


def _fire(ev):
    for cb in list(W.event_cbs):
        cb(ev, None)


def obs_frontend_streaming_start():
    if W.stream["active"] or W.stream["pending"]:
        return
    W.stream["pending"] = True
    _fire(OBS_FRONTEND_EVENT_STREAMING_STARTING)
    W.stream["pending"] = False
    W.stream["active"] = True
    _fire(OBS_FRONTEND_EVENT_STREAMING_STARTED)


def obs_frontend_streaming_stop():
    if not W.stream["active"]:
        return
    _fire(OBS_FRONTEND_EVENT_STREAMING_STOPPING)
    W.stream["active"] = False
    _fire(OBS_FRONTEND_EVENT_STREAMING_STOPPED)


def obs_frontend_streaming_active():
    return W.stream["active"]


def obs_frontend_streaming_pending():
    return W.stream["pending"]


def obs_frontend_streaming_stopping():
    return W.stream["stopping"]


def obs_frontend_recording_start():
    W.rec["active"] = True
    W.rec["paused"] = False
    _fire(OBS_FRONTEND_EVENT_RECORDING_STARTED)


def obs_frontend_recording_stop():
    W.rec["active"] = False
    W.rec["paused"] = False
    _fire(OBS_FRONTEND_EVENT_RECORDING_STOPPED)


def obs_frontend_recording_active():
    return W.rec["active"]


def obs_frontend_recording_paused():
    return W.rec["paused"]


def obs_frontend_recording_pause(p):
    if not W.rec["active"]:
        raise ObsError("未在录制")
    W.rec["paused"] = bool(p)
    _fire(OBS_FRONTEND_EVENT_RECORDING_PAUSED if p else OBS_FRONTEND_EVENT_RECORDING_UNPAUSED)


def obs_frontend_recording_split_file():
    return W.rec["active"]


def obs_frontend_recording_add_chapter(name):
    return W.rec["active"]


def obs_frontend_start_virtualcam():
    W.vcam["active"] = True


def obs_frontend_stop_virtualcam():
    W.vcam["active"] = False


def obs_frontend_virtualcam_active():
    return W.vcam["active"]


def obs_frontend_replay_buffer_start():
    W.replay["active"] = True


def obs_frontend_replay_buffer_stop():
    W.replay["active"] = False


def obs_frontend_replay_buffer_active():
    return W.replay["active"]


def obs_frontend_replay_buffer_save():
    return None


def obs_frontend_get_global_sources(out_list, flags=0):
    for s in list(W.global_sources.values()):
        out_list._list.append(s._acquire())


def obs_enum_sources():
    return [s for s in list(W.sources.values()) if s.sid != "scene"]


def source_list_release(lst):
    for s in lst:
        s._release()


# =============================== 编码器 =================================
ENCODERS = {}


def obs_output_get_audio_encoder(output, mixer_index):
    """libobs 32.2.2（obs-output.c:1137）：`return output->audio_encoders[idx];`
    —— **借用**，不加引用；fake 严格照做（脚本侧多 release 一次就该被抓到）。"""
    if not isinstance(output, FakeOutput):
        raise ObsError("obs_output_get_audio_encoder: 第一个参数必须是 obs_output_t，收到 %r" % (output,))
    if int(mixer_index) >= 6:
        return None
    return output.audio.get(int(mixer_index))


def obs_output_get_video_encoder(output):
    if not isinstance(output, FakeOutput):
        raise ObsError("obs_output_get_video_encoder: 需要 obs_output_t")
    return output.video


def obs_output_get_name(output):
    return output.name


def obs_output_active(output):
    return output.active_flag()


def obs_output_release(output):
    if output is not None:
        output._release()


def obs_frontend_get_streaming_output():
    # 前端 API：返回**新引用**，用 obs_output_release 归还
    out = W.outputs["stream"]
    return out._acquire() if out.active_flag() else None


def obs_frontend_get_recording_output():
    out = W.outputs["rec"]
    return out._acquire() if out.active_flag() else None


def obs_encoder_get_name(enc):
    return enc.name


def obs_encoder_get_bitrate(enc):
    return enc.bitrate


def obs_encoder_active(enc):
    return True


def obs_audio_encoder_get_track(enc):
    return enc.track


def obs_encoder_release(enc):
    if enc is not None:
        enc._release()


# ================================ obs_data ==============================
def obs_data_create():
    # 调用者独占的引用：owner_refs=0，脚本 release 后归零属于正常析构
    return FakeData(owner_refs=0)


def obs_data_release(data):
    if data is not None:
        data._release()


def _check(data):
    if not isinstance(data, FakeData):
        raise ObsError("bad data object")


def obs_data_get_string(data, key):
    _check(data)
    v = data.d.get(key)
    if v is None:
        return ""
    return v if isinstance(v, str) else str(v)


def obs_data_set_string(data, key, value):
    _check(data)
    data.d[key] = value
    data._sync()


def obs_data_get_int(data, key):
    _check(data)
    v = data.d.get(key, 0)
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def obs_data_set_int(data, key, value):
    _check(data)
    data.d[key] = int(value)
    data._sync()


def obs_data_get_double(data, key):
    _check(data)
    v = data.d.get(key, 0.0)
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def obs_data_set_double(data, key, value):
    _check(data)
    data.d[key] = float(value)
    data._sync()


def obs_data_get_bool(data, key):
    _check(data)
    return bool(data.d.get(key, False))


def obs_data_set_bool(data, key, value):
    _check(data)
    data.d[key] = bool(value)
    data._sync()


def obs_data_get_obj(data, key):
    v = data.d.get(key)
    if isinstance(v, dict):
        return FakeData(v)._acquire()
    return None


def obs_data_set_obj(data, key, obj):
    data.d[key] = dict(obj.d) if isinstance(obj, FakeData) else obj
    data._sync()


_TYPE_CODES = {"null": 0, "string": 1, "number": 2, "boolean": 3, "array": 4, "object": 5}


def obs_data_get_item_type(data, key):
    _check(data)
    v = data.d.get(key)
    if v is None:
        return 0
    if isinstance(v, bool):
        return 3
    if isinstance(v, (int, float)):
        return 2
    if isinstance(v, str):
        return 1
    if isinstance(v, (list, tuple)):
        return 4
    if isinstance(v, dict):
        return 5
    return 1


def obs_data_first(data):
    _check(data)
    data._sync()
    if not data._keys:
        data._i = -1
        return False
    data._i = 0
    return data._keys[0] is not None


def obs_data_next(data):
    data._i += 1
    return data._i < len(data._keys)


def obs_data_get_key(data):
    try:
        return data._keys[data._i]
    except (IndexError, TypeError):
        return None


def obs_data_array_create():
    return FakeArray(owner_refs=0)


def obs_data_array_release(arr):
    if arr is not None:
        arr._release()


def obs_data_array_count(arr):
    return len(arr.items)


def obs_data_array_item(arr, i):
    try:
        v = arr.items[i]
    except IndexError:
        return None
    if isinstance(v, FakeData):
        return v._acquire()
    return FakeData({"value": v})._acquire()


def obs_data_array_push_back(arr, obj):
    arr.items.append(obj)


def obs_data_get_array(data, key):
    v = data.d.get(key) or []
    arr = FakeArray()
    arr.items = list(v) if isinstance(v, (list, tuple)) else []
    return arr


def obs_data_set_array(data, key, arr):
    data.d[key] = [x.d if isinstance(x, FakeData) else x for x in arr.items]
    data._sync()


class FakeArray(Obj):
    def __init__(self, owner_refs=1):
        Obj.__init__(self, "array", owner_refs)
        self.items = []


# ============================= 属性面板 API ==============================
def obs_properties_create():
    W.properties_created += 1
    return FakeProps()


def obs_properties_add_bool(props, id_, desc):
    return props.add("bool", id_, desc)


def obs_properties_add_int(props, id_, desc, minv, maxv, step):
    return props.add("int", id_, desc)


def obs_properties_add_float(props, id_, desc, minv, maxv, step):
    return props.add("float", id_, desc)


def obs_properties_add_text(props, id_, desc, type_):
    return props.add("text", id_, desc)


def obs_properties_add_path(props, id_, desc, type_, filters, default):
    return props.add("path", id_, desc)


def obs_properties_add_list(props, id_, desc, ctype, fmt):
    return props.add("list", id_, desc)


def obs_properties_add_button(props, id_, desc, cb):
    props.items.append(FakeProp("button", id_, desc))
    props.items[-1].callback = cb
    return props.items[-1]


def obs_property_list_add_string(prop, name, value):
    return prop.list_add_string(name, value)


def obs_property_set_long_description(prop, text):
    prop.long_desc = text


def obs_property_set_description(prop, text):
    prop.desc = text


def obs_property_set_enabled(prop, en):
    prop.enabled = bool(en)


def obs_properties_apply_settings(props, settings):
    W.applied_settings.append(len(props.items))


def obs_data_get_default_bool(data, key):
    return False


def obs_data_set_default_string(data, key, value):
    _check(data)
    data.d.setdefault(key, value)


def obs_data_set_default_int(data, key, value):
    _check(data)
    data.d.setdefault(key, int(value))


def obs_data_set_default_double(data, key, value):
    _check(data)
    data.d.setdefault(key, float(value))


def obs_data_set_default_bool(data, key, value):
    _check(data)
    data.d.setdefault(key, bool(value))


# ============================ 其他 libobs bits ==========================
def obs_startup(locale, path, config):
    return True


def obs_shutdown():
    return None


def obs_reset_video(si):
    return 0


def obs_reset_audio(ai):
    return True


def obs_frontend_get_main_window():
    return None


def obs_frontend_get_profiler_name():
    return None


def bfree(p):
    return None
