#!/usr/bin/env bash
# 一条命令跑完：拼装 + 静态检查 + 三套测试。
set -uo pipefail
cd "$(dirname "$0")"
fail=0
step() {
  echo
  echo "################ $* ################"
  if ! "$@"; then echo "!!! 失败: $*"; fail=1; fi
}
./build.sh
step python3 -u tests/run_tests.py
step python3 -u tests/run_client_tests.py
step python3 -u tests/run_examples_tests.py
echo
if [ "$fail" = 0 ]; then echo "==== 全部通过 ===="; else echo "==== 有检查失败（见上面 !!! 标记） ===="; fi
exit $fail
