# -*- coding: utf-8 -*-
# =============================================================================
#  OBS Nexus - Agent Control Runtime for OBS Studio 32.2+
# =============================================================================
#  单文件 OBS Python 脚本（obspython）。在 OBS 内建立一个只监听 127.0.0.1 的
#  Loopback TCP 服务端，外部大模型 / 自动化脚本可以用「一行一条 JSON」的协议
#  读写 OBS 的场景、源、文本、音频、推流/录制状态，并抓取画布截图。
#
#  设计红线（务必阅读，代码严格按照这三条实现）：
#    R1  任何 libobs 调用（场景切换、源属性修改、推流/录制控制、音频表）
#        只允许发生在 OBS 主线程。
#    R2  网络 I/O 全部在独立守护线程（selectors 事件循环）里完成，
#        该线程内绝不出现任何 obs.* 调用（连指针都不跨线程传递）。
#    R3  跨线程桥接只使用 OBS 原生定时器：
#          script_load() -> obs.timer_add(self._pump, 10)
#        主线程每 tick 轮询线程安全的 queue.Queue，并在同一 tick 内
#        通过 socketpair 唤醒工作线程，避免忙等。
#
#  内存安全：所有 *_get_*_by_name / obs_scene_get_source / obs_sceneitem_get
#  等「返回新引用」的调用，都在 obsrefs 上下文管理器里配对 release；
#  脚本还内置引用泄漏计数器（system.health 可见），OBS 关闭前会打印审计结果。
#
#  用法：OBS -> 工具 -> 脚本 -> 添加本文件 -> 在属性里点「写入连接文件」。
#  客户端：python agent_client.py --call system.overview
#
#  安全提示：本服务对已鉴权的客户端拥有「完全控制 OBS」的能力（advanced 模式
#  甚至可热重载脚本）。因此它只绑定回环地址、强制 Token 鉴权、带限流与
#  载荷上限。绝不要把它暴露到局域网或转发到公网。
#
#  License: MIT
#  Author : OBS Nexus (generated)
# =============================================================================

import base64
import errno
import hashlib
import hmac
import itertools
import json
import math
import os
import re
import selectors
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import traceback
from collections import deque
from queue import Empty, Full, Queue

try:  # OBS 32.x 内置 python 有 zoneinfo，用于日志时间戳
    from zoneinfo import ZoneInfo  # noqa: F401
except Exception:  # pragma: no cover
    ZoneInfo = None

# ---------------------------------------------------------------------------
# obspython 绑定：在 OBS 里叫 `obspython`（部分发行版/旧版叫 `obs`）
# 允许在普通 CPython 下导入本文件（配合 tests/fake_obs.py 做离线回归测试）。
# ---------------------------------------------------------------------------
try:
    import obspython as obs
except ImportError:  # pragma: no cover - 非 OBS 环境
    try:
        import obs
    except ImportError:
        obs = None

try:  # OBS 30+ 提供的版本模块（可选）
    import version as _obs_version_mod
except Exception:  # pragma: no cover
    _obs_version_mod = None

try:  # 可选依赖：仅用于把截图转成压缩 JPEG / 计算 mtime_ns
    from PIL import Image as _PILImage
except Exception:  # pragma: no cover
    _PILImage = None


NEXUS_VERSION = "1.0.0"
NEXUS_PROTO = 1
NEXUS_APP = "obs-nexus"

# --------------------------- 协议 / 资源上限 -------------------------------
MAX_LINE_BYTES = 1024 * 1024          # 单行 JSON 上限 1 MiB（含结尾 \n）
MAX_BATCH_OPS = 64                    # 单请求最大 op 数量
MAX_OPS_FOR_SIZE = 4096               # 超过此 op 数直接拒绝（防爆保护）
MAX_CONNECTIONS = 8                   # 最大并发连接（鉴权前同样计数）
MAX_CONN_LINES_PER_SEC = 200.0        # 每连接行速率上限
MAX_PUMP_JOBS = 64                    # 每 tick 最多处理的桥接任务数
MAX_PUMP_TICK_MS = 12.0               # 每 tick 主线程预算（超过则让位给下一 tick）
MAX_BATCH_EXEC_MS = 250.0             # 单个请求在主线程的执行预算（分片续跑）
MAX_RESULT_BYTES = 8 * 1024 * 1024    # 单条响应字节上限
MAX_SNAPSHOT_BYTES = 6 * 1024 * 1024  # 截图 base64 前的原始字节上限
OUTBOX_LIMIT = 64 * 1024 * 1024       # 每连接发送缓冲上限（背压）
CMD_QUEUE_DEPTH = 256                 # 待执行请求队列深度（过载保护）
CMD_QUEUE_HIGH = 192                  # 队列水位告警阈值
MAX_REQUEST_TIMEOUT_MS = 30000        # 客户端可指定的超时上限
DEFAULT_REQUEST_TIMEOUT_MS = 10000
IDLE_TIMEOUT_MS = 300000              # 空闲连接断开（5 分钟）
AUTH_TIMEOUT_MS = 10000               # 鉴权超时（10 秒）
DRAIN_WAIT_MS = 2000                  # 入站缓冲泄空时间（防丢包）
SCRIPT_TIMEOUT_MS = 60000             # OBS 脚本调用超时（默认 60s，必须小于它）
TIMER_INTERVAL_MS = 10                # 主线程泵周期（需求规定 timer_add(...,10)）
POLL_SLEEP_MS = 10                    # 主线程轮询等待的最小间隔（sleep(0) 会让 OBS 卡死）

# 主线程轮询 tick 预算表：活跃期密集，空闲期退避到 ~250ms 以省 CPU
TICK_BUDGET = (24, 24, 16, 12, 8, 4, 2, 1, 1, 1)

# ----------------------------- 安全默认值 ---------------------------------
DEFAULT_PORT = 0                      # 0 = 在 PORT_RANGE 内随机挑可用端口
PORT_RANGE = (45120, 45219)           # 随机端口优先落在这个区间（便于防火墙规则）
TOKEN_BYTES = 32                      # 32 字节随机 -> 64 位 hex
DIR_MODE = 0o700
FILE_MODE = 0o600
CONN_TTL_MS = 2000                    # connection.json 被认为过期的时间

# 只允许回环地址；任何 0.0.0.0 / 局域网 IP 都会被强制改写成 127.0.0.1
LOOPBACK_V4 = "127.0.0.1"
LOOPBACK_V6 = "::1"

# OBS 日志严重级（obspython 常量；离线测试时用手写值）
LOG_DEBUG = getattr(obs, "OBS_DEBUG", 0) if obs else 0
LOG_INFO = getattr(obs, "OBS_INFO", 1) if obs else 1
LOG_WARNING = getattr(obs, "OBS_WARNING", 2) if obs else 2
LOG_ERROR = getattr(obs, "OBS_ERROR", 3) if obs else 3

# obs_frontend_get_sources() 的 flags（枚举常量由 OBS 提供；缺省值对应
# OBS_FRONTEND_SOURCE_FLAG_FILTER_ONLY=1 / UNFILTERED=2 / AUDIO=4 / GLOBAL=8）
FLAG_FILTER_ONLY = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_FILTER_ONLY", 1) if obs else 1
FLAG_UNFILTERED = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_UNFILTERED", 2) if obs else 2
FLAG_AUDIO = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_AUDIO", 4) if obs else 4
FLAG_GLOBAL = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_GLOBAL", 8) if obs else 8

# obs_source_get_type()
SOURCE_TYPE_INPUT = getattr(obs, "OBS_SOURCE_TYPE_INPUT", 0) if obs else 0
SOURCE_TYPE_FILTER = getattr(obs, "OBS_SOURCE_TYPE_FILTER", 1) if obs else 1
SOURCE_TYPE_TRANSITION = getattr(obs, "OBS_SOURCE_TYPE_TRANSITION", 2) if obs else 2

# obs_source_get_output_flags()
OBS_SOURCE_VIDEO = getattr(obs, "OBS_SOURCE_VIDEO", 1) if obs else 1
OBS_SOURCE_AUDIO = getattr(obs, "OBS_SOURCE_AUDIO", 2) if obs else 2
OBS_SOURCE_COMPOSITE = getattr(obs, "OBS_SOURCE_COMPOSITE", 4) if obs else 4
OBS_SOURCE_ASYNC = getattr(obs, "OBS_SOURCE_ASYNC", 8) if obs else 8

# obs_sceneitem_get_order()
ORDER_VISUAL_TOP = getattr(obs, "OBS_ORDER_VISUAL_TOP", 0) if obs else 0
ORDER_INPUT_BOTTOM = getattr(obs, "OBS_ORDER_INPUT_BOTTOM", 1) if obs else 1

# 音频设备名国际化：用于把「麦克风/桌面音频」这类别名映射到真实源名
AUDIO_NAME_ALIASES = {
    "mic": ("Mic/Aux", "Mic/Auxiliary Audio", "麦克风/辅助音频", "麦克风/Aux"),
    "desktop": ("Desktop Audio", "桌面音频", "桌面音频输出"),
    "mic_aux": ("Mic/Aux", "麦克风/辅助音频"),
    "aux": ("Aux/Audio", "辅助音频"),
}

# 文本源类型 -> 文本内容所在的 obs_data key
TEXT_TYPE_MAP = {
    "text_gdiplus": ("text",),
    "text_gdiplus_v2": ("text", "text_gdiplus"),
    "text_gdiplus_v3": ("text", "text_gdiplus"),
    "text_ft2_source": ("text",),
    "text_ft2_source_v2": ("text_freetype", "text"),
    "browser_source": ("url",),  # 只作为兜底提示，不直接写
}
TEXT_TYPE_IDS = tuple(k for k in TEXT_TYPE_MAP if k != "browser_source")

# OBS 关闭事件（用于优雅退出）；值来自 obs_frontend_event 枚举
FRONTEND_EVENT_OBS_SHUTDOWN = 8
FRONTEND_EVENT_SCENE_CHANGED = 0
FRONTEND_EVENT_SCENE_LIST_CHANGED = 1
FRONTEND_EVENT_TRANSITION_CHANGED = 2
FRONTEND_EVENT_PROFILE_CHANGED = 6
FRONTEND_EVENT_STREAMING_STARTING = 9
FRONTEND_EVENT_STREAMING_STARTED = 10
FRONTEND_EVENT_STREAMING_STOPPING = 11
FRONTEND_EVENT_STREAMING_STOPPED = 12
FRONTEND_EVENT_RECORDING_STARTING = 13
FRONTEND_EVENT_RECORDING_STARTED = 14
FRONTEND_EVENT_RECORDING_STOPPING = 15
FRONTEND_EVENT_RECORDING_STOPPED = 16
FRONTEND_EVENT_RECORDING_PAUSED = 17
FRONTEND_EVENT_RECORDING_UNPAUSED = 18
FRONTEND_EVENT_EXIT = 20

_FRONTEND_EVENT_NAMES = {
    FRONTEND_EVENT_OBS_SHUTDOWN: "obs_shutdown",
    FRONTEND_EVENT_SCENE_CHANGED: "scene.changed",
    FRONTEND_EVENT_SCENE_LIST_CHANGED: "scene_list.changed",
    FRONTEND_EVENT_TRANSITION_CHANGED: "transition.changed",
    FRONTEND_EVENT_PROFILE_CHANGED: "profile.changed",
    FRONTEND_EVENT_STREAMING_STARTING: "stream.starting",
    FRONTEND_EVENT_STREAMING_STARTED: "stream.started",
    FRONTEND_EVENT_STREAMING_STOPPING: "stream.stopping",
    FRONTEND_EVENT_STREAMING_STOPPED: "stream.stopped",
    FRONTEND_EVENT_RECORDING_STARTING: "record.starting",
    FRONTEND_EVENT_RECORDING_STARTED: "record.started",
    FRONTEND_EVENT_RECORDING_STOPPING: "record.stopping",
    FRONTEND_EVENT_RECORDING_STOPPED: "record.stopped",
    FRONTEND_EVENT_RECORDING_PAUSED: "record.paused",
    FRONTEND_EVENT_RECORDING_UNPAUSED: "record.unpaused",
    FRONTEND_EVENT_EXIT: "obs.exit",
}

_NAME_SAFE = re.compile(r"[^A-Za-z0-9_.@+-]+")

# 同名场景项检测最多数到几个（防御：一个场景里不该有几百个同名项，但别为此扫全表）
AMBIGUITY_PROBE_LIMIT = 8


# =============================================================================
# 错误类型
# =============================================================================
class NexusError(Exception):
    """结构化错误：会被序列化成响应里的 error 字段。"""

    def __init__(self, code, message, details=None, hint=None, retryable=False):
        Exception.__init__(self, message)
        self.code = code
        self.message = message
        self.details = details or {}
        self.hint = hint
        self.retryable = retryable

    def to_dict(self):
        out = {"code": self.code, "message": self.message, "retryable": self.retryable}
        if self.details:
            out["details"] = self.details
        if self.hint:
            out["hint"] = self.hint
        return out

    def __repr__(self):
        return "NexusError(%s: %s)" % (self.code, self.message)


def err(code, msg, **kw):
    return NexusError(code, msg, kw.get("details"), kw.get("hint"), kw.get("retryable", False))


# 常用错误码常量（Agent 侧可据此做自动重试 / 纠错）
E_PROTO = "PROTOCOL_ERROR"
E_NO_METHOD = "NO_METHOD"
E_UNKNOWN_OP = "UNKNOWN_OP"
E_BAD_PARAMS = "INVALID_PARAMS"
E_SOURCE_NOT_FOUND = "SOURCE_NOT_FOUND"
E_SOURCE_AMBIGUOUS = "SOURCE_AMBIGUOUS"
E_SCENE_NOT_FOUND = "SCENE_NOT_FOUND"
E_NOT_A_SCENE = "NOT_A_SCENE"
E_WRONG_TYPE = "WRONG_SOURCE_TYPE"
E_OBS_FAILED = "OBS_FAILED"
E_PRECONDITION = "PRECONDITION_FAILED"
E_TIMEOUT = "TIMEOUT"
E_UNSUPPORTED = "UNSUPPORTED"
E_OVERLOAD = "OVERLOADED"
E_UNAUTHORIZED = "UNAUTHORIZED"
E_FORBIDDEN = "FORBIDDEN"
E_SHUTTING_DOWN = "SHUTTING_DOWN"
E_TOO_LARGE = "TOO_LARGE"
E_INTERNAL = "INTERNAL_ERROR"


# =============================================================================
# 日志
# =============================================================================
class _Log(object):
    """双通道日志：OBS 脚本日志 + ~/.obs_nexus/logs/nexus.log。

    任何来自网络的文本都会先脱敏（token / password 等），避免凭证落盘。
    """

    MAX_BYTES = 1 << 20  # 1 MiB 后 rotate（rename 即可，无需额外 fd）

    def __init__(self):
        self.path = None
        self._fd = None
        self._lock = threading.Lock()
        self._errors = 0
        self._redact = (
            (re.compile(r'("(?:token|password|secret|auth)"\s*:\s*")(?:[^"\\]|\\.)*(")', re.I), r"\1***\2"),
            (re.compile(r"\b[A-Fa-f0-9]{64}\b"), "***redacted***"),
        )

    def open(self, path):
        try:
            parent = os.path.dirname(path)
            if parent:
                _ensure_dir(parent)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, FILE_MODE)
            with self._lock:
                self.close_locked()
                self._fd = fd
                self.path = path
            self.write(LOG_INFO, "---- log opened: %s (pid=%s, python=%s) ----" % (path, os.getpid(), sys.version.split()[0]))
        except Exception as exc:  # 日志不可用不能影响主功能
            self._fd = None
            self.emit(LOG_WARNING, "无法打开日志文件 %s: %r" % (path, exc))

    def close(self):
        with self._lock:
            self.close_locked()

    def close_locked(self):
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None

    def sanitize(self, text):
        try:
            for pat, rep in self._redact:
                text = pat.sub(rep, text)
        except Exception:
            pass
        return text

    def emit(self, level, msg):
        self.write(level, msg)

    def info(self, msg):
        self.write(LOG_INFO, msg)

    def warn(self, msg):
        self.write(LOG_WARNING, msg)

    def error(self, msg):
        self._errors += 1
        self.write(LOG_ERROR, msg)

    def debug(self, msg):
        if _LOG_DEBUG:
            self.write(LOG_DEBUG, msg)

    def write(self, level, msg):
        msg = self.sanitize("%s" % (msg,))
        if obs is not None and hasattr(obs, "script_log"):
            try:
                obs.script_log(level, "[nexus] " + msg)
            except Exception:
                pass
        else:  # pragma: no cover - 离线测试
            if level >= LOG_WARNING:
                sys.stderr.write("[nexus] %s\n" % msg)
        with self._lock:
            fd = self._fd
            if fd is None:
                return
            try:
                line = "%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
                os.write(fd, line.encode("utf-8", "replace"))
                if fd is self._fd:  # 锁内自轮转，避免悬挂 fd
                    try:
                        if os.fstat(fd).st_size > self.MAX_BYTES:
                            os.close(fd)
                            try:
                                os.rename(self.path, self.path + ".1")
                            except OSError:
                                pass
                            self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, FILE_MODE)
                    except OSError:
                        pass
            except OSError:
                pass

    @property
    def error_count(self):
        return self._errors


_LOG = _Log()
_LOG_DEBUG = False


# =============================================================================
# 小工具
# =============================================================================
def _bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        s = value.strip().lower()
        if s in ("1", "true", "yes", "y", "on", "开", "是"):
            return True
        if s in ("0", "false", "no", "n", "off", "关", "否"):
            return False
    return default


def _int(value, default=None):
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return int(value)
    try:
        return int(round(float(value)))
    except (TypeError, ValueError):
        raise err(E_BAD_PARAMS, "需要整数，收到 %r" % (value,))


def _float(value, default=None):
    if value is None or value == "":
        return default
    try:
        f = float(value)
    except (TypeError, ValueError):
        raise err(E_BAD_PARAMS, "需要数字，收到 %r" % (value,))
    if math.isnan(f) or math.isinf(f):
        raise err(E_BAD_PARAMS, "需要有限数字，收到 %r" % (value,))
    return f


def _clamp(v, lo, hi):
    return lo if v < lo else (hi if v > hi else v)


def vol_to_db(vol):
    """OBS 音量线性值(0..2) -> dB。0 记为 -100（与 OBS 表底一致）。"""
    try:
        vol = float(vol)
    except (TypeError, ValueError):
        return None
    if vol <= 0.0:
        return -100.0
    return round(20.0 * math.log10(vol), 2)


def db_to_vol(db):
    """dB -> 线性音量。"""
    try:
        db = float(db)
    except (TypeError, ValueError):
        raise err(E_BAD_PARAMS, "dB 需要数字")
    if db <= -100.0:
        return 0.0
    return _clamp(math.pow(10.0, db / 20.0), 0.0, 2.0)


def safe_name(text, limit=64):
    text = _NAME_SAFE.sub("_", ("%s" % (text,))[:limit])
    return text or "unnamed"


def now_ms():
    return int(time.time() * 1000.0)


def obs_alive():
    return obs is not None


def _fn(name):
    """取 obs 函数；不存在返回 None（用于跨版本兼容）。"""
    if obs is None:
        return None
    return getattr(obs, name, None)


def _has(*names):
    if obs is None:
        return False
    for n in names:
        if not hasattr(obs, n):
            return False
    return True


# ------------------------------- 文件系统 ---------------------------------
def _ensure_dir(path):
    try:
        os.makedirs(path, mode=DIR_MODE, exist_ok=True)
    except FileExistsError:
        pass
    except OSError as exc:
        if getattr(exc, "errno", None) != errno.EEXIST:
            raise
    try:
        os.chmod(path, DIR_MODE)
    except OSError:
        pass


def atomic_write_json(path, obj):
    """原子写：临时文件 + flush + fsync + os.replace。"""
    parent = os.path.dirname(path) or "."
    _ensure_dir(parent)
    data = (json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n").encode("utf-8")
    tmp = os.path.join(parent, ".%s.%d.tmp" % (os.path.basename(path), os.getpid()))
    fd = None
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, FILE_MODE)
        os.write(fd, data)
        os.fsync(fd)
        os.close(fd)
        fd = None
        os.chmod(tmp, FILE_MODE)
        os.replace(tmp, path)  # POSIX/Windows 都是原子替换
        tmp = None
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        if tmp and os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def read_json_file(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def pid_alive(pid):
    """跨平台判断 pid 是否存活（Windows 下 os.kill 不可用 -> 返回 None 表示未知）。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes  # 仅在 Windows 上用到

            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
            k32.CloseHandle(h)
            return bool(ok) and code.value == STILL_ACTIVE
        except Exception:
            return None  # 未知
    try:
        os.kill(pid, 0)
    except OSError as exc:
        if exc.errno == errno.EPERM:
            return True
        return False
    except Exception:
        return None
    return True


def nexus_dir():
    """Nexus 状态目录（默认 ~/.obs_nexus）。"""
    override = os.environ.get("OBS_NEXUS_DIR")
    if override:
        return os.path.abspath(os.path.expanduser(override))
    return os.path.join(os.path.expanduser("~"), ".obs_nexus")


def read_server_config():
    """读取 ~/.obs_nexus/config.json（重启后仍然生效的持久化配置）。"""
    cfg = read_json_file(os.path.join(nexus_dir(), "config.json")) or {}
    return cfg if isinstance(cfg, dict) else {}


def save_server_config(cfg):
    try:
        atomic_write_json(os.path.join(nexus_dir(), "config.json"), cfg)
        return True
    except Exception as exc:
        _LOG.warn("保存 config.json 失败: %r" % (exc,))
        return False


def file_sig(path):
    try:
        st = os.stat(path)
        return (int(st.st_size), int(getattr(st, "st_mtime_ns", 0) or 0))
    except OSError:
        return None


def _scan_new_images(dirs, since_t, exclude=None):
    """非阻塞扫描：返回 since_t 之后最新的图片文件路径（找不到返回 None）。

    必须在 OBS 主线程调用，但**绝不睡眠**：调用方（pump）按 tick 分片轮询，
    并且连续两次采样到同一个 size/mtime 才认为文件写完了。
    """
    exclude = exclude or set()
    best_path, best_t = None, -1.0
    for d in dirs:
        try:
            entries = list(os.scandir(d))
        except OSError:
            continue
        for e in entries:
            if not e.is_file():
                continue
            low = e.name.lower()
            if not low.endswith((".png", ".jpg", ".jpeg", ".bmp", ".webp")):
                continue
            if e.path in exclude:
                continue
            try:
                st = e.stat()
            except OSError:
                continue
            m = max(st.st_mtime, getattr(st, "st_ctime", 0))
            if m >= since_t - 1.0 and m > best_t:
                best_path, best_t = e.path, m
    return best_path


# =============================================================================
# OBS 桥接层：引用计数安全 + 主线程断言 + 只读快照
# =============================================================================
class RefAudit(object):
    """引用计数审计（工业级要求：获取必须配对释放）。

    libobs 的引用是「每个 id 可重入」的：同一个源可能被两次 obs_get_source_by_name
    拿到两个独立引用。所以这里按 id 维护一个**栈**，而不是「一个对象一条记录」——
    后者会把正常的并发持有误判成 double release。

    release() 只有在栈里找不到对应引用时才记 double（= 释放了借来的/别人的引用，
    这是真 bug）；进程退出时 outstanding>0 表示泄漏（= 拿了没还）。
    """

    def __init__(self, enabled=None):
        if enabled is None:
            enabled = os.environ.get("OBS_NEXUS_AUDIT", "1") != "0"
        self.enabled = enabled
        self._lock = threading.Lock()
        self._live = {}  # id(obj) -> [(token, kind), ...]
        self.gets = 0
        self.releases = 0
        self.double = 0
        self._seq = itertools.count(1)

    def acquire(self, obj, kind):
        """登记一次「取得引用」。返回 obj 便于内联调用。"""
        if obj is None or not self.enabled:
            return obj
        with self._lock:
            self.gets += 1
            self._live.setdefault(id(obj), []).append((next(self._seq), kind))
        return obj

    def release(self, obj, kind="auto"):
        """登记一次「释放引用」。kind 传对应的 release 函数名。"""
        if obj is None or not self.enabled:
            return
        with self._lock:
            self.releases += 1
            stack = self._live.get(id(obj))
            if not stack:
                self.double += 1  # 释放了没有登记过的引用：借用量被误 release，或重复 release
                return
            idx = len(stack) - 1
            if kind != "auto":
                for i in range(len(stack) - 1, -1, -1):
                    if stack[i][1] == kind:
                        idx = i
                        break
                else:
                    self.double += 1  # 配对函数不对（用 obs_source_release 去还 sceneitem）
                    return
            stack.pop(idx)
            if not stack:
                self._live.pop(id(obj), None)

    def snapshot(self):
        with self._lock:
            gets, releases, double = self.gets, self.releases, self.double
            outstanding = sum(len(v) for v in self._live.values())
            kinds = {}
            for stack in self._live.values():
                for _tok, kind in stack:
                    kinds[kind] = kinds.get(kind, 0) + 1
        return {
            "gets": gets,
            "releases": releases,
            "outstanding": outstanding,
            "leaks": outstanding,  # 语义等价：还欠着多少引用
            "double_release": double,
            "kinds": kinds,
            "enabled": self.enabled,
        }

    def reset(self):
        with self._lock:
            self._live.clear()
            self.gets = self.releases = self.double = 0

AUDIT = RefAudit()


def _release(fn_name, obj):
    """释放一个 OBS 引用；fn_name 是对应的 release 函数名。"""
    if obj is None:
        return
    AUDIT.release(obj, fn_name)
    fn = _fn(fn_name)
    if fn is None:
        return
    try:
        fn(obj)
    except Exception as exc:  # pragma: no cover
        _LOG.warn("%s 失败: %r" % (fn_name, exc))


class Refs(object):
    """主线程内的引用管理器：with 块退出时自动 release（LIFO）。

    所有「返回新引用」的 obs 调用都必须经过 track()，包括
    obs_get_source_by_name / obs_scene_get_source / obs_sceneitem_get /
    obs_scene_find_source[_recursive] / obs_source_get_filter_by_name ...
    """

    def __init__(self, audit=True):
        self._stack = []
        self._audit = audit

    def track(self, obj, release="obs_source_release"):
        if obj is not None and self._audit:
            AUDIT.acquire(obj, release)
            self._stack.append((obj, release))
        return obj

    def drop(self, obj, release="obs_source_release"):
        """提前释放一个已 track 的引用：同时把它从栈里摘掉。

        少了这一步，release_all() 会对同一个对象再 release 一次 —— 在真 OBS 里
        那是 use-after-free 级别的 bug，不是「多减一次计数」这么简单。
        """
        for i in range(len(self._stack) - 1, -1, -1):
            if self._stack[i][0] is obj:
                self._stack.pop(i)
                _release(release, obj)
                return True
        return False

    def release_all(self):
        # LIFO：先释放场景项，再释放场景/源，符合 libobs 的父子依赖习惯
        while self._stack:
            obj, release = self._stack.pop()
            _release(release, obj)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release_all()
        return False


class ListRefs(object):
    """obs_frontend_source_list / obs_frontend_property_manager 等容器。"""

    def __init__(self, kind):
        self.kind = kind
        self.obj = None

    def __enter__(self):
        if self.kind == "source_list":
            if not _has("obs_frontend_source_list_create"):
                raise err(E_UNSUPPORTED, "obspython 未提供 obs_frontend_source_list")
            self.obj = obs.obs_frontend_source_list_create()
        elif self.kind == "prop_manager":
            fn = _fn("obs_frontend_get_independent_property_manager")
            if fn is None:
                raise err(E_UNSUPPORTED, "OBS 版本过低：无独立属性管理器（需要 26+）")
            self.obj = fn()
        return self.obj

    def __exit__(self, exc_type, exc, tb):
        if self.obj is None:
            return False
        try:
            if self.kind == "source_list":
                obs.obs_frontend_source_list_free(self.obj)  # 内部会 release 所有源
            elif self.kind == "prop_manager":
                _fn("obs_frontend_release_independent_property_manager")(self.obj)
        except Exception as exc2:  # pragma: no cover
            _LOG.warn("释放 %s 失败: %r" % (self.kind, exc2))
        finally:
            self.obj = None
        return False


# ------------------------------ 主线程断言 --------------------------------
# 注：这里刻意不放 NexusRuntime 的前向占位类 —— 它在 part 5 才真正定义，
# 一个同名空壳会让「顶层重名」检查失效，还会掩盖拼装顺序错误。
def _runtime():
    return _SERVER


def require_main_thread(what="obs 调用"):
    """致命红线 R1 的守卫：发现子线程调用 libobs 立刻报错而不是静默崩溃。"""
    rt = _SERVER
    if rt is None:
        return
    main = getattr(rt, "main_thread_id", None)
    if main and threading.get_ident() != main:
        _LOG.error("线程安全红线被触碰：在非主线程调用了 %s" % what)
        raise err(
            E_INTERNAL,
            "线程安全红线：禁止在非 OBS 主线程调用 libobs（%s）" % what,
            hint="该 op 必须通过 obs.timer_add 的泵队列执行，见 R1/R3。",
        )


# ============================ 场景 / 源 查找 ==============================
def list_scenes(refs):
    """OBS 场景列表 -> [(name, scene_t)]。

    内存安全要点（逐条对着 obs-studio 32.2.2 源码核过）：
      * obs_frontend_get_scenes() 填充的列表内部持有「引用自增」的场景源，
        必须由 obs_frontend_source_list_free() 统一释放，绝不能手动 release；
      * obs_scene_from_source() **不加引用**（obs-scene.c: `return source->context.data;`），
        所以要用 obs_scene_get_ref() 另取一份独立引用（配 obs_scene_release，
        它内部就是 obs_source_release(scene->source)）；这样即使 list_free 把列表
        那份引用还给源，我们的 scene 指针依然有效；
      * 所有 scene 引用都 track 进 refs，with 块结束时统一释放（LIFO）。
    """
    out = []
    fn = _fn("obs_frontend_get_scenes")
    if fn is None or refs is None:
        return out
    if not _can_own_scene():
        raise err(
            E_UNSUPPORTED,
            "这套 OBS 绑定缺 obs_scene_get_ref/obs_source_get_ref，无法安全持有场景引用",
            hint="宁可不返回也不要 release 借用指针：那是 use-after-free。请用带完整前端的 OBS。",
        )
    with ListRefs("source_list") as lst:
        try:
            fn(lst)
        except Exception as exc:
            raise err(E_OBS_FAILED, "obs_frontend_get_scenes 失败: %r" % (exc,))
        for src in _list_get(lst):
            try:
                name = obs.obs_source_get_name(src) or ""
            except Exception:
                name = ""
            scene = None
            scene = _scene_of(src)
            if scene is None:
                continue
            refs.track(scene, "obs_scene_release")
            out.append((name, scene))
    return out


def _list_get(lst):
    if lst is None:
        return []
    getter = getattr(lst, "get_sources", None)
    if callable(getter):
        try:
            return list(getter())
        except Exception:
            return []
    return list(getattr(lst, "sources", None) or [])


def _can_own_scene():
    """这台 OBS 能不能把借用的 scene 指针变成自有引用（拿不动就别硬撑）。"""
    if _fn("obs_scene_get_ref") is not None:
        return True
    return _fn("obs_scene_get_source") is not None and (
        _fn("obs_source_get_ref") is not None or _fn("obs_source_addref") is not None
    )


def _scene_borrow(src):
    """只借不持有：obs_scene_from_source 的原始返回值（诊断/内部判断用，不要存下来）。"""
    conv = _fn("obs_scene_from_source")
    if conv is None or src is None:
        return None
    try:
        return conv(src)
    except Exception:
        return None


def _scene_of(src):
    """obs_scene_from_source() 是**借用**（libobs 里就是 `return source->context.data;`），
    这里立刻用 obs_scene_get_ref() 提升成调用者持有的引用，调用方才能安全 release。
    没导出 obs_scene_get_ref 时退回 obs_source_get_ref(obs_scene_get_source(scene))，
    两条路都没有就返回 None —— 宁可不支持，也不能少加引用还多 release。
    """
    conv = _fn("obs_scene_from_source")
    if conv is None or src is None:
        return None
    try:
        scene = conv(src)
    except Exception:
        return None
    if scene is None:
        return None
    getref = _fn("obs_scene_get_ref")
    if getref is not None:
        try:
            return getref(scene)
        except Exception:
            return None
    getsrc = _fn("obs_scene_get_source")
    addref = _fn("obs_source_get_ref") or _fn("obs_source_addref")
    if getsrc is not None and addref is not None:
        try:
            own = addref(getsrc(scene))
        except Exception:
            return None
        return scene if own is not None else None
    return None


def current_scene_name():
    fn = _fn("obs_frontend_get_current_scene")
    if fn is None:
        return None
    src = fn()
    if src is None:
        return None
    try:
        refs = Refs()
        refs.track(src, "obs_source_release")
        try:
            return obs.obs_source_get_name(src)
        finally:
            refs.release_all()
    except Exception:
        return None


def resolve_scene(refs, name=None, exact=True):
    """按名字找场景；name 为空返回当前场景。返回 (name, scene_t)。"""
    scenes = list_scenes(refs)
    if not name:
        fn = _fn("obs_frontend_get_current_scene")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_get_current_scene")
        cur_src = fn()
        if cur_src is None:
            raise err(E_OBS_FAILED, "OBS 当前没有活动场景（可能正在关闭）")
        refs.track(cur_src, "obs_source_release")
        try:
            cur_name = obs.obs_source_get_name(cur_src) or ""
            scene = refs.track(_scene_of(cur_src), "obs_scene_release")  # _scene_of 已 addref
            if scene is None and _scene_borrow(cur_src) is not None and not _can_own_scene():
                raise err(E_UNSUPPORTED, "无法持有场景引用（缺 obs_scene_get_ref）")
        finally:
            pass
        if scene is None:
            raise err(E_NOT_A_SCENE, "当前活动场景的源不是场景类型")
        return cur_name, scene
    target = ("%s" % name).strip()
    lowered = target.lower()
    matches = [(n, s) for (n, s) in scenes if n == target]
    if not matches and not exact:
        matches = [(n, s) for (n, s) in scenes if (n or "").strip().lower() == lowered]
    if not matches:
        raise err(
            E_SCENE_NOT_FOUND,
            "场景不存在: %r" % target,
            details={"known": [n for (n, _s) in scenes][:64]},
            hint="用 scene.list 查看全部场景名（注意大小写与空格）。",
        )
    return matches[0]


def _own_item(refs, item):
    """把「借用」的 scene item 变成我们自己在 refs 里持有的一份引用。

    事实依据（obs-studio 32.2.2 / libobs/obs-scene.c）：

        obs_sceneitem_t *obs_scene_find_source(obs_scene_t *scene, const char *name)
        { ...; item = scene->first_item; while (item) { if (strcmp(...)) break; ... } return item; }

    也就是**不加引用**直接返回链表节点；而 obspython 的 SWIG 接口（obspython.i）里
    没有任何针对 obs_* 对象的 addref/release typemap，脚本层不会自动帮你管引用。
    所以「拿到就 track + release」= 把场景自己那份引用 release 掉 → refcount 归零 →
    libobs 真的 free 掉这个 item（后续渲染/枚举直接 use-after-free）。

    正确姿势：先 obs_sceneitem_addref，再把 release 挂到 refs 上（LIFO 统一释放）。
    如果某个构建没导出 obs_sceneitem_addref，就退化成「只借用、绝不 release」——
    父场景的引用还在 refs 里，item 在本次 op 期间保证有效，宁可少保护也不能多释放。
    """
    if item is None or refs is None:
        return item
    add = _fn("obs_sceneitem_addref")
    if add is None:
        return item
    try:
        add(item)
    except Exception:
        return item
    refs.track(item, "obs_sceneitem_release")
    return item


def _find_scene_item(scene, name, refs=None):
    """在场景内找 item（先精确后递归，再忽略大小写）。

    refs 不为 None 时返回的是**我们持有的**引用（已 addref + track）；为 None 时是借用，
    调用方不得 release。
    """
    if scene is None:
        return None
    exact = _fn("obs_scene_find_source")
    deep = _fn("obs_scene_find_source_recursive")
    item = None
    for fn in (exact, deep):
        if fn is None:
            continue
        try:
            item = fn(scene, name)
        except Exception:
            item = None
        if item is not None:
            return _own_item(refs, item)
    low = ("%s" % (name,)).strip().lower()
    if not low:
        return None
    holder = []

    def cb(s, it, _p):
        try:
            src = obs.obs_sceneitem_get_source(it)
            if (obs.obs_source_get_name(src) or "").strip().lower() == low:
                holder.append(it)
                return False
        except Exception:
            pass
        return True

    try:
        obs.obs_scene_enum_items(scene, cb, None)
    except Exception:
        return None
    # 回调里拿到的是借用指针（enum 自己在回调前后 addref/release），交给 _own_item 处理
    return _own_item(refs, holder[0]) if holder else None


def _borrow_to_ref(borrowed):
    """把 obs_sceneitem_get_source() 的借用指针提升为新引用。

    obs_source_get_ref / obs_source_addref 在部分构建里未必导出；取不到时
    返回 None，由调用方退回「按名字全局查」路径（OBS 保证源名全局唯一）。
    """
    if borrowed is None:
        return None
    fn = _fn("obs_source_get_ref")
    if fn is not None:
        try:
            return fn(borrowed)
        except Exception:
            pass
    fn = _fn("obs_source_addref")
    if fn is not None:
        try:
            fn(borrowed)
            return borrowed
        except Exception:
            pass
    return None


def _lookup_by_name(name):
    fn = _fn("obs_get_source_by_name")
    if fn is None:
        return None
    try:
        return fn(name)
    except Exception:
        return None


def _scene_name_safe(scene):
    try:
        return obs.obs_source_get_name(obs.obs_scene_get_source(scene))
    except Exception:
        return None


def resolve_source(refs, name, scene=None, scope="auto", allow_scene=True):
    """把名字解析成 obs_source_t（新引用，已 track 进 refs）。

    解析顺序：
      1) 目标场景内的场景项（含组内递归）—— 只有这条路能拿到 item_id / 层级
      2) obs_get_source_by_name（覆盖全局源：桌面音频、麦克风、未出场源、场景）
      3) 「麦克风 / 桌面音频」等中英文别名
    返回 (source, meta)，meta 说明命中位置，回显给 Agent 方便排错。
    """
    if name is None or ("%s" % (name,)).strip() == "":
        raise err(E_BAD_PARAMS, "缺少参数 source（源名称）")
    target = ("%s" % name).strip()

    if scene is not None and scope in ("auto", "scene"):
        item = _find_scene_item(scene, target, refs)
        if item is not None:
            item_id = _item_id(item)
            got = None
            try:
                got = _borrow_to_ref(obs.obs_sceneitem_get_source(item))
            except Exception:
                got = None
            if got is None:
                got = _lookup_by_name(target)
                via = "global_name"
            else:
                via = "item"
            if got is not None:
                refs.track(got, "obs_source_release")
                return got, {"where": "scene_item", "item_id": item_id, "ref_via": via}

    if scope in ("auto", "global"):
        got = _lookup_by_name(target)
        if got is not None:
            refs.track(got, "obs_source_release")
            try:
                stype = obs.obs_source_get_id(got) or ""
            except Exception:
                stype = ""
            if stype == "scene" and not allow_scene:
                refs.drop(got, "obs_source_release")
                refs._stack.pop()
                raise err(E_BAD_PARAMS, "%r 是场景而不是源；请传场景内的源名" % target)
            return got, {"where": "global" if stype != "scene" else "scene", "item_id": None}
        for alias in AUDIO_NAME_ALIASES.get(target.lower(), ()):
            got = _lookup_by_name(alias)
            if got is not None:
                refs.track(got, "obs_source_release")
                return got, {"where": "global_alias", "alias": alias, "item_id": None}

    raise err(
        E_SOURCE_NOT_FOUND,
        "找不到源: %r" % target,
        details={"scope": scope, "scene": None if scene is None else _scene_name_safe(scene)},
        hint="source 必须与 OBS 里的源名完全一致；先用 source.list 列出可用源名。",
    )


def _items_named(scene, target, limit=AMBIGUITY_PROBE_LIMIT):
    """按名字收集场景项（含组内递归）-> [(item, depth, layer)]，保序（z 序，depth 0 第一个 = 最上层）。

    只取「个数 + item_id」用于歧义判定，故意不做完整快照：这些函数每次 op 都会跑，
    省下 source_meta 的开销。最多数到 limit 个就停，超大场景不会被这个检查拖住。
    收集到的 item 是**借用**指针（enum 回调结束就把它自己的引用还回去），
    所以调用方要长期持有必须自己 addref —— 见 _own_item。
    """
    low = (target or "").strip().lower()
    out = []

    def visit(sc, depth):
        enum = _fn("obs_scene_enum_items")
        if enum is None or depth > 4:
            return False
        state = {"layer": 0, "stop": False}

        def cb(_s, item, _p):
            if state["stop"]:
                return False
            my_layer = state["layer"]
            state["layer"] += 1
            try:
                src = obs.obs_sceneitem_get_source(item)  # 借用引用：不 addref、不 release
                nm = (obs.obs_source_get_name(src) or "") if src is not None else ""
            except Exception:
                return True
            if nm.strip().lower() == low:
                out.append((item, depth, my_layer))
                if len(out) >= limit:
                    state["stop"] = True
                    return False
            elif _is_group(item):
                gs = _fn("obs_sceneitem_get_group")
                sub = None
                try:
                    sub = gs(sc, item) if gs is not None else None
                except Exception:
                    sub = None
                if sub is None:
                    try:
                        sub = obs.obs_sceneitem_group_get_scene(item)  # 借用
                    except Exception:
                        sub = None
                if sub is not None and not visit(sub, depth + 1):
                    return False
            return True

        try:
            enum(sc, cb, None)
        except Exception:
            return False
        return len(out) < limit

    visit(scene, 0)
    return out


def resolve_scene_item(refs, scene, name, nth=None):
    """只要场景项（可见性 / 层级 / 变换类操作）。返回 (item, borrowed_source)。

    `nth`（op 参数里的 index）用于同名场景项：OBS 允许一个场景里出现多个同名项
    （同一个源加两次、或两个源起同样的名字），此时「第一个匹配」到底是谁并不显然，
    误改另一个贴片比报错糟糕得多 —— 所以我们数一下同名项，>1 就直接 SOURCE_AMBIGUOUS，
    并回显所有候选的 item_id/layer/depth，让 Agent 用 index 指定。
    """
    if scene is None:
        raise err(E_BAD_PARAMS, "该操作需要 scene（留空表示当前场景）")
    target = ("%s" % (name,)).strip()
    if not target:
        raise err(E_BAD_PARAMS, "缺少参数 source（源名称）")
    found = _items_named(scene, target)
    if not found:
        item = _find_scene_item(scene, target)  # 兜底：走 OBS 原生查找（有些构建枚举行为不同）
        if item is None:
            raise err(
                E_SOURCE_NOT_FOUND,
                "场景 %r 中找不到源项: %r" % (_scene_name_safe(scene), target),
                hint="组内源也支持；可用 source.list 配 recursive:true 查看完整层级。",
            )
        found = [(item, 0, 0)]
    if nth is None:
        if len(found) > 1:
            cands = []
            for i, (it, dep, layer) in enumerate(found):
                try:
                    iid = _item_id(it)
                except Exception:
                    iid = None
                cands.append({"index": i, "item_id": iid, "layer": layer, "depth": dep})
            raise err(
                E_SOURCE_AMBIGUOUS,
                "场景 %r 里有 %d 个同名源项 %r，无法确定你要改哪个" % (_scene_name_safe(scene), len(found), target),
                details={"count": len(found), "candidates": cands[:AMBIGUITY_PROBE_LIMIT]},
                hint="给这个 op 加 index:0..%d 指定第几个（0 = z 序最上），或先在 OBS 里改名。" % (len(found) - 1),
            )
        item = found[0][0]
    else:
        try:
            idx = int(nth)
        except (TypeError, ValueError):
            raise err(E_BAD_PARAMS, "index 必须是整数", details={"got": nth})
        if not -len(found) <= idx < len(found):
            raise err(
                E_BAD_PARAMS,
                "index 越界：%d（%r 只有 %d 个同名项）" % (idx, target, len(found)),
                details={"count": len(found), "valid_range": [0, len(found) - 1]},
            )
        item = found[idx % len(found)][0]
    return _own_item(refs, item), _borrowed_source_of(item)


def _borrowed_source_of(item):
    try:
        return obs.obs_sceneitem_get_source(item)  # 借用：调用方不得 release
    except Exception:
        return None


def _item_id(item):
    fn = _fn("obs_sceneitem_get_id")
    if fn is None or item is None:
        return None
    try:
        return int(fn(item))
    except Exception:
        return None


def source_kind(source):
    try:
        return obs.obs_source_get_type(source)
    except Exception:
        return -1


def source_has_audio(source):
    fn = _fn("obs_source_get_output_flags")
    if fn is None:
        return True
    try:
        return bool(fn(source) & (OBS_SOURCE_AUDIO | OBS_SOURCE_ASYNC))
    except Exception:
        return False


def source_size(source):
    try:
        w = int(obs.obs_source_get_width(source) or 0)
        h = int(obs.obs_source_get_height(source) or 0)
    except Exception:
        w, h = 0, 0
    return w, h


def source_meta(source, refs=None, include_settings=False, max_settings=64):
    """构造源的只读元信息（全部是 python 值，可以安全跨线程发送）。"""
    meta = {}
    if source is None:
        return meta
    try:
        meta["name"] = obs.obs_source_get_name(source) or ""
    except Exception:
        meta["name"] = ""
    try:
        meta["type"] = obs.obs_source_get_id(source) or ""
    except Exception:
        meta["type"] = ""
    meta["kind"] = {SOURCE_TYPE_INPUT: "input", SOURCE_TYPE_FILTER: "filter", SOURCE_TYPE_TRANSITION: "transition"}.get(
        source_kind(source), "unknown"
    )
    w, h = source_size(source)
    meta["width"], meta["height"] = w, h
    flags = 0
    fn = _fn("obs_source_get_output_flags")
    if fn is not None:
        try:
            flags = int(fn(source) or 0)
        except Exception:
            flags = 0
    meta["video"] = bool(flags & OBS_SOURCE_VIDEO)
    meta["audio"] = bool(flags & (OBS_SOURCE_AUDIO | OBS_SOURCE_ASYNC))
    try:
        meta["muted"] = bool(obs.obs_source_muted(source))
    except Exception:
        meta["muted"] = None
    try:
        meta["volume"] = round(float(obs.obs_source_get_volume(source)), 5)
    except Exception:
        meta["volume"] = None
    if meta.get("volume") is not None:
        meta["volume_db"] = vol_to_db(meta["volume"])
    if include_settings:
        settings = source_settings(source, max_items=max_settings)
        if settings is not None:
            meta["settings"] = settings
    return meta


def source_settings(source, max_items=64, keys=None):
    """读取 obs_data 设置（带过滤与截断，避免撑爆 LLM 上下文）。"""
    get = _fn("obs_source_get_settings")
    rel = _fn("obs_data_release")
    if get is None:
        return None
    data = get(source)
    if data is None:
        return None
    try:
        AUDIT.acquire(data, "obs_data_release")
    except Exception:
        pass
    try:
        return _dump_data(data, max_items=max_items, keys=keys)
    finally:
        try:
            AUDIT.release(data, "obs_data_release")
        except Exception:
            pass
        if rel is not None:
            try:
                rel(data)
            except Exception:
                pass


def _data_keys(data):
    """按 libobs 语义遍历 obs_data 的键：obs_data_first() 只调一次，然后 next()。

    （obs_data_first() 会把游标复位，放在循环里会导致同一个键被反复读到。）
    """
    fn = _fn("obs_data_first")
    nxt = _fn("obs_data_next")
    if fn is None or nxt is None:
        return []
    keys = []
    try:
        if not fn(data):
            return []
    except Exception:
        return []
    for _ in range(4096):  # 防御：不信任迭代器一定终止
        k = _read_key(data)
        if k:
            keys.append(k)
        try:
            if not nxt(data):
                break
        except Exception:
            break
    return keys


def _read_key(data):
    for name in ("obs_data_get_key",):
        fn = _fn(name)
        if fn is not None:
            try:
                return fn(data) or ""
            except Exception:
                pass
    return ""


def _data_type(data, key):
    fn = _fn("obs_data_get_item_type")
    if fn is None:
        return "string"
    try:
        return _TYPE_NAMES.get(int(fn(data, key)), "string")
    except Exception:
        return "string"


_TYPE_NAMES = {0: "null", 1: "string", 2: "number", 3: "boolean", 4: "array", 5: "object"}


def _dump_data(data, max_items=64, keys=None, depth=0):
    """obs_data -> 普通 python dict（截断长字符串、跳过敏感 key）。"""
    if data is None or depth > 3:
        return None
    wanted = keys
    if wanted is None:
        wanted = _data_keys(data)
    out = {}
    skipped = {}
    for key in list(wanted)[: max(1, int(max_items))]:
        t = _data_type(data, key)
        try:
            if t == "string":
                val = obs.obs_data_get_string(data, key)
            elif t == "number":
                val = _data_number(data, key)
            elif t == "boolean":
                val = bool(obs.obs_data_get_bool(data, key))
            elif t == "array":
                val = _dump_array(data, key, max_items)
            elif t == "object":
                obj = obs.obs_data_get_obj(data, key)
                try:
                    if obj is not None:
                        AUDIT.acquire(obj, "obs_data_release")
                    val = _dump_data(obj, max_items=max_items, depth=depth + 1)
                finally:
                    if obj is not None:
                        _release("obs_data_release", obj)
            else:
                val = None
        except Exception as exc:
            skipped[key] = "read_error:%r" % (exc,)
            continue
        if isinstance(val, str) and len(val) > 512:
            skipped[key] = "truncated:%d" % len(val)
            val = val[:512] + "…"
        if key.lower() in ("password", "key", "secret", "token", "rtmp_server"):
            val = "***"
        out[key] = val
    if len(wanted or []) > max_items:
        skipped["_count"] = "keys=%d(shown=%d)" % (len(wanted or []), max_items)
    if skipped:
        out["_skipped"] = skipped
    return out


def _data_number(data, key):
    try:
        f = float(obs.obs_data_get_double(data, key))
    except Exception:
        f = 0.0
    try:
        i = int(obs.obs_data_get_int(data, key))
    except Exception:
        i = 0
    if abs(f - i) < 1e-9 and not math.isnan(f):
        return i
    if math.isnan(f) or math.isinf(f):
        return None
    return round(f, 6)


def _dump_array(data, key, max_items=64):
    getter = _fn("obs_data_get_array")
    count = _fn("obs_data_array_count")
    item = _fn("obs_data_array_item")
    release_a = _fn("obs_data_array_release")
    release_i = _fn("obs_data_release")
    if not all((getter, count, item)):
        return "<array>"
    arr = getter(data, key)
    if arr is None:
        return []
    try:
        try:
            n = int(count(arr))
        except Exception:
            n = 0
        out = []
        for i in range(min(n, max_items)):
            obj = item(arr, i)
            if obj is None:
                out.append(None)
                continue
            try:
                AUDIT.acquire(obj, "obs_data_release")
            except Exception:
                pass
            t = _data_type_of_obj(obj)
            if t == "string":
                out.append(obs.obs_data_get_string(obj, "value"))
            elif t == "number":
                out.append(_data_number(obj, "value"))
            elif t == "boolean":
                out.append(bool(obs.obs_data_get_bool(obj, "value")))
            else:
                out.append(_dump_data(obj, max_items=16))
            if release_i is not None:
                _release("obs_data_release", obj)
        if n > max_items:
            out.append("…+%d more" % (n - max_items,))
        return out
    finally:
        if release_a is not None:
            try:
                release_a(arr)
            except Exception:
                pass


def _data_type_of_obj(obj):
    fn = _fn("obs_data_get_item_type")
    if fn is None:
        return "string"
    try:
        return _TYPE_NAMES.get(int(fn(obj, "value")), "object")
    except Exception:
        return "object"


# --------------------------- 场景项（含锁定标记） --------------------------
def item_locked(item):
    """OBS 没有公开的「场景项锁定」API；Nexus 用源的 private settings 存
    约定字段 nexus_locked，供 Agent 做互斥标记。"""
    src = _fn("obs_sceneitem_get_source")(item) if _fn("obs_sceneitem_get_source") else None
    if src is None:
        return False
    getp = _fn("obs_source_get_private_settings")
    rel = _fn("obs_data_release")
    if getp is None:
        return False
    data = getp(src)  # 返回借用引用：不能 release 源，但可以 release data? ->
    # 文档：obs_source_get_private_settings 返回新引用，需要 obs_data_release
    if data is None:
        return False
    try:
        AUDIT.acquire(data, "obs_data_release")
        return bool(obs.obs_data_get_int(data, "nexus_locked"))
    except Exception:
        return False
    finally:
        _release("obs_data_release", data)
        if rel is None:
            pass


def item_info_dict(item, info=None):
    """obs_sceneitem_info -> dict（pos/scale/rot/bounds/crop）。"""
    if info is None:
        return {}
    def g(*names, **kw):
        default = kw.get("default", 0.0)
        for n in names:
            if hasattr(info, n):
                try:
                    v = getattr(info, n)
                    if v is not None:
                        return v
                except Exception:
                    continue
        return default

    out = {}
    pos = g("pos")
    if hasattr(pos, "x"):
        out["pos"] = [round(float(pos.x), 2), round(float(pos.y), 2)]
    else:
        out["pos"] = [round(float(g("pos_x")), 2), round(float(g("pos_y")), 2)]
    scale = g("scale")
    if hasattr(scale, "x"):
        out["scale"] = [round(float(scale.x), 4), round(float(scale.y), 4)]
    else:
        out["scale"] = [round(float(g("scale_x", default=1.0)), 4), round(float(g("scale_y", default=1.0)), 4)]
    out["rot"] = round(float(g("rot")), 3)
    alignment = g("alignment")
    if hasattr(alignment, "x"):
        try:
            out["alignment"] = [int(alignment.x), int(alignment.y)]
        except Exception:
            out["alignment"] = [0, 0]
    else:
        out["alignment"] = [int(g("alignment_x")), int(g("alignment_y"))]
    out["bounds"] = {
        "type": int(g("bounds_type")),
        "align": int(g("bounds_alignment")),
        "flags": int(g("bounds_flags")),
        "size": [round(float(g("bounds_x")), 2), round(float(g("bounds_y")), 2)],
    }
    out["cropped"] = bool(g("cropped"))
    out["crop"] = [
        int(g("crop_left")),
        int(g("crop_right")),
        int(g("crop_top")),
        int(g("crop_bottom")),
    ]
    return out


def create_item_info():
    fn = _fn("obs_sceneitem_info_create")
    if fn is None:
        return None
    try:
        return fn()
    except Exception:
        return None


def set_item_info(item, info):
    fn = _fn("obs_sceneitem_set_info")
    if fn is None:
        raise err(E_UNSUPPORTED, "无 obs_sceneitem_set_info")
    fn(item, info)


# =============================================================================
# Ops 注册表
# =============================================================================
EXEC_MAIN = 0    # 由主线程泵执行（唯一允许触碰 libobs 的路径）
EXEC_WORKER = 1  # 由网络线程执行（不碰 libobs，只读缓存 / 纯计算）


class OpSpec(object):
    def __init__(self, name, handler, summary, args, advanced=False, execution=EXEC_MAIN, mutating=False):
        self.name = name
        self.handler = handler
        self.summary = summary
        self.args = args          # {字段: (类型, 必填?, 说明)}
        self.advanced = advanced
        self.execution = execution
        self.mutating = mutating

    def describe(self):
        out = {
            "op": self.name,
            "summary": self.summary,
            "execution": "main_thread" if self.execution == EXEC_MAIN else "network_thread",
            "mutating": self.mutating,
        }
        if self.advanced:
            out["requires_advanced"] = True
        if self.args:
            out["args"] = {k: list(v) for k, v in self.args.items()}
        return out


OPS = {}


def op(name, summary, args=None, advanced=False, execution=EXEC_MAIN, mutating=False):
    def deco(fn):
        OPS[name] = OpSpec(name, fn, summary, args or {}, advanced, execution, mutating)
        return fn

    return deco


class Async(object):
    """op 处理器返回它表示「结果稍后产生」，由主线程泵按 tick 轮询。

    poll(ctx_state) -> None(继续等) / dict(完成) / 抛 NexusError(失败)。
    绝不阻塞主线程：poll 必须是非阻塞的（不能 sleep、不能 wait 子进程）。
    """

    def __init__(self, poll, timeout_ms=3000.0, note=None):
        self.poll = poll
        self.timeout_ms = float(timeout_ms)
        self.note = note or {}


# ------------------------------ 参数工具 ----------------------------------
def arg(a, key, default=None):
    v = a.get(key, default)
    return default if v is None else v


def need(a, key, what=None):
    if not isinstance(a, dict):
        raise err(E_BAD_PARAMS, "%s 的参数必须是对象" % (what or "op"))
    v = a.get(key)
    if v is None or (isinstance(v, str) and not v.strip()):
        raise err(E_BAD_PARAMS, "缺少必填参数 %r" % key, hint="字段说明见 conn.capabilities。")
    return v


def scene_ref(a):
    return a.get("scene") or a.get("scene_name") or a.get("target_scene")


# ============================== system.* ==================================
def _stream_state():
    st = {"active": None, "pending": None, "stopping": None, "reconnecting": None, "congestion": None}
    if _has("obs_frontend_streaming_active"):
        try:
            st["active"] = bool(obs.obs_frontend_streaming_active())
        except Exception:
            pass
    if _has("obs_frontend_streaming_pending"):
        try:
            st["pending"] = bool(obs.obs_frontend_streaming_pending())
        except Exception:
            pass
    if _has("obs_frontend_streaming_stopping"):
        try:
            st["stopping"] = bool(obs.obs_frontend_streaming_stopping())
        except Exception:
            pass
    for key, fn_name in (("reconnecting", "obs_frontend_streaming_reconnecting"), ("congestion", "obs_frontend_streaming_congestion")):
        fn = _fn(fn_name)
        if fn is not None:
            try:
                st[key] = bool(fn())
            except Exception:
                pass
    if st["active"] is None and st["pending"] is None:
        out = _fn("obs_frontend_get_streaming_output")
        if out is not None:
            o = out()
            if o is not None:
                AUDIT.acquire(o, "obs_output_release")
                active_fn = _fn("obs_output_active")
                try:
                    st["active"] = bool(active_fn(o)) if active_fn else True
                except Exception:
                    st["active"] = None
                _release("obs_output_release", o)
    return st


def _record_state():
    st = {"active": None, "paused": None, "path": None}
    if _has("obs_frontend_recording_active"):
        try:
            st["active"] = bool(obs.obs_frontend_recording_active())
        except Exception:
            pass
    if _has("obs_frontend_recording_paused"):
        try:
            st["paused"] = bool(obs.obs_frontend_recording_paused())
        except Exception:
            pass
    fn = _fn("obs_frontend_get_current_record_output_path")
    if fn is not None:
        try:
            p = fn()
            st["path"] = p or None
        except Exception:
            pass
    if st["active"] is None:
        out = _fn("obs_frontend_get_recording_output")
        if out is not None:
            o = out()
            if o is not None:
                AUDIT.acquire(o, "obs_output_release")
                active_fn = _fn("obs_output_active")
                try:
                    st["active"] = bool(active_fn(o)) if active_fn else True
                except Exception:
                    st["active"] = None
                _release("obs_output_release", o)
    return st


def _active_audio_tracks():
    """推流输出的六个混音轨（mixer 0..5）概况：哪几轨真的挂在推流输出上、码率多少。

    所有权（对着 obs-studio 32.2.2 源码逐行核过，别改）：
      * `obs_frontend_get_streaming_output()` —— 前端 API，返回**新引用**，
        必须 `obs_output_release()` 归还；
      * `obs_output_get_audio_encoder(output, idx)` —— libobs 里就是
        `return output->audio_encoders[idx];`（obs-output.c:1137），**借用**，
        绝对不能再 release，否则输出的编码器被提前 free；
      * 「某轨启用」的判定 = 该 mixer index 上挂了编码器（OBS 的设置界面同样这么判断）；
      * OBS 30 起已删除 obs_audio_encoder_get_next/get_track，所以不做多编码器串联遍历。
    没在推流时返回空列表（不是错误：Agent 需要先 stream.control start_stream）。
    """
    get_out = _fn("obs_frontend_get_streaming_output")
    get_enc = _fn("obs_output_get_audio_encoder")
    if get_out is None or get_enc is None:
        return []
    try:
        out = get_out()
    except Exception:
        out = None
    if out is None:
        return []
    tracks = []
    refs = Refs()
    refs.track(out, "obs_output_release")  # 只有 output 是我们持有的
    try:
        for idx in range(6):
            try:
                enc = get_enc(out, idx)  # 借用：不 track、不 release
            except Exception:
                enc = None
            if enc is None:
                continue
            row = {"index": idx, "enabled": True}
            try:
                if _has("obs_encoder_get_name"):
                    row["name"] = obs.obs_encoder_get_name(enc)
                if _has("obs_encoder_get_bitrate"):
                    row["bitrate_kbps"] = int(obs.obs_encoder_get_bitrate(enc))
                if _has("obs_encoder_active"):
                    row["active"] = bool(obs.obs_encoder_active(enc))
            except Exception:
                row["error"] = "read_failed"
            tracks.append(row)
    finally:
        refs.release_all()
    return tracks


def obs_version_string():
    fn = _fn("obs_frontend_get_version")
    if fn is not None:
        try:
            v = fn()
            if v:
                return "%s" % v
        except Exception:
            pass
    fn = _fn("obs_get_version_string")
    if fn is not None:
        try:
            v = fn()
            if v:
                return "%s" % v
        except Exception:
            pass
    if _obs_version_mod is not None:
        for name in ("obs_version", "python_version"):
            fn = getattr(_obs_version_mod, name, None)
            if callable(fn):
                try:
                    return "%s" % fn()
                except Exception:
                    pass
    return "unknown"


@op(
    "system.overview",
    "总览：OBS 版本、活动场景、推流/录制/虚拟摄像头状态、活动音轨、Nexus 运行指标",
    {"include_stats": ["bool", False, "附带 obs_frontend_get_stats() 文本（较长，默认关闭）"]},
)
def op_system_overview(rt, a, ctx):
    stats = None
    if _bool(a.get("include_stats"), False) and _has("obs_frontend_get_stats"):
        try:
            stats = obs.obs_frontend_get_stats()
            if isinstance(stats, str):
                stats = stats[:2048]
        except Exception as exc:
            stats = "unavailable:%r" % (exc,)
    snap = snapshot_capability()
    out = {
        "obs_version": obs_version_string(),
        "obs_api": _api_version_int(),
        "nexus_version": NEXUS_VERSION,
        "proto": NEXUS_PROTO,
        "platform": _platform_name(),
        "python": sys.version.split()[0],
        "active_scene": current_scene_name(),
        "studio_mode": bool(_fn("obs_frontend_preview_program_mode_active")()) if _has("obs_frontend_preview_program_mode_active") else None,
        "preview_scene": None,
        "streaming": _stream_state(),
        "recording": _record_state(),
        "virtualcam": None,
        "replay_buffer": None,
        "audio_tracks": _active_audio_tracks(),
        "snapshot": snap,
        "runtime": rt.metrics(),
        "stats_text": stats,
    }
    if _has("obs_frontend_get_current_preview_scene"):
        src = _fn("obs_frontend_get_current_preview_scene")()
        if src is not None:
            refs = Refs()
            refs.track(src, "obs_source_release")
            try:
                out["preview_scene"] = obs.obs_source_get_name(src)
            except Exception:
                pass
            refs.release_all()
    if _has("obs_frontend_virtualcam_active"):
        try:
            out["virtualcam"] = {"active": bool(obs.obs_frontend_virtualcam_active())}
        except Exception:
            pass
    if _has("obs_frontend_replay_buffer_active"):
        try:
            out["replay_buffer"] = {"active": bool(obs.obs_frontend_replay_buffer_active())}
        except Exception:
            pass
    if _has("obs_frontend_get_current_profile"):
        try:
            out["profile"] = obs.obs_frontend_get_current_profile()
        except Exception:
            pass
    if _has("obs_frontend_get_current_scene_collection"):
        try:
            out["scene_collection"] = obs.obs_frontend_get_current_scene_collection()
        except Exception:
            pass
    return out


def _api_version_int():
    fn = _fn("obs_get_version")
    if fn is None:
        return None
    try:
        raw = int(fn())
    except Exception:
        return None
    return ((raw >> 16) & 0xFF, (raw >> 8) & 0xFF, raw & 0xFF)


def _platform_name():
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    return "linux"


@op(
    "system.health",
    "健康检查：定时器是否存活、队列深度、引用计数审计、限流与错误统计（排障首选）",
    {},
)
def op_system_health(rt, a, ctx):
    h = rt.health()
    h["refs"] = AUDIT.snapshot()
    h["ok"] = (not h["refs"]["outstanding"]) and h["timer_alive"] and h["thread_alive"]
    if h["refs"]["outstanding"]:
        h["warnings"] = h.get("warnings", [])
        h["warnings"].append("检测到未释放的 OBS 引用，详见 refs.kinds（已自动回收，无需重启）")
    return h


@op("system.ping", "往返测试：经过主线程泵，返回各阶段耗时（用于判断卡死/延迟）", {"echo": ["any", False, "原样回带"]})
def op_system_ping(rt, a, ctx):
    return {"pong": True, "echo": a.get("echo"), "main_thread": threading.get_ident() == rt.main_thread_id, "t_ms": now_ms()}


@op("system.usage", "本连接的限流/用量与全局计数", {}, execution=EXEC_WORKER)
def op_system_usage(rt, a, ctx):
    conn = ctx.get("conn")
    out = rt.metrics()
    out["connection"] = conn.usage() if conn is not None else None
    return out


@op("system.log_tail", "读取 Nexus 日志尾部（排障用）", {"lines": ["int", False, "默认 80，最多 400"]}, advanced=True)
def op_log_tail(rt, a, ctx):
    n = _clamp(_int(a.get("lines"), 80) or 80, 1, 400)
    path = _LOG.path or os.path.join(nexus_dir(), "nexus.log")
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            data = fh.read(256 * 1024)
    except OSError as exc:
        raise err(E_OBS_FAILED, "无法读取日志: %r" % (exc,), details={"path": path})
    lines = _LOG.sanitize("\n".join(data.splitlines()[-n:]))
    return {"path": path, "lines": n, "text": lines}


# ============================== scene.* ===================================
@op(
    "scene.list",
    "列出所有场景（含当前活动场景、预览场景、场景数量、每个场景的源数量）",
    {"counts": ["bool", False, "是否附带每个场景的源数量（默认 true）"], "limit": ["int", False, "最多返回条数"]},
)
def op_scene_list(rt, a, ctx):
    refs = ctx["refs"]
    scenes = list_scenes(refs)
    cur = current_scene_name()
    preview = None
    if _has("obs_frontend_get_current_preview_scene"):
        src = _fn("obs_frontend_get_current_preview_scene")()
        if src is not None:
            refs.track(src, "obs_source_release")
            try:
                preview = obs.obs_source_get_name(src)
            except Exception:
                preview = None
    want_counts = _bool(a.get("counts"), True)
    limit = _clamp(_int(a.get("limit"), 200) or 200, 1, 1000)
    out = []
    total = len(scenes)
    for i, (name, scene) in enumerate(scenes[:limit]):
        row = {"index": i, "name": name, "current": (name == cur) if cur else False}
        if preview is not None:
            row["preview"] = name == preview
        if want_counts:
            try:
                row["source_count"] = count_items(scene)
            except Exception:
                row["source_count"] = None
        out.append(row)
    trans = None
    if _has("obs_frontend_get_transition_duration"):
        try:
            trans = int(obs.obs_frontend_get_transition_duration())
        except Exception:
            trans = None
    return {
        "scenes": out,
        "total": total,
        "returned": len(out),
        "truncated": total > len(out),
        "current_scene": cur,
        "preview_scene": preview,
        "transition_duration_ms": trans,
    }


def count_items(scene):
    """只数数量，不构造行数据（scene.list 用，避免 O(n) 读取属性）。"""
    fn = _fn("obs_scene_enum_items")
    if fn is None:
        return None
    n = [0]

    def cb(s, item, p):
        n[0] += 1
        return True

    try:
        fn(scene, cb, None)
    except Exception:
        return None
    return n[0]


@op(
    "scene.switch",
    "切换当前场景；mode=transition 时临时借用 OBS 的转场时长实现「平滑切换」",
    {
        "scene": ["str", True, "目标场景名（必须与 OBS 中一致）"],
        "mode": ['"cut"|"transition"', False, "cut=立即切换(默认)；transition=走转场动画"],
        "transition_duration_ms": ["int", False, "mode=transition 时临时使用的转场时长(50-20000)"],
    },
    mutating=True,
)
def op_scene_switch(rt, a, ctx):
    name = need(a, "scene")
    mode = str(arg(a, "mode", "cut")).strip().lower()
    if mode not in ("cut", "transition", "fade"):
        raise err(E_BAD_PARAMS, "mode 只能是 cut / transition / fade", details={"got": mode})
    refs = ctx["refs"]
    _, scene = resolve_scene(refs, name)
    src = _fn("obs_scene_get_source")(scene)
    if src is None:
        raise err(E_OBS_FAILED, "无法获取场景源对象")
    setter = _fn("obs_frontend_set_current_scene")
    if setter is None:
        raise err(E_UNSUPPORTED, "无 obs_frontend_set_current_scene")
    before = current_scene_name()
    used_ms = None
    if mode != "cut":
        used_ms = _clamp(_int(a.get("transition_duration_ms"), 600) or 600, 50, 20000)
        getd, setd = _fn("obs_frontend_get_transition_duration"), _fn("obs_frontend_set_transition_duration")
        if setd is not None and getd is not None:
            try:
                old_ms = int(getd())
            except Exception:
                old_ms = None
            setd(used_ms)
            if old_ms is not None:  # 转场启动后再恢复原时长，避免污染用户设置
                rt.defer(used_ms + 200, _restore_duration, old_ms)
        setter(src)
    else:
        setter(src)
    after = current_scene_name()
    if after != name:
        raise err(
            E_OBS_FAILED,
            "场景切换未生效（OBS 可能正在关闭或处于安全模式）",
            details={"requested": name, "current": after},
        )
    return {"previous_scene": before, "current_scene": after, "mode": mode, "transition_duration_ms": used_ms, "verified": True}


def _restore_duration(ms):
    fn = _fn("obs_frontend_set_transition_duration")
    if fn is not None:
        try:
            fn(int(ms))
        except Exception:
            pass


@op(
    "scene.create",
    "新建场景（advanced）。用 obs_source_create('scene') + obs_frontend_add_source，与 obs-websocket CreateScene 同路径",
    {"scene": ["str", True, "新场景名"], "set_current": ["bool", False, "是否切到该场景"]},
    advanced=True,
    mutating=True,
)
def op_scene_create(rt, a, ctx):
    name = ("%s" % need(a, "scene")).strip()[:128]
    if not name:
        raise err(E_BAD_PARAMS, "场景名不能为空")
    refs = ctx["refs"]
    try:
        resolve_scene(refs, name)
        exists = True
    except NexusError as exc:
        if exc.code != E_SCENE_NOT_FOUND:
            raise
        exists = False
    if exists and not _bool(a.get("reuse"), False):
        raise err(E_PRECONDITION, "场景已存在: %r" % name, details={"hint": "传 reuse:true 直接返回已有场景"})
    if _has("obs_source_create") and _has("obs_frontend_add_source"):
        src = obs.obs_source_create("scene", name, None, None)
        if src is None:
            raise err(E_OBS_FAILED, "obs_source_create('scene') 返回空")
        refs.track(src, "obs_source_release")
        obs.obs_frontend_add_source(src)
        created = "frontend"
    else:
        # 没有 obs_frontend_add_source 时，只能造出一个「不在前端场景列表里」的场景：
        # op 一结束引用归零，它立刻被 free —— 与其假装成功，不如明确说不支持。
        raise err(
            E_UNSUPPORTED,
            "当前 OBS 环境缺 obs_source_create/obs_frontend_add_source，无法安全地新建场景",
            details={"has_source_create": _has("obs_source_create"), "has_add_source": _has("obs_frontend_add_source")},
            hint="用完整版 OBS（含前端 API）跑脚本；只读类 op 不受影响。",
        )
    if _bool(a.get("set_current"), True):
        _fn("obs_frontend_set_current_scene")(src)
    return {"scene": name, "created": created != "frontend" or True, "via": created, "current_scene": current_scene_name()}


@op(
    "scene.remove",
    "删除场景（advanced，危险）。必须传 confirm:'DELETE' 才会执行",
    {"scene": ["str", True, "要删除的场景名"], "confirm": ["str", True, "必须为字面量 DELETE"]},
    advanced=True,
    mutating=True,
)
def op_scene_remove(rt, a, ctx):
    if ("%s" % arg(a, "confirm", "")).strip() != "DELETE":
        raise err(E_PRECONDITION, "删除场景需要显式确认：confirm 必须为 \"DELETE\"", hint="这是防止大模型误删用户工程的保护。")
    name = ("%s" % need(a, "scene")).strip()
    if name == current_scene_name():
        raise err(E_PRECONDITION, "不能删除当前活动场景，请先 scene.switch 切走")
    refs = ctx["refs"]
    scene_name, scene = resolve_scene(refs, name)
    src = obs.obs_scene_get_source(scene)
    if src is None:
        raise err(E_OBS_FAILED, "无法取得场景源")
    fn = _fn("obs_source_remove")
    if fn is None:
        raise err(E_UNSUPPORTED, "无 obs_source_remove")
    fn(src)
    rm = _fn("obs_frontend_remove_source")
    if rm is not None:
        try:
            rm(scene_name)
        except Exception:
            pass
    return {"removed": scene_name, "current_scene": current_scene_name()}


# ============================== source.* ==================================
def walk_scene_items(scene, recursive=True, limit=4000, max_depth=4):
    """把场景项快照成纯 python 结构（组内递归）。

    全部读取都在 obs_scene_enum_items 回调内完成，item 是**借用引用**，
    绝不 release；因此不存在跨回调悬挂指针，也不需要引用管理。
    layer 是同一层内的序号：0 = 最顶层（与 OBS UI 的上下顺序一致）。
    """
    enum = _fn("obs_scene_enum_items")
    if enum is None:
        raise err(E_UNSUPPORTED, "无 obs_scene_enum_items")
    budget = {"n": 0}

    def visit(sc, depth, parent):
        rows = []

        def cb(s, item, _p):
            if budget["n"] >= limit:
                return False
            budget["n"] += 1
            try:
                src = obs.obs_sceneitem_get_source(item)  # 借用引用
                name = (obs.obs_source_get_name(src) or "") if src is not None else ""
                rtype = (obs.obs_source_get_id(src) or "") if src is not None else ""
            except Exception as exc:
                rows.append({"name": "", "error": "read_failed:%s" % (exc,)})
                return True
            row = {"layer": len(rows), "depth": depth, "name": name, "type": rtype, "id": "%s%d" % (rtype[:8] or "src", _item_id(item) or 0)}
            try:
                row["item_id"] = _item_id(item)
            except Exception:
                row["item_id"] = None
            try:
                row["visible"] = bool(obs.obs_sceneitem_visible(item))
            except Exception:
                row["visible"] = None
            try:
                sel = _fn("obs_sceneitem_selected")
                row["selected"] = bool(sel(item)) if sel is not None else None
            except Exception:
                row["selected"] = None
            row["locked"] = item_locked(item)
            grouped = _is_group(item)
            if grouped:
                row["is_group"] = True
                if parent:
                    row["parent"] = parent
                if recursive and depth < max_depth:
                    gs = _fn("obs_sceneitem_group_get_scene")(item) if _has("obs_sceneitem_group_get_scene") else None
                    if gs is not None:
                        kids = visit(gs, depth + 1, name)
                        row["children"] = kids
                        row["child_count"] = len(kids)
            rows.append(row)
            return True

        try:
            enum(sc, cb, None)
        except Exception as exc:
            rows.append({"error": "enum_failed:%s" % (exc,)})
        return rows

    return visit(scene, 0, None)


def _is_group(item):
    try:
        fn = _fn("obs_sceneitem_is_group")
        if fn is not None:
            return bool(fn(item))
        c = _fn("obs_sceneitem_group_count_items")
        return bool(c and c(item) > 0)
    except Exception:
        return False


def flatten_rows(rows, out=None):
    out = [] if out is None else out
    for r in rows:
        out.append(r)
        kids = r.get("children")
        if isinstance(kids, list):
            flatten_rows(kids, out)
    return out


DEFAULT_ITEM_FIELDS = ("name", "type", "visible", "locked", "layer", "item_id")
ITEM_FIELD_DOC = "可选: name,type,visible,locked,layer,item_id,selected,transform,size,audio"


@op(
    "source.list",
    "列出场景内所有源（名称/类型/可见性/锁定/层级），支持分页与字段裁剪，避免撑爆上下文",
    {
        "scene": ["str", False, "场景名；留空 = 当前场景"],
        "limit": ["int", False, "默认 80，最大 400"],
        "offset": ["int", False, "分页偏移（顶层行序号；flatten:true 时是扁平序号）"],
        "recursive": ["bool", False, "是否展开组内子项（默认 true）"],
        "flatten": ["bool", False, "true = 把组内子项拉平成独立行（父行不再带 children）"],
        "fields": ["[str]", False, ITEM_FIELD_DOC],
        "detailed": ["bool", False, "true 时附带 transform/尺寸/音量等完整信息"],
    },
)
def op_source_list(rt, a, ctx):
    refs = ctx["refs"]
    sname, scene = resolve_scene(refs, scene_ref(a))
    limit = _clamp(_int(a.get("limit"), 80) or 80, 1, 400)
    offset = max(0, _int(a.get("offset"), 0) or 0)
    recursive = _bool(a.get("recursive"), True)
    detailed = _bool(a.get("detailed"), False)
    fields = a.get("fields")
    if fields is not None:
        if not isinstance(fields, (list, tuple)):
            raise err(E_BAD_PARAMS, "fields 必须是字符串数组")
        fields = tuple(str(f) for f in fields)
    else:
        fields = DEFAULT_ITEM_FIELDS + ("transform", "size", "audio") if detailed else DEFAULT_ITEM_FIELDS
    rows = walk_scene_items(scene, recursive=recursive, limit=min(4000, offset + limit + 8))
    if _bool(a.get("flatten"), False):
        # 拉平模式：子项成为独立行，父行不再带 children —— 同一份数据不会出现在两个地方
        rows = flatten_rows(rows)
        for r in rows:
            r.pop("children", None)
    total = len(rows)
    page = rows[offset : offset + limit]
    if page and ("transform" in fields or "size" in fields or "audio" in fields):
        _enrich_rows(scene, flatten_rows(page), fields)  # 复用同一批 dict，组内子项也会补齐
    keep = set(fields) | {"depth", "children", "child_count", "is_group", "parent", "error", "id"}

    def _trim(lst):
        for r in lst:
            for k in list(r.keys()):
                if k not in keep:
                    r.pop(k, None)
            kids = r.get("children")
            if isinstance(kids, list):
                _trim(kids)

    _trim(rows)
    out = {
        "scene": sname,
        "is_current": sname == current_scene_name(),
        "sources": page,
        "total": total,
        "returned": len(page),
        "offset": offset,
        "limit": limit,
        "truncated": total > offset + len(page),
    }
    if out["truncated"]:
        out["hint"] = "结果被截断：offset 翻页，或用 fields 裁剪字段省 token"
    return out


def _enrich_rows(scene, rows, fields):
    """只对本页（<=400 行）做额外读取，避免对全部源做 O(n) 昂贵查询。"""
    for row in rows:
        if row.get("error"):
            continue
        name = row.get("name")
        if not name:
            continue
        refs = Refs()
        try:
            item, src = _find_item_and_source(refs, scene, name)
            if src is None:
                continue
            if "transform" in fields and item is not None:
                info = _read_info(item)
                if info is not None:
                    row["transform"] = item_info_dict(item, info)
            if "size" in fields:
                w, h = source_size(src)
                row["width"], row["height"] = w, h
            if "audio" in fields:
                m = source_meta(src)
                if m.get("audio"):
                    row["audio"] = {k: m.get(k) for k in ("muted", "volume", "volume_db")}
        except Exception as exc:
            row["detail_error"] = "%r" % (exc,)
        finally:
            refs.release_all()


def _find_item_and_source(refs, scene, name):
    item = _find_scene_item(scene, name, refs)  # 借用引用已在内部 addref
    if item is None:
        return None, None
    try:
        src = obs.obs_sceneitem_get_source(item)
    except Exception:
        src = None
    return item, src


@op(
    "source.get",
    "读取单个源详情（设置项会被过滤、截断、脱敏）",
    {
        "source": ["str", True, "源名"],
        "scene": ["str", False, "场景名；留空 = 当前场景（找不到时回退全局查找）"],
        "settings": ["bool", False, "是否附带 obs_data 设置（默认 true）"],
        "keys": ["[str]", False, "只读取指定设置字段，省 token"],
        "filter": ["str", False, "附带读取该源上某个过滤器的设置"],
    },
)
def op_source_get(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    row = source_meta(src, include_settings=_bool(a.get("settings"), True), max_settings=_clamp(_int(a.get("max_settings"), 48) or 48, 1, 200))
    row["resolved_from"] = meta
    row["scene"] = sname
    keys = a.get("keys")
    if keys and isinstance(row.get("settings"), dict):
        wanted = set(str(k) for k in keys)
        row["settings"] = {k: v for k, v in row["settings"].items() if k in wanted or k == "_skipped"}
    fname = a.get("filter")
    if fname:
        fn = _fn("obs_source_get_filter_by_name")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_source_get_filter_by_name")
        f = fn(src, "%s" % fname)
        if f is None:
            raise err(E_OBS_FAILED, "找不到过滤器 %r" % fname, details={"source": name})
        refs.track(f, "obs_source_release")
        fm = source_meta(f, include_settings=True)
        fm["name"] = fname
        row["filter"] = fm
    return row


@op(
    "source.visibility",
    "设置/切换场景项可见性（AI 弹窗、贴图淡入淡出的基础动作）",
    {
        "source": ["str", True, "源名（组内源也支持）"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"],
        "scene": ["str", False, "场景名；留空 = 当前场景"],
        "visible": ["bool", False, "true=显示, false=隐藏"],
        "toggle": ["bool", False, "true=取反当前可见性（与 visible 二选一）"],
        "silent": ["bool", False, "不广播 source.visibility 事件（自己就是事件消费者时用，避免自激）"],
    },
    mutating=True,
)
def op_source_visibility(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    before = bool(obs.obs_sceneitem_visible(item))
    if _bool(a.get("toggle"), False):
        if a.get("visible") is not None:
            raise err(E_BAD_PARAMS, "toggle 与 visible 不能同时给")
        target = not before
    elif a.get("visible") is None:
        raise err(E_BAD_PARAMS, "需要 visible:true/false 或 toggle:true", details={"current": before})
    else:
        target = _bool(a.get("visible"), True)
    obs.obs_sceneitem_set_visible(item, bool(target))
    after = bool(obs.obs_sceneitem_visible(item))
    if after != bool(target):
        raise err(E_OBS_FAILED, "可见性设置未生效", details={"before": before, "wanted": target, "after": after})
    if after != before and not _bool(a.get("silent"), False):
        # 广播出去：别的 Agent / 前端就能同步「贴片被弹出来了」这件事，不用轮询 source.list
        rt.emit_event("source.visibility", {"scene": sname, "source": name, "visible": after, "by": "op"})
    return {"scene": sname, "source": name, "before": before, "visible": after, "changed": after != before}


@op(
    "source.lock",
    "给场景项打/解 Nexus 锁定标记（写入源私有设置 nexus_locked），供多 Agent 互斥",
    {"source": ["str", True, "源名"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"], "scene": ["str", False, "场景名"], "locked": ["bool", False, "true/false，缺省 true"]},
    mutating=True,
)
def op_source_lock(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    getp = _fn("obs_source_get_private_settings")
    if getp is None:
        raise err(E_UNSUPPORTED, "无 obs_source_get_private_settings（需要 OBS 26+）")
    data = getp(src)
    if data is None:
        raise err(E_OBS_FAILED, "无法取得源私有设置")
    refs.track(data, "obs_data_release")
    want = _bool(a.get("locked"), True)
    obs.obs_data_set_int(data, "nexus_locked", 1 if want else 0)
    return {"scene": sname, "source": name, "locked": bool(want), "note": "OBS 无原生场景项锁定 API，这是 Nexus 约定标记"}


@op(
    "source.transform",
    "修改场景项变换（位置/缩放/旋转/边界/裁剪）；读-改-写，未给出的字段保持原值",
    {
        "source": ["str", True, "源名"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"],
        "scene": ["str", False, "场景名"],
        "pos": ["[x,y]", False, "位置（像素）"],
        "scale": ["[sx,sy]", False, "缩放"],
        "scale_uniform": ["float", False, "等比缩放（优先于 scale）"],
        "rot": ["float", False, "旋转角度（度）"],
        "alignment": ["[x,y]", False, "对齐点（0/1 组合）"],
        "bounds_type": ["int", False, "OBS_BOUNDS_* 枚举"],
        "bounds_size": ["[w,h]", False, "边界尺寸"],
        "crop": ["{left,right,top,bottom}", False, "裁剪像素"],
    },
    mutating=True,
)
def op_source_transform(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    info = _read_info(item)
    if info is None:
        raise err(E_UNSUPPORTED, "无 obs_sceneitem_info_create/get_info（无法修改变换）")
    before = item_info_dict(item, info)
    touched = []

    def set_vec(attr, pair):
        v = getattr(info, attr, None)
        if v is None:
            raise err(E_UNSUPPORTED, "该 OBS 版本的 obs_sceneitem_info 没有字段 %s" % attr)
        try:
            v.x = float(pair[0])
            v.y = float(pair[1])
        except (TypeError, ValueError, IndexError):
            raise err(E_BAD_PARAMS, "%s 需要 [x, y] 两个数字" % attr, details={"got": pair})
        touched.append(attr)

    def set_num(attr, value):
        try:
            setattr(info, attr, value)
        except Exception as exc:
            raise err(E_UNSUPPORTED, "字段 %s 不可写: %r" % (attr, exc))
        touched.append(attr)

    if a.get("pos") is not None:
        set_vec("pos", a["pos"])
    if a.get("scale_uniform") is not None:
        f = _float(a.get("scale_uniform"), 1.0)
        set_vec("scale", [f, f])
    elif a.get("scale") is not None:
        set_vec("scale", a["scale"])
    if a.get("alignment") is not None:
        al = a["alignment"]
        if not isinstance(al, (list, tuple)) or len(al) < 2:
            raise err(E_BAD_PARAMS, "alignment 需要 [x, y]")
        set_vec("alignment", [int(_float(al[0], 0.0)), int(_float(al[1], 0.0))])
    if a.get("rot") is not None:
        set_num("rot", _float(a.get("rot"), 0.0))
    if a.get("bounds_size") is not None:
        bs = a["bounds_size"]
        if not isinstance(bs, (list, tuple)) or len(bs) < 2:
            raise err(E_BAD_PARAMS, "bounds_size 需要 [w, h]")
        set_vec("bounds", [_float(bs[0], 0.0), _float(bs[1], 0.0)])
    if a.get("bounds_type") is not None:
        set_num("bounds_type", _int(a.get("bounds_type"), 0))
    crop = a.get("crop")
    if isinstance(crop, dict):
        for key, attr in (("left", "crop_left"), ("right", "crop_right"), ("top", "crop_top"), ("bottom", "crop_bottom")):
            if crop.get(key) is not None:
                set_num(attr, max(0, _int(crop.get(key), 0) or 0))
    elif crop is not None:
        raise err(E_BAD_PARAMS, "crop 需要对象 {left,right,top,bottom}")
    if not touched:
        raise err(E_BAD_PARAMS, "没有给任何要修改的字段", hint="可用: pos/scale/scale_uniform/rot/alignment/bounds_type/bounds_size/crop")
    set_item_info(item, info)
    after = item_info_dict(item, _read_info(item))
    return {"scene": sname, "source": name, "set_fields": touched, "before": before, "after": after}


def _read_info(item):
    info = create_item_info()
    if info is None:
        return None
    fn = _fn("obs_sceneitem_get_info")
    if fn is None:
        return None
    try:
        fn(item, info)
    except Exception:
        return None
    return info


@op(
    "source.move",
    "调整层级顺序（置顶/置底/上移下移 N 步/绝对层号）",
    {
        "source": ["str", True, "源名"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"],
        "scene": ["str", False, "场景名"],
        "to": ['"top"|"bottom"', False, "置顶 / 置底"],
        "layer": ["int", False, "绝对层级（0=最顶层）"],
        "direction": ['"up"|"down"', False, "配合 steps 使用"],
        "steps": ["int", False, "上移/下移步数（1-200）"],
    },
    mutating=True,
)
def op_source_move(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    fn = _fn("obs_sceneitem_set_order")
    if fn is None:
        raise err(E_UNSUPPORTED, "无 obs_sceneitem_set_order")
    top, bottom, up, down = 0, 1, 2, 3
    applied = None
    if a.get("layer") is not None:
        total = count_items(scene) or 0
        want = _clamp(_int(a.get("layer"), 0) or 0, 0, max(0, total - 1))
        fn(item, top)
        for i in range(want):
            fn(item, down)
        applied = "layer=%d" % want
    else:
        to = str(arg(a, "to", "")).strip().lower()
        if to in ("top", "front"):
            fn(item, top)
            applied = "top"
        elif to in ("bottom", "back"):
            fn(item, bottom)
            applied = "bottom"
        else:
            d = str(arg(a, "direction", "")).strip().lower()
            steps = _clamp(_int(a.get("steps"), 1) or 1, 1, 200)
            if d not in ("up", "down"):
                raise err(E_BAD_PARAMS, "需要 to:top|bottom 或 direction:up|down 或 layer:int")
            for _ in range(steps):
                fn(item, up if d == "up" else down)
            applied = "%s*%d" % (d, steps)
    rows = [r for r in flatten_rows(walk_scene_items(scene, recursive=False, limit=500))]
    new_layer = None
    for r in rows:
        if r.get("name") == name:
            new_layer = r.get("layer")
            break
    return {"scene": sname, "source": name, "applied": applied, "layer": new_layer, "order": [r.get("name") for r in rows]}


# ============================ source.settings.* ===========================
@op(
    "source.settings_get",
    "读取源的原始设置（截断 + 脱敏）",
    {"source": ["str", True, "源名"], "scene": ["str", False, "场景名"], "keys": ["[str]", False, "字段白名单"]},
    advanced=True,
)
def op_settings_get(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    keys = a.get("keys")
    if keys is not None and not isinstance(keys, (list, tuple)):
        raise err(E_BAD_PARAMS, "keys 必须是字符串数组")
    st = source_settings(src, max_items=_clamp(_int(a.get("max_items"), 120) or 120, 1, 400), keys=list(keys) if keys else None)
    return {
        "scene": sname,
        "source": name,
        "type": meta.get("type") or "",  # 与 source.list 一致：类型 id 字符串（如 text_gdiplus_v2）
        "kind": meta.get("kind"),  # input / filter / transition（obs_source_get_type）
        "resolved_from": meta,
        "settings": st,
    }


@op(
    "source.settings_merge",
    "浅合并设置到源（obs_source_update）。危险动作，必须 confirm:true；长文本请用 text.set",
    {"source": ["str", True, "源名"], "settings": ["obj", True, "要合并的键值"], "confirm": ["bool", False, "必须 true"]},
    advanced=True,
    mutating=True,
)
def op_settings_merge(rt, a, ctx):
    if not _bool(a.get("confirm"), False):
        raise err(E_PRECONDITION, "source.settings_merge 需要 confirm:true（会直接改 OBS 源设置）")
    patch = a.get("settings")
    if not isinstance(patch, dict) or not patch:
        raise err(E_BAD_PARAMS, "settings 必须是非空对象")
    if len(patch) > 32:
        raise err(E_TOO_LARGE, "一次最多合并 32 个键", details={"got": len(patch)})
    long_keys = [k for k, v in patch.items() if isinstance(v, str) and len(v) > 2048]
    if long_keys:
        raise err(E_TOO_LARGE, "这些字段太长：%s；请改用 text.set" % ", ".join(long_keys[:4]))
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    data = _fn("obs_data_create")()
    if data is None:
        raise err(E_UNSUPPORTED, "无 obs_data_create")
    refs.track(data, "obs_data_release")
    applied = []
    skipped = []
    for k, v in patch.items():
        k = "%s" % k
        # obs_data 的键其实很保守（字母数字下划线点冒号）；出现路径分隔符/空格/控制符
        # 基本都是大模型在乱编，直接跳过而不是写进工程，避免留下删不掉的垃圾设置。
        if not re.match(r"^[A-Za-z0-9_\-.:#\[\]]{1,64}$", k):
            skipped.append({"key": k, "why": "invalid_key"})
            continue
        try:
            _data_set(data, k, v, skipped)
            applied.append(k)
        except Exception as exc:
            skipped.append({"key": k, "why": repr(exc)})
    if not applied:
        raise err(E_BAD_PARAMS, "没有可应用的字段", details={"skipped": skipped[:8]})
    obs.obs_source_update(src, data)
    return {"scene": sname, "source": name, "applied": applied, "skipped": skipped[:8], "resolved_from": meta}


def _data_set(data, key, value, skipped=None):
    if isinstance(value, bool):
        obs.obs_data_set_bool(data, key, value)
    elif isinstance(value, int):
        obs.obs_data_set_int(data, key, value)
    elif isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            raise err(E_BAD_PARAMS, "%s: 数字非法" % key)
        obs.obs_data_set_double(data, key, value)
    elif isinstance(value, str):
        obs.obs_data_set_string(data, key, value)
    elif isinstance(value, (list, tuple)):
        create = _fn("obs_data_array_create")
        arr = create() if create else None
        if arr is None:
            raise err(E_UNSUPPORTED, "无 obs_data_array_create")
        rel_arr = _fn("obs_data_array_release")
        add = _fn("obs_data_array_push_back")
        for item in value[:256]:
            obj = _fn("obs_data_create")()
            try:
                _data_set(obj, "value", item if not isinstance(item, (list, tuple, dict)) else json.dumps(item, ensure_ascii=False))
                if obj is not None:
                    AUDIT.acquire(obj, "obs_data_release")
                add(arr, obj)
            finally:
                if obj is not None:
                    _release("obs_data_release", obj)
        try:
            AUDIT.acquire(arr, "obs_data_array_release")
            obs.obs_data_set_array(data, key, arr)
        finally:
            if rel_arr is not None:
                _release("obs_data_array_release", arr)
    elif value is None:
        obs.obs_data_set_string(data, key, "")
    else:
        obs.obs_data_set_string(data, key, json.dumps(value, ensure_ascii=False)[:4096])


# ================================ text.* ==================================
def _text_source_keys(src):
    """返回该文本源可能使用的文本字段名（按优先级）。"""
    ids = []
    for fn in ("obs_source_get_unversioned_id", "obs_source_get_id"):
        f = _fn(fn)
        if f is not None:
            try:
                v = f(src)
                if v:
                    ids.append(v)
            except Exception:
                pass
    keys = []
    for i in ids:
        for k in TEXT_TYPE_MAP.get(i, ()):
            if k not in keys:
                keys.append(k)
    return keys, (ids[0] if ids else ""), (ids[1] if len(ids) > 1 else "")


@op(
    "text.set",
    "更新文本源内容（GDI+ 2 / FreeType 2 / 文本浏览器 title），Agent 实时输出解说词的核心动作",
    {
        "source": ["str", True, "文本源名称"],
        "text": ["str", False, "新内容；留空配合 clear:true 可清空"],
        "file": ["str", False, "从该文件读取内容（二选一，适合长文案）"],
        "filter": ["str", False, "目标是源上的文本过滤器时给出过滤器名"],
        "append": ["bool", False, "true = 追加到现有文本末尾（用 \\n 连接）"],
        "clear": ["bool", False, "true = 清空文本"],
        "silent": ["bool", False, "不广播 text.updated 事件（自己就是事件消费者时用，避免自激）"],
        "scene": ["str", False, "场景名（留空 = 当前场景）"],
        "force": ["bool", False, "源类型不是已知文本源时仍尝试写入 text 字段"],
        "override_read_from_file": ["bool", False, "源开启了『读取文件』模式时，改为直接写文本字段并关掉该模式"],
        "refresh_properties": ["bool", False, "调用 obs_source_update_properties 刷新属性面板"],
    },
    mutating=True,
)
def op_text_set(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")

    fname = a.get("filter")
    if fname:
        fn = _fn("obs_source_get_filter_by_name")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_source_get_filter_by_name")
        f = fn(src, "%s" % fname)
        if f is None:
            raise err(E_OBS_FAILED, "源 %r 上没有过滤器 %r" % (name, fname))
        refs.track(f, "obs_source_release")
        src = f

    keys, stype, unversioned = _text_source_keys(src)
    force = _bool(a.get("force"), False)
    if not keys:
        if not force:
            raise err(
                E_WRONG_TYPE,
                "源 %r 的类型是 %r，不是已知文本源" % (name, stype),
                details={
                    "type": stype,
                    "known_text_types": list(TEXT_TYPE_IDS),
                    "note": "「文本」(text) 是 OBS 28 之前的旧类型，已不存在",
                },
                hint="在 OBS 里改用「GDI+ 文本 (」或「FreeType 2 文本」；确认无误可加 force:true 强写 text 字段。",
            )
        keys = ["text"]

    # ---- 取新内容 ----
    text = a.get("text")
    if text is None:
        text = a.get("value")
    src_file = a.get("file")
    if src_file:
        path = os.path.abspath(os.path.expanduser("%s" % src_file))
        try:
            size = os.path.getsize(path)
        except OSError as exc:
            raise err(E_BAD_PARAMS, "无法读取文本文件: %r" % (exc,), details={"path": path})
        cap = rt.limits["max_text_bytes"]
        if size > cap:
            raise err(E_TOO_LARGE, "文本文件 %d 字节超过上限 %d" % (size, cap), details={"path": path})
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read(cap + 1)
        except OSError as exc:
            raise err(E_BAD_PARAMS, "读取文本文件失败: %r" % (exc,))
    if text is None:
        if _bool(a.get("clear"), False):
            text = ""
        else:
            raise err(E_BAD_PARAMS, "缺少 text（或 file / clear:true）")
    if isinstance(text, (dict, list)):
        text = json.dumps(text, ensure_ascii=False)
    text = ("%s" % text).replace("\r\n", "\n").replace("\r", "\n")

    cap = rt.limits["max_text_bytes"]
    raw = text.encode("utf-8")
    truncated = False
    if len(raw) > cap:
        if not _bool(a.get("truncate"), False):
            raise err(
                E_TOO_LARGE,
                "文本 %d 字节超过上限 %d" % (len(raw), cap),
                hint="缩短内容，或传 truncate:true，或调大脚本属性 max_text_bytes。",
            )
        text = raw[:cap].decode("utf-8", "ignore")
        truncated = True
    if _bool(a.get("append"), False):
        cur = _read_text(src, keys)
        if cur:
            text = cur + "\n" + text

    # ---- 「读取文件」模式冲突检测 ----
    settings = source_settings(src, keys=["read_from_file", "file", "custom_width", "font"], max_items=8) or {}
    if _bool(settings.get("read_from_file"), False) and not _bool(a.get("override_read_from_file"), False):
        raise err(
            E_PRECONDITION,
            "源 %r 开启了「读取文件」模式，写 text 字段不会生效" % name,
            details={"read_from_file": True, "file": settings.get("file")},
            hint="关掉该勾选，或传 override_read_from_file:true 让 Nexus 帮你关掉并直接写文本。",
        )

    data = _fn("obs_data_create")()
    if data is None:
        raise err(E_UNSUPPORTED, "无 obs_data_create")
    refs.track(data, "obs_data_release")
    obs.obs_data_set_string(data, keys[0], text)
    if _bool(settings.get("read_from_file"), False):
        obs.obs_data_set_bool(data, "read_from_file", False)
    for extra in keys[1:]:  # 兼容某些版本同时存在两个 key
        try:
            obs.obs_data_set_string(data, extra, text)
        except Exception:
            pass
    before = _read_text(src, keys)
    obs.obs_source_update(src, data)
    if _bool(a.get("refresh_properties"), True):
        fn = _fn("obs_source_update_properties")
        if fn is not None:
            try:
                fn(src)
            except Exception:
                pass
    after = _read_text(src, keys)
    result = {
        "scene": sname,
        "source": name,
        "type": stype or unversioned,
        "field": keys[0],
        "chars": len(after or ""),
        "bytes": len((after or "").encode("utf-8")),
        "verified": after == text,
        "text": after if rt.props.get("echo_text", True) else None,
        "changed": before != after,
    }
    if truncated:
        result["truncated"] = True
    if not result["verified"]:
        result["warning"] = "回读内容与写入不一致：可能被过滤器/编码或源自身逻辑改写"
    if result["changed"] and not _bool(a.get("silent"), False):
        rt.emit_event(
            "text.updated",
            {"scene": sname, "source": name, "field": keys[0], "chars": result["chars"], "text": result.get("text"), "by": "op"},
        )
    return result


def _read_text(src, keys):
    if src is None:
        return None
    get = _fn("obs_source_get_settings")
    rel = _fn("obs_data_release")
    data = get(src) if get is not None else None
    if data is None:
        return None
    AUDIT.acquire(data, "obs_data_release")
    try:
        for k in list(keys) + ["text", "text_gdiplus", "text_freetype"]:
            try:
                v = obs.obs_data_get_string(data, k)
            except Exception:
                v = ""
            if v:
                return v
        return ""
    finally:
        if rel is not None:
            _release("obs_data_release", data)


@op(
    "text.get",
    "读取文本源当前内容（供 Agent 读取上下文 / 校对）",
    {"source": ["str", True, "文本源名"], "scene": ["str", False, "场景名"], "filter": ["str", False, "文本过滤器名"]},
)
def op_text_get(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    fname = a.get("filter")
    if fname:
        fn = _fn("obs_source_get_filter_by_name")
        f = fn(src, "%s" % fname) if fn is not None else None
        if f is None:
            raise err(E_OBS_FAILED, "找不到过滤器 %r" % fname)
        refs.track(f, "obs_source_release")
        src = f
    keys, stype, _unv = _text_source_keys(src)
    if not keys:
        keys = ["text"]
    text = _read_text(src, keys)
    out = {"scene": sname, "source": name, "type": stype, "field": keys[0], "text": text, "chars": len(text or "")}
    if text is not None and len(text.encode("utf-8")) > rt.limits["max_text_bytes"]:
        out["text"] = text[: rt.limits["max_text_bytes"] // 4]
        out["truncated"] = True
    return out


# ================================ audio.* =================================
MONITORING_NAMES = {0: "none", 1: "monitor_only", 2: "monitor_and_output", 4: "output_only"}
CHANNEL_NAMES = {0: "none", 1: "mono", 2: "stereo", 3: "quad", 4: "5.1", 5: "7.1"}


def _audio_status_row(src, name=None):
    row = {}
    try:
        row["name"] = obs.obs_source_get_name(src) if name is None else name
        row["type"] = obs.obs_source_get_id(src)
    except Exception:
        pass
    try:
        row["muted"] = bool(obs.obs_source_muted(src))
    except Exception:
        row["muted"] = None
    try:
        vol = float(obs.obs_source_get_volume(src))
    except Exception:
        vol = None
    row["volume"] = round(vol, 5) if vol is not None else None
    row["volume_percent"] = round(vol * 100.0, 2) if vol is not None else None
    row["volume_db"] = vol_to_db(vol) if vol is not None else None
    fn = _fn("obs_source_get_audio_sync")
    if fn is not None:
        try:
            row["sync_offset_ms"] = round(float(fn(src)) * 1000.0, 1)
        except Exception:
            pass
    for fname in ("obs_source_get_monitoring_type", "obs_source_get_audio_monitoring_type"):
        fn = _fn(fname)
        if fn is not None:
            try:
                row["audio_monitoring"] = MONITORING_NAMES.get(int(fn(src)), int(fn(src)))
                break
            except Exception:
                pass
    fn = _fn("obs_source_get_channel") or _fn("obs_source_get_speaker_layout")
    if fn is not None:
        try:
            row["channel_layout"] = CHANNEL_NAMES.get(int(fn(src)), int(fn(src)))
        except Exception:
            pass
    fn = _fn("obs_source_push_to_mute_enabled")
    if fn is not None:
        try:
            row["push_to_mute"] = bool(fn(src))
        except Exception:
            pass
    row["audio_source"] = bool(source_has_audio(src))
    row["meter"] = None
    row["meter_note"] = "OBS 脚本 API 不暴露实时电平表（峰值/RMS 需要 obs-websocket 或原生插件）"
    return row


def _require_audio_source(src, name):
    if not source_has_audio(src):
        raise err(
            E_WRONG_TYPE,
            "源 %r (type=%r) 没有音频能力" % (name, obs.obs_source_get_id(src) if _has("obs_source_get_id") else "?"),
            hint="音频操作只支持麦克风/桌面音频/媒体源/音频输出捕获等。",
        )


@op(
    "audio.status",
    "读取音频源音量(dB/百分比)、静音、同步偏移、监听方式；all:true 一次读全部音频源",
    {"source": ["str", False, "源名（all=true 时可省略）"], "scene": ["str", False, "场景名"], "all": ["bool", False, "列出全部音频源"]},
)
def op_audio_status(rt, a, ctx):
    refs = ctx["refs"]
    if not str(arg(a, "source", "") or "").strip() and not _bool(a.get("all"), False):
        raise err(
            E_BAD_PARAMS,
            "audio.status 需要 source，或者 all:true 一次读全部音频源",
            hint='例：{"op":"audio.status","all":true}',
        )
    if _bool(a.get("all"), False):
        sname, scene = resolve_scene(refs, scene_ref(a))
        rows = []
        names = []
        for r in flatten_rows(walk_scene_items(scene, recursive=True, limit=300)):
            if r.get("name") and r["name"] not in names:
                names.append(r["name"])
        for group in ("mic", "desktop", "aux"):
            for alias in AUDIO_NAME_ALIASES.get(group, ()):
                if alias not in names:
                    names.append(alias)
        for n in names[:64]:
            try:
                src, m = resolve_source(refs, n, scene=scene, scope="auto")
            except NexusError:
                continue
            if not source_has_audio(src):
                continue
            row = _audio_status_row(src, n)
            row["scene_item"] = m.get("where")
            rows.append(row)
        return {"scene": sname, "count": len(rows), "audio_sources": rows}
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    row = _audio_status_row(src, name)
    if not row.get("audio_source"):
        row["warning"] = "该源没有音频能力，音量字段可能无意义"
    row["resolved_from"] = meta
    row["scene"] = sname
    return row


@op(
    "audio.mute",
    "设置/切换音频源静音",
    {"source": ["str", True, "源名"], "muted": ["bool", False, "true=静音"], "toggle": ["bool", False, "取反"], "scene": ["str", False, "场景名"]},
    mutating=True,
)
def op_audio_mute(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    _require_audio_source(src, name)
    before = bool(obs.obs_source_muted(src))
    if _bool(a.get("toggle"), False):
        target = not before
    elif a.get("muted") is None:
        raise err(E_BAD_PARAMS, "需要 muted:true/false 或 toggle:true", details={"current": before})
    else:
        target = _bool(a.get("muted"), True)
    obs.obs_source_set_muted(src, bool(target))
    after = bool(obs.obs_source_muted(src))
    if after != bool(target):
        raise err(E_OBS_FAILED, "静音状态未生效", details={"wanted": target, "after": after})
    return {"scene": sname, "source": name, "before": before, "muted": after, "changed": before != after}


@op(
    "audio.volume",
    "调整音频源音量：percent / db / delta_db / delta_percent 四选一（OBS 线性音量 0..2）",
    {
        "source": ["str", True, "源名"],
        "percent": ["float", False, "0-200（100 = 0dB）"],
        "db": ["float", False, "-100..+6 dB"],
        "delta_db": ["float", False, "在当前基础上加 dB"],
        "delta_percent": ["float", False, "在当前基础上加百分比"],
        "scene": ["str", False, "场景名"],
    },
    mutating=True,
)
def op_audio_volume(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    _require_audio_source(src, name)
    try:
        cur = float(obs.obs_source_get_volume(src))
    except Exception:
        cur = 1.0
    given = [k for k in ("percent", "db", "delta_db", "delta_percent", "volume") if a.get(k) is not None]
    if not given:
        raise err(E_BAD_PARAMS, "需要 percent / db / delta_db / delta_percent 之一", details={"current_percent": round(cur * 100.0, 2)})
    if len(given) > 1:
        raise err(E_BAD_PARAMS, "只能给一个音量字段", details={"given": given})
    which = given[0]
    v = _float(a.get(which), 0.0)
    if which == "percent":
        if not (-0.001 <= v <= 200.0):
            raise err(E_BAD_PARAMS, "percent 需要在 0..200", details={"got": v})
        new = v / 100.0
    elif which == "volume":
        new = v
    elif which == "db":
        if not (-100.0 <= v <= 6.0):
            raise err(E_BAD_PARAMS, "db 需要在 -100..+6", details={"got": v})
        new = db_to_vol(v)
    elif which == "delta_db":
        new = db_to_vol(vol_to_db(cur) + v)
    else:
        new = _clamp(cur + v / 100.0, 0.0, 2.0)
    new = _clamp(new, 0.0, 2.0)
    obs.obs_source_set_volume(src, float(new))
    try:
        after = float(obs.obs_source_get_volume(src))
    except Exception:
        after = new
    return {
        "scene": sname,
        "source": name,
        "before_percent": round(cur * 100.0, 2),
        "before_db": vol_to_db(cur),
        "volume_percent": round(after * 100.0, 2),
        "volume_db": vol_to_db(after),
        "raw_volume": round(after, 5),
        "input": {which: v},
    }


# ============================== stream.* ==================================
STREAM_ACTIONS = {
    "start_stream": ("stream", True),
    "stop_stream": ("stream", False),
    "start_record": ("record", True),
    "stop_record": ("record", False),
    "pause_record": ("record_pause", True),
    "unpause_record": ("record_pause", False),
    "toggle_record": ("record", None),
    "split_record_file": ("record_split", None),
    "add_chapter": ("record_chapter", None),
    "start_replay_buffer": ("replay", True),
    "stop_replay_buffer": ("replay", False),
    "save_replay": ("replay_save", None),
    "start_virtualcam": ("vcam", True),
    "stop_virtualcam": ("vcam", False),
    "toggle_virtualcam": ("vcam", None),
}


@op(
    "stream.control",
    "控制推流/录制/虚拟摄像头：start_stream stop_stream start_record stop_record pause_record unpause_record ...",
    {
        "action": ["|".join(sorted(STREAM_ACTIONS)), True, "要执行的动作"],
        "chapter": ["str", False, "add_chapter 的章节名"],
        "wait": ["bool", False, "true = 等到状态真的变化（跨 tick 轮询，不阻塞主线程）"],
        "wait_ms": ["int", False, "等待上限，默认 3000"],
        "confirm": ["bool", False, "stop_stream 需要 confirm:true 防误触"],
    },
    mutating=True,
)
def op_stream_control(rt, a, ctx):
    action = ("%s" % need(a, "action")).strip().lower()
    spec = STREAM_ACTIONS.get(action)
    if spec is None:
        raise err(
            E_UNKNOWN_OP,
            "未知 action: %r" % action,
            details={"supported": sorted(STREAM_ACTIONS.keys())},
            hint="见 stream.control 的 args 文档。",
        )
    kind, want = spec
    st = {}
    if kind == "stream":
        if want is None:
            raise err(E_BAD_PARAMS, "stream 不支持 toggle")
        if action == "stop_stream" and not _bool(a.get("confirm"), False):
            raise err(E_PRECONDITION, "停止推流需要 confirm:true（会影响直播）", hint="确认要断开直播就传 confirm:true。")
        cur = _stream_state()
        if want and (cur["active"] or cur["pending"]):
            return {"action": action, "skipped": "already_active", "streaming": cur}
        if not want and not (cur["active"] or cur["stopping"]):
            return {"action": action, "skipped": "not_active", "streaming": cur}
        fn = _fn("obs_frontend_streaming_start" if want else "obs_frontend_streaming_stop")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 %s" % (fn,))
        fn()
        st = {"streaming": _stream_state()}
        target = bool(want)
        check = lambda: (_stream_state().get("active") is target)
    elif kind == "record":
        cur = _record_state()
        if want and cur["active"]:
            return {"action": action, "skipped": "already_recording", "recording": cur}
        if not want and not cur["active"]:
            return {"action": action, "skipped": "not_recording", "recording": cur}
        fn = _fn("obs_frontend_recording_start" if want else "obs_frontend_recording_stop")
        if fn is None:
            raise err(E_UNSUPPORTED, "OBS 未提供录制控制函数")
        fn()
        st = {"recording": _record_state()}
        target = bool(want)
        check = lambda: (_record_state().get("active") is target)
    elif kind == "record_pause":
        cur = _record_state()
        if not cur["active"]:
            raise err(E_PRECONDITION, "当前没有录制，无法暂停/恢复", details={"recording": cur})
        if bool(cur["paused"]) == bool(want):
            return {"action": action, "skipped": "already_in_state", "recording": cur}
        fn = _fn("obs_frontend_recording_pause")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_recording_pause")
        fn(bool(want))
        st = {"recording": _record_state()}
        check = lambda: (_record_state().get("paused") is bool(want))
    elif kind == "record_split":
        fn = _fn("obs_frontend_recording_split_file")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_recording_split_file")
        okv = bool(fn())
        st = {"accepted": okv, "recording": _record_state()}
        if not okv:
            raise err(E_PRECONDITION, "OBS 拒绝了分片请求（未录制 / 已暂停 / 未开启自动分段）", details=st)
        check = None
    elif kind == "record_chapter":
        fn = _fn("obs_frontend_recording_add_chapter")
        if fn is None:
            raise err(E_UNSUPPORTED, "obs_frontend_recording_add_chapter 需要 OBS 30.2+", details={"obs_version": obs_version_string()})
        okv = bool(fn(a.get("chapter") or ("AI chapter %s" % time.strftime("%H:%M:%S"))))
        st = {"accepted": okv, "recording": _record_state()}
        check = None
    elif kind == "replay":
        cur = {}
        if _has("obs_frontend_replay_buffer_active"):
            cur = {"active": bool(obs.obs_frontend_replay_buffer_active())}
        else:
            raise err(E_UNSUPPORTED, "无 obs_frontend_replay_buffer_active")
        fn = _fn("obs_frontend_replay_buffer_start" if want else "obs_frontend_replay_buffer_stop")
        if fn is None:
            raise err(E_UNSUPPORTED, "无回放缓冲控制函数")
        fn()
        st = {"replay_buffer": {"active": bool(obs.obs_frontend_replay_buffer_active())}}
        check = None
    elif kind == "replay_save":
        fn = _fn("obs_frontend_replay_buffer_save")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_replay_buffer_save")
        fn()
        st = {"requested": True}
        check = None
    else:  # vcam
        if _has("obs_frontend_virtualcam_active"):
            active = bool(obs.obs_frontend_virtualcam_active())
        else:
            active = False
        target = (not active) if want is None else bool(want)
        fn = _fn("obs_frontend_start_virtualcam" if target else "obs_frontend_stop_virtualcam")
        if fn is None:
            raise err(E_UNSUPPORTED, "OBS 未提供虚拟摄像头控制")
        fn()
        st = {"virtualcam": {"active": bool(_fn("obs_frontend_virtualcam_active")()) if _has("obs_frontend_virtualcam_active") else None}}
        check = lambda: bool(_fn("obs_frontend_virtualcam_active")()) == target if _has("obs_frontend_virtualcam_active") else None
    waited = None
    if _bool(a.get("wait"), False) and check is not None:
        timeout = _clamp(_int(a.get("wait_ms"), 3000) or 3000, 50, 15000)

        def poll(state=None):
            try:
                done = bool(check())
            except Exception:
                done = False
            if not done:
                return None
            snapshot = {"streaming": _stream_state(), "recording": _record_state()}
            return dict(
                {"action": action, "waited_ms": int(state.elapsed * 1000) if state else 0, "reached": True},
                **snapshot
            )

        return Async(poll, timeout_ms=timeout, note={"pending_action": action, **st})
    return {"action": action, "confirmed_immediately": check is None, **st}


# ============================== canvas.* ==================================
def _snapshot_dirs():
    """截图落盘候选目录（obs_frontend_get_last_screenshot 不可用时的兜底）。"""
    rt = _SERVER
    dirs = []
    if rt is not None:
        d = (rt.props or {}).get("snapshot_dir")
        if d:
            dirs.append(os.path.abspath(os.path.expanduser(d)))
    dirs.append(os.path.join(nexus_dir(), "snapshots"))
    fn = _fn("obs_frontend_get_recordings_folder")
    if fn is not None:
        try:
            v = fn()
            if v:
                dirs.append(v)
        except Exception:
            pass
    for env in ("USERPROFILE", "HOME"):
        home = os.environ.get(env)
        if home:
            dirs.append(os.path.join(home, "Pictures"))
    fn = _fn("obs_frontend_get_current_profile_path")
    if fn is not None:
        try:
            v = fn()
            if v:
                dirs.append(v)
        except Exception:
            pass
    seen, out = set(), []
    for d in dirs:
        if not d:
            continue
        d = os.path.normpath(d)
        if d not in seen and os.path.isdir(d):
            seen.add(d)
            out.append(d)
    return out


def snapshot_capability():
    rt = _SERVER
    props = (rt.props if rt is not None else {}) or {}
    mode = str(props.get("snapshot_mode") or "auto")
    have_native = _has("obs_frontend_take_screenshot") and _has("obs_frontend_get_last_screenshot")
    modes = []
    if have_native:
        modes.append("native")
    if props.get("snapshot_command"):
        modes.append("command")
    modes.append("dir")
    if mode == "off":
        modes = []
    return {
        "available": bool(modes),
        "mode": mode,
        "supported_modes": modes,
        "native_api": bool(have_native),
        "source_screenshot_api": bool(_has("obs_frontend_take_source_screenshot")),
        "pil_jpeg": _PILImage is not None,
        "jpeg_inline": bool(have_native and (_PILImage is not None or True)),
        "dirs": _snapshot_dirs()[:4],
        "hint": "OBS 侧格式在「设置-高级-截图」；没有 Pillow 时 jpeg 会失败，可用 format:'png' 或 format:'file'"
        if _PILImage is None
        else None,
    }


def _encode_snapshot(path, want_format, max_bytes, max_width, quality=82):
    """读取截图 -> (format, base64, bytes, width, height)；必要时用 PIL 压缩/缩放。"""
    try:
        size = os.path.getsize(path)
    except OSError as exc:
        raise err(E_TIMEOUT, "截图文件不可读: %r" % (exc,), details={"path": path}, retryable=True)
    if size > max_bytes:
        raise err(
            E_TOO_LARGE,
            "截图 %d 字节超过上限 %d" % (size, max_bytes),
            hint="调小 width / 降低 max_bytes / 或在 OBS 设置里把截图格式改成 JPEG。",
            details={"path": path},
        )
    try:
        with open(path, "rb") as fh:
            raw = fh.read(max_bytes + 1)
    except OSError as exc:
        raise err(E_TIMEOUT, "读取截图失败: %r" % (exc,), retryable=True)
    ext = os.path.splitext(path)[1].lower()
    fmt = "jpeg" if ext in (".jpg", ".jpeg") else ("png" if ext == ".png" else "png")
    info = {"width": None, "height": None, "converted": False}
    do_convert = _PILImage is not None and (want_format in ("jpeg", "jpg") or (max_width or 0) > 0)
    if do_convert:
        try:
            from io import BytesIO

            im = _PILImage.open(BytesIO(raw))
            if im.mode not in ("RGB", "L"):
                im = im.convert("RGB")
            if max_width and im.width > max_width:
                im = im.resize((int(max_width), max(1, int(im.height * float(max_width) / im.width))), _PILImage.LANCZOS)
            buf = BytesIO()
            if want_format in ("jpeg", "jpg"):
                im.save(buf, format="JPEG", quality=int(quality or 82), optimize=True, progressive=False)
                fmt = "jpeg"
            else:
                im.save(buf, format="PNG", optimize=True)
            raw = buf.getvalue()
            info = {"width": im.width, "height": im.height, "converted": True}
            im.close()
        except Exception as exc:
            _LOG.debug("PIL 转码失败（退回原图）: %r" % (exc,))
    if want_format in ("jpeg", "jpg") and fmt != "jpeg" and _PILImage is None:
        raise err(
            E_UNSUPPORTED,
            "请求 JPEG 但 OBS 保存的是 %s，且运行环境没有 Pillow 可用于转码" % fmt,
            hint="在 OBS「设置-高级-截图」里把格式改成 JPEG；或 format:'png' / format:'file'；"
            "或 pip install Pillow 到 OBS 的 python 环境。",
            details={"path": path, "pil": False},
        )
    if len(raw) > max_bytes:
        raise err(E_TOO_LARGE, "转码后仍有 %d 字节" % len(raw), details={"max_bytes": max_bytes})
    b64 = base64.b64encode(raw).decode("ascii")
    return fmt, b64, len(raw), info


@op(
    "canvas.snapshot",
    "抓取画布或指定源的截图：走 OBS 原生截图管线落盘后回传 Base64（推荐高频时用 format:file）",
    {
        "source": ["str", False, "留空 = 主输出(Program/Preview 合成)；可填源名或场景名"],
        "scene": ["str", False, "解析 source 时使用的场景（留空 = 当前场景）"],
        "format": ['"jpeg"|"png"|"file"', False, "file = 只回路径，不做 base64（省 token/省 CPU）"],
        "width": ["int", False, "最长边像素，需 Pillow 才能缩放"],
        "quality": ["int", False, "JPEG 质量 20-100，需 Pillow"],
        "max_bytes": ["int", False, "base64 之前的字节上限（默认取脚本属性）"],
        "mode": ['"auto"|"native"|"dir"|"command"', False, "抓取后端；off 表示禁用"],
        "timeout_ms": ["int", False, "等待 OBS 写出文件的超时（默认 2500）"],
        "save_copy": ["str", False, "额外把图片另存到该路径"],
        "must_be_last": ["bool", False, "内部约束：snapshot 之后的 op 会被拒绝（异步收尾）"],
    },
)
def op_canvas_snapshot(rt, a, ctx):
    if not ctx.get("is_last", True):
        raise err(
            E_BAD_PARAMS,
            "canvas.snapshot 必须是批量里的最后一个 op",
            hint="截图是 OBS 异步落盘 + 网络线程收尾的模式，放到最后才能保证顺序语义；"
            "需要在它之前做别的操作就分成两次请求。",
        )
    mode = str(arg(a, "mode", (rt.props or {}).get("snapshot_mode") or "auto")).strip().lower()
    if mode == "off":
        raise err(E_UNSUPPORTED, "canvas.snapshot 已被脚本属性禁用（snapshot_mode=off）", hint="在脚本属性里改回 auto/native。")
    fmt_want = str(arg(a, "format", "jpeg")).strip().lower()
    if fmt_want not in ("jpeg", "jpg", "png", "file"):
        raise err(E_BAD_PARAMS, "format 只能是 jpeg / png / file", details={"got": fmt_want})
    quality = _clamp(_int(a.get("quality"), (rt.props or {}).get("snapshot_quality", 82)) or 82, 20, 100)
    max_bytes = _clamp(
        _int(a.get("max_bytes"), (rt.props or {}).get("max_snapshot_bytes") or MAX_SNAPSHOT_BYTES) or MAX_SNAPSHOT_BYTES,
        16 * 1024,
        MAX_SNAPSHOT_BYTES,
    )
    max_width = max(0, _int(a.get("width"), 0) or 0)
    timeout = _clamp(_int(a.get("timeout_ms"), (rt.props or {}).get("snapshot_timeout_ms", 2500)) or 2500, 100, 10000)
    dirs = _snapshot_dirs()
    refs = ctx["refs"]
    prev_last = None
    src = None
    sname = None
    name = a.get("source")
    if name:
        sname, scene = resolve_scene(refs, scene_ref(a))
        src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    # 记下触发前已存在的图片：兜底扫目录时只认「新出现」的文件，
    # 否则可能把上一次截图当成这次的结果返回（静默错误，比超时更糟）。
    exclude = set()
    if prev_last:
        exclude.add(prev_last)
    if mode != "dir":  # dir 模式就是要取「已有」的最新图，不能排除
        for d in dirs[:4]:
            try:
                for e in os.scandir(d):
                    exclude.add(e.path)
                    if len(exclude) > 800:
                        break
            except OSError:
                continue
    common = {
        "op": "canvas.snapshot",
        "format": "file" if fmt_want in ("file",) else ("png" if fmt_want == "png" else "jpeg"),
        "max_bytes": max_bytes,
        "width": max_width,
        "quality": quality,
        "save_copy": a.get("save_copy"),
        "timeout_ms": timeout,
        "t0": time.time(),
        "exclude": exclude,
        "scene": sname,
        "source": name,
        "dirs": dirs[:6],
    }
    if mode == "dir":
        if not dirs:
            raise err(E_UNSUPPORTED, "找不到截图目录", hint="在脚本属性 snapshot_dir 里指定 OBS 的截图保存目录。")
        common.update({"mode": "dir", "prev": None, "t0": 0.0})
        return Capture(**common)
    if mode == "command":
        cmd = str((rt.props or {}).get("snapshot_command") or "").strip()
        if not cmd:
            raise err(E_UNSUPPORTED, "snapshot_command 未配置", hint="在脚本属性里填外部截图命令，用 {output} 占位输出路径。")
        out_dir = os.path.join(nexus_dir(), "snapshots")
        _ensure_dir(out_dir)
        out_path = os.path.join(out_dir, "nexus-%d.png" % now_ms())
        line = cmd.replace("{output}", out_path).replace("{source}", name or "program")
        common.update({"mode": "command", "command": line, "out_path": out_path, "prev": None, "t0": time.time()})
        return Capture(**common)
    if not (_has("obs_frontend_take_screenshot") and _has("obs_frontend_get_last_screenshot")):
        raise err(
            E_UNSUPPORTED,
            "当前 OBS 未提供 obs_frontend_take_*_screenshot / get_last_screenshot（需要 OBS 26+）",
            details={"mode": mode, "obs_version": obs_version_string()},
            hint="改用 mode:'dir'（从截图目录取最新文件）或 mode:'command'。",
        )
    prev = prev_last
    fn = _fn("obs_frontend_get_last_screenshot")
    try:
        if fn is not None:
            prev = fn() or None
    except Exception:
        prev = None
    trigger = _fn("obs_frontend_take_source_screenshot") if src is not None else _fn("obs_frontend_take_screenshot")
    if trigger is None:
        raise err(E_UNSUPPORTED, "OBS 未提供 take_screenshot 接口")
    try:
        if src is not None:
            trigger(src)
        else:
            trigger()
    except Exception as exc:
        raise err(E_OBS_FAILED, "obs_frontend_take_*_screenshot 调用失败: %r" % (exc,), hint="OBS 可能正在关闭；稍后重试。", retryable=True)
    common.update({"mode": "native", "prev": prev, "t0": time.time() - 0.4})
    return Capture(**common)


# ================================ conn.* ==================================
@op("conn.status", "Nexus 服务端运行时状态（连接数、队列、限流水位、鉴权模式）", {}, execution=EXEC_WORKER)
def op_conn_status(rt, a, ctx):
    return rt.metrics(detailed=True)


@op(
    "conn.subscribe",
    "订阅主线程推送的事件（scene.changed / text.updated / record.* / stream.* …）",
    {
        "events": ["[str]", False, "事件名数组（覆盖式订阅）；不传 = 恢复默认集，[] = 全部退订"],
        "min_interval_ms": ["int", False, "同类事件最小间隔（0 = 不限速）"],
    },
)
def op_conn_subscribe(rt, a, ctx):
    conn = ctx.get("conn")
    if conn is None:
        raise err(E_BAD_PARAMS, "conn.subscribe 只能在活动连接上调用")
    ev = a.get("events")
    if ev is None:
        want = set(rt.default_events)
    elif isinstance(ev, (list, tuple)):
        want = set(str(x) for x in ev)
        unknown = [x for x in want if x not in rt.event_names]
        if unknown:
            raise err(E_BAD_PARAMS, "未知事件: %s" % ", ".join(sorted(unknown)[:6]), details={"known": sorted(rt.event_names)})
    else:
        raise err(E_BAD_PARAMS, "events 必须是数组")
    conn.subscribe(want, _int(a.get("min_interval_ms"), 0) or 0)
    return {"subscribed": sorted(want), "min_interval_ms": conn.min_interval_ms, "note": "事件走同一 TCP 连接，type=event"}


@op(
    "nexus.reload",
    "重新读取 ~/.obs_nexus/config.json 并热应用（端口/限流变化会自动重启服务端）",
    {},
    advanced=True,
)
def op_nexus_reload(rt, a, ctx):
    out = rt.reload_settings()
    out["note"] = "改完脚本面板里的属性也会触发同样的热应用；本 op 用于「直接改文件后生效」。"
    return out


@op(
    "nexus.stop",
    "临时关掉网络服务（OBS 不退出，所有 agent 连接断开；脚本面板「启动服务」可再开）",
    {"reason": ["str", False, "写进日志的原因"]},
    advanced=True,
)
def op_nexus_stop(rt, a, ctx):
    reason = str(arg(a, "reason", "nexus.stop") or "nexus.stop")[:60]
    # 延迟到本次响应写完之后，否则自己先把连接掐了、客户端只能看到断线
    rt.post_deferred(150, _defer_stop_server, rt, reason)
    return {
        "stopping_in_ms": 150,
        "reason": reason,
        "note": "响应发完后断开全部连接并停掉监听；OBS 仍正常运行，可在脚本面板点「启动服务」恢复。",
    }


def _defer_stop_server(rt, reason):
    try:
        rt.stop_server(reason)
    except Exception:
        _LOG.error("stop_server 异常:\n%s" % traceback.format_exc())


@op("conn.capabilities", "自描述：所有可用 op 与参数说明（Agent 可以先问这个再干活）", {}, execution=EXEC_WORKER)
def op_conn_capabilities(rt, a, ctx):
    return {
        "proto": NEXUS_PROTO,
        "nexus_version": NEXUS_VERSION,
        "ops": [spec.describe() for name, spec in sorted(OPS.items()) if not spec.advanced or rt.advanced],
        "advanced_enabled": rt.advanced,
        "limits": dict(rt.limits, max_line_bytes=MAX_LINE_BYTES, max_batch_ops=MAX_BATCH_OPS),
        "response_shape": {
            "ok": "bool",
            "result": "{op,data} 或 {op,error}(批量单步失败时)",
            "error": "{code,message,details,hint,retryable} 或 null",
            "batch": "{index,count,aborted,continue_on_error}",
            "request_id": "回显",
        },
        "usage": '每行一条 JSON: {"t":"req","id":"1","op":"text.set","source":"字幕","text":"hi"}\\n',
    }


# =============================================================================
# 网络层：selectors 单线程事件循环（本文件内**严禁**出现任何 obs.* 调用）
# =============================================================================
class LineFramer(object):
    """按行切分 UTF-8 JSON 帧；超长立即报错并丢弃缓冲（防爆 + 防内存增长）。"""

    def __init__(self, max_bytes=MAX_LINE_BYTES):
        self.buf = bytearray()
        self.max_bytes = max_bytes
        self.overflow = False
        self.dropped_bytes = 0
        self.dropped_lines = 0

    def feed(self, data):
        """返回 [line_bytes, ...]；超限溢出后本连接会被强制断开。"""
        if self.overflow:
            return []
        if len(self.buf) + len(data) > self.max_bytes:
            take = self.max_bytes - len(self.buf)
            if take > 0:
                self.buf += data[:take]
            self.overflow = True
            self._drop_rest(data, take)
            return []
        self.buf += data
        out = []
        while True:
            i = self.buf.find(b"\n")
            if i < 0:
                break
            line = bytes(self.buf[:i])
            del self.buf[: i + 1]
            if line.endswith(b"\r"):
                line = line[:-1]
            if line.strip():
                out.append(line)
            else:
                self.dropped_lines += 1
        return out

    def _drop_rest(self, data, take):
        self.dropped_bytes += max(0, len(data) - max(0, take))
        self.buf = bytearray()

    def pending_overflow(self):
        if not self.overflow:
            return None
        return err(
            E_TOO_LARGE,
            "单行超过 %d 字节上限（已丢 %d 字节）" % (self.max_bytes, self.dropped_bytes),
            details={"max_line_bytes": self.max_bytes},
            hint="把大内容写进文件再用 text.set 的 file 参数；图片用 format:'file'。",
        )


class RateBudget(object):
    """滑动窗口限流：每秒行数。"""

    __slots__ = ("rate", "window", "hits")

    def __init__(self, rate=MAX_CONN_LINES_PER_SEC):
        self.rate = float(rate)
        self.window = deque()
        self.hits = 0

    def configure(self, rate):
        self.rate = float(rate)

    def allow(self, now=None, cost=1):
        now = time.time() if now is None else now
        self.hits += cost
        self.window.append(now)
        cutoff = now - 1.0
        while self.window and self.window[0] < cutoff:
            self.window.popleft()
        return len(self.window) <= max(1, self.rate)

    def usage(self):
        return {"rate_per_sec": self.rate, "window_hits": len(self.window), "hits_total": self.hits}


class Conn(object):
    """一条客户端连接的完整状态（只在网络线程与主线程间通过消息传递，不共享对象引用）。"""

    _ids = itertools.count(1)

    def __init__(self, sock, addr, runtime):
        self.id = next(self._ids)
        self.sock = sock
        self.addr = addr
        self.rt = runtime
        self.framer = LineFramer(MAX_LINE_BYTES)
        self.rate = RateBudget(runtime.props.get("rate_per_sec") or MAX_CONN_LINES_PER_SEC)
        self.outbox = deque()
        self.out_bytes = 0
        self.want_write = False
        self.authenticated = False
        self.created = time.time()
        self.last_read = time.time()
        self.last_activity = time.time()
        self.requests = 0
        self.errors = 0
        self.rejected = 0
        self.events_sent = 0
        self.events_dropped = 0
        self.subscribed = set()
        self.min_interval_ms = 0
        self._last_event_at = {}
        self.in_flight = False
        self.pending_capture = None
        self.close_after_flush = False
        self.closing = False
        self.read_paused = False
        self.label = "%s:%s" % (addr[0], addr[1]) if addr else "?"
        self.buf_max = 0

    # --------------------------- 发送 ---------------------------
    def send_obj(self, obj):
        """一帧 = 一行 JSON + \n（协议终止符，绝不能漏）。"""
        try:
            data = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n"
        except (TypeError, ValueError) as exc:
            data = json.dumps(
                {"v": NEXUS_PROTO, "type": "response", "ok": False, "error": {"code": E_INTERNAL, "message": "响应无法序列化: %r" % (exc,)}},
                separators=(",", ":"),
            ).encode("utf-8")
        if len(data) > self.rt.limits["max_result_bytes"]:
            data = json.dumps(
                {
                    "v": NEXUS_PROTO,
                    "type": "response",
                    "ok": False,
                    "error": {
                        "code": E_TOO_LARGE,
                        "message": "响应 %d 字节超过上限 %d" % (len(data), self.rt.limits["max_result_bytes"]),
                        "hint": "用 limit/offset/fields 裁剪结果，或把 canvas.snapshot 的 format 设为 file。",
                    },
                }
            ).encode("utf-8") + b"\n"
        if self.out_bytes + len(data) > OUTBOX_LIMIT:
            self.rt.stats["dropped_replies"] += 1
            self.close("outbox_overflow")
            return False
        self.outbox.append(data)
        self.out_bytes += len(data)
        self._set_write(True)
        return True

    def _set_write(self, want):
        self.want_write = want
        self.rt.net.update_write(self, want)

    # --------------------------- 关闭 ---------------------------
    def flush_then_close(self, reason="closed_by_server"):
        self.close_after_flush = True
        self._reason = reason

    def close(self, reason="closed"):
        self.closing = True
        self._reason = reason
        self.rt.net.drop_connection(self, reason)

    # --------------------------- 事件 ---------------------------
    def wants(self, name):
        return name in self.subscribed

    def subscribe(self, names, min_interval_ms=0):
        self.subscribed = set(names)
        self.min_interval_ms = max(0, int(min_interval_ms or 0))

    def push_event(self, name, data):
        if not self.authenticated or self.closing:
            return False
        if self.min_interval_ms:
            last = self._last_event_at.get(name, 0.0)
            if (time.time() - last) * 1000.0 < self.min_interval_ms:
                self.events_dropped += 1
                return False
            self._last_event_at[name] = time.time()
        payload = {
            "v": NEXUS_PROTO,
            "type": "event",
            "event": name,
            "seq": self.rt.stats["events"],
            "ts": round(time.time(), 3),
            "data": data,
        }
        self.events_sent += 1
        return self.send_obj(payload)

    def usage(self):
        return {
            "id": self.id,
            "peer": self.label,
            "authenticated": self.authenticated,
            "requests": self.requests,
            "errors": self.errors,
            "rejected": self.rejected,
            "events_sent": self.events_sent,
            "events_dropped": self.events_dropped,
            "subscribed": sorted(self.subscribed),
            "in_flight": self.in_flight,
            "outbox_bytes": self.out_bytes,
            "rx_buffer_bytes": len(self.framer.buf),
            "rx_buffer_peak": self.buf_max,
            "rate": self.rate.usage(),
            "idle_s": round(time.time() - self.last_activity, 2),
            "age_s": round(time.time() - self.created, 2),
        }


class NetServer(object):
    """后台守护线程：bind 127.0.0.1:随机端口 -> accept -> 行协议 -> 投递主线程。

    线程安全约定：本类只与 runtime 的两个 queue 交互（cmd_q / reply_q），
    绝不调用任何 obspython API。
    """

    def __init__(self, runtime):
        self.rt = runtime
        self.listen_sock = None
        self.port = 0
        self.conns = {}
        self.sel = None
        self._thread = None
        self._stopping = False
        self._force_stop = False
        self._wakeup_r = None
        self._wakeup_w = None
        self._auth_failures = {}
        self._accepted_total = 0
        self._rejected_preauth = 0
        self._by_fd = {}
        self.tick = 0

    # 由 Conn 调用：只调整 selector 的写兴趣（读兴趣保持常开，串行由 in_flight 保证）
    def update_write(self, conn, want):
        if self.sel is None or conn.closing:
            return
        try:
            events = selectors.EVENT_READ | (selectors.EVENT_WRITE if want else 0)
            self.sel.modify(conn.sock, events, conn.id)
        except (KeyError, ValueError, OSError):
            pass

    # ------------------------- 生命周期 -------------------------
    def start(self, host, port, prefer_range=True):
        self.port = self._bind(host, port, prefer_range)
        try:
            self._wakeup_r, self._wakeup_w = socket.socketpair()
            for s in (self._wakeup_r, self._wakeup_w):
                s.setblocking(False)
        except (OSError, AttributeError):  # pragma: no cover - 极少见
            self._wakeup_r = self._wakeup_w = None
        self.sel = selectors.DefaultSelector()
        self.sel.register(self.listen_sock, selectors.EVENT_READ, "listen")
        if self._wakeup_r is not None:
            self.sel.register(self._wakeup_r, selectors.EVENT_READ, "wakeup")
        self._thread = threading.Thread(target=self._guarded_loop, name="NexusNetworkThread", daemon=True)
        self._thread.start()
        return self.port

    def _bind(self, host, port, prefer_range):
        last = None
        candidates = []
        if port:
            candidates.append(int(port))
        elif prefer_range:
            lo, hi = self.rt.props.get("port_range") or PORT_RANGE
            try:
                lo, hi = int(lo), int(hi)
            except Exception:
                lo, hi = PORT_RANGE
            span = max(0, hi - lo)
            start = lo + (int.from_bytes(os.urandom(2), "big") % (span + 1))
            for i in range(min(span + 1, 120)):
                candidates.append(((start - lo + i) % (span + 1)) + lo)
        for cand in candidates or [0]:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind((host, int(cand)))
                sock.listen(16)
                sock.setblocking(False)
                self.listen_sock = sock
                return sock.getsockname()[1]
            except OSError as exc:
                last = exc
                try:
                    sock.close()
                except OSError:
                    pass
        raise err(E_OBS_FAILED, "无法在 127.0.0.1 上监听：%r" % (last,), details={"host": host, "tried": len(candidates) or 1})

    def _guarded_loop(self):  # pragma: no cover - 兜底：线程绝不因异常静默死掉
        try:
            self._loop()
        except Exception:
            _LOG.error("网络线程异常退出：\n%s" % traceback.format_exc())
        finally:
            self._cleanup_sockets("thread_exit")
            if self.rt is not None:
                self.rt.stats["net_thread_died"] = now_ms()

    def stop(self, force=False, timeout=1.5):
        self._stopping = True
        if force:
            self._force_stop = True
        self.wake()
        th = self._thread
        if th is not None and th is not threading.current_thread():
            th.join(timeout)
            if th.is_alive():  # 极端情况：网络线程卡死 -> 强杀，OBS 关闭不受影响
                _LOG.warn("网络线程未在 %.1fs 内退出，强制关闭" % timeout)
                self._cleanup_sockets("forced")
                try:
                    th._stop() if hasattr(th, "_stop") else None
                except Exception:
                    pass
        return not (th is not None and th.is_alive())

    def wake(self):
        w = self._wakeup_w
        if w is None:
            return
        try:
            w.send(b"\x01")
        except OSError:
            pass

    # --------------------------- 主循环 ---------------------------
    def _loop(self):
        sel = self.sel
        while not self._stopping:
            self.tick += 1
            timeout = 0.25
            if any(c.in_flight or c.pending_capture is not None or c.want_write for c in self.conns.values()):
                timeout = 0.02
            elif self.rt.cmd_backlog():
                timeout = 0.05
            try:
                events = sel.select(timeout)
            except OSError as exc:
                if getattr(exc, "errno", None) == errno.EINTR:
                    continue
                break
            except ValueError:  # selector 被关闭
                break
            for key, mask in events:
                tag = key.data
                try:
                    if tag == "listen":
                        self._accept()
                    elif tag == "wakeup":
                        self._drain_wakeup()
                        self._drain_replies()
                    else:
                        self._on_conn_event(key.fileobj, mask)
                except Exception as exc:
                    _LOG.warn("连接事件处理异常 (%s): %r" % (tag, exc))
                    conn = self.conns.get(key.fileobj)
                    if conn is not None:
                        conn.close("event_error")
            try:
                self._drain_replies()
                self._tick_conns()
            except Exception as exc:
                _LOG.warn("tick 异常: %r" % (exc,))
        self._cleanup_sockets("stopping")

    def _drain_wakeup(self):
        r = self._wakeup_r
        if r is None:
            return
        try:
            while r.recv(4096):
                pass
        except (OSError, BlockingIOError):
            pass

    def _cleanup_sockets(self, reason):
        for conn in list(self.conns.values()):
            try:
                conn.sock.close()
            except OSError:
                pass
        self.conns.clear()
        for attr in ("listen_sock", "_wakeup_r", "_wakeup_w"):
            obj = getattr(self, attr, None)
            if obj is not None:
                try:
                    obj.close()
                except OSError:
                    pass
        if self.sel is not None:
            try:
                self.sel.close()
            except Exception:
                pass
            self.sel = None

    # --------------------------- 连接管理 ---------------------------
    def _accept(self):
        if len(self.conns) >= self.rt.limits["max_connections"]:
            try:
                sock, addr = self.listen_sock.accept()
            except OSError:
                return
            self._rejected_preauth += 1
            self.rt.stats["rejected"] += 1
            try:
                sock.sendall(
                    json.dumps(
                        {
                            "v": NEXUS_PROTO,
                            "type": "error",
                            "error": {
                                "code": E_OVERLOAD,
                                "message": "连接数已达上限 %d" % self.rt.limits["max_connections"],
                                "retryable": True,
                            },
                        }
                    ).encode("utf-8")
                    + b"\n"
                )
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
            _LOG.warn("拒绝新连接 %s（连接数已满）" % (addr,))
            return
        try:
            sock, addr = self.listen_sock.accept()
        except (BlockingIOError, OSError):
            return
        try:
            sock.setblocking(False)
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass
            conn = Conn(sock, addr, self.rt)
            self.conns[conn.id] = conn
            self._by_fd[sock.fileno()] = conn.id
            self._accepted_total += 1
            self.rt.stats["connections_total"] += 1
            self.sel.register(sock, selectors.EVENT_READ, conn.id)
            # 预鉴权握手信息：故意不含 token / 场景内容，避免未鉴权信息泄露
            conn.send_obj(
                {
                    "v": NEXUS_PROTO,
                    "type": "hello",
                    "proto": NEXUS_PROTO,
                    "app": NEXUS_APP,
                    "nexus_version": NEXUS_VERSION,
                    "auth_required": bool(self.rt.token),
                    "auth_scheme": "nexus-token-v1",
                    "limits": {"max_line_bytes": MAX_LINE_BYTES, "max_batch_ops": MAX_BATCH_OPS},
                    "auth_hint": '{"t":"auth","token":"<connection.json 里的 token>"}',
                    "auth_deadline_ms": AUTH_TIMEOUT_MS,
                }
            )
        except Exception as exc:
            _LOG.warn("accept 失败: %r" % (exc,))
            try:
                sock.close()
            except OSError:
                pass

    def drop_connection(self, conn, reason):
        self.conns.pop(conn.id, None)
        try:
            self._by_fd.pop(conn.sock.fileno(), None)
        except OSError:
            pass
        try:
            self.sel.unregister(conn.sock)
        except Exception:
            pass
        try:
            conn.sock.close()
        except OSError:
            pass
        if conn.in_flight:
            self.rt.forget_connection(conn.id)
        conn.in_flight = False
        conn.pending_capture = None
        if reason not in ("eof", "closed_by_client", "idle_timeout", "stopping", "thread_exit", "client_shutdown"):
            _LOG.info("断开连接 %s: %s" % (conn.label, reason))
        conn.closing = True

    def _on_conn_event(self, sock, mask):
        conn = self.conns.get(self._by_fd.get(sock.fileno(), -1))
        if conn is None:
            try:
                sock.close()
            except OSError:
                pass
            return
        if mask & selectors.EVENT_READ:
            self._on_read(conn)
        if conn.closing:
            return
        if mask & selectors.EVENT_WRITE:
            self._on_write(conn)
            if conn.closing:
                return
        if conn.close_after_flush and not conn.outbox:
            self.drop_connection(conn, getattr(conn, "_reason", "flushed"))
            return
        if conn.want_write != conn.out_bytes > 0:
            conn.want_write = conn.out_bytes > 0
            conn._set_write(conn.want_write)

    def _on_read(self, conn):
        try:
            data = conn.sock.recv(65536)
        except (BlockingIOError, InterruptedError):
            return
        except (ConnectionResetError, ConnectionAbortedError, OSError) as exc:
            if getattr(exc, "errno", None) in (errno.EAGAIN, errno.EWOULDBLOCK):
                return
            self.drop_connection(conn, "read_error")
            return
        if not data:
            self.drop_connection(conn, "eof")
            return
        conn.last_read = time.time()
        conn.last_activity = conn.last_read
        lines = conn.framer.feed(data)
        conn.buf_max = max(conn.buf_max, len(conn.framer.buf))
        over = conn.framer.pending_overflow()
        if over is not None:
            self._send_error(conn, None, over)
            conn.flush_then_close("line_overflow")
            return
        for line in lines:
            if not conn.rate.allow():
                conn.rejected += 1
                self.rt.stats["rejected"] += 1
                self._send_error(
                    conn,
                    None,
                    err(
                        E_OVERLOAD,
                        "消息速率超过上限 %.0f 行/秒" % conn.rate.rate,
                        retryable=True,
                        hint="降低轮询频率，或改用 conn.subscribe 事件推送，或调大脚本属性 rate_per_sec。",
                    ),
                )
                if conn.rejected > 20:
                    conn.flush_then_close("rate_limit_abuse")
                    return
                continue
            self._handle_line(conn, line)
            if conn.closing:
                return

    def _on_write(self, conn):
        while conn.outbox:
            chunk = conn.outbox[0]
            try:
                n = conn.sock.send(chunk)
            except (BlockingIOError, InterruptedError):
                return
            except (BrokenPipeError, ConnectionResetError, OSError):
                self.drop_connection(conn, "write_error")
                return
            if n <= 0:
                self.drop_connection(conn, "write_zero")
                return
            if n == len(chunk):
                conn.outbox.popleft()
                conn.out_bytes -= len(chunk)
            else:
                conn.outbox[0] = chunk[n:]
                conn.out_bytes -= n
        if not conn.outbox:
            conn._set_write(False)

    # --------------------------- 消息处理 ---------------------------
    def _handle_line(self, conn, line):
        try:
            req = json.loads(line.decode("utf-8"))
        except UnicodeDecodeError as exc:
            self._send_error(conn, None, err(E_PROTO, "请求必须是 UTF-8: %r" % (exc,)))
            return
        except ValueError as exc:
            self.rt.stats["json_errors"] += 1
            self._send_error(
                conn,
                None,
                err(E_PROTO, "JSON 解析失败: %s" % (str(exc)[:180],), hint="每个请求必须是一行合法 JSON，且以 \\n 结尾。"),
            )
            return
        if not isinstance(req, dict):
            self._send_error(conn, None, err(E_PROTO, "顶层必须是 JSON 对象，收到 %s" % type(req).__name__))
            return
        rtype = str(req.get("t") or req.get("type") or "").strip().lower()
        if rtype in ("ping", "heartbeat"):
            conn.send_obj(
                {
                    "v": NEXUS_PROTO,
                    "type": "pong",
                    "ts": round(time.time(), 3),
                    "request_id": req.get("id"),
                    "authenticated": bool(conn.authenticated),
                }
            )
            return
        if rtype == "auth":
            self._handle_auth(conn, req)
            return
        if not conn.authenticated:
            self.rt.stats["unauth_attempts"] += 1
            self._send_error(
                conn,
                req.get("id") or req.get("request_id"),
                err(
                    E_UNAUTHORIZED,
                    "未鉴权：必须先发送 {\"t\":\"auth\",\"token\":...}",
                    hint="token 在 %s 里；若为 null 则无需鉴权。" % self.rt.conn_file,
                ),
            )
            conn.flush_then_close("unauthenticated")
            return
        if rtype in ("exit", "shutdown", "close"):
            conn.send_obj({"v": NEXUS_PROTO, "type": "bye", "ok": True, "request_id": req.get("id")})
            conn.flush_then_close("client_shutdown")
            return
        self._dispatch(conn, req)

    def _handle_auth(self, conn, req):
        provided = req.get("token")
        if provided is None:
            provided = req.get("auth") or req.get("password")
        expected = self.rt.token or ""
        ok = bool(expected) and isinstance(provided, str) and _const_eq(provided.strip(), expected)
        if not expected and self.rt.allow_no_auth:
            ok = True
        if ok:
            conn.authenticated = True
            self.rt.stats["auth_ok"] += 1
            conn.send_obj(
                {
                    "v": NEXUS_PROTO,
                    "type": "auth",
                    "ok": True,
                    "request_id": req.get("id") or req.get("request_id"),
                    "proto": NEXUS_PROTO,
                    "nexus_version": NEXUS_VERSION,
                    "obs_version": self.rt.cached("obs_version"),
                    "advanced": self.rt.advanced,
                    "limits": dict(self.rt.limits),
                    "ops": [n for n in sorted(OPS) if not OPS[n].advanced or self.rt.advanced],
                    "events": sorted(self.rt.event_names),
                    "note": "已鉴权。发送 {\"op\":\"...\"} 或 {\"ops\":[...]}，一行一条。",
                }
            )
            conn.push_event("connection.ready", {"peer": conn.label, "port": self.port})
            return
        self.rt.stats["auth_fail"] += 1
        now = time.time()
        fails = [t for t in self._auth_failures.get(conn.label, []) if now - t < 60.0]
        fails.append(now)
        self._auth_failures[conn.label] = fails
        if len(fails) > 8:
            _LOG.error("来自 %s 的 token 校验连续失败 %d 次，已断开并拉黑 60s" % (conn.label, len(fails)))
        self._send_error(
            conn,
            req.get("id"),
            err(
                E_UNAUTHORIZED,
                "Token 校验失败",
                details={"attempts_last_60s": len(fails), "expected_source": self.rt.conn_file},
                hint="重新点「写入连接文件」获取新 token；token 为 null 表示已关闭鉴权。",
            ),
        )
        conn.flush_then_close("auth_failed")

    def _dispatch(self, conn, req):
        if conn.in_flight:
            self._send_error(
                conn,
                req.get("id"),
                err(
                    E_PRECONDITION,
                    "上一条请求仍在执行中（同一连接串行）",
                    retryable=True,
                    hint="等待响应，或为并发请求另开一条 TCP 连接。",
                ),
            )
            return
        if not self.rt.cmd_space():
            self.rt.stats["rejected"] += 1
            self._send_error(
                conn,
                req.get("id"),
                err(
                    E_OVERLOAD,
                    "主线程队列已满（%d）" % self.rt.cmd_backlog(),
                    retryable=True,
                    details={"queue_depth": self.rt.cmd_backlog()},
                    hint="降低批量大小或放慢调用频率；OBS 主线程可能正忙。",
                ),
            )
            return
        try:
            parsed = parse_request(req, self.rt)
        except NexusError as exc:
            conn.errors += 1
            self._send_error(conn, req.get("id") or req.get("request_id"), exc)
            return
        conn.requests += 1
        conn.in_flight = True
        self.rt.submit_request(conn, parsed)

    def _send_error(self, conn, req_id, exc):
        if conn is not None:
            conn.errors += 1
        conn.send_obj(build_error_response(req_id, exc))

    # --------------------------- 主线程回包 ---------------------------
    def _drain_replies(self):
        q = self.rt.reply_q
        for _ in range(256):
            try:
                item = q.get_nowait()
            except Empty:
                break
            kind = item[0]
            if kind == "reply":
                _, conn_id, payload, capture = item
                conn = self.conns.get(conn_id)
                if conn is None:
                    continue
                conn.in_flight = False
                if capture is not None:
                    conn.pending_capture = {"payload": payload, "capture": capture, "conn_id": conn_id}
                    conn.pending_capture["deadline"] = time.time() + capture.get("timeout_ms", 3000) / 1000.0
                    conn.pending_capture["state"] = {"sig": None, "path": None, "tries": 0}
                else:
                    conn.send_obj(payload)
            elif kind == "close":
                conn = self.conns.get(item[1])
                if conn is not None:
                    conn.flush_then_close(item[2] if len(item) > 2 else "server_close")
            elif kind == "event":
                self._broadcast(item[1], item[2])
            elif kind == "force_close":
                conn = self.conns.get(item[1])
                if conn is not None:
                    self.drop_connection(conn, item[2] if len(item) > 2 else "closed")

    def _broadcast(self, name, data):
        for conn in list(self.conns.values()):
            if conn.wants(name):
                conn.push_event(name, data)

    def _tick_conns(self):
        now = time.time()
        idle_ms = self.rt.props.get("idle_timeout_ms") or IDLE_TIMEOUT_MS
        for conn in list(self.conns.values()):
            try:
                if not conn.closing and not conn.authenticated and (now - conn.created) * 1000.0 > AUTH_TIMEOUT_MS:
                    self._send_error(conn, None, err(E_UNAUTHORIZED, "%d ms 内未完成鉴权，断开" % AUTH_TIMEOUT_MS, retryable=True))
                    conn.flush_then_close("auth_timeout")
                    continue
                if not conn.closing and (now - conn.last_activity) * 1000.0 > idle_ms:
                    conn.send_obj({"v": NEXUS_PROTO, "type": "bye", "ok": True, "reason": "idle_timeout"})
                    conn.flush_then_close("idle_timeout")
                    continue
                if conn.pending_capture is not None:
                    self._advance_capture(conn, now)
            except Exception as exc:  # 单连接异常不能带崩整个事件循环
                _LOG.warn("tick 连接异常: %r" % (exc,))
                conn.close("tick_error")

    # ------------------ 截图收尾（文件等待 + 编码全在 worker 线程） ------------------
    def _advance_capture(self, conn, now=None):
        now = time.time() if now is None else now
        pc = conn.pending_capture
        cap = pc["capture"]
        st = pc["state"]
        st["tries"] += 1
        # command 后端：懒启动外部命令，之后按 tick 轮询其退出状态（永不阻塞事件循环）
        if cap.get("command"):
            if st.get("proc") is None:
                try:
                    st["proc"] = subprocess.Popen(
                        cap["command"],
                        shell=True,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.PIPE,
                        cwd=nexus_dir(),
                    )
                except Exception as exc:
                    self._resolve_capture(conn, pc, err(E_OBS_FAILED, "snapshot_command 启动失败: %r" % (exc,)))
                    return
                return
            rc = st["proc"].poll()
            if rc is None:
                if now > pc["deadline"]:
                    try:
                        st["proc"].kill()
                    except Exception:
                        pass
                    self._resolve_capture(conn, pc, err(E_TIMEOUT, "snapshot_command 超时未退出", retryable=True))
                return
            if rc != 0:
                txt = b""
                try:
                    txt = (st["proc"].stderr.read() or b"")[:400]
                except Exception:
                    pass
                self._resolve_capture(
                    conn, pc, err(E_OBS_FAILED, "snapshot_command 退出码 %s：%s" % (rc, txt.decode("utf-8", "replace").strip()[:256]))
                )
                return
            cand = cap.get("out_path")
            if cand and os.path.exists(cand):
                self._resolve_capture(conn, pc, None, cand)
            else:
                self._resolve_capture(conn, pc, err(E_TIMEOUT, "snapshot_command 没有产出文件 %s" % cand, retryable=True))
            return
        # native / dir：先看主线程刷新的 last_screenshot 缓存，再兜底扫目录
        cand = None
        cache = self.rt.shot_cache
        if cap.get("prev") is not None and cache.get("path") and cache["path"] != cap["prev"]:
            cand = cache["path"]
        if cand is None and st["tries"] % 3 == 1:
            cand = _scan_new_images(cap.get("dirs") or [], cap.get("t0") or now, exclude=cap.get("exclude") or set())
        settled = False
        if cand:
            sig = file_sig(cand)
            if sig is not None and st.get("sig") == (cand, sig):
                settled = True
            st["sig"] = (cand, sig)
            st["path"] = cand
        if not settled and st.get("path") and st.get("sig"):
            cand = st["path"]
            sig = file_sig(cand)
            if sig is not None and st["sig"][1] == sig:
                settled = True
        if settled:
            self._resolve_capture(conn, pc, None, cand)
            return
        if now > pc["deadline"]:
            self._resolve_capture(
                conn,
                pc,
                err(
                    E_TIMEOUT,
                    "等待 OBS 写出截图文件超时（%.1fs）" % (now - (cap.get("t0") or now)),
                    details={"dirs": cap.get("dirs"), "last_screenshot": self.rt.shot_cache.get("path")},
                    retryable=True,
                    hint="确认 OBS「设置-高级-截图」保存目录，并在脚本属性 snapshot_dir 填同一路径；"
                    "或改 mode:'dir' / format:'file'；OBS 主线程被卡住也会导致本超时（见 system.health）。",
                ),
            )

    def _resolve_capture(self, conn, pc, exc, path=None):
        payload = pc["payload"]
        cap = pc["capture"]
        conn.pending_capture = None
        idx = cap.get("index")
        if exc is None:
            try:
                result = finish_capture(path, cap)
                result["waited_ms"] = int((time.time() - (cap.get("t0") or time.time())) * 1000)
            except NexusError as exc2:
                exc, result = exc2, None
            except Exception as exc2:  # pragma: no cover
                exc, result = err(E_INTERNAL, "截图后处理失败: %r" % (exc2,)), None
        else:
            result = None
        results = payload.get("results")
        if isinstance(results, list) and idx is not None and 0 <= idx < len(results):
            if result is not None:
                results[idx] = {"ok": True, "op": "canvas.snapshot", "data": result}
            else:
                results[idx] = {"ok": False, "op": "canvas.snapshot", "error": exc.to_dict()}
            payload["ok"] = all(bool(r.get("ok")) for r in results if isinstance(r, dict))
            payload["result"] = results[idx]
            payload["error"] = None if result is not None else exc.to_dict()
            payload["batch"]["aborted"] = payload["batch"].get("aborted") or (result is None and not payload.get("ok", False))
        else:
            payload["ok"] = result is not None
            payload["result"] = {"ok": result is not None, "op": "canvas.snapshot", "data": result}
            if result is None:
                payload["error"] = exc.to_dict()
        payload.pop("pending_capture", None)
        self._send_final(conn, payload)
        if result is None:
            self.rt.stats.inc("captures_failed")
        else:
            self.rt.stats.inc("captures")


    def _send_final(self, conn, payload):
        try:
            conn.send_obj(payload)
        except Exception as exc:  # pragma: no cover
            _LOG.warn("发送失败: %r" % (exc,))


def _const_eq(a, b):
    try:
        return hmac.compare_digest(("%s" % a).encode("utf-8"), ("%s" % b).encode("utf-8"))
    except Exception:
        return ("%s" % a) == ("%s" % b)


def finish_capture(path, cap):
    """worker 线程里执行：读文件 + 可选转码/缩放 + base64（不碰 libobs）。"""
    fmt_want = cap.get("format", "jpeg")
    max_bytes = cap.get("max_bytes", MAX_SNAPSHOT_BYTES)
    out = {"path": path, "mode": cap.get("mode", "native"), "bytes": None}
    for echo in ("scene", "source", "width", "quality"):
        if cap.get(echo) is not None:
            out[echo] = cap[echo]
    if fmt_want == "file":
        try:
            out["bytes"] = os.path.getsize(path)
        except OSError as exc:
            raise err(E_TIMEOUT, "无法 stat 截图文件: %r" % (exc,), retryable=True)
        out["image_data"] = None
        out["note"] = "format=file：只返回路径，未内联 base64（省 token 推荐用法）"
        return out
    fmt, b64, nbytes, info = _encode_snapshot(path, fmt_want, max_bytes, cap.get("width") or 0, cap.get("quality") or 82)
    out.update({"format": fmt, "bytes": nbytes, "b64_chars": len(b64), "image_data": b64, "mime": "image/" + ("jpeg" if fmt == "jpeg" else fmt)})
    out.update(info)
    dest = cap.get("save_copy")
    if dest:
        try:
            _ensure_dir(os.path.dirname(os.path.abspath(os.path.expanduser(dest))) or ".")
            shutil.copyfile(path, os.path.abspath(os.path.expanduser(dest)))
            out["saved_copy"] = dest
        except Exception as exc:
            out["saved_copy_error"] = repr(exc)
    return out


def build_error_response(req_id, exc):
    return {
        "v": NEXUS_PROTO,
        "type": "response",
        "request_id": req_id,
        "ok": False,
        "elapsed_ms": 0,
        "result": None,
        "error": exc.to_dict() if isinstance(exc, NexusError) else {"code": E_INTERNAL, "message": "%r" % (exc,)},
        "batch": {"index": 0, "count": 1, "aborted": True, "continue_on_error": False},
    }


# ----------------------------- 请求解析（纯计算，可在网络线程执行） -----------------------------
REQ_KEYS_OP = ("op", "method", "action", "cmd", "name")
REQ_KEYS_OPS = ("ops", "batch", "commands")  # 注意：不要把 steps/params 之类常见参数名放进来
REQ_KEYS_ARGS = ("args", "params", "p", "data")


def parse_request(req, rt):
    """把一行 JSON 解析成 {"id","ops","continue_on_error","deadline","budget"}。

    同时提供「兼容层」：
      {"method":"call","params":[{"op":...},...]}
      {"action":"text.set","source":"字幕","text":"hi"}
      单个对象 {"op":"text.set","source":...,"text":...}
    """
    if not isinstance(req, dict):
        raise err(E_PROTO, "顶层必须是对象")
    req_id = req.get("id")
    if req_id is None:
        req_id = req.get("request_id")
    if req_id is not None and not isinstance(req_id, (str, int)):
        raise err(E_PROTO, "id 必须是字符串或整数")
    if req_id is not None:
        req_id = ("%s" % req_id)[:64]
    timeout_ms = req.get("timeout_ms", req.get("timeout"))
    try:
        timeout_ms = _int(timeout_ms, DEFAULT_REQUEST_TIMEOUT_MS) or DEFAULT_REQUEST_TIMEOUT_MS
    except NexusError:
        raise err(E_PROTO, "timeout_ms 必须是整数")
    timeout_ms = _clamp(timeout_ms, 50, MAX_REQUEST_TIMEOUT_MS)
    batch_cfg = req.get("batch") if isinstance(req.get("batch"), dict) else {}
    if isinstance(req.get("ops"), dict):  # {"ops":{...}} 这种写法也接受（等价单 op）
        req = dict(req)
        req["ops"] = [req["ops"]]
    ops_raw = None
    for k in REQ_KEYS_OPS:
        v = req.get(k)
        if v is None:
            continue
        if not isinstance(v, list):
            raise err(
                E_PROTO,
                "字段 %r 必须是数组（批量请求）" % k,
                details={"got": type(v).__name__},
                hint='例：{"ops":[{"op":"text.set","source":"字幕","text":"hi"}]}',
            )
        ops_raw = v
        break
    op_key = None
    if ops_raw is None:
        op_name = None
        for k in REQ_KEYS_OP:
            v = req.get(k)
            if isinstance(v, str) and v.strip():
                op_name = v.strip()
                op_key = k
                break
        if op_name is None:
            raise err(
                E_NO_METHOD,
                "请求里找不到 op / ops / method / action 字段",
                details={"keys_seen": sorted(str(k) for k in req.keys())[:16]},
                hint='例：{"op":"text.set","source":"字幕","text":"你好"} 或 {"ops":[{"op":"system.overview"}]}',
            )
        args = None
        for k in REQ_KEYS_ARGS:
            if isinstance(req.get(k), dict):
                args = req.get(k)
                break
        if args is not None and op_name not in OPS:
            inner = args.get("op") or args.get("method")
            if isinstance(inner, str) and inner.strip() in OPS:  # {"method":"call","params":{"op":...}}
                args = dict(args)
                args.pop("op", None)
                args.pop("method", None)
                op_name = inner.strip()
        if args is None:
            skip = set(("v", "t", "type", "id", "request_id", "timeout_ms", "timeout", "continue_on_error", "batch", "main_budget_ms"))
            skip.update(k for k in REQ_KEYS_ARGS if isinstance(req.get(k), dict))
            if op_key is not None:  # 只排除真正当作 op 名使用的键，其它动作字段（如 action）保留为参数
                skip.add(op_key)
            args = {k: v for k, v in req.items() if k not in skip}
        ops_raw = [dict(args or {}, op=op_name)]
    ops = normalize_ops(ops_raw, rt)
    coe = req.get("continue_on_error")
    if coe is None:
        coe = req.get("stop_on_error")
        coe = not _bool(coe, True) if coe is not None else False
    coe = _bool(coe, False) or _bool(batch_cfg.get("continue_on_error"), False)
    return {
        "id": req_id,
        "ops": ops,
        "continue_on_error": coe,
        "timeout_ms": timeout_ms,
        "main_budget_ms": _clamp(
            _int(req.get("main_budget_ms"), (rt.props or {}).get("max_batch_exec_ms") or MAX_BATCH_EXEC_MS) or MAX_BATCH_EXEC_MS, 20, 1000
        ),
        "client": req.get("client"),
    }


def normalize_ops(ops_raw, rt):
    if not isinstance(ops_raw, list) or not ops_raw:
        raise err(E_PROTO, "ops 必须是非空数组")
    if len(ops_raw) > MAX_OPS_FOR_SIZE:
        raise err(E_TOO_LARGE, "ops 数组过大（%d > %d）" % (len(ops_raw), MAX_OPS_FOR_SIZE), details={"split": True})
    if len(ops_raw) > MAX_BATCH_OPS:
        raise err(
            E_TOO_LARGE,
            "批量 op 数量 %d 超过上限 %d" % (len(ops_raw), MAX_BATCH_OPS),
            hint="拆成多次请求，或调大脚本属性 max_batch_ops（不建议）。",
        )
    out = []
    for i, item in enumerate(ops_raw):
        if isinstance(item, str):
            item = {"op": item}
        if not isinstance(item, dict):
            raise err(E_PROTO, "ops[%d] 必须是对象或字符串" % i, details={"got": type(item).__name__})
        item = dict(item)
        name = None
        name_key = None
        for k in REQ_KEYS_OP:
            v = item.get(k)
            if isinstance(v, str) and v.strip():
                name = v.strip()
                name_key = k
                break
        if name is None:
            raise err(E_NO_METHOD, "ops[%d] 缺少 op 字段" % i, details={"keys_seen": sorted(str(k) for k in item.keys())[:12]})
        spec = OPS.get(name)
        if spec is None:
            near = _closest(name, OPS.keys())
            raise err(
                E_UNKNOWN_OP,
                "未知 op: %r" % name,
                details={"did_you_mean": near, "known": sorted(OPS.keys())[:64]},
                hint="用 conn.capabilities 获取全部 op 与参数说明。",
            )
        if spec.advanced and not rt.advanced:
            raise err(
                E_FORBIDDEN,
                "op %r 需要开启 advanced_script_controls" % name,
                details={"op": name},
                hint="在脚本属性里勾选「允许高级控制」（仅本地调试建议）。",
            )
        args = {}
        for k in REQ_KEYS_ARGS:
            v = item.pop(k, None)
            if isinstance(v, dict):
                args.update(v)
        for k, v in item.items():
            if k == name_key and v == name:
                continue
            args.setdefault(k, v)
        out.append({"index": i, "op": name, "args": args, "spec": spec})
    return out


def _closest(word, candidates, n=3):
    low = ("%s" % word).lower()
    scored = []
    for c in candidates:
        cl = c.lower()
        s = 0
        if cl.startswith(low) or low in cl:
            s += 2
        common = len(set(low) & set(cl))
        s += common / max(1.0, float(len(set(low) | set(cl))))
        scored.append((s, c))
    scored.sort(reverse=True)
    return [c for _s, c in scored[:n]]


# =============================================================================
# 运行时：主线程泵 + 请求状态机 + 生命周期
# =============================================================================
_SERVER = None

STAT_KEYS = (
    "connections_total",
    "rejected",
    "json_errors",
    "unauth_attempts",
    "auth_ok",
    "auth_fail",
    "dropped_replies",
    "submitted",
    "executed",
    "exec_errors",
    "ops_ok",
    "ops_err",
    "events",
    "pump_ticks",
    "pump_over_budget",
    "queue_high_water",
    "slow_requests",
    "timeouts",
    "captures",
    "captures_failed",
    "overload_drops",
    "restarts",
    "deferred_run",
)


class Stats(object):
    """两线程共享的计数器（键在构造时全部预建，只做整数自增，不做结构变更）。"""

    def __init__(self, keys=STAT_KEYS):
        self._d = {k: 0 for k in keys}
        self._extra = {}

    def __getitem__(self, k):
        return self._d.get(k, 0)

    def __setitem__(self, k, v):
        if k in self._d:
            self._d[k] = v
        else:
            self._extra[k] = v

    def inc(self, k, n=1):
        if k in self._d:
            self._d[k] += n
        else:
            self._extra[k] = self._extra.get(k, 0) + n

    def get(self, k, default=0):
        v = self._d.get(k, self._extra.get(k, default))
        return default if v is None else v

    def as_dict(self):
        out = dict(self._d)
        out.update(self._extra)
        return out


class Capture(object):
    """交给网络线程收尾的截图任务（OBS 已在本 tick 触发落盘）。"""

    def __init__(self, **kw):
        self.kw = kw

    def as_dict(self):
        return dict(self.kw)


class RequestState(object):
    """一个请求的执行状态机。

    - 只在 OBS 主线程内被推进（由 pump 调用 run()），不阻塞：
      单个请求每 tick 最多占用 max_batch_exec_ms，超预算就回到 _flight 等下一次 tick；
    - 支持 Async（等待 OBS 异步产生结果，如录制状态变化）与 Capture（截图落盘等待，
      由网络线程完成文件读取与编码，避免把 base64/PIL 的开销压到主线程）。
    """

    def __init__(self, rt, conn_id, parsed, on_main=True):
        self.rt = rt
        self.conn_id = conn_id
        self.parsed = parsed
        self.on_main = on_main
        self.ops = parsed["ops"]
        self.index = 0
        self.results = []
        self.abort = False
        self.aborted = False
        self.t0 = time.monotonic()
        self.deadline = self.t0 + parsed["timeout_ms"] / 1000.0
        self.budget_ms = (rt.props or {}).get("max_batch_exec_ms") or MAX_BATCH_EXEC_MS
        self.pending = None
        self.pending_t0 = 0.0
        self.capture = None
        self.done = False
        self.payload = None
        self.client = parsed.get("client")

    @property
    def elapsed(self):
        """已经消耗的主线程时间（秒），Async 轮询回调可以用它计算 waited_ms。"""
        return time.monotonic() - self.t0

    # ------------------------- 执行 -------------------------
    def run(self, budget_ms=None):
        """推进执行；返回 True 表示可以发响应了。"""
        if self.done:
            return True
        limit = self.budget_ms if budget_ms is None else budget_ms
        while self.index < len(self.ops):
            now = time.monotonic()
            if now > self.deadline:
                self._timeout_rest()
                break
            if self.on_main and (now - self.t0) * 1000.0 > limit:
                return False  # 让出主线程，下个 tick 继续
            if self.abort:
                self.results.append({"ok": False, "op": self.ops[self.index]["op"], "skipped": "aborted", "error": self.error_of_abort()})
                self.index += 1
                continue
            spec_op = self.ops[self.index]
            if self.pending is not None:
                advanced = self._advance_pending(now)
                if not advanced:
                    return False
                continue
            try:
                self._exec_one(spec_op)
            except NexusError as exc:
                self._record_error(spec_op, exc)
            except Exception as exc:  # 兜底：任何 handler 异常都不能带崩 OBS
                _LOG.error("op %s 内部异常:\n%s" % (spec_op["op"], traceback.format_exc()))
                self.rt.stats.inc("exec_errors")
                self._record_error(
                    spec_op,
                    err(E_INTERNAL, "%s 执行时抛出异常: %s" % (spec_op["op"], exc.__class__.__name__), details={"error": str(exc)[:300]}),
                )
        self.finalize()
        return True

    def _exec_one(self, spec_op):
        rt = self.rt
        handler = spec_op["spec"].handler
        conn = rt.net.conn(self.conn_id) if rt.net is not None else None
        ctx = {
            "conn": conn,
            "index": self.index,
            "rt": rt,
            "on_main": self.on_main,
            "refs": None,
            "is_last": self.index == len(self.ops) - 1,
        }
        t0 = time.monotonic()
        if self.on_main:
            require_main_thread(spec_op["op"])
        with Refs() as refs:
            ctx["refs"] = refs
            out = handler(rt, spec_op["args"] or {}, ctx)
        dt = (time.monotonic() - t0) * 1000.0
        if isinstance(out, Async):
            self.pending = out
            self.pending_t0 = time.monotonic()
            self.pending_ctx = {"op": spec_op["op"], "index": self.index, "t0": t0, "started_ms": dt}
            return
        if isinstance(out, Capture):
            # 截图已在本次 tick 触发（OBS 异步落盘）；文件等待与编码交给网络线程收尾，
            # 因此本 op 必须是批量里的最后一个（handler 已用 ctx["is_last"] 做过校验）。
            self.capture = out
            self.results.append({"ok": True, "op": spec_op["op"], "pending": "await_file", "capture": out.as_dict()})
            self.index += 1
            return
        self.results.append({"ok": True, "op": spec_op["op"], "data": out, "ms": round(dt, 2)})
        self.index += 1

    def _advance_pending(self, now):
        pend = self.pending
        try:
            res = pend.poll(self)
        except NexusError as exc:
            self.pending = None
            self._record_error(self.ops[self.pending_ctx["index"]], exc)
            return True
        except Exception as exc:
            self.pending = None
            _LOG.error("async op 异常: %s" % traceback.format_exc())
            self._record_error(
                self.ops[self.pending_ctx["index"]], err(E_INTERNAL, "异步等待失败: %s" % (exc.__class__.__name__), details={"error": str(exc)[:200]})
            )
            return True
        if res is None:
            if (now - self.pending_t0) * 1000.0 > pend.timeout_ms or now > self.deadline:
                self.pending = None
                self._record_error(
                    self.ops[self.pending_ctx["index"]],
                    err(
                        E_TIMEOUT,
                        "等待 OBS 状态变化超时（%.0f ms）" % pend.timeout_ms,
                        details={"op": self.pending_ctx["op"], **{k: v for k, v in (pend.note or {}).items() if isinstance(v, (str, int, float, bool))}},
                        retryable=True,
                        hint="动作已经下发，可能仍在连接/停止中；稍后用 system.overview 复查。",
                    ),
                )
            return False
        self.pending = None
        idx = self.pending_ctx["index"]
        self.results.append(
            {
                "ok": True,
                "op": self.ops[idx]["op"],
                "data": res,
                "ms": round((time.monotonic() - self.pending_ctx["t0"]) * 1000.0, 2),
            }
        )
        self.index += 1
        return True

    def _record_error(self, spec_op, exc):
        self.rt.stats.inc("ops_err")
        self.results.append({"ok": False, "op": spec_op["op"], "error": exc.to_dict()})
        self.index += 1
        if not self.parsed["continue_on_error"]:
            self.abort = True
            self.aborted = True
            self.abort_error = exc

    def error_of_abort(self):
        e = getattr(self, "abort_error", None)
        return {"code": E_PRECONDITION, "message": "因前序 op 失败而跳过", "stopped_at": e.code if e else None}

    def _timeout_rest(self):
        exc = err(
            E_TIMEOUT,
            "请求超时（%d ms）：OBS 主线程可能在忙或脚本被阻塞" % self.parsed["timeout_ms"],
            retryable=True,
            hint="用 system.health 看 pump 是否活着；减小批量或频率。",
        )
        while self.index < len(self.ops):
            self._record_error(self.ops[self.index], exc)
            self.rt.stats.inc("timeouts")
        self.abort = True
        self.aborted = True

    def finalize(self):
        if self.done:
            return
        self.done = True
        ok_all = bool(self.results) and all(r.get("ok") for r in self.results)
        first_err = None
        for r in self.results:
            if not r.get("ok"):
                first_err = r.get("error")
                break
        payload = {
            "v": NEXUS_PROTO,
            "type": "response",
            "request_id": self.parsed.get("id"),
            "ok": ok_all,
            "elapsed_ms": round((time.monotonic() - self.t0) * 1000.0, 2),
            "result": self.results[0] if len(self.results) == 1 else None,
            "results": self.results,
            "batch": {
                "index": min(self.index, len(self.ops)) - 1 if self.ops else 0,
                "count": len(self.ops),
                "aborted": bool(self.aborted),
                "continue_on_error": bool(self.parsed["continue_on_error"]),
                "executed": sum(1 for r in self.results if not r.get("skipped")),
            },
            "error": first_err,
        }
        if self.pending is not None:
            payload["note"] = "仍有 op 在等待 OBS 状态变化，被超时截断"
        if self.capture is not None:
            payload["pending_capture"] = dict(self.capture.as_dict(), index=len(self.results) - 1)
            payload["batch"]["index"] = len(self.results) - 1
        for r in self.results:  # 发出去之前把内部字段去掉
            r.pop("capture", None)
        self.payload = payload


class NexusRuntime(object):
    """OBS Nexus 服务端本体（生命周期 + 主线程泵）。"""

    def __init__(self, settings=None):
        self.created = time.time()
        self.main_thread_id = threading.get_ident()
        self.net = NetServer(self)
        self.cmd_q = Queue(maxsize=CMD_QUEUE_DEPTH)
        self.reply_q = Queue(maxsize=512)
        self._flight = []
        self._deferred = deque()
        self.stats = Stats()
        self.token = None
        self.token_source = "runtime"
        self.host = LOOPBACK_V4
        self.allow_no_auth = False
        self.allow_lan = False
        self.advanced = False
        self.verbose_events = False
        self.running = False
        self.stopping = False
        self._timer_added = False
        self._frontend_events_added = False
        self._event_seq = 0
        self._recent = deque(maxlen=64)
        self._event_log = deque(maxlen=120)
        self._cache = {}
        self._cache_at = {}
        self._idle_streak = 0
        self.shot_cache = {"path": None, "serial": 0}
        self._capture_deadline = 0.0
        self.dir = nexus_dir()
        self.conn_file = os.path.join(self.dir, "connection.json")
        self.props = {}
        self.limits = {}
        self.event_names = (
            set(_FRONTEND_EVENT_NAMES.values())
            | {
                "text.updated",
                "source.visibility",
                "connection.ready",
                "nexus.reload",
                "nexus.config_changed",
                "nexus.error",
                "frontend_event",  # verbose_events 打开时，未识别的前端事件走这个
            }
        )
        self.default_events = {"scene.changed", "record.started", "record.stopped", "record.paused", "record.unpaused", "stream.started", "stream.stopped"}
        AUDIT.enabled = True
        self.configure(settings, starting=True)

    # --------------------------- 配置 ---------------------------
    def configure(self, settings, starting=False):
        raw = read_server_config()
        vals = {}
        for key, kind, default, _label in PROP_SPECS:
            v = _settings_get(settings, key, kind) if settings is not None else None
            if v is None:
                v = raw.get(key)
            if v is None:
                v = default
            vals[key] = _coerce_prop(kind, v, default)
        env_tok = os.environ.get("OBS_NEXUS_TOKEN")
        if env_tok:
            vals["token"] = env_tok.strip()
        self.props = vals
        self.advanced = bool(vals.get("advanced"))
        self.verbose_events = bool(vals.get("verbose_events"))
        self.allow_lan = bool(vals.get("allow_lan"))
        AUDIT.enabled = bool(vals.get("audit_refs"))
        self.host = LOOPBACK_V4 if not self.allow_lan else (vals.get("bind_host") or LOOPBACK_V4)
        if self.host not in (LOOPBACK_V4, LOOPBACK_V6):
            _LOG.warn("allow_lan 已开启：绑定 %s —— 请把端口限制在防火墙/代理之后" % self.host)
            self.host = LOOPBACK_V4
        self.limits = {
            "max_line_bytes": MAX_LINE_BYTES,
            "max_batch_ops": int(vals.get("max_batch_ops") or MAX_BATCH_OPS),
            "max_connections": int(vals.get("max_connections") or MAX_CONNECTIONS),
            "max_result_bytes": MAX_RESULT_BYTES,
            "max_snapshot_bytes": int(vals.get("max_snapshot_bytes") or MAX_SNAPSHOT_BYTES),
            "max_text_bytes": int(vals.get("max_text_bytes") or 32768),
            "max_list_items": int(vals.get("max_list_items") or 80),
            "idle_timeout_ms": int(vals.get("idle_timeout_ms") or IDLE_TIMEOUT_MS),
            "rate_per_sec": int(vals.get("rate_per_sec") or MAX_CONN_LINES_PER_SEC),
            "timer_interval_ms": TIMER_INTERVAL_MS,
            "request_timeout_max_ms": MAX_REQUEST_TIMEOUT_MS,
        }
        if os.environ.get("OBS_NEXUS_MAX_LINE"):
            try:
                self.limits["max_line_bytes"] = int(os.environ["OBS_NEXUS_MAX_LINE"])
            except ValueError:
                pass
        MAX_LINE_BYTES_eff = self.limits["max_line_bytes"]
        if self.net is not None and self.net.conns:
            for c in list(self.net.conns.values()):
                c.framer.max_bytes = MAX_LINE_BYTES_eff
                c.rate.configure(self.limits["rate_per_sec"])
        want_token = vals.get("require_auth") if not vals.get("token_override") else vals.get("token_override")
        if want_token and not self.token:
            self.ensure_token(force=bool(vals.get("rotate_token")))
        elif not self.allow_no_auth and not want_token:
            self.token = None
            self.token_source = "disabled"
        if starting:
            self.persist_config()

    def persist_config(self):
        keep = {k: self.props.get(k) for k, _t, _d, _l in PROP_SPECS if k not in ("rotate_token", "token_override")}
        save_server_config(keep)

    def ensure_token(self, force=False):
        if self.token and not force:
            return self.token
        self.token = os.urandom(TOKEN_BYTES).hex()
        self.token_source = "generated"
        return self.token

    # --------------------------- 缓存值（worker 可读） ---------------------------
    def cached(self, key, ttl=5.0):
        now = time.time()
        val = self._cache.get(key)
        if val is not None and now - self._cache_at.get(key, 0.0) < ttl:
            return val
        try:
            if key == "obs_version":
                val = obs_version_string()
            elif key == "active_scene":
                val = current_scene_name()
            elif key == "dirs":
                val = _snapshot_dirs()
            else:
                val = None
        except Exception:
            val = None
        self._cache[key] = val
        self._cache_at[key] = now
        return val

    # --------------------------- 生命周期 ---------------------------
    def start(self):
        if self.running:
            return {"ok": True, "note": "已在运行", "port": self.net.port}
        if not obs_alive():
            _LOG.error("obspython 不可用，拒绝启动")
            return {"ok": False, "error": "obspython 不可用"}
        try:
            if not os.path.isdir(self.dir):
                _ensure_dir(self.dir)
            _LOG.open(os.path.join(self.dir, "logs", "nexus.log"))
        except Exception as exc:
            _LOG.warn("状态目录准备失败: %r" % (exc,))
        try:
            startup = _fn("obs_startup")
            if startup is not None:
                pass  # OBS 已完成 obs_startup，脚本不需要（也不能）再调用
            port = self.net.start(self.host, int(self.props.get("port") or 0))
            self.running = True
            self.stopping = False
        except Exception as exc:
            _LOG.error("启动失败: %r\n%s" % (exc, traceback.format_exc()))
            return {"ok": False, "error": "启动失败: %r" % (exc,)}
        try:
            add = _fn("obs_frontend_add_event_callback")
            if add is not None:
                add(_frontend_event_cb, None)
                self._frontend_events_added = True
        except Exception as exc:
            _LOG.warn("注册前端事件失败: %r" % (exc,))
        try:
            if obs is not None and hasattr(obs, "timer_add"):
                obs.timer_add(self._pump, TIMER_INTERVAL_MS)
                self._timer_added = True
        except Exception as exc:
            _LOG.error("obs.timer_add 失败，服务无法桥接到主线程: %r" % (exc,))
            self.stop("timer_failed")
            return {"ok": False, "error": "timer_add 失败: %r" % (exc,)}
        self.write_conn_file()
        self._cache["obs_version"] = obs_version_string()
        self._cache_at["obs_version"] = 0.0
        _LOG.info(
            "OBS Nexus 已启动: %s:%d (auth=%s, advanced=%s, obs=%s, pid=%s)"
            % (self.host, port, "token" if self.token else "off", self.advanced, self._cache.get("obs_version"), os.getpid())
        )
        return {"ok": True, "port": port, "host": self.host, "auth": bool(self.token)}

    def stop(self, reason="manual", report=True):
        if self.stopping:
            return {"ok": True, "note": "已在停止流程中"}
        self.stopping = True
        _LOG.info("停止中（%s）…" % reason)
        try:
            if self._timer_added and obs is not None and hasattr(obs, "timer_remove"):
                obs.timer_remove(self._pump)
        except Exception as exc:
            _LOG.warn("timer_remove 失败: %r" % (exc,))
        self._timer_added = False
        try:
            if self._frontend_events_added:
                rm = _fn("obs_frontend_remove_event_callback")
                if rm is not None:
                    rm(_frontend_event_cb, None)
        except Exception:
            pass
        self._frontend_events_added = False
        ok = True
        try:
            ok = self.net.stop(force=False, timeout=1.5)
        except Exception as exc:
            _LOG.warn("关闭网络线程出错: %r" % (exc,))
        self.running = False
        for st in list(self._flight):
            st.deadline = 0.0
        self._flight = []
        try:
            self.reject_queued(reason)  # 已排队未执行的请求：给个像样的错误，再关连接
        except Exception:
            pass
        self._deferred.clear()
        try:
            while not self.cmd_q.empty():
                self.cmd_q.get_nowait()
        except Empty:
            pass
        try:
            while not self.reply_q.empty():
                self.reply_q.get_nowait()
        except Empty:
            pass
        self.remove_conn_file(reason)
        if report:
            try:
                self._audit_report("shutdown")
            except Exception:
                pass
        _LOG.info("已停止并清理（%s）" % reason)
        _LOG.close()
        return {"ok": bool(ok), "reason": reason}

    def stop_server(self, reason="nexus.stop"):
        """只关掉网络服务：OBS 侧的计时器/回调保留，脚本面板点「启动服务」即可再起来。

        与 stop() 的区别是不注销 OBS 回调、不关日志，属于「临时锁门」而不是「卸载」。
        """
        if not self.running or self.stopping:
            return {"ok": True, "was_running": False, "note": "服务当前没在运行"}
        ok = True
        try:
            ok = self.net.stop(force=False, timeout=1.5)
        except Exception as exc:
            _LOG.warn("net.stop 异常: %r" % (exc,))
            ok = False
        self.running = False
        for st in list(self._flight):
            st.deadline = 0.0
        self._flight.clear()
        self._deferred.clear()
        try:
            while not self.cmd_q.empty():
                self.cmd_q.get_nowait()
        except Exception:
            pass
        self.remove_conn_file(reason)
        _LOG.info("网络服务已停止（%s），OBS 仍在运行" % reason)
        return {"ok": bool(ok), "was_running": True, "reason": reason, "resumable": True}

    def reload_settings(self, restart_if_needed=True):
        """重新读取 config.json 并热应用（改了端口/限流不用重启 OBS）。"""
        before = dict(self.props)
        self.configure(None)
        changed = sorted(k for k in (set(before) | set(self.props)) if before.get(k) != self.props.get(k))[:20]
        needs = [k for k in ("port", "allow_lan", "rate_per_sec", "max_connections") if k in changed]
        restarted = False
        if needs and restart_if_needed and self.running:
            self.restart("nexus.reload:" + ",".join(needs))
            restarted = True
        elif self.running:
            self.write_conn_file()
        self.emit_event("nexus.config_changed", {"changed": changed, "restarted": restarted, "source": "nexus.reload"})
        return {"ok": True, "changed": changed, "restarted": restarted, "port": self.net.port if self.net else 0, "running": self.running}

    def restart(self, reason="restart"):
        self.stop(reason, report=False)
        self.stats.inc("restarts")
        self.net = NetServer(self)
        self.running = False
        self.stopping = False
        self.cmd_q = Queue(maxsize=CMD_QUEUE_DEPTH)
        self.reply_q = Queue(maxsize=512)
        out = self.start()
        if self._timer_added:  # start() 会重新添加；若 timer 仍在则去重
            pass
        return out

    # --------------------------- 连接文件 ---------------------------
    def write_conn_file(self):
        port = self.net.port if self.net else 0
        payload = {
            "app": NEXUS_APP,
            "proto": NEXUS_PROTO,
            "nexus_version": NEXUS_VERSION,
            "host": LOOPBACK_V4,
            "port": int(port),
            "token": self.token,
            "token_source": self.token_source,
            "pid": int(os.getpid()),
            "obs_version": self._cache.get("obs_version") or obs_version_string(),
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "created_ts": round(time.time(), 3),
            "path": self.conn_file,
            "advanced": bool(self.advanced),
            "limits": dict(self.limits),
            "note": "0600；OBS 退出/脚本卸载时自动删除；token 等同 OBS 完全控制权限，切勿外传",
        }
        if not port:
            payload["port"] = 0
            payload["note"] += "（服务未运行）"
        try:
            atomic_write_json(self.conn_file, payload)
            _LOG.info("连接文件已写入 %s (127.0.0.1:%d)" % (self.conn_file, port))
            return {"ok": True, "path": self.conn_file, "port": port, "token_present": bool(self.token)}
        except Exception as exc:
            _LOG.error("写入连接文件失败: %r" % (exc,))
            return {"ok": False, "error": repr(exc)}

    def remove_conn_file(self, reason=""):
        try:
            data = read_json_file(self.conn_file)
            if isinstance(data, dict) and data.get("token") and self.token and data.get("token") != self.token:
                return False  # 不是我们的文件（另一个 OBS 实例持有）-> 不删
        except Exception:
            pass
        try:
            os.unlink(self.conn_file)
            _LOG.info("已删除连接文件 %s (%s)" % (self.conn_file, reason or "n/a"))
            return True
        except FileNotFoundError:
            return False
        except OSError as exc:
            _LOG.warn("删除连接文件失败: %r" % (exc,))
            return False

    def conn_file_state(self):
        data = read_json_file(self.conn_file)
        if not isinstance(data, dict):
            return {"present": False, "path": self.conn_file}
        ours = data.get("token") == self.token and data.get("pid") == os.getpid()
        alive = pid_alive(data.get("pid"))
        return {
            "present": True,
            "ours": bool(ours),
            "port": data.get("port"),
            "pid": data.get("pid"),
            "pid_alive": alive,
            "age_s": round(time.time() - float(data.get("created_ts") or 0), 1) if data.get("created_ts") else None,
            "stale": (alive is False) or (data.get("created_ts") and time.time() - float(data["created_ts"]) > CONN_TTL_MS / 1000.0 * 600),
            "token_null": data.get("token") is None,
        }

    # --------------------------- 桥接：worker -> 主线程 ---------------------------
    def submit_request(self, conn, parsed):
        state = RequestState(self, conn.id, parsed, on_main=not all(o["spec"].execution == EXEC_WORKER for o in parsed["ops"]))
        if not state.on_main:
            # 纯本地 op（不碰 libobs）直接在网络线程执行，零排队延迟
            try:
                state.run()
                self.reply_q.put(("reply", conn.id, state.payload, state.payload.get("pending_capture")))
                self.notify()
            except Exception as exc:
                _LOG.error("本地 op 执行失败: %s" % traceback.format_exc())
                conn.send_obj(build_error_response(parsed.get("id"), err(E_INTERNAL, "本地 op 失败: %r" % (exc,))))
            return True
        try:
            self.cmd_q.put_nowait(state)
        except Full:
            self.stats.inc("overload_drops")
            conn.in_flight = False
            conn.send_obj(
                build_error_response(
                    parsed.get("id"),
                    err(
                        E_OVERLOAD,
                        "主线程队列已满（深度 %d）" % self.cmd_q.qsize(),
                        retryable=True,
                        details={"backlog": self.cmd_q.qsize()},
                        hint="OBS 主线程可能正忙；退避后重试，或降低批量大小。",
                    ),
                )
            )
            return False
        self.stats.inc("submitted")
        depth = self.cmd_q.qsize()
        if depth > self.stats.get("queue_high_water"):
            self.stats["queue_high_water"] = depth
        if depth >= CMD_QUEUE_HIGH:
            _LOG.warn("命令队列水位偏高: %d/%d" % (depth, CMD_QUEUE_DEPTH))
        return True

    def cmd_space(self):
        return self.cmd_q.qsize() < CMD_QUEUE_DEPTH

    def cmd_backlog(self):
        return self.cmd_q.qsize()

    def notify(self):
        try:
            if self.net is not None:
                self.net.wake()
        except Exception:
            pass

    def post_reply(self, conn_id, payload):
        try:
            self.reply_q.put_nowait(("reply", conn_id, payload, payload.get("pending_capture")))
        except Full:
            self.stats.inc("dropped_replies")
            try:
                self.reply_q.put_nowait(("force_close", conn_id, "reply_overflow"))
            except Full:
                pass
        self.notify()

    def forget_connection(self, conn_id):
        for st in list(self._flight):
            if st.conn_id == conn_id:
                self._flight.remove(st)
        self.notify()

    def post_deferred(self, delay_ms, fn, *args):
        self._deferred.append((time.monotonic() + max(0.0, delay_ms / 1000.0), fn, args))

    defer = post_deferred

    def emit_event(self, name, data=None):
        self._event_seq += 1
        self.stats.inc("events")
        self._event_log.appendleft((round(time.time(), 3), name, data))
        for conn_id in list(self.net.conns) if self.net else []:
            conn = self.net.conn(conn_id)
            if conn is not None and conn.wants(name):
                pass  # 真正的推送在 _drain_replies 的 ("event",..) 分支里做
        try:
            self.reply_q.put_nowait(("event", name, data))
        except Full:
            self.stats.inc("dropped_replies")
        self.notify()

    def snapshot_props(self):
        return dict(self.props)

    # --------------------------- 主线程泵（R3） ---------------------------
    def _pump(self, seconds=0.0):
        """OBS 主线程定时器回调（签名必须收 float 秒数：OBS 用 CallFunction(handler,"f",secs)）。"""
        t0 = time.monotonic()
        self._tick_secs = seconds
        self.stats.inc("pump_ticks")
        if self.stopping:
            # 停机中：一个 op 都不许碰 libobs，但要把排队的请求答复完再退
            self.reject_queued("pump")
            return
        budget = self._tick_budget()
        did = 0
        # 1) 消费网络线程投递的任务/请求
        while did < budget:
            try:
                job = self.cmd_q.get_nowait()
            except Empty:
                break
            did += 1
            try:
                if isinstance(job, RequestState):
                    if job.run():
                        self._finish(job)
                    else:
                        self._flight.append(job)
                elif callable(job):
                    job()
            except NexusError as exc:
                _LOG.warn("泵内任务返回错误: %s" % exc.code)
            except Exception as exc:
                self.stats.inc("exec_errors")
                _LOG.error("泵内任务异常:\n%s" % traceback.format_exc())
                self._emit_error("pump_job", exc)
        # 2) 推进未完成请求（Async 等待 / 超预算续跑 / 超时）
        for st in list(self._flight):
            if time.monotonic() > st.deadline:
                st._timeout_rest()
                st.finalize()
                self._flight.remove(st)
                self._finish(st)
                continue
            try:
                if st.run(40.0):
                    self._flight.remove(st)
                    self._finish(st)
                    did += 1
            except Exception as exc:
                _LOG.error("flight 推进异常:\n%s" % traceback.format_exc())
                self._emit_error("pump_flight", exc)
                try:
                    self._flight.remove(st)
                    st.finalize()
                    self._finish(st)
                except Exception:
                    pass
        # 3) 延时任务
        now = time.monotonic()
        for _ in range(32):
            if not self._deferred:
                break
            due, fn, args = self._deferred[0]
            if due > now:
                break
            self._deferred.popleft()
            try:
                fn(*args)
                self.stats.inc("deferred_run")
            except Exception:
                _LOG.warn("延时任务失败:\n%s" % traceback.format_exc())
        # 4) 截图路径缓存（把主线程专属值变成纯 python 值给 worker 用）
        if now < self._capture_deadline:
            fn = _fn("obs_frontend_get_last_screenshot")
            if fn is not None:
                try:
                    p = fn()
                    if p != self.shot_cache.get("path"):
                        self.shot_cache = {"path": p, "serial": self.shot_cache.get("serial", 0) + 1, "ts": time.time()}
                except Exception:
                    pass
        # 5) 周期性自检
        if self.stats.get("pump_ticks") % 600 == 0:
            self._audit_report("periodic")
        took = (time.monotonic() - t0) * 1000.0
        self._last_pump_ms = took
        self._last_pump_at = time.time()
        self._pump_work = did
        if took > MAX_PUMP_TICK_MS:
            self.stats.inc("pump_over_budget")
        self._idle_streak = self._idle_streak + 1 if did == 0 else 0
        self._pump_count_since_work = getattr(self, "_pump_count_since_work", 0)
        if did:
            self.notify()

    def _tick_budget(self):
        i = min(self._idle_streak, len(TICK_BUDGET) - 1)
        return TICK_BUDGET[i]

    def reject_queued(self, reason):
        """把 cmd_q 里还没执行的请求逐个回 `SHUTTING_DOWN`（不执行任何 libobs 调用）。

        没有这一步的话，停机瞬间排队的请求只会随着 socket 关闭变成「连接被重置」，
        客户端分不清「没送到」和「被拒绝」，容易写出无限重试的循环。
        """
        n = 0
        while n < MAX_PUMP_JOBS:
            try:
                job = self.cmd_q.get_nowait()
            except Empty:
                break
            n += 1
            if not isinstance(job, RequestState):
                continue  # 内部 callable 任务：直接丢掉（都是日志/收尾类，重复执行才危险）
            try:
                job.payload = build_error_response(
                    job.parsed.get("id"),
                    err(
                        E_SHUTTING_DOWN,
                        "OBS 正在关闭，请求未执行（%s）" % reason,
                        details={"queued_ops": [o["op"] for o in job.ops][:8]},
                        hint="进程即将退出：不要重试，等脚本重新起来。",
                        retryable=False,
                    ),
                )
                job.done = True
                self._finish(job)
            except Exception:
                pass
        return n

    def _finish(self, state):
        self.stats.inc("executed")
        if state.capture is not None:
            self._capture_deadline = time.monotonic() + (state.capture.as_dict().get("timeout_ms", 2500) / 1000.0) + 0.5
            self.stats.inc("captures")
        if state.payload and not state.payload.get("ok"):
            self.stats.inc("ops_err")
        if state.payload and state.payload.get("elapsed_ms", 0) > 1000:
            self.stats.inc("slow_requests")
        conn = self.net.conn(state.conn_id) if self.net is not None else None
        if conn is None:
            return  # 客户端已断开：直接丢弃响应（引用已在本 tick 释放）
        self.post_reply(state.conn_id, state.payload)

    def _emit_error(self, where, detail):
        """把「服务端自己出事了」推给订阅者（默认没人收，节流 2s 一条）。

        泵里的异常只写日志的话，Agent 只会看到超时/断连，排障要靠猜；
        有了这个事件，LLM 侧至少知道「OBS 主线程里刚才抛了什么」。
        """
        now = time.monotonic()
        if now - getattr(self, "_last_error_evt_at", 0.0) < 2.0:
            return
        self._last_error_evt_at = now
        try:
            self.emit_event("nexus.error", {"where": where, "detail": str(detail)[:600]})
        except Exception:
            pass

    def _audit_report(self, why):
        snap = AUDIT.snapshot()
        if snap["outstanding"] or snap["leaks"] or snap["double_release"]:
            _LOG.warn("引用审计(%s): %s" % (why, snap))
            self._emit_error("ref_audit", "%s: %s" % (why, snap))
        elif _LOG_DEBUG:
            _LOG.debug("引用审计(%s): 干净 gets=%d releases=%d" % (why, snap["gets"], snap["releases"]))

    # --------------------------- 观测 ---------------------------
    def metrics(self, detailed=False):
        now = time.time()
        out = {
            "running": bool(self.running),
            "stopping": bool(self.stopping),
            "listen": "%s:%s" % (self.host, self.net.port if self.net else 0),
            "port": self.net.port if self.net else 0,
            "pid": os.getpid(),
            "connections": len(self.net.conns) if self.net else 0,
            "max_connections": self.limits.get("max_connections"),
            "queue_depth": self.cmd_q.qsize(),
            "queue_capacity": CMD_QUEUE_DEPTH,
            "reply_queue": self.reply_q.qsize(),
            "in_flight": len(self._flight),
            "pump_ticks": self.stats.get("pump_ticks"),
            "pump_lag_ms": round((now - getattr(self, "_last_pump_at", now)) * 1000.0, 1),
            "last_pump_ms": round(getattr(self, "_last_pump_ms", 0.0), 2),
            "tick_budget": self._tick_budget(),
            "auth_required": bool(self.token),
            "advanced": bool(self.advanced),
            "uptime_s": round(now - self.created, 1),
            "idle_streak": self._idle_streak,
        }
        if detailed:
            out["counters"] = self.stats.as_dict()
            out["limits"] = dict(self.limits)
            out["connections_detail"] = [c.usage() for c in list(self.net.conns.values())] if self.net else []
            out["recent_requests"] = list(self._recent)[:12]
            out["recent_events"] = [{"ts": t, "event": n} for (t, n, _d) in list(self._event_log)[:12]]
            out["conn_file"] = self.conn_file_state()
            out["refs"] = AUDIT.snapshot()
            out["log_path"] = _LOG.path
            out["snapshot"] = snapshot_capability()
        return out

    def health(self):
        now = time.time()
        return {
            "timer_alive": bool(self._timer_added),
            "thread_alive": bool(self.net and self.net._thread and self.net._thread.is_alive()),
            "pump_age_ms": round((now - getattr(self, "_last_pump_at", now)) * 1000.0, 1),
            "pump_ticks": self.stats.get("pump_ticks"),
            "pump_over_budget": self.stats.get("pump_over_budget"),
            "queue_depth": self.cmd_q.qsize(),
            "in_flight": len(self._flight),
            "log_errors": _LOG.error_count,
            "conn_file": self.conn_file_state(),
            "running": bool(self.running),
            "stopping": bool(self.stopping),
            "uptime_s": round(now - self.created, 1),
        }

    def observe_request(self, info):
        self._recent.appendleft(info)


# 主线程 -> 网络线程的唯一「事件」通道；网络线程 -> 主线程走 cmd_q
_server_ref = {"rt": None}


def _server():
    return _SERVER


# NetworkServer 需要的 conn 查询（保持 NetServer 不直接依赖 runtime 细节）
def _net_conn(self, conn_id):
    return self.conns.get(conn_id)


NetServer.conn = _net_conn


def safe(fn):
    """OBS 回调保护：任何异常都不能穿透到 libobs（否则 OBS 直接闪退）。"""

    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except NexusError as exc:
            _LOG.warn("%s: %s" % (fn.__name__, exc.message))
        except Exception:
            _LOG.error("%s 内部异常:\n%s" % (fn.__name__, traceback.format_exc()))
        return None

    wrapper.__name__ = "safe_" + fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


@safe
def _frontend_event_cb(event, _param):
    """OBS 前端事件（主线程）：转成纯 python 数据后推给订阅者。"""
    rt = _SERVER
    if rt is None:
        return
    try:
        ev = int(event)
    except (TypeError, ValueError):
        return
    name = _FRONTEND_EVENT_NAMES.get(ev)
    if name is None:
        if rt.verbose_events:
            rt.emit_event("frontend_event", {"event_id": ev})
        if ev not in (FRONTEND_EVENT_OBS_SHUTDOWN, FRONTEND_EVENT_EXIT):
            return
        name = _FRONTEND_EVENT_NAMES.get(ev) or "obs_shutdown"
    data = {}
    if name in ("scene.changed", "scene_list.changed", "profile.changed", "transition.changed"):
        data["current_scene"] = current_scene_name()
        if name == "scene_list.changed":
            refs = Refs()
            try:
                data["scenes"] = [n for (n, _s) in list_scenes(refs)][:200]
            finally:
                refs.release_all()
    elif name and name.startswith("stream"):
        data["streaming"] = _stream_state()
    elif name and name.startswith("record"):
        data["recording"] = _record_state()
    if name in ("obs_shutdown", "obs.exit"):
        _LOG.info("收到 OBS %s 事件，开始优雅退出" % name)
        rt.post_deferred(0, rt.stop, "obs_" + name)
        return
    rt.emit_event(name, data)


def _settings_get(settings, key, kind):
    if settings is None:
        return None
    try:
        if kind == "bool":
            return bool(obs.obs_data_get_bool(settings, key))
        if kind == "int":
            v = obs.obs_data_get_int(settings, key)
            return int(v) if v is not None else None
        if kind in ("str", "path", "text"):
            v = obs.obs_data_get_string(settings, key)
            return v if v else None
        if kind == "list":
            v = obs.obs_data_get_string(settings, key)
            return v if v else None
    except Exception:
        return None
    return None


def _coerce_prop(kind, value, default):
    try:
        if kind == "bool":
            return _bool(value, bool(default))
        if kind == "int":
            return int(float(value))
    except (TypeError, ValueError):
        return default
    return ("%s" % value).strip() if isinstance(value, str) else value


def _data_set_default(settings, key, kind, value):
    """写「默认值」而不是写「值」：OBS 加载脚本时会先调 script_defaults(settings)。

    这里如果手滑用了 obs_data_set_*，每次启动 OBS 都会把用户调好的设置抹回默认值
    （端口、限流、advanced 全没了），而且很难发现。obs_data_set_default_* 的语义是
    「键不存在才填」，正是我们要的。
    """
    if settings is None:
        return
    try:
        if kind == "bool":
            obs.obs_data_set_default_bool(settings, key, bool(value))
        elif kind in ("int",):
            obs.obs_data_set_default_int(settings, key, int(value or 0))
        elif kind in ("float", "number"):
            obs.obs_data_set_default_double(settings, key, float(value or 0.0))
        elif kind in ("list", "str", "combotext"):
            obs.obs_data_set_default_string(settings, key, "%s" % (value if value is not None else ""))
        else:
            obs.obs_data_set_default_string(settings, key, "%s" % (value if value is not None else ""))
    except Exception:
        pass


def _data_set_prop(settings, key, value):
    try:
        if isinstance(value, bool):
            obs.obs_data_set_bool(settings, key, value)
        elif isinstance(value, int):
            obs.obs_data_set_int(settings, key, value)
        else:
            obs.obs_data_set_string(settings, key, "%s" % value)
    except Exception:
        pass


# =============================================================================
# 脚本属性面板
# =============================================================================
PROP_SPECS = (
    ("autostart", "bool", True, "OBS 启动时自动开启 Nexus 服务"),
    ("port", "int", 0, "监听端口（0 = 在下方区间内随机挑选可用端口）"),
    ("port_lo", "int", PORT_RANGE[0], "随机端口区间下限"),
    ("port_hi", "int", PORT_RANGE[1], "随机端口区间上限"),
    ("require_auth", "bool", True, "强制 Token 鉴权（强烈推荐保持勾选）"),
    ("allow_lan", "bool", False, "⚠️ 允许局域网访问（关闭仅回环保护；只应配合 SSH/端口转发+防火墙使用）"),
    ("rate_per_sec", "int", 200, "每连接每秒最大请求行数（限流防爆）"),
    ("max_batch_ops", "int", MAX_BATCH_OPS, "单请求最大 op 数（批量防爆）"),
    ("max_connections", "int", MAX_CONNECTIONS, "最大并发连接数"),
    ("max_list_items", "int", 80, "source.list 默认返回条数（省 LLM 上下文）"),
    ("max_text_bytes", "int", 32768, "text.set 单次写入字节上限"),
    ("max_snapshot_bytes", "int", MAX_SNAPSHOT_BYTES // 4, "canvas.snapshot base64 前字节上限"),
    ("snapshot_mode", "list", "auto", "截图后端：auto / native / file / dir / command / off"),
    ("snapshot_dir", "str", "", "截图兜底目录（留空 = 自动探测 OBS 截图目录 + ~/.obs_nexus/snapshots）"),
    ("snapshot_quality", "int", 82, "JPEG 质量（需 Pillow 才生效）"),
    ("snapshot_timeout_ms", "int", 2500, "等待 OBS 写出截图文件的超时"),
    ("snapshot_command", "str", "", "外部截图命令（advanced；占位符 {output} {source}）"),
    ("echo_text", "bool", True, "text.set 结果里回显写入后的文本（便于校对）"),
    ("verbose_events", "bool", False, "把所有 OBS 前端事件都转发（默认只转发状态相关事件）"),
    ("keep_conn_file", "bool", True, "退出时删除 connection.json（保持勾选更安全）"),
    ("advanced", "bool", False, "⚠️ 允许高级控制（settings_merge / 场景增删 / 热重载 / 日志读取）"),
    ("audit_refs", "bool", True, "引用计数审计（排查泄漏用，可关闭省性能）"),
    ("max_batch_exec_ms", "int", int(MAX_BATCH_EXEC_MS), "单请求每 tick 占用的主线程预算(ms)"),
    ("rotate_token", "bool", False, "勾选后下次启动重新生成 token（配合「写入连接文件」按钮）"),
)


def script_description():
    return (
        "<h3>OBS Nexus %s — Agent 控制运行时（Loopback JSON）</h3>"
        "<p>在本机 <code>127.0.0.1</code> 随机端口上开一个单行 JSON 协议服务，"
        "供外部大模型/自动化脚本控制 OBS（场景、源、文本、音频、录制推流、画布截图）。</p>"
        "<p><b>线程模型</b>：网络在独立守护线程（selectors），所有 libobs 调用由 "
        "<code>obs.timer_add(pump, %d)</code> 投递到 OBS 主线程执行；引用配对释放并带泄漏审计。</p>"
        "<p><b>连接方式</b>：启动后把 host/port/token 原子写入 <code>~/.obs_nexus/connection.json</code>（0600），"
        "客户端 <code>agent_client.py</code> 自动读取。OBS 退出/脚本卸载会自动删除该文件。</p>"
        "<p><b>快速开始</b>：点下面的「写入连接文件」，然后终端执行 "
        "<code>python agent_client.py --call system.overview</code>；"
        "AI 字幕：<code>--op text.set --arg source=字幕 --arg text=hello</code>。</p>"
        "<p style='color:#c60'><b>安全</b>：Token 等同 OBS 完全控制权，服务只监听回环地址；"
        "不要转发到公网，不要在不信任的网络里取消勾选「强制 Token 鉴权」。</p>"
        % (NEXUS_VERSION, TIMER_INTERVAL_MS)
    )


def script_defaults(settings):
    # 只兜「没设过的键」，绝不能覆盖用户已有设置（见 _data_set_default 的说明）
    for key, kind, default, _label in PROP_SPECS:
        _data_set_default(settings, key, kind, default)


def script_properties():
    props = obs.obs_properties_create()
    rt = _SERVER
    for key, kind, default, label in PROP_SPECS:
        cur = (rt.props.get(key) if rt is not None else None)
        cur = default if cur is None else cur
        if kind == "bool":
            p = obs.obs_properties_add_bool(props, key, label)
        elif kind == "int":
            lo, hi = 0, 1000000
            if key == "port":
                lo, hi = 0, 65535
            elif key == "snapshot_quality":
                lo, hi = 20, 100
            elif key in ("max_batch_ops", "max_connections"):
                lo, hi = 1, 4096
            p = obs.obs_properties_add_int(props, key, label, lo, hi, 1)
        elif key == "snapshot_mode":
            p = obs.obs_properties_add_list(props, key, label, 0, 1)  # OBS_COMBO_TYPE_LIST / FORMAT_STRING
            for opt in ("auto", "native", "file", "dir", "command", "off"):
                try:
                    obs.obs_property_list_add_string(p, opt, opt)
                except Exception:
                    pass
            try:
                obs.obs_property_set_long_description(p, "native = 用 OBS 原生截图管线；file = 只回路径不塞 base64；dir = 只从目录取最新图；command = 调外部命令")
            except Exception:
                pass
        else:
            p = obs.obs_properties_add_text(props, key, label, 1 if key.endswith("_dir") else 0)
        try:
            obs.obs_property_set_long_description(p, "%s（当前 %r）" % (label, cur))
        except Exception:
            pass
    try:
        text = obs.obs_properties_add_text(props, "status_line", "状态", 1)
        if rt is not None:
            obs.obs_property_set_description(text, _status_line(rt))
            obs.obs_property_set_long_description(text, json.dumps(rt.metrics(detailed=True), ensure_ascii=False, default=str)[:2000])
    except Exception:
        pass
    obs.obs_properties_add_button(props, "btn_start_stop", "▶ / ⏹ 启动或停止服务", _btn_start_stop)
    obs.obs_properties_add_button(props, "btn_write_conn", "📝 写入连接文件 connection.json", _btn_write_conn)
    obs.obs_properties_add_button(props, "btn_revoke", "🔑 重新生成 Token 并覆盖连接文件", _btn_revoke)
    obs.obs_properties_add_button(props, "btn_caps", "📄 导出 ops 能力清单 capabilities.json", _btn_caps)
    obs.obs_properties_add_button(props, "btn_dir", "📁 打开 ~/.obs_nexus 目录", _btn_open_dir)
    return props


def _status_line(rt):
    if rt is None:
        return "状态：未初始化"
    m = rt.metrics()
    return (
        "状态：%s  监听 127.0.0.1:%s  连接 %s  鉴权 %s  队列 %s  pump %s tick"
        % (
            "运行中" if m["running"] else ("停止中" if m["stopping"] else "已停止"),
            m["port"],
            m["connections"],
            "开" if m["auth_required"] else "关",
            m["queue_depth"],
            m["pump_ticks"],
        )
    )


@safe
def _btn_start_stop(props, prop):
    rt = _SERVER
    if rt is None:
        return None
    if rt.running:
        rt.stop("button")
    else:
        rt.start()
    _refresh_props(rt)
    return None


@safe
def _btn_write_conn(props, prop):
    rt = _SERVER
    if rt is not None:
        out = rt.write_conn_file()
        _LOG.info("写入连接文件结果: %s" % out)
    return None


@safe
def _btn_revoke(props, prop):
    rt = _SERVER
    if rt is None:
        return None
    rt.ensure_token(force=True)
    rt.token_source = "rotated"
    rt.write_conn_file()
    _LOG.info("Token 已重新生成（旧 token 立即失效）")
    return None


@safe
def _btn_caps(props, prop):
    rt = _SERVER
    try:
        payload = {
            "nexus_version": NEXUS_VERSION,
            "proto": NEXUS_PROTO,
            "obs_version": (rt or _server_ref["rt"])._cache.get("obs_version") if rt else obs_version_string(),
            "limits": dict(rt.limits) if rt else {},
            "ops": [spec.describe() for name, spec in sorted(OPS.items())],
        }
        atomic_write_json(os.path.join(nexus_dir(), "capabilities.json"), payload)
        _LOG.info("已导出 %d 个 op 到 %s" % (len(OPS), os.path.join(nexus_dir(), "capabilities.json")))
    except Exception as exc:
        _LOG.error("导出能力清单失败: %r" % (exc,))
    return None


@safe
def _btn_open_dir(props, prop):
    rt = _SERVER
    path = (rt.dir if rt else nexus_dir()) or nexus_dir()
    try:
        if os.name == "nt":
            os.startfile(path)  # noqa: S606
        else:
            opener = "open" if sys.platform == "darwin" else "xdg-open"
            if shutil.which(opener):
                subprocess.Popen([opener, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                _LOG.info("请手动打开：%s" % path)
    except Exception as exc:
        _LOG.warn("打开目录失败: %r（路径 %s）" % (exc, path))
    return None


def _refresh_props(rt):
    cb = _fn("obs_properties_apply_settings")
    if cb is not None and rt is not None:
        try:
            obs_script = _fn("obs_script_get_properties")
            if obs_script is not None:
                pass
        except Exception:
            pass


def script_update(settings):
    rt = _SERVER
    if rt is None:
        return
    before = dict(rt.props)
    rt.configure(settings)
    rt.persist_config()
    changed_restart = [k for k in ("port", "allow_lan", "rate_per_sec", "max_connections") if before.get(k) != rt.props.get(k)]
    if rt.running and changed_restart:
        _LOG.info("检测到 %s 变化，重启网络服务端" % ",".join(changed_restart))
        rt.restart("props:" + ",".join(changed_restart))
    elif rt.running and before.get("require_auth") != rt.props.get("require_auth"):
        if not rt.props.get("require_auth"):
            rt.token = None
            rt.token_source = "disabled"
        else:
            rt.ensure_token(force=True)
        rt.write_conn_file()
    rt.emit_event("nexus.config_changed", {"changed": sorted(k for k in set(before) | set(rt.props) if before.get(k) != rt.props.get(k))[:16]})


def script_load(settings):
    global _LOG_DEBUG, MAX_LINE_BYTES
    _LOG_DEBUG = bool(os.environ.get("OBS_NEXUS_DEBUG"))
    try:
        p = obs.script_get_path() if obs is not None and hasattr(obs, "script_get_path") else ""
        if p:
            _LOG.debug("脚本路径: %s" % p)
    except Exception:
        pass
    if not obs_alive():
        _LOG.error("无法导入 obspython：OBS Nexus 需要在 OBS 的 Python 脚本环境中运行")
        return
    cfg = read_server_config()
    if settings is not None:
        for key, kind, _default, _label in PROP_SPECS:
            v = _settings_get(settings, key, kind)
            if v is None and key in cfg:
                _data_set_prop(settings, key, cfg[key])
    global _SERVER
    if _SERVER is not None:  # 重复加载（例如手动 reload）：先干净停掉旧的
        try:
            _SERVER.stop("reload")
        except Exception:
            pass
        _SERVER = None
    _SERVER = NexusRuntime(settings)
    _server_ref["rt"] = _SERVER
    if _SERVER.props.get("autostart", True):
        _SERVER.start()
    else:
        _LOG.info("autostart=off：等待点「启动服务」按钮")


def script_unload():
    global _SERVER
    rt = _SERVER
    _SERVER = None
    if rt is None:
        return
    try:
        keep = bool((rt.props or {}).get("keep_conn_file", True))
        if not keep:
            rt.write_conn_file()  # 故意留下最新连接信息（不推荐）
        rt.stop("script_unload")
        if keep:
            rt.remove_conn_file("script_unload")
    except Exception:
        _LOG.error("script_unload 异常:\n%s" % traceback.format_exc())
