#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""agent_client.py —— OBS Nexus 的独立命令行客户端（只用 Python 标准库）。

设计目标：给 LLM / 自动化脚本当「手」。它自己找连接信息，不需要你传端口和 token。

    # 看一眼 OBS 现在什么状态
    python3 agent_client.py --op system.overview

    # 改字幕（AI 解说）
    python3 agent_client.py --op text.set --set source=字幕 --set text="大家好，欢迎来到我的直播间"

    # 显示/隐藏 AI 贴片
    python3 agent_client.py --op source.visibility --set scene=场景A --set source=AI提示 --toggle

    # 录制控制
    python3 agent_client.py --op stream.control --json '{"action":"start_record"}'

    # 批量（一次 TCP 往返做完一组动作）
    python3 agent_client.py --batch '[{"op":"scene.switch","scene":"游戏"},{"op":"stream.control","action":"start_record"}]'

    # 管道模式：每行一个请求，每行一个响应（适合常驻 agent 循环）
    while read -r line; do echo "$line"; done | python3 agent_client.py --ndjson

    # 订阅事件
    python3 agent_client.py --watch --events scene.changed,record.started

    # 截图存文件
    python3 agent_client.py --op canvas.snapshot --json '{"source":"摄像头"}' --snapshot-out /tmp/cam.jpg

退出码（给脚本判断用，比读文案可靠）：
    0  全部成功
    1  连接通了，但 op 返回了错误（含批量里某一步失败）
    2  传输层失败（连不上 / 被断开 / 超时 / 协议不对）
    3  配置层失败（找不到 connection.json、token 不对、OBS 没在跑）

环境变量：
    OBS_NEXUS_DIR    覆盖 ~/.obs_nexus（connection.json 所在目录）
    OBS_NEXUS_TOKEN  直接给 token（跳过文件读取，方便 CI）
"""

from __future__ import annotations

import argparse
import base64
import errno
import json
import os
import socket
import sys
import time

EXIT_OK = 0
EXIT_OP_ERROR = 1
EXIT_TRANSPORT = 2
EXIT_CONFIG = 3

DEFAULT_TIMEOUT = 8.0
MAX_LINE = 1 << 20  # 与 OBS Nexus 的服务端上限保持一致


# --------------------------------------------------------------------------- #
# 连接信息
# --------------------------------------------------------------------------- #
def conn_file_path(cli_value=None):
    """定位 connection.json：显式参数 > $OBS_NEXUS_DIR > ~/.obs_nexus。"""
    if cli_value:
        return os.path.expanduser(cli_value)
    base = os.environ.get("OBS_NEXUS_DIR") or os.path.join(os.path.expanduser("~"), ".obs_nexus")
    return os.path.join(base, "connection.json")


def pid_alive(pid):
    """判断 pid 是否还活着（跨平台，不依赖 psutil）。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        try:  # 只在 Windows 上加载 ctypes
            import ctypes
            from ctypes import wintypes

            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not h:
                return False
            try:
                code = wintypes.DWORD()
                if kernel32.GetExitCodeProcess(h, ctypes.byref(code)):
                    return code.value == STILL_ACTIVE
                return True  # 拿不到退出码但句柄有效：认为还在
            finally:
                kernel32.CloseHandle(h)
        except Exception:
            return True  # 判不准时宁可放行，让后面的 TCP 连接去说话
    try:
        os.kill(pid, 0)
    except OSError as exc:
        return exc.errno == errno.EPERM  # 有进程但没权限看 = 活着
    except Exception:
        return False
    return True


class ConnInfo(object):
    """~/.obs_nexus/connection.json 的内容 + 新鲜度判断。"""

    def __init__(self, data, path):
        self.path = path
        self.data = data or {}
        self.host = str(self.data.get("host") or "127.0.0.1")
        self.port = int(self.data.get("port") or 0)
        self.token = self.data.get("token")
        self.pid = self.data.get("pid")
        self.obs_version = self.data.get("obs_version")
        self.nexus_version = self.data.get("nexus_version")
        self.updated_at = self.data.get("updated_at")

    @classmethod
    def load(cls, path=None, allow_stale=False):
        """读取并校验；返回 (info, None) 或 (None, 人话错误)。"""
        p = conn_file_path(path)
        if not os.path.isfile(p):
            return None, (
                "找不到 %s\n"
                "  → OBS 里 工具(Tools) → 脚本(Scripts) → 加载 obs_nexus.py，并确认「启用服务」已勾选。\n"
                "  → 或在脚本面板点一次「写入连接文件」。" % p
            )
        try:
            with open(p, "r", encoding="utf-8") as fh:
                raw = fh.read()
        except OSError as exc:
            return None, "无法读取 %s: %s" % (p, exc)
        try:
            data = json.loads(raw)
        except ValueError as exc:
            return None, "%s 不是合法 JSON（可能被别的程序写坏了）: %s" % (p, exc)
        if not isinstance(data, dict):
            return None, "%s 顶层应该是对象" % p
        info = cls(data, p)
        if not info.port:
            return None, "%s 里没有 port 字段，重新点「写入连接文件」" % p
        env_tok = os.environ.get("OBS_NEXUS_TOKEN", "").strip()
        if env_tok:
            info.token = env_tok
        if not allow_stale and info.pid and not pid_alive(info.pid):
            return None, (
                "连接文件里的 OBS 进程 pid=%s 已经不在了（陈旧文件：%s）。\n"
                "  → 启动 OBS 并加载脚本后重试；确认要按文件里的地址连接请加 --ignore-stale。\n"
                "  → 想指定别的目录：设 OBS_NEXUS_DIR 或用 --conn-file。" % (info.pid, p)
            )
        return info, None


# --------------------------------------------------------------------------- #
# 客户端
# --------------------------------------------------------------------------- #
class NexusError(Exception):
    def __init__(self, code, msg, exit_code=EXIT_TRANSPORT):
        Exception.__init__(self, msg)
        self.code = code
        self.exit_code = exit_code


class Client(object):
    """单连接、按 request_id 匹配响应、事件另存一列。"""

    def __init__(self, host, port, token=None, timeout=DEFAULT_TIMEOUT, tls=False):
        self.timeout = timeout
        self.token = token
        self.sock = None
        self.host = host
        self.port = port
        self._buf = b""
        self._seq = 0
        self.events = []  # 收到的 type=event（以及暂时用不上的消息）
        self.server_info = {}
        self._connect()

    # ---------------- 连接 / 帧 ----------------
    def _targets(self):
        """连接候选地址：本机优先 127.0.0.1，其次 ::1，再退回原 host。"""
        host = self.host or "127.0.0.1"
        if host in ("localhost", "127.0.0.1"):
            return [(socket.AF_INET, ("127.0.0.1", self.port)), (socket.AF_INET6, ("::1", self.port, 0, 0))]
        if host in ("::1", "[::1]"):
            return [(socket.AF_INET6, ("::1", self.port, 0, 0))]
        try:
            infos = socket.getaddrinfo(host, self.port, 0, socket.SOCK_STREAM)
        except OSError:
            infos = []
        out = [(fam, addr) for fam, _cn, addr in [(i[0], i[1], i[4]) for i in infos]]
        return out or [(socket.AF_INET, (host, self.port))]

    def _connect(self):
        errs = []
        for fam, addr in self._targets():
            s = None
            try:
                s = socket.socket(fam, socket.SOCK_STREAM)
                s.settimeout(self.timeout)
                s.connect(addr)
                s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                self.sock = s
                return
            except OSError as exc:
                errs.append("%s: %s" % (addr[0] if isinstance(addr, tuple) else addr, exc.strerror or exc))
                if s is not None:
                    try:
                        s.close()
                    except OSError:
                        pass
            except Exception as exc:
                errs.append(repr(exc))
                if s is not None:
                    try:
                        s.close()
                    except OSError:
                        pass
        raise NexusError(
            "connect_failed",
            "连不上 OBS Nexus %s:%d —— %s\n"
            "  → OBS 在跑吗？脚本加载了吗？端口对吗（看 connection.json 的 port）？"
            % (self.host, self.port, "; ".join(errs[:3]) or "没有可用地址"),
        )

    def close(self):
        if self.sock is not None:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def _send_line(self, obj):
        try:
            payload = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise NexusError("bad_json", "请求不是可序列化的 JSON: %s" % exc, EXIT_CONFIG)
        if len(payload) + 1 > MAX_LINE:
            raise NexusError("too_large", "单行请求 %d 字节，超过上限 %d" % (len(payload), MAX_LINE), EXIT_CONFIG)
        try:
            self.sock.sendall(payload + b"\n")
        except OSError as exc:
            raise NexusError("write_failed", "发送失败：%s（连接可能已被 OBS 关闭）" % exc)

    def _read_line(self, deadline=None):
        """读一行 \\n 结尾的 JSON。deadline 是 time.monotonic() 的绝对时刻。"""
        while b"\n" not in self._buf:
            if deadline is not None:
                left = deadline - time.monotonic()
                if left <= 0:
                    raise NexusError("timeout", "等待响应超时（服务端仍在处理？用 --timeout 加大）")
                self.sock.settimeout(min(self.timeout, left))
            try:
                chunk = self.sock.recv(65536)
            except socket.timeout:
                raise NexusError("timeout", "等待响应超时")
            except OSError as exc:
                raise NexusError("read_failed", "读取失败：%s" % exc)
            if not chunk:
                if self._buf.strip():
                    break  # 服务端关闭前留下的半行，下面照样解析
                raise NexusError("closed", "OBS 侧关闭了连接（脚本被卸载 / OBS 退出 / token 变了）")
            self._buf += chunk
        if b"\n" in self._buf:
            line, self._buf = self._buf.split(b"\n", 1)
        else:
            line, self._buf = self._buf, b""
        line = line.strip()
        if not line:
            return None
        try:
            return json.loads(line.decode("utf-8", "replace"))
        except ValueError as exc:
            raise NexusError("bad_frame", "服务端回了非 JSON 行: %s / %r" % (exc, line[:120]))

    # ---------------- 握手 ----------------
    def hello(self):
        msg = self._read_line(deadline=time.monotonic() + self.timeout)
        self.server_info = msg or {}
        return self.server_info

    def auth(self, deadline=None):
        if not self.token:
            return {"ok": True, "note": "未提供 token，跳过鉴权（若服务端开了鉴权会被拒）"}
        self._seq += 1
        rid = "auth-%d" % self._seq
        self._send_line({"t": "auth", "id": rid, "token": self.token})
        reply = self._await(rid, deadline or (time.monotonic() + self.timeout))
        if not reply or not reply.get("ok"):
            raise NexusError(
                "auth_failed",
                "token 校验失败：%s" % ((reply or {}).get("error") or "服务端没给原因"),
                EXIT_CONFIG,
            )
        self.server_info.update(reply)
        return reply

    # ---------------- 请求 ----------------
    def _await(self, rid, deadline):
        """一直读到 request_id==rid 的响应；其它消息（事件等）进 self.events。"""
        while True:
            msg = self._read_line(deadline=deadline)
            if msg is None:
                continue
            if msg.get("request_id") == rid and msg.get("type") != "event":
                return msg
            self.events.append(msg)

    def request(self, obj, timeout=None, retries=0):
        """发一个请求，返回响应 dict。timeout 是整个请求的墙钟预算。"""
        budget = float(timeout or self.timeout)
        attempt = 0
        while True:
            self._seq += 1
            rid = obj.get("id") or ("c%d-%d" % (os.getpid(), self._seq))
            payload = dict(obj)
            payload["id"] = rid
            self._send_line(payload)
            try:
                return self._await(rid, time.monotonic() + budget)
            except NexusError as exc:
                retryable = exc.code in ("timeout", "read_failed") and attempt < retries
                if not retryable:
                    raise
                attempt += 1
                time.sleep(min(1.0, 0.2 * (2 ** attempt)))
                self.reconnect()

    def reconnect(self):
        self.close()
        self._buf = b""
        self._connect()
        self.hello()
        if self.token:
            try:
                self.auth()
            except NexusError:
                pass

    def next_event(self, name=None, timeout=3.0):
        """从缓冲里取一个事件；没有就边收边等。取不到返回 None。"""
        deadline = time.monotonic() + timeout
        for i, e in enumerate(self.events):
            if e.get("type") == "event" and (name is None or e.get("event") == name):
                return self.events.pop(i)
        while time.monotonic() < deadline:
            try:
                msg = self._read_line(deadline=deadline)
            except NexusError as exc:
                if exc.code in ("timeout", "read_failed"):
                    break
                raise
            if msg is None:
                continue
            if msg.get("type") == "event" and (name is None or msg.get("event") == name):
                return msg
            self.events.append(msg)
        return None


# --------------------------------------------------------------------------- #
# 参数解析辅助
# --------------------------------------------------------------------------- #
def parse_kv(pairs):
    """--set k=v（值会尝试按 JSON 解析：true/123/[1,2]/{"a":1}）。"""
    out = {}
    for raw in pairs or []:
        if "=" not in raw:
            raise SystemExit("--set 需要 key=value 形式，收到: %r" % raw)
        k, v = raw.split("=", 1)
        out[k.strip()] = coerce(v)
    return out


def coerce(text):
    t = text.strip()
    if t == "":
        return ""
    try:
        return json.loads(t)
    except ValueError:
        return t


def load_json_arg(inline, path, what):
    if inline and path:
        raise NexusError("bad_arg", "--%s 与 --%s-file 只能二选一" % (what, what), EXIT_CONFIG)
    raw = None
    if path:
        try:
            with open(os.path.expanduser(path), "r", encoding="utf-8") as fh:
                raw = fh.read()
        except OSError as exc:
            raise NexusError("bad_arg", "读取 %s 失败: %s" % (path, exc), EXIT_CONFIG)
    elif inline:
        raw = inline
    if raw is None:
        return None
    raw = raw.strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except ValueError as exc:
        raise NexusError("bad_json", "%s 不是合法 JSON: %s" % (what, str(exc)[:200]), EXIT_CONFIG)


def dump(obj, pretty):
    text = json.dumps(obj, ensure_ascii=False, indent=2 if pretty else None, sort_keys=False)
    out = sys.stdout
    try:
        out.write(text + "\n")
    except UnicodeEncodeError:  # Windows 控制台可能是 GBK
        out.write(text.encode(sys.stdout.encoding or "utf-8", "replace").decode(sys.stdout.encoding or "utf-8", "replace") + "\n")
    return text


def _strip_one(container, out_path, keep_inline, note_holder=None):
    if not isinstance(container, dict):
        return False
    data = container.get("data")
    if not isinstance(data, dict) or "image_data" not in data:
        return False
    b64 = data.pop("image_data")
    got = {"bytes_removed_from_output": len(b64) if isinstance(b64, str) else 0, "format": data.get("format")}
    if out_path:
        try:
            blob = base64.b64decode(b64 or "")
            with open(os.path.expanduser(out_path), "wb") as fh:
                fh.write(blob)
            got["written_to"] = os.path.abspath(os.path.expanduser(out_path))
            got["size"] = len(blob)
        except (OSError, ValueError) as exc:
            got["write_error"] = repr(exc)
    else:
        got["note"] = "image_data 已剥离；保存请加 --snapshot-out 路径，要原样输出加 --keep-inline-image"
    if keep_inline:
        data["image_data"] = b64
    else:
        data["image"] = got
    if note_holder is not None:
        note_holder[:] = [got]
    return True


def strip_image(payload, out_path, keep_inline):
    """把 result.data / results[].data 里的 image_data 落盘或剥离。

    几十 KB 的 base64 直接打给大模型是最典型的「上下文爆炸」，所以默认剥掉；
    批量响应里同一份图会在 result 和 results[] 两处出现，两边都要处理干净。
    """
    if not isinstance(payload, dict):
        return payload
    note = []
    result = payload.get("result")
    if isinstance(result, dict):
        _strip_one(result, out_path, keep_inline, note)
    rows = payload.get("results")
    if isinstance(rows, list):
        for row in rows:
            if isinstance(row, dict) and row.get("op") == "canvas.snapshot":
                _strip_one(row, out_path, keep_inline, None)
    if note and isinstance(result, dict) and isinstance(result.get("data"), dict):
        result["data"]["image"] = note[0]
    return payload


# --------------------------------------------------------------------------- #
# 主流程
# --------------------------------------------------------------------------- #
def build_parser():
    p = argparse.ArgumentParser(
        prog="agent_client.py",
        description="OBS Nexus 命令行客户端（自动读取 ~/.obs_nexus/connection.json）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "例子:\n"
            "  agent_client.py --op system.overview\n"
            "  agent_client.py --op text.set --set source=字幕 --set text='开播了'\n"
            "  agent_client.py --op scene.switch --set scene=游戏 --set transition=0\n"
            "  agent_client.py --batch '[{\"op\":\"stream.control\",\"action\":\"start_record\"}]'\n"
            "  agent_client.py --watch --events scene.changed\n"
            "  agent_client.py --capabilities | python3 -m json.tool\n"
        ),
    )
    g = p.add_argument_group("连接")
    g.add_argument("--conn-file", help="connection.json 路径（默认 $OBS_NEXUS_DIR 或 ~/.obs_nexus/connection.json）")
    g.add_argument("--host", help="覆盖 connection.json 里的 host")
    g.add_argument("--port", type=int, help="覆盖 connection.json 里的 port")
    g.add_argument("--token", help="覆盖 connection.json 里的 token（传 - 表示不带 token）")
    g.add_argument("--ignore-stale", action="store_true", help="pid 不在了也照样连（排障用）")
    g.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT, help="整体超时秒数（默认 %.1f）" % DEFAULT_TIMEOUT)
    g.add_argument("--retries", type=int, default=0, help="可重试错误（超时/断连）的重试次数，默认 0")

    g = p.add_argument_group("要做什么")
    g.add_argument("--op", help="单个 op 名，例如 text.set")
    g.add_argument("--json", help="op 参数，JSON 对象字符串")
    g.add_argument("--json-file", help="从文件读 op 参数")
    g.add_argument("--set", action="append", metavar="K=V", dest="sets", help="逐个塞参数，可重复；值会按 JSON 解析")
    g.add_argument("--batch", help="批量请求，JSON 数组字符串")
    g.add_argument("--batch-file", help="从文件读批量 JSON 数组")
    g.add_argument("--continue-on-error", action="store_true", help="批量里某步失败也继续（默认遇错即停）")
    g.add_argument("--deadline-ms", type=int, help="服务端执行预算（毫秒），超时会被服务端填 TIMEOUT")
    g.add_argument("--ndjson", action="store_true", help="从 stdin 逐行读请求、逐行写响应（常驻管道模式）")
    g.add_argument("--watch", action="store_true", help="订阅并打印事件（Ctrl-C 退出）")
    g.add_argument("--events", help="逗号分隔的事件名，配合 --watch / --wait-event")
    g.add_argument("--wait-event", metavar="NAME", help="等到某个事件就退出（退出码 0，事件 JSON 打到 stdout）")
    g.add_argument("--ping", action="store_true", help="测一次往返延迟")
    g.add_argument("--discover", action="store_true", help="打印连接信息与只读快照摘要")
    g.add_argument("--capabilities", action="store_true", help="打印 conn.capabilities（所有 op 的自描述）")
    g.add_argument("--raw", action="append", metavar="JSON", dest="raws", help="原样发送一行 JSON（可重复），不做任何包装")

    g = p.add_argument_group("输出")
    g.add_argument("--pretty", action="store_true", help="缩进美化（默认就是缩进；配 --compact 关掉）")
    g.add_argument("--compact", action="store_true", help="单行 JSON，便于管道")
    g.add_argument("--data-only", action="store_true", help="只打 result.data（省 token）")
    g.add_argument("--snapshot-out", metavar="PATH", help="把 canvas.snapshot 的图片解码写到文件")
    g.add_argument("--keep-inline-image", action="store_true", help="保留 image_data 字段（默认剥离，避免刷屏）")
    g.add_argument("--exit-nonzero-on-op-error", action="store_true", default=True, dest="exit_on_op_error", help=argparse.SUPPRESS)
    g.add_argument("--quiet", "-q", action="store_true", help="出错才说话")
    return p


def norm_events(text):
    if not text:
        return None
    return [x.strip() for x in str(text).replace(" ", ",").split(",") if x.strip()]


def do_discover(cli, info, client):
    """连接信息 + 一份只读快照，方便一眼确认「能不能用」。"""
    out = {
        "connection_file": info.path if info else None,
        "endpoint": "%s:%s" % (cli_host(cli, info), cli_port(cli, info)),
        "obs_pid": getattr(info, "pid", None),
        "obs_pid_alive": pid_alive(getattr(info, "pid", 0)) if info else None,
        "obs_version": (getattr(info, "obs_version", None)),
        "nexus_version": getattr(info, "nexus_version", None),
        "auth": bool(getattr(info, "token", None)),
    }
    if client is not None:
        try:
            r = client.request({"op": "system.overview"}, timeout=cli.timeout)
            out["overview"] = (r.get("result") or {}).get("data")
            out["ok"] = bool(r.get("ok"))
        except NexusError as exc:
            out["error"] = str(exc)
    return out


def cli_host(cli, info):
    return cli.host or (info.host if info else "127.0.0.1")


def cli_port(cli, info):
    return cli.port or (info.port if info else 0)


def main(argv=None):
    try:  # Windows 控制台的中文/emoji 保护
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass
    cli = build_parser().parse_args(argv)
    pretty = not cli.compact

    modes = [bool(cli.op), bool(cli.batch or cli.batch_file), cli.ndjson, cli.watch, bool(cli.wait_event), cli.ping, cli.discover, cli.capabilities, bool(cli.raws)]
    if sum(1 for m in modes if m) == 0:
        build_parser().print_help(sys.stderr)
        return EXIT_CONFIG
    if sum(1 for m in modes if m) > 1 and not (cli.op and (cli.watch or cli.wait_event)):
        sys.stderr.write("一次只能做一件事（--op / --batch / --ndjson / --watch / --ping / --discover / --capabilities / --raw）\n")
        return EXIT_CONFIG

    info, err = ConnInfo.load(cli.conn_file, allow_stale=cli.ignore_stale or bool(cli.port))
    if err and not cli.port:
        sys.stderr.write("[配置] %s\n" % err)
        return EXIT_CONFIG
    if info is None:
        info = ConnInfo({}, conn_file_path(cli.conn_file))

    token = cli.token
    if token == "-":
        token = ""
    elif token is None:
        token = info.token or ""

    try:
        client = Client(cli_host(cli, info), cli_port(cli, info), token=token, timeout=cli.timeout)
    except NexusError as exc:
        sys.stderr.write("[连接] %s\n" % exc)
        return exc.exit_code

    try:
        client.hello()
        if token:
            client.auth()
        return run_mode(cli, info, client, pretty)
    except NexusError as exc:
        sys.stderr.write("[%s] %s\n" % (exc.code, exc))
        return exc.exit_code
    except KeyboardInterrupt:
        return EXIT_OK
    finally:
        client.close()


def run_mode(cli, info, client, pretty):
    # ---- 一次性只读 / 元信息 ----
    if cli.discover:
        dump(do_discover(cli, info, client), pretty)
        return EXIT_OK
    if cli.capabilities:
        r = client.request({"op": "conn.capabilities"}, timeout=cli.timeout)
        dump((r.get("result") or {}).get("data") if r.get("ok") else r, pretty)
        return EXIT_OK if r.get("ok") else EXIT_OP_ERROR
    if cli.ping:
        t0 = time.perf_counter()
        r = client.request({"t": "ping"}, timeout=cli.timeout)
        rtt_ms = (time.perf_counter() - t0) * 1000.0
        t0 = time.perf_counter()
        r2 = client.request({"op": "system.ping"}, timeout=cli.timeout)
        op_ms = (time.perf_counter() - t0) * 1000.0
        dump({"transport_rtt_ms": round(rtt_ms, 2), "op_roundtrip_ms": round(op_ms, 2), "pong": r, "through_main_thread": (r2.get("result") or {}).get("data")}, pretty)
        return EXIT_OK

    # ---- 事件 ----
    if cli.watch or cli.wait_event:
        want = norm_events(cli.events)
        sub = {"op": "conn.subscribe"}
        if want:
            sub["events"] = want
        r = client.request(sub, timeout=cli.timeout)
        if not r.get("ok") and want:
            sys.stderr.write("[op] 订阅失败: %s\n" % json.dumps(r.get("error"), ensure_ascii=False))
            return EXIT_OP_ERROR
        if cli.wait_event:
            e = client.next_event(cli.wait_event, timeout=max(cli.timeout, 1.0))
            if e is None:
                sys.stderr.write("[timeout] 没等到事件 %r\n" % cli.wait_event)
                return EXIT_TRANSPORT
            dump(e, pretty)
            return EXIT_OK
        while True:  # --watch
            e = client.next_event(None, timeout=30.0)
            if e is None:
                continue
            if want and e.get("event") not in want:
                continue
            line = json.dumps({"ts": time.strftime("%H:%M:%S"), "event": e.get("event"), "data": e.get("data")}, ensure_ascii=False)
            sys.stdout.write(line + "\n")
            sys.stdout.flush()

    # ---- 管道模式 ----
    if cli.ndjson:
        bad = EXIT_OK
        for line in sys.stdin:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            try:
                req = json.loads(line)
            except ValueError as exc:
                sys.stdout.write(json.dumps({"ok": False, "error": {"code": "bad_json", "message": str(exc)}}, ensure_ascii=False) + "\n")
                sys.stdout.flush()
                bad = EXIT_OP_ERROR
                continue
            if isinstance(req, dict) and not req.get("id"):
                client._seq += 1
                req["id"] = "pipe-%d" % client._seq
            rid = (req or {}).get("id") if isinstance(req, dict) else None
            try:
                if isinstance(req, dict) and rid:
                    resp = client.request(req, timeout=cli.timeout, retries=cli.retries)
                else:
                    client._send_line(req)
                    resp = {"ok": False, "error": {"code": "no_id", "message": "缺 id"}}
            except NexusError as exc:
                resp = {"ok": False, "error": {"code": exc.code, "message": str(exc)}}
                bad = exc.exit_code
            resp = strip_image(resp, cli.snapshot_out, cli.keep_inline_image)
            if cli.data_only and isinstance(resp, dict) and resp.get("ok") is True:
                sys.stdout.write(json.dumps((resp.get("result") or {}).get("data"), ensure_ascii=False) + "\n")
                sys.stdout.flush()
                if resp.get("ok") is not True:
                    bad = max(bad, EXIT_OP_ERROR)
                continue
            sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
            sys.stdout.flush()
            if isinstance(resp, dict) and not resp.get("ok"):
                bad = max(bad, EXIT_OP_ERROR)
        return bad

    # ---- 原样发送（调试/新帧型逃生口）----
    if cli.raws:
        code = EXIT_OK
        for i, raw in enumerate(cli.raws):
            try:
                obj = json.loads(raw)
            except ValueError as exc:
                sys.stderr.write("[bad_json] 第 %d 条: %s\n" % (i + 1, exc))
                return EXIT_CONFIG
            if not isinstance(obj, dict):
                sys.stderr.write("[bad_arg] 第 %d 条：顶层必须是对象\n" % (i + 1))
                return EXIT_CONFIG
            resp = client.request(obj, timeout=cli.timeout)
            dump(strip_image(resp, cli.snapshot_out, cli.keep_inline_image), pretty)
            # 只有真正的 op 失败才算错；pong / hello / event 这些帧没有 ok 字段，不是错误
            if isinstance(resp, dict) and resp.get("type") == "response" and resp.get("ok") is False:
                code = EXIT_OP_ERROR
        return code

    # ---- 批量 ----
    if cli.batch or cli.batch_file:
        ops = load_json_arg(cli.batch, cli.batch_file, "batch")
        if not isinstance(ops, list) or not ops:
            sys.stderr.write("--batch 应该是非空 JSON 数组\n")
            return EXIT_CONFIG
        req = {"ops": ops}
        if cli.continue_on_error:
            req["continue_on_error"] = True
        if cli.deadline_ms:
            req["deadline_ms"] = cli.deadline_ms
        r = client.request(req, timeout=cli.timeout, retries=cli.retries)
        r = strip_image(r, cli.snapshot_out, cli.keep_inline_image)
        if cli.data_only:
            r = {"ok": r.get("ok"), "batch": r.get("batch"), "results": [(x.get("result") or {}).get("data") if x.get("ok") else x.get("error") for x in (r.get("results") or [])]}
        dump(r, pretty)
        return EXIT_OK if r.get("ok") else EXIT_OP_ERROR

    # ---- 单 op ----
    args = load_json_arg(cli.json, cli.json_file, "json") or {}
    extra = parse_kv(cli.sets)
    if not isinstance(args, dict):
        sys.stderr.write("--json 应该是 JSON 对象\n")
        return EXIT_CONFIG
    args.update(extra)
    req = {"op": cli.op}
    req.update(args)
    if cli.deadline_ms:
        req["deadline_ms"] = cli.deadline_ms
    r = client.request(req, timeout=cli.timeout, retries=cli.retries)
    r = strip_image(r, cli.snapshot_out, cli.keep_inline_image)
    ok = bool(r.get("ok"))  # 先存住：--data-only 会把外层信封剥掉，别把退出码也剥没了
    out = (r.get("result") or {}).get("data") if (cli.data_only and ok) else r
    if not (cli.quiet and ok):
        dump(out, pretty)
    return EXIT_OK if ok else EXIT_OP_ERROR


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
    except BrokenPipeError:  # 管道对面提前关了（head / jq）
        try:
            os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        except Exception:
            pass
        sys.exit(EXIT_OK)
