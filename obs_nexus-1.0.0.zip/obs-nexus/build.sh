#!/usr/bin/env bash
# 把 parts/*.py 拼装成单文件交付物 src/obs_nexus.py，并做四项静态检查。
set -euo pipefail
cd "$(dirname "$0")"
PARTS="parts/nexus_01_head.py parts/nexus_02_bridge.py parts/nexus_03_ops.py parts/nexus_03b_ops.py parts/nexus_04_net.py parts/nexus_05_script.py"
for f in $PARTS; do [ -f "$f" ] || { echo "缺少 $f"; exit 1; }; done
cat $PARTS > src/obs_nexus.py
python3 - <<'PY'
import ast, os, sys
src = open('src/obs_nexus.py', encoding='utf-8').read()
tree = ast.parse(src)
print("拼装完成: %d 行" % src.count('\n'))

# 1) 语法（按 3.8 的语法级别校验，保证老 OBS 的内嵌 Python 也能加载）
for f in ['src/obs_nexus.py', 'src/agent_client.py'] + [os.path.join('examples', x) for x in os.listdir('examples') if x.endswith('.py')]:
    compile(open(f, encoding='utf-8').read(), f, 'exec', ast.PyCF_ONLY_AST, dont_inherit=True, _feature_version=8)
print("语法(3.8+): ok")

# 2) 顶层重名（拼装最容易出的事故：某个函数被覆盖了，或重复注册）
top = {}
for st in tree.body:
    if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        top.setdefault(st.name, []).append(st.lineno)
dupes = {k: v for k, v in top.items() if len(v) > 1}
print("顶层重名:", "无" if not dupes else dupes)
assert not dupes, "存在被覆盖的顶层定义！"

# 3) 未定义名（粗筛：模块级 Load 引用的名字要么在模块里有定义/导入，要么是内建）
defined = set(top) | {t.id for n in ast.walk(tree) if isinstance(n, (ast.Assign, ast.AugAssign, ast.AnnAssign))
                       for t in ast.walk(n) if isinstance(t, ast.Name) and isinstance(t.ctx, ast.Store)}
for n in ast.walk(tree):
    if isinstance(n, (ast.Import, ast.ImportFrom)):
        defined |= {(al.asname or al.name.split('.')[0]) for al in n.names}
    elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        defined.add(n.name)
    elif isinstance(n, ast.arg):
        defined.add(n.arg)
    elif isinstance(n, ast.ExceptHandler) and n.name:
        defined.add(n.name)
    elif isinstance(n, ast.comprehension) and isinstance(n.target, ast.Name):
        defined.add(n.target.id)
    elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
        defined.add(n.id)
import builtins
bi = set(dir(builtins))
missing = sorted({n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)
                  and n.id not in defined and n.id not in bi})
print("可能未定义的名字:", "无" if not missing else missing[:12])
assert not missing, "有未定义的名字（多半是拼装时漏贴了某段代码）"

# 4) 赋了值给模块级名字但忘了 global（script_unload 忘了 global _SERVER 就是这类）
cands = set()
for stmt in tree.body:
    if isinstance(stmt, ast.Assign):
        for t in stmt.targets:
            if isinstance(t, ast.Name) and (t.id.startswith('_') or t.id.isupper()):
                cands.add(t.id)
bad = []
for fn in [f for f in ast.walk(tree) if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))]:
    decl = set()
    for st in fn.body:
        if isinstance(st, ast.Global):
            decl |= set(st.names)
    assigned = set()
    for st in ast.walk(fn):
        if isinstance(st, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
            for t in ast.walk(st):
                if isinstance(t, ast.Name) and isinstance(t.ctx, ast.Store):
                    assigned.add(t.id)
    for name in sorted((assigned & cands) - decl):
        bad.append("%s:%d -> global %s" % (fn.name, fn.lineno, name))
print("缺 global 声明:", "无" if not bad else bad)
assert not bad, "有函数在改模块级单例却没声明 global"
PY
echo "build ok"
