

# ================================ text.* ==================================
def _text_source_keys(src):
    """返回该文本源可能使用的文本字段名（按优先级）。"""
    ids = []
    for fn in ("obs_source_get_unversioned_id", "obs_source_get_id"):
        f = _fn(fn)
        if f is not None:
            try:
                v = f(src)
                if v:
                    ids.append(v)
            except Exception:
                pass
    keys = []
    for i in ids:
        for k in TEXT_TYPE_MAP.get(i, ()):
            if k not in keys:
                keys.append(k)
    return keys, (ids[0] if ids else ""), (ids[1] if len(ids) > 1 else "")


@op(
    "text.set",
    "更新文本源内容（GDI+ 2 / FreeType 2 / 文本浏览器 title），Agent 实时输出解说词的核心动作",
    {
        "source": ["str", True, "文本源名称"],
        "text": ["str", False, "新内容；留空配合 clear:true 可清空"],
        "file": ["str", False, "从该文件读取内容（二选一，适合长文案）"],
        "filter": ["str", False, "目标是源上的文本过滤器时给出过滤器名"],
        "append": ["bool", False, "true = 追加到现有文本末尾（用 \\n 连接）"],
        "clear": ["bool", False, "true = 清空文本"],
        "silent": ["bool", False, "不广播 text.updated 事件（自己就是事件消费者时用，避免自激）"],
        "scene": ["str", False, "场景名（留空 = 当前场景）"],
        "force": ["bool", False, "源类型不是已知文本源时仍尝试写入 text 字段"],
        "override_read_from_file": ["bool", False, "源开启了『读取文件』模式时，改为直接写文本字段并关掉该模式"],
        "refresh_properties": ["bool", False, "调用 obs_source_update_properties 刷新属性面板"],
    },
    mutating=True,
)
def op_text_set(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")

    fname = a.get("filter")
    if fname:
        fn = _fn("obs_source_get_filter_by_name")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_source_get_filter_by_name")
        f = fn(src, "%s" % fname)
        if f is None:
            raise err(E_OBS_FAILED, "源 %r 上没有过滤器 %r" % (name, fname))
        refs.track(f, "obs_source_release")
        src = f

    keys, stype, unversioned = _text_source_keys(src)
    force = _bool(a.get("force"), False)
    if not keys:
        if not force:
            raise err(
                E_WRONG_TYPE,
                "源 %r 的类型是 %r，不是已知文本源" % (name, stype),
                details={
                    "type": stype,
                    "known_text_types": list(TEXT_TYPE_IDS),
                    "note": "「文本」(text) 是 OBS 28 之前的旧类型，已不存在",
                },
                hint="在 OBS 里改用「GDI+ 文本 (」或「FreeType 2 文本」；确认无误可加 force:true 强写 text 字段。",
            )
        keys = ["text"]

    # ---- 取新内容 ----
    text = a.get("text")
    if text is None:
        text = a.get("value")
    src_file = a.get("file")
    if src_file:
        path = os.path.abspath(os.path.expanduser("%s" % src_file))
        try:
            size = os.path.getsize(path)
        except OSError as exc:
            raise err(E_BAD_PARAMS, "无法读取文本文件: %r" % (exc,), details={"path": path})
        cap = rt.limits["max_text_bytes"]
        if size > cap:
            raise err(E_TOO_LARGE, "文本文件 %d 字节超过上限 %d" % (size, cap), details={"path": path})
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read(cap + 1)
        except OSError as exc:
            raise err(E_BAD_PARAMS, "读取文本文件失败: %r" % (exc,))
    if text is None:
        if _bool(a.get("clear"), False):
            text = ""
        else:
            raise err(E_BAD_PARAMS, "缺少 text（或 file / clear:true）")
    if isinstance(text, (dict, list)):
        text = json.dumps(text, ensure_ascii=False)
    text = ("%s" % text).replace("\r\n", "\n").replace("\r", "\n")

    cap = rt.limits["max_text_bytes"]
    raw = text.encode("utf-8")
    truncated = False
    if len(raw) > cap:
        if not _bool(a.get("truncate"), False):
            raise err(
                E_TOO_LARGE,
                "文本 %d 字节超过上限 %d" % (len(raw), cap),
                hint="缩短内容，或传 truncate:true，或调大脚本属性 max_text_bytes。",
            )
        text = raw[:cap].decode("utf-8", "ignore")
        truncated = True
    if _bool(a.get("append"), False):
        cur = _read_text(src, keys)
        if cur:
            text = cur + "\n" + text

    # ---- 「读取文件」模式冲突检测 ----
    settings = source_settings(src, keys=["read_from_file", "file", "custom_width", "font"], max_items=8) or {}
    if _bool(settings.get("read_from_file"), False) and not _bool(a.get("override_read_from_file"), False):
        raise err(
            E_PRECONDITION,
            "源 %r 开启了「读取文件」模式，写 text 字段不会生效" % name,
            details={"read_from_file": True, "file": settings.get("file")},
            hint="关掉该勾选，或传 override_read_from_file:true 让 Nexus 帮你关掉并直接写文本。",
        )

    data = _fn("obs_data_create")()
    if data is None:
        raise err(E_UNSUPPORTED, "无 obs_data_create")
    refs.track(data, "obs_data_release")
    obs.obs_data_set_string(data, keys[0], text)
    if _bool(settings.get("read_from_file"), False):
        obs.obs_data_set_bool(data, "read_from_file", False)
    for extra in keys[1:]:  # 兼容某些版本同时存在两个 key
        try:
            obs.obs_data_set_string(data, extra, text)
        except Exception:
            pass
    before = _read_text(src, keys)
    obs.obs_source_update(src, data)
    if _bool(a.get("refresh_properties"), True):
        fn = _fn("obs_source_update_properties")
        if fn is not None:
            try:
                fn(src)
            except Exception:
                pass
    after = _read_text(src, keys)
    result = {
        "scene": sname,
        "source": name,
        "type": stype or unversioned,
        "field": keys[0],
        "chars": len(after or ""),
        "bytes": len((after or "").encode("utf-8")),
        "verified": after == text,
        "text": after if rt.props.get("echo_text", True) else None,
        "changed": before != after,
    }
    if truncated:
        result["truncated"] = True
    if not result["verified"]:
        result["warning"] = "回读内容与写入不一致：可能被过滤器/编码或源自身逻辑改写"
    if result["changed"] and not _bool(a.get("silent"), False):
        rt.emit_event(
            "text.updated",
            {"scene": sname, "source": name, "field": keys[0], "chars": result["chars"], "text": result.get("text"), "by": "op"},
        )
    return result


def _read_text(src, keys):
    if src is None:
        return None
    get = _fn("obs_source_get_settings")
    rel = _fn("obs_data_release")
    data = get(src) if get is not None else None
    if data is None:
        return None
    AUDIT.acquire(data, "obs_data_release")
    try:
        for k in list(keys) + ["text", "text_gdiplus", "text_freetype"]:
            try:
                v = obs.obs_data_get_string(data, k)
            except Exception:
                v = ""
            if v:
                return v
        return ""
    finally:
        if rel is not None:
            _release("obs_data_release", data)


@op(
    "text.get",
    "读取文本源当前内容（供 Agent 读取上下文 / 校对）",
    {"source": ["str", True, "文本源名"], "scene": ["str", False, "场景名"], "filter": ["str", False, "文本过滤器名"]},
)
def op_text_get(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    fname = a.get("filter")
    if fname:
        fn = _fn("obs_source_get_filter_by_name")
        f = fn(src, "%s" % fname) if fn is not None else None
        if f is None:
            raise err(E_OBS_FAILED, "找不到过滤器 %r" % fname)
        refs.track(f, "obs_source_release")
        src = f
    keys, stype, _unv = _text_source_keys(src)
    if not keys:
        keys = ["text"]
    text = _read_text(src, keys)
    out = {"scene": sname, "source": name, "type": stype, "field": keys[0], "text": text, "chars": len(text or "")}
    if text is not None and len(text.encode("utf-8")) > rt.limits["max_text_bytes"]:
        out["text"] = text[: rt.limits["max_text_bytes"] // 4]
        out["truncated"] = True
    return out


# ================================ audio.* =================================
MONITORING_NAMES = {0: "none", 1: "monitor_only", 2: "monitor_and_output", 4: "output_only"}
CHANNEL_NAMES = {0: "none", 1: "mono", 2: "stereo", 3: "quad", 4: "5.1", 5: "7.1"}


def _audio_status_row(src, name=None):
    row = {}
    try:
        row["name"] = obs.obs_source_get_name(src) if name is None else name
        row["type"] = obs.obs_source_get_id(src)
    except Exception:
        pass
    try:
        row["muted"] = bool(obs.obs_source_muted(src))
    except Exception:
        row["muted"] = None
    try:
        vol = float(obs.obs_source_get_volume(src))
    except Exception:
        vol = None
    row["volume"] = round(vol, 5) if vol is not None else None
    row["volume_percent"] = round(vol * 100.0, 2) if vol is not None else None
    row["volume_db"] = vol_to_db(vol) if vol is not None else None
    fn = _fn("obs_source_get_audio_sync")
    if fn is not None:
        try:
            row["sync_offset_ms"] = round(float(fn(src)) * 1000.0, 1)
        except Exception:
            pass
    for fname in ("obs_source_get_monitoring_type", "obs_source_get_audio_monitoring_type"):
        fn = _fn(fname)
        if fn is not None:
            try:
                row["audio_monitoring"] = MONITORING_NAMES.get(int(fn(src)), int(fn(src)))
                break
            except Exception:
                pass
    fn = _fn("obs_source_get_channel") or _fn("obs_source_get_speaker_layout")
    if fn is not None:
        try:
            row["channel_layout"] = CHANNEL_NAMES.get(int(fn(src)), int(fn(src)))
        except Exception:
            pass
    fn = _fn("obs_source_push_to_mute_enabled")
    if fn is not None:
        try:
            row["push_to_mute"] = bool(fn(src))
        except Exception:
            pass
    row["audio_source"] = bool(source_has_audio(src))
    row["meter"] = None
    row["meter_note"] = "OBS 脚本 API 不暴露实时电平表（峰值/RMS 需要 obs-websocket 或原生插件）"
    return row


def _require_audio_source(src, name):
    if not source_has_audio(src):
        raise err(
            E_WRONG_TYPE,
            "源 %r (type=%r) 没有音频能力" % (name, obs.obs_source_get_id(src) if _has("obs_source_get_id") else "?"),
            hint="音频操作只支持麦克风/桌面音频/媒体源/音频输出捕获等。",
        )


@op(
    "audio.status",
    "读取音频源音量(dB/百分比)、静音、同步偏移、监听方式；all:true 一次读全部音频源",
    {"source": ["str", False, "源名（all=true 时可省略）"], "scene": ["str", False, "场景名"], "all": ["bool", False, "列出全部音频源"]},
)
def op_audio_status(rt, a, ctx):
    refs = ctx["refs"]
    if not str(arg(a, "source", "") or "").strip() and not _bool(a.get("all"), False):
        raise err(
            E_BAD_PARAMS,
            "audio.status 需要 source，或者 all:true 一次读全部音频源",
            hint='例：{"op":"audio.status","all":true}',
        )
    if _bool(a.get("all"), False):
        sname, scene = resolve_scene(refs, scene_ref(a))
        rows = []
        names = []
        for r in flatten_rows(walk_scene_items(scene, recursive=True, limit=300)):
            if r.get("name") and r["name"] not in names:
                names.append(r["name"])
        for group in ("mic", "desktop", "aux"):
            for alias in AUDIO_NAME_ALIASES.get(group, ()):
                if alias not in names:
                    names.append(alias)
        for n in names[:64]:
            try:
                src, m = resolve_source(refs, n, scene=scene, scope="auto")
            except NexusError:
                continue
            if not source_has_audio(src):
                continue
            row = _audio_status_row(src, n)
            row["scene_item"] = m.get("where")
            rows.append(row)
        return {"scene": sname, "count": len(rows), "audio_sources": rows}
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    row = _audio_status_row(src, name)
    if not row.get("audio_source"):
        row["warning"] = "该源没有音频能力，音量字段可能无意义"
    row["resolved_from"] = meta
    row["scene"] = sname
    return row


@op(
    "audio.mute",
    "设置/切换音频源静音",
    {"source": ["str", True, "源名"], "muted": ["bool", False, "true=静音"], "toggle": ["bool", False, "取反"], "scene": ["str", False, "场景名"]},
    mutating=True,
)
def op_audio_mute(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    _require_audio_source(src, name)
    before = bool(obs.obs_source_muted(src))
    if _bool(a.get("toggle"), False):
        target = not before
    elif a.get("muted") is None:
        raise err(E_BAD_PARAMS, "需要 muted:true/false 或 toggle:true", details={"current": before})
    else:
        target = _bool(a.get("muted"), True)
    obs.obs_source_set_muted(src, bool(target))
    after = bool(obs.obs_source_muted(src))
    if after != bool(target):
        raise err(E_OBS_FAILED, "静音状态未生效", details={"wanted": target, "after": after})
    return {"scene": sname, "source": name, "before": before, "muted": after, "changed": before != after}


@op(
    "audio.volume",
    "调整音频源音量：percent / db / delta_db / delta_percent 四选一（OBS 线性音量 0..2）",
    {
        "source": ["str", True, "源名"],
        "percent": ["float", False, "0-200（100 = 0dB）"],
        "db": ["float", False, "-100..+6 dB"],
        "delta_db": ["float", False, "在当前基础上加 dB"],
        "delta_percent": ["float", False, "在当前基础上加百分比"],
        "scene": ["str", False, "场景名"],
    },
    mutating=True,
)
def op_audio_volume(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    _require_audio_source(src, name)
    try:
        cur = float(obs.obs_source_get_volume(src))
    except Exception:
        cur = 1.0
    given = [k for k in ("percent", "db", "delta_db", "delta_percent", "volume") if a.get(k) is not None]
    if not given:
        raise err(E_BAD_PARAMS, "需要 percent / db / delta_db / delta_percent 之一", details={"current_percent": round(cur * 100.0, 2)})
    if len(given) > 1:
        raise err(E_BAD_PARAMS, "只能给一个音量字段", details={"given": given})
    which = given[0]
    v = _float(a.get(which), 0.0)
    if which == "percent":
        if not (-0.001 <= v <= 200.0):
            raise err(E_BAD_PARAMS, "percent 需要在 0..200", details={"got": v})
        new = v / 100.0
    elif which == "volume":
        new = v
    elif which == "db":
        if not (-100.0 <= v <= 6.0):
            raise err(E_BAD_PARAMS, "db 需要在 -100..+6", details={"got": v})
        new = db_to_vol(v)
    elif which == "delta_db":
        new = db_to_vol(vol_to_db(cur) + v)
    else:
        new = _clamp(cur + v / 100.0, 0.0, 2.0)
    new = _clamp(new, 0.0, 2.0)
    obs.obs_source_set_volume(src, float(new))
    try:
        after = float(obs.obs_source_get_volume(src))
    except Exception:
        after = new
    return {
        "scene": sname,
        "source": name,
        "before_percent": round(cur * 100.0, 2),
        "before_db": vol_to_db(cur),
        "volume_percent": round(after * 100.0, 2),
        "volume_db": vol_to_db(after),
        "raw_volume": round(after, 5),
        "input": {which: v},
    }


# ============================== stream.* ==================================
STREAM_ACTIONS = {
    "start_stream": ("stream", True),
    "stop_stream": ("stream", False),
    "start_record": ("record", True),
    "stop_record": ("record", False),
    "pause_record": ("record_pause", True),
    "unpause_record": ("record_pause", False),
    "toggle_record": ("record", None),
    "split_record_file": ("record_split", None),
    "add_chapter": ("record_chapter", None),
    "start_replay_buffer": ("replay", True),
    "stop_replay_buffer": ("replay", False),
    "save_replay": ("replay_save", None),
    "start_virtualcam": ("vcam", True),
    "stop_virtualcam": ("vcam", False),
    "toggle_virtualcam": ("vcam", None),
}


@op(
    "stream.control",
    "控制推流/录制/虚拟摄像头：start_stream stop_stream start_record stop_record pause_record unpause_record ...",
    {
        "action": ["|".join(sorted(STREAM_ACTIONS)), True, "要执行的动作"],
        "chapter": ["str", False, "add_chapter 的章节名"],
        "wait": ["bool", False, "true = 等到状态真的变化（跨 tick 轮询，不阻塞主线程）"],
        "wait_ms": ["int", False, "等待上限，默认 3000"],
        "confirm": ["bool", False, "stop_stream 需要 confirm:true 防误触"],
    },
    mutating=True,
)
def op_stream_control(rt, a, ctx):
    action = ("%s" % need(a, "action")).strip().lower()
    spec = STREAM_ACTIONS.get(action)
    if spec is None:
        raise err(
            E_UNKNOWN_OP,
            "未知 action: %r" % action,
            details={"supported": sorted(STREAM_ACTIONS.keys())},
            hint="见 stream.control 的 args 文档。",
        )
    kind, want = spec
    st = {}
    if kind == "stream":
        if want is None:
            raise err(E_BAD_PARAMS, "stream 不支持 toggle")
        if action == "stop_stream" and not _bool(a.get("confirm"), False):
            raise err(E_PRECONDITION, "停止推流需要 confirm:true（会影响直播）", hint="确认要断开直播就传 confirm:true。")
        cur = _stream_state()
        if want and (cur["active"] or cur["pending"]):
            return {"action": action, "skipped": "already_active", "streaming": cur}
        if not want and not (cur["active"] or cur["stopping"]):
            return {"action": action, "skipped": "not_active", "streaming": cur}
        fn = _fn("obs_frontend_streaming_start" if want else "obs_frontend_streaming_stop")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 %s" % (fn,))
        fn()
        st = {"streaming": _stream_state()}
        target = bool(want)
        check = lambda: (_stream_state().get("active") is target)
    elif kind == "record":
        cur = _record_state()
        if want and cur["active"]:
            return {"action": action, "skipped": "already_recording", "recording": cur}
        if not want and not cur["active"]:
            return {"action": action, "skipped": "not_recording", "recording": cur}
        fn = _fn("obs_frontend_recording_start" if want else "obs_frontend_recording_stop")
        if fn is None:
            raise err(E_UNSUPPORTED, "OBS 未提供录制控制函数")
        fn()
        st = {"recording": _record_state()}
        target = bool(want)
        check = lambda: (_record_state().get("active") is target)
    elif kind == "record_pause":
        cur = _record_state()
        if not cur["active"]:
            raise err(E_PRECONDITION, "当前没有录制，无法暂停/恢复", details={"recording": cur})
        if bool(cur["paused"]) == bool(want):
            return {"action": action, "skipped": "already_in_state", "recording": cur}
        fn = _fn("obs_frontend_recording_pause")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_recording_pause")
        fn(bool(want))
        st = {"recording": _record_state()}
        check = lambda: (_record_state().get("paused") is bool(want))
    elif kind == "record_split":
        fn = _fn("obs_frontend_recording_split_file")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_recording_split_file")
        okv = bool(fn())
        st = {"accepted": okv, "recording": _record_state()}
        if not okv:
            raise err(E_PRECONDITION, "OBS 拒绝了分片请求（未录制 / 已暂停 / 未开启自动分段）", details=st)
        check = None
    elif kind == "record_chapter":
        fn = _fn("obs_frontend_recording_add_chapter")
        if fn is None:
            raise err(E_UNSUPPORTED, "obs_frontend_recording_add_chapter 需要 OBS 30.2+", details={"obs_version": obs_version_string()})
        okv = bool(fn(a.get("chapter") or ("AI chapter %s" % time.strftime("%H:%M:%S"))))
        st = {"accepted": okv, "recording": _record_state()}
        check = None
    elif kind == "replay":
        cur = {}
        if _has("obs_frontend_replay_buffer_active"):
            cur = {"active": bool(obs.obs_frontend_replay_buffer_active())}
        else:
            raise err(E_UNSUPPORTED, "无 obs_frontend_replay_buffer_active")
        fn = _fn("obs_frontend_replay_buffer_start" if want else "obs_frontend_replay_buffer_stop")
        if fn is None:
            raise err(E_UNSUPPORTED, "无回放缓冲控制函数")
        fn()
        st = {"replay_buffer": {"active": bool(obs.obs_frontend_replay_buffer_active())}}
        check = None
    elif kind == "replay_save":
        fn = _fn("obs_frontend_replay_buffer_save")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_replay_buffer_save")
        fn()
        st = {"requested": True}
        check = None
    else:  # vcam
        if _has("obs_frontend_virtualcam_active"):
            active = bool(obs.obs_frontend_virtualcam_active())
        else:
            active = False
        target = (not active) if want is None else bool(want)
        fn = _fn("obs_frontend_start_virtualcam" if target else "obs_frontend_stop_virtualcam")
        if fn is None:
            raise err(E_UNSUPPORTED, "OBS 未提供虚拟摄像头控制")
        fn()
        st = {"virtualcam": {"active": bool(_fn("obs_frontend_virtualcam_active")()) if _has("obs_frontend_virtualcam_active") else None}}
        check = lambda: bool(_fn("obs_frontend_virtualcam_active")()) == target if _has("obs_frontend_virtualcam_active") else None
    waited = None
    if _bool(a.get("wait"), False) and check is not None:
        timeout = _clamp(_int(a.get("wait_ms"), 3000) or 3000, 50, 15000)

        def poll(state=None):
            try:
                done = bool(check())
            except Exception:
                done = False
            if not done:
                return None
            snapshot = {"streaming": _stream_state(), "recording": _record_state()}
            return dict(
                {"action": action, "waited_ms": int(state.elapsed * 1000) if state else 0, "reached": True},
                **snapshot
            )

        return Async(poll, timeout_ms=timeout, note={"pending_action": action, **st})
    return {"action": action, "confirmed_immediately": check is None, **st}


# ============================== canvas.* ==================================
def _snapshot_dirs():
    """截图落盘候选目录（obs_frontend_get_last_screenshot 不可用时的兜底）。"""
    rt = _SERVER
    dirs = []
    if rt is not None:
        d = (rt.props or {}).get("snapshot_dir")
        if d:
            dirs.append(os.path.abspath(os.path.expanduser(d)))
    dirs.append(os.path.join(nexus_dir(), "snapshots"))
    fn = _fn("obs_frontend_get_recordings_folder")
    if fn is not None:
        try:
            v = fn()
            if v:
                dirs.append(v)
        except Exception:
            pass
    for env in ("USERPROFILE", "HOME"):
        home = os.environ.get(env)
        if home:
            dirs.append(os.path.join(home, "Pictures"))
    fn = _fn("obs_frontend_get_current_profile_path")
    if fn is not None:
        try:
            v = fn()
            if v:
                dirs.append(v)
        except Exception:
            pass
    seen, out = set(), []
    for d in dirs:
        if not d:
            continue
        d = os.path.normpath(d)
        if d not in seen and os.path.isdir(d):
            seen.add(d)
            out.append(d)
    return out


def snapshot_capability():
    rt = _SERVER
    props = (rt.props if rt is not None else {}) or {}
    mode = str(props.get("snapshot_mode") or "auto")
    have_native = _has("obs_frontend_take_screenshot") and _has("obs_frontend_get_last_screenshot")
    modes = []
    if have_native:
        modes.append("native")
    if props.get("snapshot_command"):
        modes.append("command")
    modes.append("dir")
    if mode == "off":
        modes = []
    return {
        "available": bool(modes),
        "mode": mode,
        "supported_modes": modes,
        "native_api": bool(have_native),
        "source_screenshot_api": bool(_has("obs_frontend_take_source_screenshot")),
        "pil_jpeg": _PILImage is not None,
        "jpeg_inline": bool(have_native and (_PILImage is not None or True)),
        "dirs": _snapshot_dirs()[:4],
        "hint": "OBS 侧格式在「设置-高级-截图」；没有 Pillow 时 jpeg 会失败，可用 format:'png' 或 format:'file'"
        if _PILImage is None
        else None,
    }


def _encode_snapshot(path, want_format, max_bytes, max_width, quality=82):
    """读取截图 -> (format, base64, bytes, width, height)；必要时用 PIL 压缩/缩放。"""
    try:
        size = os.path.getsize(path)
    except OSError as exc:
        raise err(E_TIMEOUT, "截图文件不可读: %r" % (exc,), details={"path": path}, retryable=True)
    if size > max_bytes:
        raise err(
            E_TOO_LARGE,
            "截图 %d 字节超过上限 %d" % (size, max_bytes),
            hint="调小 width / 降低 max_bytes / 或在 OBS 设置里把截图格式改成 JPEG。",
            details={"path": path},
        )
    try:
        with open(path, "rb") as fh:
            raw = fh.read(max_bytes + 1)
    except OSError as exc:
        raise err(E_TIMEOUT, "读取截图失败: %r" % (exc,), retryable=True)
    ext = os.path.splitext(path)[1].lower()
    fmt = "jpeg" if ext in (".jpg", ".jpeg") else ("png" if ext == ".png" else "png")
    info = {"width": None, "height": None, "converted": False}
    do_convert = _PILImage is not None and (want_format in ("jpeg", "jpg") or (max_width or 0) > 0)
    if do_convert:
        try:
            from io import BytesIO

            im = _PILImage.open(BytesIO(raw))
            if im.mode not in ("RGB", "L"):
                im = im.convert("RGB")
            if max_width and im.width > max_width:
                im = im.resize((int(max_width), max(1, int(im.height * float(max_width) / im.width))), _PILImage.LANCZOS)
            buf = BytesIO()
            if want_format in ("jpeg", "jpg"):
                im.save(buf, format="JPEG", quality=int(quality or 82), optimize=True, progressive=False)
                fmt = "jpeg"
            else:
                im.save(buf, format="PNG", optimize=True)
            raw = buf.getvalue()
            info = {"width": im.width, "height": im.height, "converted": True}
            im.close()
        except Exception as exc:
            _LOG.debug("PIL 转码失败（退回原图）: %r" % (exc,))
    if want_format in ("jpeg", "jpg") and fmt != "jpeg" and _PILImage is None:
        raise err(
            E_UNSUPPORTED,
            "请求 JPEG 但 OBS 保存的是 %s，且运行环境没有 Pillow 可用于转码" % fmt,
            hint="在 OBS「设置-高级-截图」里把格式改成 JPEG；或 format:'png' / format:'file'；"
            "或 pip install Pillow 到 OBS 的 python 环境。",
            details={"path": path, "pil": False},
        )
    if len(raw) > max_bytes:
        raise err(E_TOO_LARGE, "转码后仍有 %d 字节" % len(raw), details={"max_bytes": max_bytes})
    b64 = base64.b64encode(raw).decode("ascii")
    return fmt, b64, len(raw), info


@op(
    "canvas.snapshot",
    "抓取画布或指定源的截图：走 OBS 原生截图管线落盘后回传 Base64（推荐高频时用 format:file）",
    {
        "source": ["str", False, "留空 = 主输出(Program/Preview 合成)；可填源名或场景名"],
        "scene": ["str", False, "解析 source 时使用的场景（留空 = 当前场景）"],
        "format": ['"jpeg"|"png"|"file"', False, "file = 只回路径，不做 base64（省 token/省 CPU）"],
        "width": ["int", False, "最长边像素，需 Pillow 才能缩放"],
        "quality": ["int", False, "JPEG 质量 20-100，需 Pillow"],
        "max_bytes": ["int", False, "base64 之前的字节上限（默认取脚本属性）"],
        "mode": ['"auto"|"native"|"dir"|"command"', False, "抓取后端；off 表示禁用"],
        "timeout_ms": ["int", False, "等待 OBS 写出文件的超时（默认 2500）"],
        "save_copy": ["str", False, "额外把图片另存到该路径"],
        "must_be_last": ["bool", False, "内部约束：snapshot 之后的 op 会被拒绝（异步收尾）"],
    },
)
def op_canvas_snapshot(rt, a, ctx):
    if not ctx.get("is_last", True):
        raise err(
            E_BAD_PARAMS,
            "canvas.snapshot 必须是批量里的最后一个 op",
            hint="截图是 OBS 异步落盘 + 网络线程收尾的模式，放到最后才能保证顺序语义；"
            "需要在它之前做别的操作就分成两次请求。",
        )
    mode = str(arg(a, "mode", (rt.props or {}).get("snapshot_mode") or "auto")).strip().lower()
    if mode == "off":
        raise err(E_UNSUPPORTED, "canvas.snapshot 已被脚本属性禁用（snapshot_mode=off）", hint="在脚本属性里改回 auto/native。")
    fmt_want = str(arg(a, "format", "jpeg")).strip().lower()
    if fmt_want not in ("jpeg", "jpg", "png", "file"):
        raise err(E_BAD_PARAMS, "format 只能是 jpeg / png / file", details={"got": fmt_want})
    quality = _clamp(_int(a.get("quality"), (rt.props or {}).get("snapshot_quality", 82)) or 82, 20, 100)
    max_bytes = _clamp(
        _int(a.get("max_bytes"), (rt.props or {}).get("max_snapshot_bytes") or MAX_SNAPSHOT_BYTES) or MAX_SNAPSHOT_BYTES,
        16 * 1024,
        MAX_SNAPSHOT_BYTES,
    )
    max_width = max(0, _int(a.get("width"), 0) or 0)
    timeout = _clamp(_int(a.get("timeout_ms"), (rt.props or {}).get("snapshot_timeout_ms", 2500)) or 2500, 100, 10000)
    dirs = _snapshot_dirs()
    refs = ctx["refs"]
    prev_last = None
    src = None
    sname = None
    name = a.get("source")
    if name:
        sname, scene = resolve_scene(refs, scene_ref(a))
        src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    # 记下触发前已存在的图片：兜底扫目录时只认「新出现」的文件，
    # 否则可能把上一次截图当成这次的结果返回（静默错误，比超时更糟）。
    exclude = set()
    if prev_last:
        exclude.add(prev_last)
    if mode != "dir":  # dir 模式就是要取「已有」的最新图，不能排除
        for d in dirs[:4]:
            try:
                for e in os.scandir(d):
                    exclude.add(e.path)
                    if len(exclude) > 800:
                        break
            except OSError:
                continue
    common = {
        "op": "canvas.snapshot",
        "format": "file" if fmt_want in ("file",) else ("png" if fmt_want == "png" else "jpeg"),
        "max_bytes": max_bytes,
        "width": max_width,
        "quality": quality,
        "save_copy": a.get("save_copy"),
        "timeout_ms": timeout,
        "t0": time.time(),
        "exclude": exclude,
        "scene": sname,
        "source": name,
        "dirs": dirs[:6],
    }
    if mode == "dir":
        if not dirs:
            raise err(E_UNSUPPORTED, "找不到截图目录", hint="在脚本属性 snapshot_dir 里指定 OBS 的截图保存目录。")
        common.update({"mode": "dir", "prev": None, "t0": 0.0})
        return Capture(**common)
    if mode == "command":
        cmd = str((rt.props or {}).get("snapshot_command") or "").strip()
        if not cmd:
            raise err(E_UNSUPPORTED, "snapshot_command 未配置", hint="在脚本属性里填外部截图命令，用 {output} 占位输出路径。")
        out_dir = os.path.join(nexus_dir(), "snapshots")
        _ensure_dir(out_dir)
        out_path = os.path.join(out_dir, "nexus-%d.png" % now_ms())
        line = cmd.replace("{output}", out_path).replace("{source}", name or "program")
        common.update({"mode": "command", "command": line, "out_path": out_path, "prev": None, "t0": time.time()})
        return Capture(**common)
    if not (_has("obs_frontend_take_screenshot") and _has("obs_frontend_get_last_screenshot")):
        raise err(
            E_UNSUPPORTED,
            "当前 OBS 未提供 obs_frontend_take_*_screenshot / get_last_screenshot（需要 OBS 26+）",
            details={"mode": mode, "obs_version": obs_version_string()},
            hint="改用 mode:'dir'（从截图目录取最新文件）或 mode:'command'。",
        )
    prev = prev_last
    fn = _fn("obs_frontend_get_last_screenshot")
    try:
        if fn is not None:
            prev = fn() or None
    except Exception:
        prev = None
    trigger = _fn("obs_frontend_take_source_screenshot") if src is not None else _fn("obs_frontend_take_screenshot")
    if trigger is None:
        raise err(E_UNSUPPORTED, "OBS 未提供 take_screenshot 接口")
    try:
        if src is not None:
            trigger(src)
        else:
            trigger()
    except Exception as exc:
        raise err(E_OBS_FAILED, "obs_frontend_take_*_screenshot 调用失败: %r" % (exc,), hint="OBS 可能正在关闭；稍后重试。", retryable=True)
    common.update({"mode": "native", "prev": prev, "t0": time.time() - 0.4})
    return Capture(**common)


# ================================ conn.* ==================================
@op("conn.status", "Nexus 服务端运行时状态（连接数、队列、限流水位、鉴权模式）", {}, execution=EXEC_WORKER)
def op_conn_status(rt, a, ctx):
    return rt.metrics(detailed=True)


@op(
    "conn.subscribe",
    "订阅主线程推送的事件（scene.changed / text.updated / record.* / stream.* …）",
    {
        "events": ["[str]", False, "事件名数组（覆盖式订阅）；不传 = 恢复默认集，[] = 全部退订"],
        "min_interval_ms": ["int", False, "同类事件最小间隔（0 = 不限速）"],
    },
)
def op_conn_subscribe(rt, a, ctx):
    conn = ctx.get("conn")
    if conn is None:
        raise err(E_BAD_PARAMS, "conn.subscribe 只能在活动连接上调用")
    ev = a.get("events")
    if ev is None:
        want = set(rt.default_events)
    elif isinstance(ev, (list, tuple)):
        want = set(str(x) for x in ev)
        unknown = [x for x in want if x not in rt.event_names]
        if unknown:
            raise err(E_BAD_PARAMS, "未知事件: %s" % ", ".join(sorted(unknown)[:6]), details={"known": sorted(rt.event_names)})
    else:
        raise err(E_BAD_PARAMS, "events 必须是数组")
    conn.subscribe(want, _int(a.get("min_interval_ms"), 0) or 0)
    return {"subscribed": sorted(want), "min_interval_ms": conn.min_interval_ms, "note": "事件走同一 TCP 连接，type=event"}


@op(
    "nexus.reload",
    "重新读取 ~/.obs_nexus/config.json 并热应用（端口/限流变化会自动重启服务端）",
    {},
    advanced=True,
)
def op_nexus_reload(rt, a, ctx):
    out = rt.reload_settings()
    out["note"] = "改完脚本面板里的属性也会触发同样的热应用；本 op 用于「直接改文件后生效」。"
    return out


@op(
    "nexus.stop",
    "临时关掉网络服务（OBS 不退出，所有 agent 连接断开；脚本面板「启动服务」可再开）",
    {"reason": ["str", False, "写进日志的原因"]},
    advanced=True,
)
def op_nexus_stop(rt, a, ctx):
    reason = str(arg(a, "reason", "nexus.stop") or "nexus.stop")[:60]
    # 延迟到本次响应写完之后，否则自己先把连接掐了、客户端只能看到断线
    rt.post_deferred(150, _defer_stop_server, rt, reason)
    return {
        "stopping_in_ms": 150,
        "reason": reason,
        "note": "响应发完后断开全部连接并停掉监听；OBS 仍正常运行，可在脚本面板点「启动服务」恢复。",
    }


def _defer_stop_server(rt, reason):
    try:
        rt.stop_server(reason)
    except Exception:
        _LOG.error("stop_server 异常:\n%s" % traceback.format_exc())


@op("conn.capabilities", "自描述：所有可用 op 与参数说明（Agent 可以先问这个再干活）", {}, execution=EXEC_WORKER)
def op_conn_capabilities(rt, a, ctx):
    return {
        "proto": NEXUS_PROTO,
        "nexus_version": NEXUS_VERSION,
        "ops": [spec.describe() for name, spec in sorted(OPS.items()) if not spec.advanced or rt.advanced],
        "advanced_enabled": rt.advanced,
        "limits": dict(rt.limits, max_line_bytes=MAX_LINE_BYTES, max_batch_ops=MAX_BATCH_OPS),
        "response_shape": {
            "ok": "bool",
            "result": "{op,data} 或 {op,error}(批量单步失败时)",
            "error": "{code,message,details,hint,retryable} 或 null",
            "batch": "{index,count,aborted,continue_on_error}",
            "request_id": "回显",
        },
        "usage": '每行一条 JSON: {"t":"req","id":"1","op":"text.set","source":"字幕","text":"hi"}\\n',
    }
