

# =============================================================================
# OBS 桥接层：引用计数安全 + 主线程断言 + 只读快照
# =============================================================================
class RefAudit(object):
    """引用计数审计（工业级要求：获取必须配对释放）。

    libobs 的引用是「每个 id 可重入」的：同一个源可能被两次 obs_get_source_by_name
    拿到两个独立引用。所以这里按 id 维护一个**栈**，而不是「一个对象一条记录」——
    后者会把正常的并发持有误判成 double release。

    release() 只有在栈里找不到对应引用时才记 double（= 释放了借来的/别人的引用，
    这是真 bug）；进程退出时 outstanding>0 表示泄漏（= 拿了没还）。
    """

    def __init__(self, enabled=None):
        if enabled is None:
            enabled = os.environ.get("OBS_NEXUS_AUDIT", "1") != "0"
        self.enabled = enabled
        self._lock = threading.Lock()
        self._live = {}  # id(obj) -> [(token, kind), ...]
        self.gets = 0
        self.releases = 0
        self.double = 0
        self._seq = itertools.count(1)

    def acquire(self, obj, kind):
        """登记一次「取得引用」。返回 obj 便于内联调用。"""
        if obj is None or not self.enabled:
            return obj
        with self._lock:
            self.gets += 1
            self._live.setdefault(id(obj), []).append((next(self._seq), kind))
        return obj

    def release(self, obj, kind="auto"):
        """登记一次「释放引用」。kind 传对应的 release 函数名。"""
        if obj is None or not self.enabled:
            return
        with self._lock:
            self.releases += 1
            stack = self._live.get(id(obj))
            if not stack:
                self.double += 1  # 释放了没有登记过的引用：借用量被误 release，或重复 release
                return
            idx = len(stack) - 1
            if kind != "auto":
                for i in range(len(stack) - 1, -1, -1):
                    if stack[i][1] == kind:
                        idx = i
                        break
                else:
                    self.double += 1  # 配对函数不对（用 obs_source_release 去还 sceneitem）
                    return
            stack.pop(idx)
            if not stack:
                self._live.pop(id(obj), None)

    def snapshot(self):
        with self._lock:
            gets, releases, double = self.gets, self.releases, self.double
            outstanding = sum(len(v) for v in self._live.values())
            kinds = {}
            for stack in self._live.values():
                for _tok, kind in stack:
                    kinds[kind] = kinds.get(kind, 0) + 1
        return {
            "gets": gets,
            "releases": releases,
            "outstanding": outstanding,
            "leaks": outstanding,  # 语义等价：还欠着多少引用
            "double_release": double,
            "kinds": kinds,
            "enabled": self.enabled,
        }

    def reset(self):
        with self._lock:
            self._live.clear()
            self.gets = self.releases = self.double = 0

AUDIT = RefAudit()


def _release(fn_name, obj):
    """释放一个 OBS 引用；fn_name 是对应的 release 函数名。"""
    if obj is None:
        return
    AUDIT.release(obj, fn_name)
    fn = _fn(fn_name)
    if fn is None:
        return
    try:
        fn(obj)
    except Exception as exc:  # pragma: no cover
        _LOG.warn("%s 失败: %r" % (fn_name, exc))


class Refs(object):
    """主线程内的引用管理器：with 块退出时自动 release（LIFO）。

    所有「返回新引用」的 obs 调用都必须经过 track()，包括
    obs_get_source_by_name / obs_scene_get_source / obs_sceneitem_get /
    obs_scene_find_source[_recursive] / obs_source_get_filter_by_name ...
    """

    def __init__(self, audit=True):
        self._stack = []
        self._audit = audit

    def track(self, obj, release="obs_source_release"):
        if obj is not None and self._audit:
            AUDIT.acquire(obj, release)
            self._stack.append((obj, release))
        return obj

    def drop(self, obj, release="obs_source_release"):
        """提前释放一个已 track 的引用：同时把它从栈里摘掉。

        少了这一步，release_all() 会对同一个对象再 release 一次 —— 在真 OBS 里
        那是 use-after-free 级别的 bug，不是「多减一次计数」这么简单。
        """
        for i in range(len(self._stack) - 1, -1, -1):
            if self._stack[i][0] is obj:
                self._stack.pop(i)
                _release(release, obj)
                return True
        return False

    def release_all(self):
        # LIFO：先释放场景项，再释放场景/源，符合 libobs 的父子依赖习惯
        while self._stack:
            obj, release = self._stack.pop()
            _release(release, obj)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release_all()
        return False


class ListRefs(object):
    """obs_frontend_source_list / obs_frontend_property_manager 等容器。"""

    def __init__(self, kind):
        self.kind = kind
        self.obj = None

    def __enter__(self):
        if self.kind == "source_list":
            if not _has("obs_frontend_source_list_create"):
                raise err(E_UNSUPPORTED, "obspython 未提供 obs_frontend_source_list")
            self.obj = obs.obs_frontend_source_list_create()
        elif self.kind == "prop_manager":
            fn = _fn("obs_frontend_get_independent_property_manager")
            if fn is None:
                raise err(E_UNSUPPORTED, "OBS 版本过低：无独立属性管理器（需要 26+）")
            self.obj = fn()
        return self.obj

    def __exit__(self, exc_type, exc, tb):
        if self.obj is None:
            return False
        try:
            if self.kind == "source_list":
                obs.obs_frontend_source_list_free(self.obj)  # 内部会 release 所有源
            elif self.kind == "prop_manager":
                _fn("obs_frontend_release_independent_property_manager")(self.obj)
        except Exception as exc2:  # pragma: no cover
            _LOG.warn("释放 %s 失败: %r" % (self.kind, exc2))
        finally:
            self.obj = None
        return False


# ------------------------------ 主线程断言 --------------------------------
# 注：这里刻意不放 NexusRuntime 的前向占位类 —— 它在 part 5 才真正定义，
# 一个同名空壳会让「顶层重名」检查失效，还会掩盖拼装顺序错误。
def _runtime():
    return _SERVER


def require_main_thread(what="obs 调用"):
    """致命红线 R1 的守卫：发现子线程调用 libobs 立刻报错而不是静默崩溃。"""
    rt = _SERVER
    if rt is None:
        return
    main = getattr(rt, "main_thread_id", None)
    if main and threading.get_ident() != main:
        _LOG.error("线程安全红线被触碰：在非主线程调用了 %s" % what)
        raise err(
            E_INTERNAL,
            "线程安全红线：禁止在非 OBS 主线程调用 libobs（%s）" % what,
            hint="该 op 必须通过 obs.timer_add 的泵队列执行，见 R1/R3。",
        )


# ============================ 场景 / 源 查找 ==============================
def list_scenes(refs):
    """OBS 场景列表 -> [(name, scene_t)]。

    内存安全要点（逐条对着 obs-studio 32.2.2 源码核过）：
      * obs_frontend_get_scenes() 填充的列表内部持有「引用自增」的场景源，
        必须由 obs_frontend_source_list_free() 统一释放，绝不能手动 release；
      * obs_scene_from_source() **不加引用**（obs-scene.c: `return source->context.data;`），
        所以要用 obs_scene_get_ref() 另取一份独立引用（配 obs_scene_release，
        它内部就是 obs_source_release(scene->source)）；这样即使 list_free 把列表
        那份引用还给源，我们的 scene 指针依然有效；
      * 所有 scene 引用都 track 进 refs，with 块结束时统一释放（LIFO）。
    """
    out = []
    fn = _fn("obs_frontend_get_scenes")
    if fn is None or refs is None:
        return out
    if not _can_own_scene():
        raise err(
            E_UNSUPPORTED,
            "这套 OBS 绑定缺 obs_scene_get_ref/obs_source_get_ref，无法安全持有场景引用",
            hint="宁可不返回也不要 release 借用指针：那是 use-after-free。请用带完整前端的 OBS。",
        )
    with ListRefs("source_list") as lst:
        try:
            fn(lst)
        except Exception as exc:
            raise err(E_OBS_FAILED, "obs_frontend_get_scenes 失败: %r" % (exc,))
        for src in _list_get(lst):
            try:
                name = obs.obs_source_get_name(src) or ""
            except Exception:
                name = ""
            scene = None
            scene = _scene_of(src)
            if scene is None:
                continue
            refs.track(scene, "obs_scene_release")
            out.append((name, scene))
    return out


def _list_get(lst):
    if lst is None:
        return []
    getter = getattr(lst, "get_sources", None)
    if callable(getter):
        try:
            return list(getter())
        except Exception:
            return []
    return list(getattr(lst, "sources", None) or [])


def _can_own_scene():
    """这台 OBS 能不能把借用的 scene 指针变成自有引用（拿不动就别硬撑）。"""
    if _fn("obs_scene_get_ref") is not None:
        return True
    return _fn("obs_scene_get_source") is not None and (
        _fn("obs_source_get_ref") is not None or _fn("obs_source_addref") is not None
    )


def _scene_borrow(src):
    """只借不持有：obs_scene_from_source 的原始返回值（诊断/内部判断用，不要存下来）。"""
    conv = _fn("obs_scene_from_source")
    if conv is None or src is None:
        return None
    try:
        return conv(src)
    except Exception:
        return None


def _scene_of(src):
    """obs_scene_from_source() 是**借用**（libobs 里就是 `return source->context.data;`），
    这里立刻用 obs_scene_get_ref() 提升成调用者持有的引用，调用方才能安全 release。
    没导出 obs_scene_get_ref 时退回 obs_source_get_ref(obs_scene_get_source(scene))，
    两条路都没有就返回 None —— 宁可不支持，也不能少加引用还多 release。
    """
    conv = _fn("obs_scene_from_source")
    if conv is None or src is None:
        return None
    try:
        scene = conv(src)
    except Exception:
        return None
    if scene is None:
        return None
    getref = _fn("obs_scene_get_ref")
    if getref is not None:
        try:
            return getref(scene)
        except Exception:
            return None
    getsrc = _fn("obs_scene_get_source")
    addref = _fn("obs_source_get_ref") or _fn("obs_source_addref")
    if getsrc is not None and addref is not None:
        try:
            own = addref(getsrc(scene))
        except Exception:
            return None
        return scene if own is not None else None
    return None


def current_scene_name():
    fn = _fn("obs_frontend_get_current_scene")
    if fn is None:
        return None
    src = fn()
    if src is None:
        return None
    try:
        refs = Refs()
        refs.track(src, "obs_source_release")
        try:
            return obs.obs_source_get_name(src)
        finally:
            refs.release_all()
    except Exception:
        return None


def resolve_scene(refs, name=None, exact=True):
    """按名字找场景；name 为空返回当前场景。返回 (name, scene_t)。"""
    scenes = list_scenes(refs)
    if not name:
        fn = _fn("obs_frontend_get_current_scene")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_frontend_get_current_scene")
        cur_src = fn()
        if cur_src is None:
            raise err(E_OBS_FAILED, "OBS 当前没有活动场景（可能正在关闭）")
        refs.track(cur_src, "obs_source_release")
        try:
            cur_name = obs.obs_source_get_name(cur_src) or ""
            scene = refs.track(_scene_of(cur_src), "obs_scene_release")  # _scene_of 已 addref
            if scene is None and _scene_borrow(cur_src) is not None and not _can_own_scene():
                raise err(E_UNSUPPORTED, "无法持有场景引用（缺 obs_scene_get_ref）")
        finally:
            pass
        if scene is None:
            raise err(E_NOT_A_SCENE, "当前活动场景的源不是场景类型")
        return cur_name, scene
    target = ("%s" % name).strip()
    lowered = target.lower()
    matches = [(n, s) for (n, s) in scenes if n == target]
    if not matches and not exact:
        matches = [(n, s) for (n, s) in scenes if (n or "").strip().lower() == lowered]
    if not matches:
        raise err(
            E_SCENE_NOT_FOUND,
            "场景不存在: %r" % target,
            details={"known": [n for (n, _s) in scenes][:64]},
            hint="用 scene.list 查看全部场景名（注意大小写与空格）。",
        )
    return matches[0]


def _own_item(refs, item):
    """把「借用」的 scene item 变成我们自己在 refs 里持有的一份引用。

    事实依据（obs-studio 32.2.2 / libobs/obs-scene.c）：

        obs_sceneitem_t *obs_scene_find_source(obs_scene_t *scene, const char *name)
        { ...; item = scene->first_item; while (item) { if (strcmp(...)) break; ... } return item; }

    也就是**不加引用**直接返回链表节点；而 obspython 的 SWIG 接口（obspython.i）里
    没有任何针对 obs_* 对象的 addref/release typemap，脚本层不会自动帮你管引用。
    所以「拿到就 track + release」= 把场景自己那份引用 release 掉 → refcount 归零 →
    libobs 真的 free 掉这个 item（后续渲染/枚举直接 use-after-free）。

    正确姿势：先 obs_sceneitem_addref，再把 release 挂到 refs 上（LIFO 统一释放）。
    如果某个构建没导出 obs_sceneitem_addref，就退化成「只借用、绝不 release」——
    父场景的引用还在 refs 里，item 在本次 op 期间保证有效，宁可少保护也不能多释放。
    """
    if item is None or refs is None:
        return item
    add = _fn("obs_sceneitem_addref")
    if add is None:
        return item
    try:
        add(item)
    except Exception:
        return item
    refs.track(item, "obs_sceneitem_release")
    return item


def _find_scene_item(scene, name, refs=None):
    """在场景内找 item（先精确后递归，再忽略大小写）。

    refs 不为 None 时返回的是**我们持有的**引用（已 addref + track）；为 None 时是借用，
    调用方不得 release。
    """
    if scene is None:
        return None
    exact = _fn("obs_scene_find_source")
    deep = _fn("obs_scene_find_source_recursive")
    item = None
    for fn in (exact, deep):
        if fn is None:
            continue
        try:
            item = fn(scene, name)
        except Exception:
            item = None
        if item is not None:
            return _own_item(refs, item)
    low = ("%s" % (name,)).strip().lower()
    if not low:
        return None
    holder = []

    def cb(s, it, _p):
        try:
            src = obs.obs_sceneitem_get_source(it)
            if (obs.obs_source_get_name(src) or "").strip().lower() == low:
                holder.append(it)
                return False
        except Exception:
            pass
        return True

    try:
        obs.obs_scene_enum_items(scene, cb, None)
    except Exception:
        return None
    # 回调里拿到的是借用指针（enum 自己在回调前后 addref/release），交给 _own_item 处理
    return _own_item(refs, holder[0]) if holder else None


def _borrow_to_ref(borrowed):
    """把 obs_sceneitem_get_source() 的借用指针提升为新引用。

    obs_source_get_ref / obs_source_addref 在部分构建里未必导出；取不到时
    返回 None，由调用方退回「按名字全局查」路径（OBS 保证源名全局唯一）。
    """
    if borrowed is None:
        return None
    fn = _fn("obs_source_get_ref")
    if fn is not None:
        try:
            return fn(borrowed)
        except Exception:
            pass
    fn = _fn("obs_source_addref")
    if fn is not None:
        try:
            fn(borrowed)
            return borrowed
        except Exception:
            pass
    return None


def _lookup_by_name(name):
    fn = _fn("obs_get_source_by_name")
    if fn is None:
        return None
    try:
        return fn(name)
    except Exception:
        return None


def _scene_name_safe(scene):
    try:
        return obs.obs_source_get_name(obs.obs_scene_get_source(scene))
    except Exception:
        return None


def resolve_source(refs, name, scene=None, scope="auto", allow_scene=True):
    """把名字解析成 obs_source_t（新引用，已 track 进 refs）。

    解析顺序：
      1) 目标场景内的场景项（含组内递归）—— 只有这条路能拿到 item_id / 层级
      2) obs_get_source_by_name（覆盖全局源：桌面音频、麦克风、未出场源、场景）
      3) 「麦克风 / 桌面音频」等中英文别名
    返回 (source, meta)，meta 说明命中位置，回显给 Agent 方便排错。
    """
    if name is None or ("%s" % (name,)).strip() == "":
        raise err(E_BAD_PARAMS, "缺少参数 source（源名称）")
    target = ("%s" % name).strip()

    if scene is not None and scope in ("auto", "scene"):
        item = _find_scene_item(scene, target, refs)
        if item is not None:
            item_id = _item_id(item)
            got = None
            try:
                got = _borrow_to_ref(obs.obs_sceneitem_get_source(item))
            except Exception:
                got = None
            if got is None:
                got = _lookup_by_name(target)
                via = "global_name"
            else:
                via = "item"
            if got is not None:
                refs.track(got, "obs_source_release")
                return got, {"where": "scene_item", "item_id": item_id, "ref_via": via}

    if scope in ("auto", "global"):
        got = _lookup_by_name(target)
        if got is not None:
            refs.track(got, "obs_source_release")
            try:
                stype = obs.obs_source_get_id(got) or ""
            except Exception:
                stype = ""
            if stype == "scene" and not allow_scene:
                refs.drop(got, "obs_source_release")
                refs._stack.pop()
                raise err(E_BAD_PARAMS, "%r 是场景而不是源；请传场景内的源名" % target)
            return got, {"where": "global" if stype != "scene" else "scene", "item_id": None}
        for alias in AUDIO_NAME_ALIASES.get(target.lower(), ()):
            got = _lookup_by_name(alias)
            if got is not None:
                refs.track(got, "obs_source_release")
                return got, {"where": "global_alias", "alias": alias, "item_id": None}

    raise err(
        E_SOURCE_NOT_FOUND,
        "找不到源: %r" % target,
        details={"scope": scope, "scene": None if scene is None else _scene_name_safe(scene)},
        hint="source 必须与 OBS 里的源名完全一致；先用 source.list 列出可用源名。",
    )


def _items_named(scene, target, limit=AMBIGUITY_PROBE_LIMIT):
    """按名字收集场景项（含组内递归）-> [(item, depth, layer)]，保序（z 序，depth 0 第一个 = 最上层）。

    只取「个数 + item_id」用于歧义判定，故意不做完整快照：这些函数每次 op 都会跑，
    省下 source_meta 的开销。最多数到 limit 个就停，超大场景不会被这个检查拖住。
    收集到的 item 是**借用**指针（enum 回调结束就把它自己的引用还回去），
    所以调用方要长期持有必须自己 addref —— 见 _own_item。
    """
    low = (target or "").strip().lower()
    out = []

    def visit(sc, depth):
        enum = _fn("obs_scene_enum_items")
        if enum is None or depth > 4:
            return False
        state = {"layer": 0, "stop": False}

        def cb(_s, item, _p):
            if state["stop"]:
                return False
            my_layer = state["layer"]
            state["layer"] += 1
            try:
                src = obs.obs_sceneitem_get_source(item)  # 借用引用：不 addref、不 release
                nm = (obs.obs_source_get_name(src) or "") if src is not None else ""
            except Exception:
                return True
            if nm.strip().lower() == low:
                out.append((item, depth, my_layer))
                if len(out) >= limit:
                    state["stop"] = True
                    return False
            elif _is_group(item):
                gs = _fn("obs_sceneitem_get_group")
                sub = None
                try:
                    sub = gs(sc, item) if gs is not None else None
                except Exception:
                    sub = None
                if sub is None:
                    try:
                        sub = obs.obs_sceneitem_group_get_scene(item)  # 借用
                    except Exception:
                        sub = None
                if sub is not None and not visit(sub, depth + 1):
                    return False
            return True

        try:
            enum(sc, cb, None)
        except Exception:
            return False
        return len(out) < limit

    visit(scene, 0)
    return out


def resolve_scene_item(refs, scene, name, nth=None):
    """只要场景项（可见性 / 层级 / 变换类操作）。返回 (item, borrowed_source)。

    `nth`（op 参数里的 index）用于同名场景项：OBS 允许一个场景里出现多个同名项
    （同一个源加两次、或两个源起同样的名字），此时「第一个匹配」到底是谁并不显然，
    误改另一个贴片比报错糟糕得多 —— 所以我们数一下同名项，>1 就直接 SOURCE_AMBIGUOUS，
    并回显所有候选的 item_id/layer/depth，让 Agent 用 index 指定。
    """
    if scene is None:
        raise err(E_BAD_PARAMS, "该操作需要 scene（留空表示当前场景）")
    target = ("%s" % (name,)).strip()
    if not target:
        raise err(E_BAD_PARAMS, "缺少参数 source（源名称）")
    found = _items_named(scene, target)
    if not found:
        item = _find_scene_item(scene, target)  # 兜底：走 OBS 原生查找（有些构建枚举行为不同）
        if item is None:
            raise err(
                E_SOURCE_NOT_FOUND,
                "场景 %r 中找不到源项: %r" % (_scene_name_safe(scene), target),
                hint="组内源也支持；可用 source.list 配 recursive:true 查看完整层级。",
            )
        found = [(item, 0, 0)]
    if nth is None:
        if len(found) > 1:
            cands = []
            for i, (it, dep, layer) in enumerate(found):
                try:
                    iid = _item_id(it)
                except Exception:
                    iid = None
                cands.append({"index": i, "item_id": iid, "layer": layer, "depth": dep})
            raise err(
                E_SOURCE_AMBIGUOUS,
                "场景 %r 里有 %d 个同名源项 %r，无法确定你要改哪个" % (_scene_name_safe(scene), len(found), target),
                details={"count": len(found), "candidates": cands[:AMBIGUITY_PROBE_LIMIT]},
                hint="给这个 op 加 index:0..%d 指定第几个（0 = z 序最上），或先在 OBS 里改名。" % (len(found) - 1),
            )
        item = found[0][0]
    else:
        try:
            idx = int(nth)
        except (TypeError, ValueError):
            raise err(E_BAD_PARAMS, "index 必须是整数", details={"got": nth})
        if not -len(found) <= idx < len(found):
            raise err(
                E_BAD_PARAMS,
                "index 越界：%d（%r 只有 %d 个同名项）" % (idx, target, len(found)),
                details={"count": len(found), "valid_range": [0, len(found) - 1]},
            )
        item = found[idx % len(found)][0]
    return _own_item(refs, item), _borrowed_source_of(item)


def _borrowed_source_of(item):
    try:
        return obs.obs_sceneitem_get_source(item)  # 借用：调用方不得 release
    except Exception:
        return None


def _item_id(item):
    fn = _fn("obs_sceneitem_get_id")
    if fn is None or item is None:
        return None
    try:
        return int(fn(item))
    except Exception:
        return None


def source_kind(source):
    try:
        return obs.obs_source_get_type(source)
    except Exception:
        return -1


def source_has_audio(source):
    fn = _fn("obs_source_get_output_flags")
    if fn is None:
        return True
    try:
        return bool(fn(source) & (OBS_SOURCE_AUDIO | OBS_SOURCE_ASYNC))
    except Exception:
        return False


def source_size(source):
    try:
        w = int(obs.obs_source_get_width(source) or 0)
        h = int(obs.obs_source_get_height(source) or 0)
    except Exception:
        w, h = 0, 0
    return w, h


def source_meta(source, refs=None, include_settings=False, max_settings=64):
    """构造源的只读元信息（全部是 python 值，可以安全跨线程发送）。"""
    meta = {}
    if source is None:
        return meta
    try:
        meta["name"] = obs.obs_source_get_name(source) or ""
    except Exception:
        meta["name"] = ""
    try:
        meta["type"] = obs.obs_source_get_id(source) or ""
    except Exception:
        meta["type"] = ""
    meta["kind"] = {SOURCE_TYPE_INPUT: "input", SOURCE_TYPE_FILTER: "filter", SOURCE_TYPE_TRANSITION: "transition"}.get(
        source_kind(source), "unknown"
    )
    w, h = source_size(source)
    meta["width"], meta["height"] = w, h
    flags = 0
    fn = _fn("obs_source_get_output_flags")
    if fn is not None:
        try:
            flags = int(fn(source) or 0)
        except Exception:
            flags = 0
    meta["video"] = bool(flags & OBS_SOURCE_VIDEO)
    meta["audio"] = bool(flags & (OBS_SOURCE_AUDIO | OBS_SOURCE_ASYNC))
    try:
        meta["muted"] = bool(obs.obs_source_muted(source))
    except Exception:
        meta["muted"] = None
    try:
        meta["volume"] = round(float(obs.obs_source_get_volume(source)), 5)
    except Exception:
        meta["volume"] = None
    if meta.get("volume") is not None:
        meta["volume_db"] = vol_to_db(meta["volume"])
    if include_settings:
        settings = source_settings(source, max_items=max_settings)
        if settings is not None:
            meta["settings"] = settings
    return meta


def source_settings(source, max_items=64, keys=None):
    """读取 obs_data 设置（带过滤与截断，避免撑爆 LLM 上下文）。"""
    get = _fn("obs_source_get_settings")
    rel = _fn("obs_data_release")
    if get is None:
        return None
    data = get(source)
    if data is None:
        return None
    try:
        AUDIT.acquire(data, "obs_data_release")
    except Exception:
        pass
    try:
        return _dump_data(data, max_items=max_items, keys=keys)
    finally:
        try:
            AUDIT.release(data, "obs_data_release")
        except Exception:
            pass
        if rel is not None:
            try:
                rel(data)
            except Exception:
                pass


def _data_keys(data):
    """按 libobs 语义遍历 obs_data 的键：obs_data_first() 只调一次，然后 next()。

    （obs_data_first() 会把游标复位，放在循环里会导致同一个键被反复读到。）
    """
    fn = _fn("obs_data_first")
    nxt = _fn("obs_data_next")
    if fn is None or nxt is None:
        return []
    keys = []
    try:
        if not fn(data):
            return []
    except Exception:
        return []
    for _ in range(4096):  # 防御：不信任迭代器一定终止
        k = _read_key(data)
        if k:
            keys.append(k)
        try:
            if not nxt(data):
                break
        except Exception:
            break
    return keys


def _read_key(data):
    for name in ("obs_data_get_key",):
        fn = _fn(name)
        if fn is not None:
            try:
                return fn(data) or ""
            except Exception:
                pass
    return ""


def _data_type(data, key):
    fn = _fn("obs_data_get_item_type")
    if fn is None:
        return "string"
    try:
        return _TYPE_NAMES.get(int(fn(data, key)), "string")
    except Exception:
        return "string"


_TYPE_NAMES = {0: "null", 1: "string", 2: "number", 3: "boolean", 4: "array", 5: "object"}


def _dump_data(data, max_items=64, keys=None, depth=0):
    """obs_data -> 普通 python dict（截断长字符串、跳过敏感 key）。"""
    if data is None or depth > 3:
        return None
    wanted = keys
    if wanted is None:
        wanted = _data_keys(data)
    out = {}
    skipped = {}
    for key in list(wanted)[: max(1, int(max_items))]:
        t = _data_type(data, key)
        try:
            if t == "string":
                val = obs.obs_data_get_string(data, key)
            elif t == "number":
                val = _data_number(data, key)
            elif t == "boolean":
                val = bool(obs.obs_data_get_bool(data, key))
            elif t == "array":
                val = _dump_array(data, key, max_items)
            elif t == "object":
                obj = obs.obs_data_get_obj(data, key)
                try:
                    if obj is not None:
                        AUDIT.acquire(obj, "obs_data_release")
                    val = _dump_data(obj, max_items=max_items, depth=depth + 1)
                finally:
                    if obj is not None:
                        _release("obs_data_release", obj)
            else:
                val = None
        except Exception as exc:
            skipped[key] = "read_error:%r" % (exc,)
            continue
        if isinstance(val, str) and len(val) > 512:
            skipped[key] = "truncated:%d" % len(val)
            val = val[:512] + "…"
        if key.lower() in ("password", "key", "secret", "token", "rtmp_server"):
            val = "***"
        out[key] = val
    if len(wanted or []) > max_items:
        skipped["_count"] = "keys=%d(shown=%d)" % (len(wanted or []), max_items)
    if skipped:
        out["_skipped"] = skipped
    return out


def _data_number(data, key):
    try:
        f = float(obs.obs_data_get_double(data, key))
    except Exception:
        f = 0.0
    try:
        i = int(obs.obs_data_get_int(data, key))
    except Exception:
        i = 0
    if abs(f - i) < 1e-9 and not math.isnan(f):
        return i
    if math.isnan(f) or math.isinf(f):
        return None
    return round(f, 6)


def _dump_array(data, key, max_items=64):
    getter = _fn("obs_data_get_array")
    count = _fn("obs_data_array_count")
    item = _fn("obs_data_array_item")
    release_a = _fn("obs_data_array_release")
    release_i = _fn("obs_data_release")
    if not all((getter, count, item)):
        return "<array>"
    arr = getter(data, key)
    if arr is None:
        return []
    try:
        try:
            n = int(count(arr))
        except Exception:
            n = 0
        out = []
        for i in range(min(n, max_items)):
            obj = item(arr, i)
            if obj is None:
                out.append(None)
                continue
            try:
                AUDIT.acquire(obj, "obs_data_release")
            except Exception:
                pass
            t = _data_type_of_obj(obj)
            if t == "string":
                out.append(obs.obs_data_get_string(obj, "value"))
            elif t == "number":
                out.append(_data_number(obj, "value"))
            elif t == "boolean":
                out.append(bool(obs.obs_data_get_bool(obj, "value")))
            else:
                out.append(_dump_data(obj, max_items=16))
            if release_i is not None:
                _release("obs_data_release", obj)
        if n > max_items:
            out.append("…+%d more" % (n - max_items,))
        return out
    finally:
        if release_a is not None:
            try:
                release_a(arr)
            except Exception:
                pass


def _data_type_of_obj(obj):
    fn = _fn("obs_data_get_item_type")
    if fn is None:
        return "string"
    try:
        return _TYPE_NAMES.get(int(fn(obj, "value")), "object")
    except Exception:
        return "object"


# --------------------------- 场景项（含锁定标记） --------------------------
def item_locked(item):
    """OBS 没有公开的「场景项锁定」API；Nexus 用源的 private settings 存
    约定字段 nexus_locked，供 Agent 做互斥标记。"""
    src = _fn("obs_sceneitem_get_source")(item) if _fn("obs_sceneitem_get_source") else None
    if src is None:
        return False
    getp = _fn("obs_source_get_private_settings")
    rel = _fn("obs_data_release")
    if getp is None:
        return False
    data = getp(src)  # 返回借用引用：不能 release 源，但可以 release data? ->
    # 文档：obs_source_get_private_settings 返回新引用，需要 obs_data_release
    if data is None:
        return False
    try:
        AUDIT.acquire(data, "obs_data_release")
        return bool(obs.obs_data_get_int(data, "nexus_locked"))
    except Exception:
        return False
    finally:
        _release("obs_data_release", data)
        if rel is None:
            pass


def item_info_dict(item, info=None):
    """obs_sceneitem_info -> dict（pos/scale/rot/bounds/crop）。"""
    if info is None:
        return {}
    def g(*names, **kw):
        default = kw.get("default", 0.0)
        for n in names:
            if hasattr(info, n):
                try:
                    v = getattr(info, n)
                    if v is not None:
                        return v
                except Exception:
                    continue
        return default

    out = {}
    pos = g("pos")
    if hasattr(pos, "x"):
        out["pos"] = [round(float(pos.x), 2), round(float(pos.y), 2)]
    else:
        out["pos"] = [round(float(g("pos_x")), 2), round(float(g("pos_y")), 2)]
    scale = g("scale")
    if hasattr(scale, "x"):
        out["scale"] = [round(float(scale.x), 4), round(float(scale.y), 4)]
    else:
        out["scale"] = [round(float(g("scale_x", default=1.0)), 4), round(float(g("scale_y", default=1.0)), 4)]
    out["rot"] = round(float(g("rot")), 3)
    alignment = g("alignment")
    if hasattr(alignment, "x"):
        try:
            out["alignment"] = [int(alignment.x), int(alignment.y)]
        except Exception:
            out["alignment"] = [0, 0]
    else:
        out["alignment"] = [int(g("alignment_x")), int(g("alignment_y"))]
    out["bounds"] = {
        "type": int(g("bounds_type")),
        "align": int(g("bounds_alignment")),
        "flags": int(g("bounds_flags")),
        "size": [round(float(g("bounds_x")), 2), round(float(g("bounds_y")), 2)],
    }
    out["cropped"] = bool(g("cropped"))
    out["crop"] = [
        int(g("crop_left")),
        int(g("crop_right")),
        int(g("crop_top")),
        int(g("crop_bottom")),
    ]
    return out


def create_item_info():
    fn = _fn("obs_sceneitem_info_create")
    if fn is None:
        return None
    try:
        return fn()
    except Exception:
        return None


def set_item_info(item, info):
    fn = _fn("obs_sceneitem_set_info")
    if fn is None:
        raise err(E_UNSUPPORTED, "无 obs_sceneitem_set_info")
    fn(item, info)
