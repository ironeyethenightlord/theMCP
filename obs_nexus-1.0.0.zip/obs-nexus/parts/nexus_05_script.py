

# =============================================================================
# 运行时：主线程泵 + 请求状态机 + 生命周期
# =============================================================================
_SERVER = None

STAT_KEYS = (
    "connections_total",
    "rejected",
    "json_errors",
    "unauth_attempts",
    "auth_ok",
    "auth_fail",
    "dropped_replies",
    "submitted",
    "executed",
    "exec_errors",
    "ops_ok",
    "ops_err",
    "events",
    "pump_ticks",
    "pump_over_budget",
    "queue_high_water",
    "slow_requests",
    "timeouts",
    "captures",
    "captures_failed",
    "overload_drops",
    "restarts",
    "deferred_run",
)


class Stats(object):
    """两线程共享的计数器（键在构造时全部预建，只做整数自增，不做结构变更）。"""

    def __init__(self, keys=STAT_KEYS):
        self._d = {k: 0 for k in keys}
        self._extra = {}

    def __getitem__(self, k):
        return self._d.get(k, 0)

    def __setitem__(self, k, v):
        if k in self._d:
            self._d[k] = v
        else:
            self._extra[k] = v

    def inc(self, k, n=1):
        if k in self._d:
            self._d[k] += n
        else:
            self._extra[k] = self._extra.get(k, 0) + n

    def get(self, k, default=0):
        v = self._d.get(k, self._extra.get(k, default))
        return default if v is None else v

    def as_dict(self):
        out = dict(self._d)
        out.update(self._extra)
        return out


class Capture(object):
    """交给网络线程收尾的截图任务（OBS 已在本 tick 触发落盘）。"""

    def __init__(self, **kw):
        self.kw = kw

    def as_dict(self):
        return dict(self.kw)


class RequestState(object):
    """一个请求的执行状态机。

    - 只在 OBS 主线程内被推进（由 pump 调用 run()），不阻塞：
      单个请求每 tick 最多占用 max_batch_exec_ms，超预算就回到 _flight 等下一次 tick；
    - 支持 Async（等待 OBS 异步产生结果，如录制状态变化）与 Capture（截图落盘等待，
      由网络线程完成文件读取与编码，避免把 base64/PIL 的开销压到主线程）。
    """

    def __init__(self, rt, conn_id, parsed, on_main=True):
        self.rt = rt
        self.conn_id = conn_id
        self.parsed = parsed
        self.on_main = on_main
        self.ops = parsed["ops"]
        self.index = 0
        self.results = []
        self.abort = False
        self.aborted = False
        self.t0 = time.monotonic()
        self.deadline = self.t0 + parsed["timeout_ms"] / 1000.0
        self.budget_ms = (rt.props or {}).get("max_batch_exec_ms") or MAX_BATCH_EXEC_MS
        self.pending = None
        self.pending_t0 = 0.0
        self.capture = None
        self.done = False
        self.payload = None
        self.client = parsed.get("client")

    @property
    def elapsed(self):
        """已经消耗的主线程时间（秒），Async 轮询回调可以用它计算 waited_ms。"""
        return time.monotonic() - self.t0

    # ------------------------- 执行 -------------------------
    def run(self, budget_ms=None):
        """推进执行；返回 True 表示可以发响应了。"""
        if self.done:
            return True
        limit = self.budget_ms if budget_ms is None else budget_ms
        while self.index < len(self.ops):
            now = time.monotonic()
            if now > self.deadline:
                self._timeout_rest()
                break
            if self.on_main and (now - self.t0) * 1000.0 > limit:
                return False  # 让出主线程，下个 tick 继续
            if self.abort:
                self.results.append({"ok": False, "op": self.ops[self.index]["op"], "skipped": "aborted", "error": self.error_of_abort()})
                self.index += 1
                continue
            spec_op = self.ops[self.index]
            if self.pending is not None:
                advanced = self._advance_pending(now)
                if not advanced:
                    return False
                continue
            try:
                self._exec_one(spec_op)
            except NexusError as exc:
                self._record_error(spec_op, exc)
            except Exception as exc:  # 兜底：任何 handler 异常都不能带崩 OBS
                _LOG.error("op %s 内部异常:\n%s" % (spec_op["op"], traceback.format_exc()))
                self.rt.stats.inc("exec_errors")
                self._record_error(
                    spec_op,
                    err(E_INTERNAL, "%s 执行时抛出异常: %s" % (spec_op["op"], exc.__class__.__name__), details={"error": str(exc)[:300]}),
                )
        self.finalize()
        return True

    def _exec_one(self, spec_op):
        rt = self.rt
        handler = spec_op["spec"].handler
        conn = rt.net.conn(self.conn_id) if rt.net is not None else None
        ctx = {
            "conn": conn,
            "index": self.index,
            "rt": rt,
            "on_main": self.on_main,
            "refs": None,
            "is_last": self.index == len(self.ops) - 1,
        }
        t0 = time.monotonic()
        if self.on_main:
            require_main_thread(spec_op["op"])
        with Refs() as refs:
            ctx["refs"] = refs
            out = handler(rt, spec_op["args"] or {}, ctx)
        dt = (time.monotonic() - t0) * 1000.0
        if isinstance(out, Async):
            self.pending = out
            self.pending_t0 = time.monotonic()
            self.pending_ctx = {"op": spec_op["op"], "index": self.index, "t0": t0, "started_ms": dt}
            return
        if isinstance(out, Capture):
            # 截图已在本次 tick 触发（OBS 异步落盘）；文件等待与编码交给网络线程收尾，
            # 因此本 op 必须是批量里的最后一个（handler 已用 ctx["is_last"] 做过校验）。
            self.capture = out
            self.results.append({"ok": True, "op": spec_op["op"], "pending": "await_file", "capture": out.as_dict()})
            self.index += 1
            return
        self.results.append({"ok": True, "op": spec_op["op"], "data": out, "ms": round(dt, 2)})
        self.index += 1

    def _advance_pending(self, now):
        pend = self.pending
        try:
            res = pend.poll(self)
        except NexusError as exc:
            self.pending = None
            self._record_error(self.ops[self.pending_ctx["index"]], exc)
            return True
        except Exception as exc:
            self.pending = None
            _LOG.error("async op 异常: %s" % traceback.format_exc())
            self._record_error(
                self.ops[self.pending_ctx["index"]], err(E_INTERNAL, "异步等待失败: %s" % (exc.__class__.__name__), details={"error": str(exc)[:200]})
            )
            return True
        if res is None:
            if (now - self.pending_t0) * 1000.0 > pend.timeout_ms or now > self.deadline:
                self.pending = None
                self._record_error(
                    self.ops[self.pending_ctx["index"]],
                    err(
                        E_TIMEOUT,
                        "等待 OBS 状态变化超时（%.0f ms）" % pend.timeout_ms,
                        details={"op": self.pending_ctx["op"], **{k: v for k, v in (pend.note or {}).items() if isinstance(v, (str, int, float, bool))}},
                        retryable=True,
                        hint="动作已经下发，可能仍在连接/停止中；稍后用 system.overview 复查。",
                    ),
                )
            return False
        self.pending = None
        idx = self.pending_ctx["index"]
        self.results.append(
            {
                "ok": True,
                "op": self.ops[idx]["op"],
                "data": res,
                "ms": round((time.monotonic() - self.pending_ctx["t0"]) * 1000.0, 2),
            }
        )
        self.index += 1
        return True

    def _record_error(self, spec_op, exc):
        self.rt.stats.inc("ops_err")
        self.results.append({"ok": False, "op": spec_op["op"], "error": exc.to_dict()})
        self.index += 1
        if not self.parsed["continue_on_error"]:
            self.abort = True
            self.aborted = True
            self.abort_error = exc

    def error_of_abort(self):
        e = getattr(self, "abort_error", None)
        return {"code": E_PRECONDITION, "message": "因前序 op 失败而跳过", "stopped_at": e.code if e else None}

    def _timeout_rest(self):
        exc = err(
            E_TIMEOUT,
            "请求超时（%d ms）：OBS 主线程可能在忙或脚本被阻塞" % self.parsed["timeout_ms"],
            retryable=True,
            hint="用 system.health 看 pump 是否活着；减小批量或频率。",
        )
        while self.index < len(self.ops):
            self._record_error(self.ops[self.index], exc)
            self.rt.stats.inc("timeouts")
        self.abort = True
        self.aborted = True

    def finalize(self):
        if self.done:
            return
        self.done = True
        ok_all = bool(self.results) and all(r.get("ok") for r in self.results)
        first_err = None
        for r in self.results:
            if not r.get("ok"):
                first_err = r.get("error")
                break
        payload = {
            "v": NEXUS_PROTO,
            "type": "response",
            "request_id": self.parsed.get("id"),
            "ok": ok_all,
            "elapsed_ms": round((time.monotonic() - self.t0) * 1000.0, 2),
            "result": self.results[0] if len(self.results) == 1 else None,
            "results": self.results,
            "batch": {
                "index": min(self.index, len(self.ops)) - 1 if self.ops else 0,
                "count": len(self.ops),
                "aborted": bool(self.aborted),
                "continue_on_error": bool(self.parsed["continue_on_error"]),
                "executed": sum(1 for r in self.results if not r.get("skipped")),
            },
            "error": first_err,
        }
        if self.pending is not None:
            payload["note"] = "仍有 op 在等待 OBS 状态变化，被超时截断"
        if self.capture is not None:
            payload["pending_capture"] = dict(self.capture.as_dict(), index=len(self.results) - 1)
            payload["batch"]["index"] = len(self.results) - 1
        for r in self.results:  # 发出去之前把内部字段去掉
            r.pop("capture", None)
        self.payload = payload


class NexusRuntime(object):
    """OBS Nexus 服务端本体（生命周期 + 主线程泵）。"""

    def __init__(self, settings=None):
        self.created = time.time()
        self.main_thread_id = threading.get_ident()
        self.net = NetServer(self)
        self.cmd_q = Queue(maxsize=CMD_QUEUE_DEPTH)
        self.reply_q = Queue(maxsize=512)
        self._flight = []
        self._deferred = deque()
        self.stats = Stats()
        self.token = None
        self.token_source = "runtime"
        self.host = LOOPBACK_V4
        self.allow_no_auth = False
        self.allow_lan = False
        self.advanced = False
        self.verbose_events = False
        self.running = False
        self.stopping = False
        self._timer_added = False
        self._frontend_events_added = False
        self._event_seq = 0
        self._recent = deque(maxlen=64)
        self._event_log = deque(maxlen=120)
        self._cache = {}
        self._cache_at = {}
        self._idle_streak = 0
        self.shot_cache = {"path": None, "serial": 0}
        self._capture_deadline = 0.0
        self.dir = nexus_dir()
        self.conn_file = os.path.join(self.dir, "connection.json")
        self.props = {}
        self.limits = {}
        self.event_names = (
            set(_FRONTEND_EVENT_NAMES.values())
            | {
                "text.updated",
                "source.visibility",
                "connection.ready",
                "nexus.reload",
                "nexus.config_changed",
                "nexus.error",
                "frontend_event",  # verbose_events 打开时，未识别的前端事件走这个
            }
        )
        self.default_events = {"scene.changed", "record.started", "record.stopped", "record.paused", "record.unpaused", "stream.started", "stream.stopped"}
        AUDIT.enabled = True
        self.configure(settings, starting=True)

    # --------------------------- 配置 ---------------------------
    def configure(self, settings, starting=False):
        raw = read_server_config()
        vals = {}
        for key, kind, default, _label in PROP_SPECS:
            v = _settings_get(settings, key, kind) if settings is not None else None
            if v is None:
                v = raw.get(key)
            if v is None:
                v = default
            vals[key] = _coerce_prop(kind, v, default)
        env_tok = os.environ.get("OBS_NEXUS_TOKEN")
        if env_tok:
            vals["token"] = env_tok.strip()
        self.props = vals
        self.advanced = bool(vals.get("advanced"))
        self.verbose_events = bool(vals.get("verbose_events"))
        self.allow_lan = bool(vals.get("allow_lan"))
        AUDIT.enabled = bool(vals.get("audit_refs"))
        self.host = LOOPBACK_V4 if not self.allow_lan else (vals.get("bind_host") or LOOPBACK_V4)
        if self.host not in (LOOPBACK_V4, LOOPBACK_V6):
            _LOG.warn("allow_lan 已开启：绑定 %s —— 请把端口限制在防火墙/代理之后" % self.host)
            self.host = LOOPBACK_V4
        self.limits = {
            "max_line_bytes": MAX_LINE_BYTES,
            "max_batch_ops": int(vals.get("max_batch_ops") or MAX_BATCH_OPS),
            "max_connections": int(vals.get("max_connections") or MAX_CONNECTIONS),
            "max_result_bytes": MAX_RESULT_BYTES,
            "max_snapshot_bytes": int(vals.get("max_snapshot_bytes") or MAX_SNAPSHOT_BYTES),
            "max_text_bytes": int(vals.get("max_text_bytes") or 32768),
            "max_list_items": int(vals.get("max_list_items") or 80),
            "idle_timeout_ms": int(vals.get("idle_timeout_ms") or IDLE_TIMEOUT_MS),
            "rate_per_sec": int(vals.get("rate_per_sec") or MAX_CONN_LINES_PER_SEC),
            "timer_interval_ms": TIMER_INTERVAL_MS,
            "request_timeout_max_ms": MAX_REQUEST_TIMEOUT_MS,
        }
        if os.environ.get("OBS_NEXUS_MAX_LINE"):
            try:
                self.limits["max_line_bytes"] = int(os.environ["OBS_NEXUS_MAX_LINE"])
            except ValueError:
                pass
        MAX_LINE_BYTES_eff = self.limits["max_line_bytes"]
        if self.net is not None and self.net.conns:
            for c in list(self.net.conns.values()):
                c.framer.max_bytes = MAX_LINE_BYTES_eff
                c.rate.configure(self.limits["rate_per_sec"])
        want_token = vals.get("require_auth") if not vals.get("token_override") else vals.get("token_override")
        if want_token and not self.token:
            self.ensure_token(force=bool(vals.get("rotate_token")))
        elif not self.allow_no_auth and not want_token:
            self.token = None
            self.token_source = "disabled"
        if starting:
            self.persist_config()

    def persist_config(self):
        keep = {k: self.props.get(k) for k, _t, _d, _l in PROP_SPECS if k not in ("rotate_token", "token_override")}
        save_server_config(keep)

    def ensure_token(self, force=False):
        if self.token and not force:
            return self.token
        self.token = os.urandom(TOKEN_BYTES).hex()
        self.token_source = "generated"
        return self.token

    # --------------------------- 缓存值（worker 可读） ---------------------------
    def cached(self, key, ttl=5.0):
        now = time.time()
        val = self._cache.get(key)
        if val is not None and now - self._cache_at.get(key, 0.0) < ttl:
            return val
        try:
            if key == "obs_version":
                val = obs_version_string()
            elif key == "active_scene":
                val = current_scene_name()
            elif key == "dirs":
                val = _snapshot_dirs()
            else:
                val = None
        except Exception:
            val = None
        self._cache[key] = val
        self._cache_at[key] = now
        return val

    # --------------------------- 生命周期 ---------------------------
    def start(self):
        if self.running:
            return {"ok": True, "note": "已在运行", "port": self.net.port}
        if not obs_alive():
            _LOG.error("obspython 不可用，拒绝启动")
            return {"ok": False, "error": "obspython 不可用"}
        try:
            if not os.path.isdir(self.dir):
                _ensure_dir(self.dir)
            _LOG.open(os.path.join(self.dir, "logs", "nexus.log"))
        except Exception as exc:
            _LOG.warn("状态目录准备失败: %r" % (exc,))
        try:
            startup = _fn("obs_startup")
            if startup is not None:
                pass  # OBS 已完成 obs_startup，脚本不需要（也不能）再调用
            port = self.net.start(self.host, int(self.props.get("port") or 0))
            self.running = True
            self.stopping = False
        except Exception as exc:
            _LOG.error("启动失败: %r\n%s" % (exc, traceback.format_exc()))
            return {"ok": False, "error": "启动失败: %r" % (exc,)}
        try:
            add = _fn("obs_frontend_add_event_callback")
            if add is not None:
                add(_frontend_event_cb, None)
                self._frontend_events_added = True
        except Exception as exc:
            _LOG.warn("注册前端事件失败: %r" % (exc,))
        try:
            if obs is not None and hasattr(obs, "timer_add"):
                obs.timer_add(self._pump, TIMER_INTERVAL_MS)
                self._timer_added = True
        except Exception as exc:
            _LOG.error("obs.timer_add 失败，服务无法桥接到主线程: %r" % (exc,))
            self.stop("timer_failed")
            return {"ok": False, "error": "timer_add 失败: %r" % (exc,)}
        self.write_conn_file()
        self._cache["obs_version"] = obs_version_string()
        self._cache_at["obs_version"] = 0.0
        _LOG.info(
            "OBS Nexus 已启动: %s:%d (auth=%s, advanced=%s, obs=%s, pid=%s)"
            % (self.host, port, "token" if self.token else "off", self.advanced, self._cache.get("obs_version"), os.getpid())
        )
        return {"ok": True, "port": port, "host": self.host, "auth": bool(self.token)}

    def stop(self, reason="manual", report=True):
        if self.stopping:
            return {"ok": True, "note": "已在停止流程中"}
        self.stopping = True
        _LOG.info("停止中（%s）…" % reason)
        try:
            if self._timer_added and obs is not None and hasattr(obs, "timer_remove"):
                obs.timer_remove(self._pump)
        except Exception as exc:
            _LOG.warn("timer_remove 失败: %r" % (exc,))
        self._timer_added = False
        try:
            if self._frontend_events_added:
                rm = _fn("obs_frontend_remove_event_callback")
                if rm is not None:
                    rm(_frontend_event_cb, None)
        except Exception:
            pass
        self._frontend_events_added = False
        ok = True
        try:
            ok = self.net.stop(force=False, timeout=1.5)
        except Exception as exc:
            _LOG.warn("关闭网络线程出错: %r" % (exc,))
        self.running = False
        for st in list(self._flight):
            st.deadline = 0.0
        self._flight = []
        try:
            self.reject_queued(reason)  # 已排队未执行的请求：给个像样的错误，再关连接
        except Exception:
            pass
        self._deferred.clear()
        try:
            while not self.cmd_q.empty():
                self.cmd_q.get_nowait()
        except Empty:
            pass
        try:
            while not self.reply_q.empty():
                self.reply_q.get_nowait()
        except Empty:
            pass
        self.remove_conn_file(reason)
        if report:
            try:
                self._audit_report("shutdown")
            except Exception:
                pass
        _LOG.info("已停止并清理（%s）" % reason)
        _LOG.close()
        return {"ok": bool(ok), "reason": reason}

    def stop_server(self, reason="nexus.stop"):
        """只关掉网络服务：OBS 侧的计时器/回调保留，脚本面板点「启动服务」即可再起来。

        与 stop() 的区别是不注销 OBS 回调、不关日志，属于「临时锁门」而不是「卸载」。
        """
        if not self.running or self.stopping:
            return {"ok": True, "was_running": False, "note": "服务当前没在运行"}
        ok = True
        try:
            ok = self.net.stop(force=False, timeout=1.5)
        except Exception as exc:
            _LOG.warn("net.stop 异常: %r" % (exc,))
            ok = False
        self.running = False
        for st in list(self._flight):
            st.deadline = 0.0
        self._flight.clear()
        self._deferred.clear()
        try:
            while not self.cmd_q.empty():
                self.cmd_q.get_nowait()
        except Exception:
            pass
        self.remove_conn_file(reason)
        _LOG.info("网络服务已停止（%s），OBS 仍在运行" % reason)
        return {"ok": bool(ok), "was_running": True, "reason": reason, "resumable": True}

    def reload_settings(self, restart_if_needed=True):
        """重新读取 config.json 并热应用（改了端口/限流不用重启 OBS）。"""
        before = dict(self.props)
        self.configure(None)
        changed = sorted(k for k in (set(before) | set(self.props)) if before.get(k) != self.props.get(k))[:20]
        needs = [k for k in ("port", "allow_lan", "rate_per_sec", "max_connections") if k in changed]
        restarted = False
        if needs and restart_if_needed and self.running:
            self.restart("nexus.reload:" + ",".join(needs))
            restarted = True
        elif self.running:
            self.write_conn_file()
        self.emit_event("nexus.config_changed", {"changed": changed, "restarted": restarted, "source": "nexus.reload"})
        return {"ok": True, "changed": changed, "restarted": restarted, "port": self.net.port if self.net else 0, "running": self.running}

    def restart(self, reason="restart"):
        self.stop(reason, report=False)
        self.stats.inc("restarts")
        self.net = NetServer(self)
        self.running = False
        self.stopping = False
        self.cmd_q = Queue(maxsize=CMD_QUEUE_DEPTH)
        self.reply_q = Queue(maxsize=512)
        out = self.start()
        if self._timer_added:  # start() 会重新添加；若 timer 仍在则去重
            pass
        return out

    # --------------------------- 连接文件 ---------------------------
    def write_conn_file(self):
        port = self.net.port if self.net else 0
        payload = {
            "app": NEXUS_APP,
            "proto": NEXUS_PROTO,
            "nexus_version": NEXUS_VERSION,
            "host": LOOPBACK_V4,
            "port": int(port),
            "token": self.token,
            "token_source": self.token_source,
            "pid": int(os.getpid()),
            "obs_version": self._cache.get("obs_version") or obs_version_string(),
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "created_ts": round(time.time(), 3),
            "path": self.conn_file,
            "advanced": bool(self.advanced),
            "limits": dict(self.limits),
            "note": "0600；OBS 退出/脚本卸载时自动删除；token 等同 OBS 完全控制权限，切勿外传",
        }
        if not port:
            payload["port"] = 0
            payload["note"] += "（服务未运行）"
        try:
            atomic_write_json(self.conn_file, payload)
            _LOG.info("连接文件已写入 %s (127.0.0.1:%d)" % (self.conn_file, port))
            return {"ok": True, "path": self.conn_file, "port": port, "token_present": bool(self.token)}
        except Exception as exc:
            _LOG.error("写入连接文件失败: %r" % (exc,))
            return {"ok": False, "error": repr(exc)}

    def remove_conn_file(self, reason=""):
        try:
            data = read_json_file(self.conn_file)
            if isinstance(data, dict) and data.get("token") and self.token and data.get("token") != self.token:
                return False  # 不是我们的文件（另一个 OBS 实例持有）-> 不删
        except Exception:
            pass
        try:
            os.unlink(self.conn_file)
            _LOG.info("已删除连接文件 %s (%s)" % (self.conn_file, reason or "n/a"))
            return True
        except FileNotFoundError:
            return False
        except OSError as exc:
            _LOG.warn("删除连接文件失败: %r" % (exc,))
            return False

    def conn_file_state(self):
        data = read_json_file(self.conn_file)
        if not isinstance(data, dict):
            return {"present": False, "path": self.conn_file}
        ours = data.get("token") == self.token and data.get("pid") == os.getpid()
        alive = pid_alive(data.get("pid"))
        return {
            "present": True,
            "ours": bool(ours),
            "port": data.get("port"),
            "pid": data.get("pid"),
            "pid_alive": alive,
            "age_s": round(time.time() - float(data.get("created_ts") or 0), 1) if data.get("created_ts") else None,
            "stale": (alive is False) or (data.get("created_ts") and time.time() - float(data["created_ts"]) > CONN_TTL_MS / 1000.0 * 600),
            "token_null": data.get("token") is None,
        }

    # --------------------------- 桥接：worker -> 主线程 ---------------------------
    def submit_request(self, conn, parsed):
        state = RequestState(self, conn.id, parsed, on_main=not all(o["spec"].execution == EXEC_WORKER for o in parsed["ops"]))
        if not state.on_main:
            # 纯本地 op（不碰 libobs）直接在网络线程执行，零排队延迟
            try:
                state.run()
                self.reply_q.put(("reply", conn.id, state.payload, state.payload.get("pending_capture")))
                self.notify()
            except Exception as exc:
                _LOG.error("本地 op 执行失败: %s" % traceback.format_exc())
                conn.send_obj(build_error_response(parsed.get("id"), err(E_INTERNAL, "本地 op 失败: %r" % (exc,))))
            return True
        try:
            self.cmd_q.put_nowait(state)
        except Full:
            self.stats.inc("overload_drops")
            conn.in_flight = False
            conn.send_obj(
                build_error_response(
                    parsed.get("id"),
                    err(
                        E_OVERLOAD,
                        "主线程队列已满（深度 %d）" % self.cmd_q.qsize(),
                        retryable=True,
                        details={"backlog": self.cmd_q.qsize()},
                        hint="OBS 主线程可能正忙；退避后重试，或降低批量大小。",
                    ),
                )
            )
            return False
        self.stats.inc("submitted")
        depth = self.cmd_q.qsize()
        if depth > self.stats.get("queue_high_water"):
            self.stats["queue_high_water"] = depth
        if depth >= CMD_QUEUE_HIGH:
            _LOG.warn("命令队列水位偏高: %d/%d" % (depth, CMD_QUEUE_DEPTH))
        return True

    def cmd_space(self):
        return self.cmd_q.qsize() < CMD_QUEUE_DEPTH

    def cmd_backlog(self):
        return self.cmd_q.qsize()

    def notify(self):
        try:
            if self.net is not None:
                self.net.wake()
        except Exception:
            pass

    def post_reply(self, conn_id, payload):
        try:
            self.reply_q.put_nowait(("reply", conn_id, payload, payload.get("pending_capture")))
        except Full:
            self.stats.inc("dropped_replies")
            try:
                self.reply_q.put_nowait(("force_close", conn_id, "reply_overflow"))
            except Full:
                pass
        self.notify()

    def forget_connection(self, conn_id):
        for st in list(self._flight):
            if st.conn_id == conn_id:
                self._flight.remove(st)
        self.notify()

    def post_deferred(self, delay_ms, fn, *args):
        self._deferred.append((time.monotonic() + max(0.0, delay_ms / 1000.0), fn, args))

    defer = post_deferred

    def emit_event(self, name, data=None):
        self._event_seq += 1
        self.stats.inc("events")
        self._event_log.appendleft((round(time.time(), 3), name, data))
        for conn_id in list(self.net.conns) if self.net else []:
            conn = self.net.conn(conn_id)
            if conn is not None and conn.wants(name):
                pass  # 真正的推送在 _drain_replies 的 ("event",..) 分支里做
        try:
            self.reply_q.put_nowait(("event", name, data))
        except Full:
            self.stats.inc("dropped_replies")
        self.notify()

    def snapshot_props(self):
        return dict(self.props)

    # --------------------------- 主线程泵（R3） ---------------------------
    def _pump(self, seconds=0.0):
        """OBS 主线程定时器回调（签名必须收 float 秒数：OBS 用 CallFunction(handler,"f",secs)）。"""
        t0 = time.monotonic()
        self._tick_secs = seconds
        self.stats.inc("pump_ticks")
        if self.stopping:
            # 停机中：一个 op 都不许碰 libobs，但要把排队的请求答复完再退
            self.reject_queued("pump")
            return
        budget = self._tick_budget()
        did = 0
        # 1) 消费网络线程投递的任务/请求
        while did < budget:
            try:
                job = self.cmd_q.get_nowait()
            except Empty:
                break
            did += 1
            try:
                if isinstance(job, RequestState):
                    if job.run():
                        self._finish(job)
                    else:
                        self._flight.append(job)
                elif callable(job):
                    job()
            except NexusError as exc:
                _LOG.warn("泵内任务返回错误: %s" % exc.code)
            except Exception as exc:
                self.stats.inc("exec_errors")
                _LOG.error("泵内任务异常:\n%s" % traceback.format_exc())
                self._emit_error("pump_job", exc)
        # 2) 推进未完成请求（Async 等待 / 超预算续跑 / 超时）
        for st in list(self._flight):
            if time.monotonic() > st.deadline:
                st._timeout_rest()
                st.finalize()
                self._flight.remove(st)
                self._finish(st)
                continue
            try:
                if st.run(40.0):
                    self._flight.remove(st)
                    self._finish(st)
                    did += 1
            except Exception as exc:
                _LOG.error("flight 推进异常:\n%s" % traceback.format_exc())
                self._emit_error("pump_flight", exc)
                try:
                    self._flight.remove(st)
                    st.finalize()
                    self._finish(st)
                except Exception:
                    pass
        # 3) 延时任务
        now = time.monotonic()
        for _ in range(32):
            if not self._deferred:
                break
            due, fn, args = self._deferred[0]
            if due > now:
                break
            self._deferred.popleft()
            try:
                fn(*args)
                self.stats.inc("deferred_run")
            except Exception:
                _LOG.warn("延时任务失败:\n%s" % traceback.format_exc())
        # 4) 截图路径缓存（把主线程专属值变成纯 python 值给 worker 用）
        if now < self._capture_deadline:
            fn = _fn("obs_frontend_get_last_screenshot")
            if fn is not None:
                try:
                    p = fn()
                    if p != self.shot_cache.get("path"):
                        self.shot_cache = {"path": p, "serial": self.shot_cache.get("serial", 0) + 1, "ts": time.time()}
                except Exception:
                    pass
        # 5) 周期性自检
        if self.stats.get("pump_ticks") % 600 == 0:
            self._audit_report("periodic")
        took = (time.monotonic() - t0) * 1000.0
        self._last_pump_ms = took
        self._last_pump_at = time.time()
        self._pump_work = did
        if took > MAX_PUMP_TICK_MS:
            self.stats.inc("pump_over_budget")
        self._idle_streak = self._idle_streak + 1 if did == 0 else 0
        self._pump_count_since_work = getattr(self, "_pump_count_since_work", 0)
        if did:
            self.notify()

    def _tick_budget(self):
        i = min(self._idle_streak, len(TICK_BUDGET) - 1)
        return TICK_BUDGET[i]

    def reject_queued(self, reason):
        """把 cmd_q 里还没执行的请求逐个回 `SHUTTING_DOWN`（不执行任何 libobs 调用）。

        没有这一步的话，停机瞬间排队的请求只会随着 socket 关闭变成「连接被重置」，
        客户端分不清「没送到」和「被拒绝」，容易写出无限重试的循环。
        """
        n = 0
        while n < MAX_PUMP_JOBS:
            try:
                job = self.cmd_q.get_nowait()
            except Empty:
                break
            n += 1
            if not isinstance(job, RequestState):
                continue  # 内部 callable 任务：直接丢掉（都是日志/收尾类，重复执行才危险）
            try:
                job.payload = build_error_response(
                    job.parsed.get("id"),
                    err(
                        E_SHUTTING_DOWN,
                        "OBS 正在关闭，请求未执行（%s）" % reason,
                        details={"queued_ops": [o["op"] for o in job.ops][:8]},
                        hint="进程即将退出：不要重试，等脚本重新起来。",
                        retryable=False,
                    ),
                )
                job.done = True
                self._finish(job)
            except Exception:
                pass
        return n

    def _finish(self, state):
        self.stats.inc("executed")
        if state.capture is not None:
            self._capture_deadline = time.monotonic() + (state.capture.as_dict().get("timeout_ms", 2500) / 1000.0) + 0.5
            self.stats.inc("captures")
        if state.payload and not state.payload.get("ok"):
            self.stats.inc("ops_err")
        if state.payload and state.payload.get("elapsed_ms", 0) > 1000:
            self.stats.inc("slow_requests")
        conn = self.net.conn(state.conn_id) if self.net is not None else None
        if conn is None:
            return  # 客户端已断开：直接丢弃响应（引用已在本 tick 释放）
        self.post_reply(state.conn_id, state.payload)

    def _emit_error(self, where, detail):
        """把「服务端自己出事了」推给订阅者（默认没人收，节流 2s 一条）。

        泵里的异常只写日志的话，Agent 只会看到超时/断连，排障要靠猜；
        有了这个事件，LLM 侧至少知道「OBS 主线程里刚才抛了什么」。
        """
        now = time.monotonic()
        if now - getattr(self, "_last_error_evt_at", 0.0) < 2.0:
            return
        self._last_error_evt_at = now
        try:
            self.emit_event("nexus.error", {"where": where, "detail": str(detail)[:600]})
        except Exception:
            pass

    def _audit_report(self, why):
        snap = AUDIT.snapshot()
        if snap["outstanding"] or snap["leaks"] or snap["double_release"]:
            _LOG.warn("引用审计(%s): %s" % (why, snap))
            self._emit_error("ref_audit", "%s: %s" % (why, snap))
        elif _LOG_DEBUG:
            _LOG.debug("引用审计(%s): 干净 gets=%d releases=%d" % (why, snap["gets"], snap["releases"]))

    # --------------------------- 观测 ---------------------------
    def metrics(self, detailed=False):
        now = time.time()
        out = {
            "running": bool(self.running),
            "stopping": bool(self.stopping),
            "listen": "%s:%s" % (self.host, self.net.port if self.net else 0),
            "port": self.net.port if self.net else 0,
            "pid": os.getpid(),
            "connections": len(self.net.conns) if self.net else 0,
            "max_connections": self.limits.get("max_connections"),
            "queue_depth": self.cmd_q.qsize(),
            "queue_capacity": CMD_QUEUE_DEPTH,
            "reply_queue": self.reply_q.qsize(),
            "in_flight": len(self._flight),
            "pump_ticks": self.stats.get("pump_ticks"),
            "pump_lag_ms": round((now - getattr(self, "_last_pump_at", now)) * 1000.0, 1),
            "last_pump_ms": round(getattr(self, "_last_pump_ms", 0.0), 2),
            "tick_budget": self._tick_budget(),
            "auth_required": bool(self.token),
            "advanced": bool(self.advanced),
            "uptime_s": round(now - self.created, 1),
            "idle_streak": self._idle_streak,
        }
        if detailed:
            out["counters"] = self.stats.as_dict()
            out["limits"] = dict(self.limits)
            out["connections_detail"] = [c.usage() for c in list(self.net.conns.values())] if self.net else []
            out["recent_requests"] = list(self._recent)[:12]
            out["recent_events"] = [{"ts": t, "event": n} for (t, n, _d) in list(self._event_log)[:12]]
            out["conn_file"] = self.conn_file_state()
            out["refs"] = AUDIT.snapshot()
            out["log_path"] = _LOG.path
            out["snapshot"] = snapshot_capability()
        return out

    def health(self):
        now = time.time()
        return {
            "timer_alive": bool(self._timer_added),
            "thread_alive": bool(self.net and self.net._thread and self.net._thread.is_alive()),
            "pump_age_ms": round((now - getattr(self, "_last_pump_at", now)) * 1000.0, 1),
            "pump_ticks": self.stats.get("pump_ticks"),
            "pump_over_budget": self.stats.get("pump_over_budget"),
            "queue_depth": self.cmd_q.qsize(),
            "in_flight": len(self._flight),
            "log_errors": _LOG.error_count,
            "conn_file": self.conn_file_state(),
            "running": bool(self.running),
            "stopping": bool(self.stopping),
            "uptime_s": round(now - self.created, 1),
        }

    def observe_request(self, info):
        self._recent.appendleft(info)


# 主线程 -> 网络线程的唯一「事件」通道；网络线程 -> 主线程走 cmd_q
_server_ref = {"rt": None}


def _server():
    return _SERVER


# NetworkServer 需要的 conn 查询（保持 NetServer 不直接依赖 runtime 细节）
def _net_conn(self, conn_id):
    return self.conns.get(conn_id)


NetServer.conn = _net_conn


def safe(fn):
    """OBS 回调保护：任何异常都不能穿透到 libobs（否则 OBS 直接闪退）。"""

    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except NexusError as exc:
            _LOG.warn("%s: %s" % (fn.__name__, exc.message))
        except Exception:
            _LOG.error("%s 内部异常:\n%s" % (fn.__name__, traceback.format_exc()))
        return None

    wrapper.__name__ = "safe_" + fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


@safe
def _frontend_event_cb(event, _param):
    """OBS 前端事件（主线程）：转成纯 python 数据后推给订阅者。"""
    rt = _SERVER
    if rt is None:
        return
    try:
        ev = int(event)
    except (TypeError, ValueError):
        return
    name = _FRONTEND_EVENT_NAMES.get(ev)
    if name is None:
        if rt.verbose_events:
            rt.emit_event("frontend_event", {"event_id": ev})
        if ev not in (FRONTEND_EVENT_OBS_SHUTDOWN, FRONTEND_EVENT_EXIT):
            return
        name = _FRONTEND_EVENT_NAMES.get(ev) or "obs_shutdown"
    data = {}
    if name in ("scene.changed", "scene_list.changed", "profile.changed", "transition.changed"):
        data["current_scene"] = current_scene_name()
        if name == "scene_list.changed":
            refs = Refs()
            try:
                data["scenes"] = [n for (n, _s) in list_scenes(refs)][:200]
            finally:
                refs.release_all()
    elif name and name.startswith("stream"):
        data["streaming"] = _stream_state()
    elif name and name.startswith("record"):
        data["recording"] = _record_state()
    if name in ("obs_shutdown", "obs.exit"):
        _LOG.info("收到 OBS %s 事件，开始优雅退出" % name)
        rt.post_deferred(0, rt.stop, "obs_" + name)
        return
    rt.emit_event(name, data)


def _settings_get(settings, key, kind):
    if settings is None:
        return None
    try:
        if kind == "bool":
            return bool(obs.obs_data_get_bool(settings, key))
        if kind == "int":
            v = obs.obs_data_get_int(settings, key)
            return int(v) if v is not None else None
        if kind in ("str", "path", "text"):
            v = obs.obs_data_get_string(settings, key)
            return v if v else None
        if kind == "list":
            v = obs.obs_data_get_string(settings, key)
            return v if v else None
    except Exception:
        return None
    return None


def _coerce_prop(kind, value, default):
    try:
        if kind == "bool":
            return _bool(value, bool(default))
        if kind == "int":
            return int(float(value))
    except (TypeError, ValueError):
        return default
    return ("%s" % value).strip() if isinstance(value, str) else value


def _data_set_default(settings, key, kind, value):
    """写「默认值」而不是写「值」：OBS 加载脚本时会先调 script_defaults(settings)。

    这里如果手滑用了 obs_data_set_*，每次启动 OBS 都会把用户调好的设置抹回默认值
    （端口、限流、advanced 全没了），而且很难发现。obs_data_set_default_* 的语义是
    「键不存在才填」，正是我们要的。
    """
    if settings is None:
        return
    try:
        if kind == "bool":
            obs.obs_data_set_default_bool(settings, key, bool(value))
        elif kind in ("int",):
            obs.obs_data_set_default_int(settings, key, int(value or 0))
        elif kind in ("float", "number"):
            obs.obs_data_set_default_double(settings, key, float(value or 0.0))
        elif kind in ("list", "str", "combotext"):
            obs.obs_data_set_default_string(settings, key, "%s" % (value if value is not None else ""))
        else:
            obs.obs_data_set_default_string(settings, key, "%s" % (value if value is not None else ""))
    except Exception:
        pass


def _data_set_prop(settings, key, value):
    try:
        if isinstance(value, bool):
            obs.obs_data_set_bool(settings, key, value)
        elif isinstance(value, int):
            obs.obs_data_set_int(settings, key, value)
        else:
            obs.obs_data_set_string(settings, key, "%s" % value)
    except Exception:
        pass


# =============================================================================
# 脚本属性面板
# =============================================================================
PROP_SPECS = (
    ("autostart", "bool", True, "OBS 启动时自动开启 Nexus 服务"),
    ("port", "int", 0, "监听端口（0 = 在下方区间内随机挑选可用端口）"),
    ("port_lo", "int", PORT_RANGE[0], "随机端口区间下限"),
    ("port_hi", "int", PORT_RANGE[1], "随机端口区间上限"),
    ("require_auth", "bool", True, "强制 Token 鉴权（强烈推荐保持勾选）"),
    ("allow_lan", "bool", False, "⚠️ 允许局域网访问（关闭仅回环保护；只应配合 SSH/端口转发+防火墙使用）"),
    ("rate_per_sec", "int", 200, "每连接每秒最大请求行数（限流防爆）"),
    ("max_batch_ops", "int", MAX_BATCH_OPS, "单请求最大 op 数（批量防爆）"),
    ("max_connections", "int", MAX_CONNECTIONS, "最大并发连接数"),
    ("max_list_items", "int", 80, "source.list 默认返回条数（省 LLM 上下文）"),
    ("max_text_bytes", "int", 32768, "text.set 单次写入字节上限"),
    ("max_snapshot_bytes", "int", MAX_SNAPSHOT_BYTES // 4, "canvas.snapshot base64 前字节上限"),
    ("snapshot_mode", "list", "auto", "截图后端：auto / native / file / dir / command / off"),
    ("snapshot_dir", "str", "", "截图兜底目录（留空 = 自动探测 OBS 截图目录 + ~/.obs_nexus/snapshots）"),
    ("snapshot_quality", "int", 82, "JPEG 质量（需 Pillow 才生效）"),
    ("snapshot_timeout_ms", "int", 2500, "等待 OBS 写出截图文件的超时"),
    ("snapshot_command", "str", "", "外部截图命令（advanced；占位符 {output} {source}）"),
    ("echo_text", "bool", True, "text.set 结果里回显写入后的文本（便于校对）"),
    ("verbose_events", "bool", False, "把所有 OBS 前端事件都转发（默认只转发状态相关事件）"),
    ("keep_conn_file", "bool", True, "退出时删除 connection.json（保持勾选更安全）"),
    ("advanced", "bool", False, "⚠️ 允许高级控制（settings_merge / 场景增删 / 热重载 / 日志读取）"),
    ("audit_refs", "bool", True, "引用计数审计（排查泄漏用，可关闭省性能）"),
    ("max_batch_exec_ms", "int", int(MAX_BATCH_EXEC_MS), "单请求每 tick 占用的主线程预算(ms)"),
    ("rotate_token", "bool", False, "勾选后下次启动重新生成 token（配合「写入连接文件」按钮）"),
)


def script_description():
    return (
        "<h3>OBS Nexus %s — Agent 控制运行时（Loopback JSON）</h3>"
        "<p>在本机 <code>127.0.0.1</code> 随机端口上开一个单行 JSON 协议服务，"
        "供外部大模型/自动化脚本控制 OBS（场景、源、文本、音频、录制推流、画布截图）。</p>"
        "<p><b>线程模型</b>：网络在独立守护线程（selectors），所有 libobs 调用由 "
        "<code>obs.timer_add(pump, %d)</code> 投递到 OBS 主线程执行；引用配对释放并带泄漏审计。</p>"
        "<p><b>连接方式</b>：启动后把 host/port/token 原子写入 <code>~/.obs_nexus/connection.json</code>（0600），"
        "客户端 <code>agent_client.py</code> 自动读取。OBS 退出/脚本卸载会自动删除该文件。</p>"
        "<p><b>快速开始</b>：点下面的「写入连接文件」，然后终端执行 "
        "<code>python agent_client.py --call system.overview</code>；"
        "AI 字幕：<code>--op text.set --arg source=字幕 --arg text=hello</code>。</p>"
        "<p style='color:#c60'><b>安全</b>：Token 等同 OBS 完全控制权，服务只监听回环地址；"
        "不要转发到公网，不要在不信任的网络里取消勾选「强制 Token 鉴权」。</p>"
        % (NEXUS_VERSION, TIMER_INTERVAL_MS)
    )


def script_defaults(settings):
    # 只兜「没设过的键」，绝不能覆盖用户已有设置（见 _data_set_default 的说明）
    for key, kind, default, _label in PROP_SPECS:
        _data_set_default(settings, key, kind, default)


def script_properties():
    props = obs.obs_properties_create()
    rt = _SERVER
    for key, kind, default, label in PROP_SPECS:
        cur = (rt.props.get(key) if rt is not None else None)
        cur = default if cur is None else cur
        if kind == "bool":
            p = obs.obs_properties_add_bool(props, key, label)
        elif kind == "int":
            lo, hi = 0, 1000000
            if key == "port":
                lo, hi = 0, 65535
            elif key == "snapshot_quality":
                lo, hi = 20, 100
            elif key in ("max_batch_ops", "max_connections"):
                lo, hi = 1, 4096
            p = obs.obs_properties_add_int(props, key, label, lo, hi, 1)
        elif key == "snapshot_mode":
            p = obs.obs_properties_add_list(props, key, label, 0, 1)  # OBS_COMBO_TYPE_LIST / FORMAT_STRING
            for opt in ("auto", "native", "file", "dir", "command", "off"):
                try:
                    obs.obs_property_list_add_string(p, opt, opt)
                except Exception:
                    pass
            try:
                obs.obs_property_set_long_description(p, "native = 用 OBS 原生截图管线；file = 只回路径不塞 base64；dir = 只从目录取最新图；command = 调外部命令")
            except Exception:
                pass
        else:
            p = obs.obs_properties_add_text(props, key, label, 1 if key.endswith("_dir") else 0)
        try:
            obs.obs_property_set_long_description(p, "%s（当前 %r）" % (label, cur))
        except Exception:
            pass
    try:
        text = obs.obs_properties_add_text(props, "status_line", "状态", 1)
        if rt is not None:
            obs.obs_property_set_description(text, _status_line(rt))
            obs.obs_property_set_long_description(text, json.dumps(rt.metrics(detailed=True), ensure_ascii=False, default=str)[:2000])
    except Exception:
        pass
    obs.obs_properties_add_button(props, "btn_start_stop", "▶ / ⏹ 启动或停止服务", _btn_start_stop)
    obs.obs_properties_add_button(props, "btn_write_conn", "📝 写入连接文件 connection.json", _btn_write_conn)
    obs.obs_properties_add_button(props, "btn_revoke", "🔑 重新生成 Token 并覆盖连接文件", _btn_revoke)
    obs.obs_properties_add_button(props, "btn_caps", "📄 导出 ops 能力清单 capabilities.json", _btn_caps)
    obs.obs_properties_add_button(props, "btn_dir", "📁 打开 ~/.obs_nexus 目录", _btn_open_dir)
    return props


def _status_line(rt):
    if rt is None:
        return "状态：未初始化"
    m = rt.metrics()
    return (
        "状态：%s  监听 127.0.0.1:%s  连接 %s  鉴权 %s  队列 %s  pump %s tick"
        % (
            "运行中" if m["running"] else ("停止中" if m["stopping"] else "已停止"),
            m["port"],
            m["connections"],
            "开" if m["auth_required"] else "关",
            m["queue_depth"],
            m["pump_ticks"],
        )
    )


@safe
def _btn_start_stop(props, prop):
    rt = _SERVER
    if rt is None:
        return None
    if rt.running:
        rt.stop("button")
    else:
        rt.start()
    _refresh_props(rt)
    return None


@safe
def _btn_write_conn(props, prop):
    rt = _SERVER
    if rt is not None:
        out = rt.write_conn_file()
        _LOG.info("写入连接文件结果: %s" % out)
    return None


@safe
def _btn_revoke(props, prop):
    rt = _SERVER
    if rt is None:
        return None
    rt.ensure_token(force=True)
    rt.token_source = "rotated"
    rt.write_conn_file()
    _LOG.info("Token 已重新生成（旧 token 立即失效）")
    return None


@safe
def _btn_caps(props, prop):
    rt = _SERVER
    try:
        payload = {
            "nexus_version": NEXUS_VERSION,
            "proto": NEXUS_PROTO,
            "obs_version": (rt or _server_ref["rt"])._cache.get("obs_version") if rt else obs_version_string(),
            "limits": dict(rt.limits) if rt else {},
            "ops": [spec.describe() for name, spec in sorted(OPS.items())],
        }
        atomic_write_json(os.path.join(nexus_dir(), "capabilities.json"), payload)
        _LOG.info("已导出 %d 个 op 到 %s" % (len(OPS), os.path.join(nexus_dir(), "capabilities.json")))
    except Exception as exc:
        _LOG.error("导出能力清单失败: %r" % (exc,))
    return None


@safe
def _btn_open_dir(props, prop):
    rt = _SERVER
    path = (rt.dir if rt else nexus_dir()) or nexus_dir()
    try:
        if os.name == "nt":
            os.startfile(path)  # noqa: S606
        else:
            opener = "open" if sys.platform == "darwin" else "xdg-open"
            if shutil.which(opener):
                subprocess.Popen([opener, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                _LOG.info("请手动打开：%s" % path)
    except Exception as exc:
        _LOG.warn("打开目录失败: %r（路径 %s）" % (exc, path))
    return None


def _refresh_props(rt):
    cb = _fn("obs_properties_apply_settings")
    if cb is not None and rt is not None:
        try:
            obs_script = _fn("obs_script_get_properties")
            if obs_script is not None:
                pass
        except Exception:
            pass


def script_update(settings):
    rt = _SERVER
    if rt is None:
        return
    before = dict(rt.props)
    rt.configure(settings)
    rt.persist_config()
    changed_restart = [k for k in ("port", "allow_lan", "rate_per_sec", "max_connections") if before.get(k) != rt.props.get(k)]
    if rt.running and changed_restart:
        _LOG.info("检测到 %s 变化，重启网络服务端" % ",".join(changed_restart))
        rt.restart("props:" + ",".join(changed_restart))
    elif rt.running and before.get("require_auth") != rt.props.get("require_auth"):
        if not rt.props.get("require_auth"):
            rt.token = None
            rt.token_source = "disabled"
        else:
            rt.ensure_token(force=True)
        rt.write_conn_file()
    rt.emit_event("nexus.config_changed", {"changed": sorted(k for k in set(before) | set(rt.props) if before.get(k) != rt.props.get(k))[:16]})


def script_load(settings):
    global _LOG_DEBUG, MAX_LINE_BYTES
    _LOG_DEBUG = bool(os.environ.get("OBS_NEXUS_DEBUG"))
    try:
        p = obs.script_get_path() if obs is not None and hasattr(obs, "script_get_path") else ""
        if p:
            _LOG.debug("脚本路径: %s" % p)
    except Exception:
        pass
    if not obs_alive():
        _LOG.error("无法导入 obspython：OBS Nexus 需要在 OBS 的 Python 脚本环境中运行")
        return
    cfg = read_server_config()
    if settings is not None:
        for key, kind, _default, _label in PROP_SPECS:
            v = _settings_get(settings, key, kind)
            if v is None and key in cfg:
                _data_set_prop(settings, key, cfg[key])
    global _SERVER
    if _SERVER is not None:  # 重复加载（例如手动 reload）：先干净停掉旧的
        try:
            _SERVER.stop("reload")
        except Exception:
            pass
        _SERVER = None
    _SERVER = NexusRuntime(settings)
    _server_ref["rt"] = _SERVER
    if _SERVER.props.get("autostart", True):
        _SERVER.start()
    else:
        _LOG.info("autostart=off：等待点「启动服务」按钮")


def script_unload():
    global _SERVER
    rt = _SERVER
    _SERVER = None
    if rt is None:
        return
    try:
        keep = bool((rt.props or {}).get("keep_conn_file", True))
        if not keep:
            rt.write_conn_file()  # 故意留下最新连接信息（不推荐）
        rt.stop("script_unload")
        if keep:
            rt.remove_conn_file("script_unload")
    except Exception:
        _LOG.error("script_unload 异常:\n%s" % traceback.format_exc())
