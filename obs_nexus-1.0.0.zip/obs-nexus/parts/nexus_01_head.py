# -*- coding: utf-8 -*-
# =============================================================================
#  OBS Nexus - Agent Control Runtime for OBS Studio 32.2+
# =============================================================================
#  单文件 OBS Python 脚本（obspython）。在 OBS 内建立一个只监听 127.0.0.1 的
#  Loopback TCP 服务端，外部大模型 / 自动化脚本可以用「一行一条 JSON」的协议
#  读写 OBS 的场景、源、文本、音频、推流/录制状态，并抓取画布截图。
#
#  设计红线（务必阅读，代码严格按照这三条实现）：
#    R1  任何 libobs 调用（场景切换、源属性修改、推流/录制控制、音频表）
#        只允许发生在 OBS 主线程。
#    R2  网络 I/O 全部在独立守护线程（selectors 事件循环）里完成，
#        该线程内绝不出现任何 obs.* 调用（连指针都不跨线程传递）。
#    R3  跨线程桥接只使用 OBS 原生定时器：
#          script_load() -> obs.timer_add(self._pump, 10)
#        主线程每 tick 轮询线程安全的 queue.Queue，并在同一 tick 内
#        通过 socketpair 唤醒工作线程，避免忙等。
#
#  内存安全：所有 *_get_*_by_name / obs_scene_get_source / obs_sceneitem_get
#  等「返回新引用」的调用，都在 obsrefs 上下文管理器里配对 release；
#  脚本还内置引用泄漏计数器（system.health 可见），OBS 关闭前会打印审计结果。
#
#  用法：OBS -> 工具 -> 脚本 -> 添加本文件 -> 在属性里点「写入连接文件」。
#  客户端：python agent_client.py --call system.overview
#
#  安全提示：本服务对已鉴权的客户端拥有「完全控制 OBS」的能力（advanced 模式
#  甚至可热重载脚本）。因此它只绑定回环地址、强制 Token 鉴权、带限流与
#  载荷上限。绝不要把它暴露到局域网或转发到公网。
#
#  License: MIT
#  Author : OBS Nexus (generated)
# =============================================================================

import base64
import errno
import hashlib
import hmac
import itertools
import json
import math
import os
import re
import selectors
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import traceback
from collections import deque
from queue import Empty, Full, Queue

try:  # OBS 32.x 内置 python 有 zoneinfo，用于日志时间戳
    from zoneinfo import ZoneInfo  # noqa: F401
except Exception:  # pragma: no cover
    ZoneInfo = None

# ---------------------------------------------------------------------------
# obspython 绑定：在 OBS 里叫 `obspython`（部分发行版/旧版叫 `obs`）
# 允许在普通 CPython 下导入本文件（配合 tests/fake_obs.py 做离线回归测试）。
# ---------------------------------------------------------------------------
try:
    import obspython as obs
except ImportError:  # pragma: no cover - 非 OBS 环境
    try:
        import obs
    except ImportError:
        obs = None

try:  # OBS 30+ 提供的版本模块（可选）
    import version as _obs_version_mod
except Exception:  # pragma: no cover
    _obs_version_mod = None

try:  # 可选依赖：仅用于把截图转成压缩 JPEG / 计算 mtime_ns
    from PIL import Image as _PILImage
except Exception:  # pragma: no cover
    _PILImage = None


NEXUS_VERSION = "1.0.0"
NEXUS_PROTO = 1
NEXUS_APP = "obs-nexus"

# --------------------------- 协议 / 资源上限 -------------------------------
MAX_LINE_BYTES = 1024 * 1024          # 单行 JSON 上限 1 MiB（含结尾 \n）
MAX_BATCH_OPS = 64                    # 单请求最大 op 数量
MAX_OPS_FOR_SIZE = 4096               # 超过此 op 数直接拒绝（防爆保护）
MAX_CONNECTIONS = 8                   # 最大并发连接（鉴权前同样计数）
MAX_CONN_LINES_PER_SEC = 200.0        # 每连接行速率上限
MAX_PUMP_JOBS = 64                    # 每 tick 最多处理的桥接任务数
MAX_PUMP_TICK_MS = 12.0               # 每 tick 主线程预算（超过则让位给下一 tick）
MAX_BATCH_EXEC_MS = 250.0             # 单个请求在主线程的执行预算（分片续跑）
MAX_RESULT_BYTES = 8 * 1024 * 1024    # 单条响应字节上限
MAX_SNAPSHOT_BYTES = 6 * 1024 * 1024  # 截图 base64 前的原始字节上限
OUTBOX_LIMIT = 64 * 1024 * 1024       # 每连接发送缓冲上限（背压）
CMD_QUEUE_DEPTH = 256                 # 待执行请求队列深度（过载保护）
CMD_QUEUE_HIGH = 192                  # 队列水位告警阈值
MAX_REQUEST_TIMEOUT_MS = 30000        # 客户端可指定的超时上限
DEFAULT_REQUEST_TIMEOUT_MS = 10000
IDLE_TIMEOUT_MS = 300000              # 空闲连接断开（5 分钟）
AUTH_TIMEOUT_MS = 10000               # 鉴权超时（10 秒）
DRAIN_WAIT_MS = 2000                  # 入站缓冲泄空时间（防丢包）
SCRIPT_TIMEOUT_MS = 60000             # OBS 脚本调用超时（默认 60s，必须小于它）
TIMER_INTERVAL_MS = 10                # 主线程泵周期（需求规定 timer_add(...,10)）
POLL_SLEEP_MS = 10                    # 主线程轮询等待的最小间隔（sleep(0) 会让 OBS 卡死）

# 主线程轮询 tick 预算表：活跃期密集，空闲期退避到 ~250ms 以省 CPU
TICK_BUDGET = (24, 24, 16, 12, 8, 4, 2, 1, 1, 1)

# ----------------------------- 安全默认值 ---------------------------------
DEFAULT_PORT = 0                      # 0 = 在 PORT_RANGE 内随机挑可用端口
PORT_RANGE = (45120, 45219)           # 随机端口优先落在这个区间（便于防火墙规则）
TOKEN_BYTES = 32                      # 32 字节随机 -> 64 位 hex
DIR_MODE = 0o700
FILE_MODE = 0o600
CONN_TTL_MS = 2000                    # connection.json 被认为过期的时间

# 只允许回环地址；任何 0.0.0.0 / 局域网 IP 都会被强制改写成 127.0.0.1
LOOPBACK_V4 = "127.0.0.1"
LOOPBACK_V6 = "::1"

# OBS 日志严重级（obspython 常量；离线测试时用手写值）
LOG_DEBUG = getattr(obs, "OBS_DEBUG", 0) if obs else 0
LOG_INFO = getattr(obs, "OBS_INFO", 1) if obs else 1
LOG_WARNING = getattr(obs, "OBS_WARNING", 2) if obs else 2
LOG_ERROR = getattr(obs, "OBS_ERROR", 3) if obs else 3

# obs_frontend_get_sources() 的 flags（枚举常量由 OBS 提供；缺省值对应
# OBS_FRONTEND_SOURCE_FLAG_FILTER_ONLY=1 / UNFILTERED=2 / AUDIO=4 / GLOBAL=8）
FLAG_FILTER_ONLY = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_FILTER_ONLY", 1) if obs else 1
FLAG_UNFILTERED = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_UNFILTERED", 2) if obs else 2
FLAG_AUDIO = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_AUDIO", 4) if obs else 4
FLAG_GLOBAL = getattr(obs, "OBS_FRONTEND_SOURCE_FLAG_GLOBAL", 8) if obs else 8

# obs_source_get_type()
SOURCE_TYPE_INPUT = getattr(obs, "OBS_SOURCE_TYPE_INPUT", 0) if obs else 0
SOURCE_TYPE_FILTER = getattr(obs, "OBS_SOURCE_TYPE_FILTER", 1) if obs else 1
SOURCE_TYPE_TRANSITION = getattr(obs, "OBS_SOURCE_TYPE_TRANSITION", 2) if obs else 2

# obs_source_get_output_flags()
OBS_SOURCE_VIDEO = getattr(obs, "OBS_SOURCE_VIDEO", 1) if obs else 1
OBS_SOURCE_AUDIO = getattr(obs, "OBS_SOURCE_AUDIO", 2) if obs else 2
OBS_SOURCE_COMPOSITE = getattr(obs, "OBS_SOURCE_COMPOSITE", 4) if obs else 4
OBS_SOURCE_ASYNC = getattr(obs, "OBS_SOURCE_ASYNC", 8) if obs else 8

# obs_sceneitem_get_order()
ORDER_VISUAL_TOP = getattr(obs, "OBS_ORDER_VISUAL_TOP", 0) if obs else 0
ORDER_INPUT_BOTTOM = getattr(obs, "OBS_ORDER_INPUT_BOTTOM", 1) if obs else 1

# 音频设备名国际化：用于把「麦克风/桌面音频」这类别名映射到真实源名
AUDIO_NAME_ALIASES = {
    "mic": ("Mic/Aux", "Mic/Auxiliary Audio", "麦克风/辅助音频", "麦克风/Aux"),
    "desktop": ("Desktop Audio", "桌面音频", "桌面音频输出"),
    "mic_aux": ("Mic/Aux", "麦克风/辅助音频"),
    "aux": ("Aux/Audio", "辅助音频"),
}

# 文本源类型 -> 文本内容所在的 obs_data key
TEXT_TYPE_MAP = {
    "text_gdiplus": ("text",),
    "text_gdiplus_v2": ("text", "text_gdiplus"),
    "text_gdiplus_v3": ("text", "text_gdiplus"),
    "text_ft2_source": ("text",),
    "text_ft2_source_v2": ("text_freetype", "text"),
    "browser_source": ("url",),  # 只作为兜底提示，不直接写
}
TEXT_TYPE_IDS = tuple(k for k in TEXT_TYPE_MAP if k != "browser_source")

# OBS 关闭事件（用于优雅退出）；值来自 obs_frontend_event 枚举
FRONTEND_EVENT_OBS_SHUTDOWN = 8
FRONTEND_EVENT_SCENE_CHANGED = 0
FRONTEND_EVENT_SCENE_LIST_CHANGED = 1
FRONTEND_EVENT_TRANSITION_CHANGED = 2
FRONTEND_EVENT_PROFILE_CHANGED = 6
FRONTEND_EVENT_STREAMING_STARTING = 9
FRONTEND_EVENT_STREAMING_STARTED = 10
FRONTEND_EVENT_STREAMING_STOPPING = 11
FRONTEND_EVENT_STREAMING_STOPPED = 12
FRONTEND_EVENT_RECORDING_STARTING = 13
FRONTEND_EVENT_RECORDING_STARTED = 14
FRONTEND_EVENT_RECORDING_STOPPING = 15
FRONTEND_EVENT_RECORDING_STOPPED = 16
FRONTEND_EVENT_RECORDING_PAUSED = 17
FRONTEND_EVENT_RECORDING_UNPAUSED = 18
FRONTEND_EVENT_EXIT = 20

_FRONTEND_EVENT_NAMES = {
    FRONTEND_EVENT_OBS_SHUTDOWN: "obs_shutdown",
    FRONTEND_EVENT_SCENE_CHANGED: "scene.changed",
    FRONTEND_EVENT_SCENE_LIST_CHANGED: "scene_list.changed",
    FRONTEND_EVENT_TRANSITION_CHANGED: "transition.changed",
    FRONTEND_EVENT_PROFILE_CHANGED: "profile.changed",
    FRONTEND_EVENT_STREAMING_STARTING: "stream.starting",
    FRONTEND_EVENT_STREAMING_STARTED: "stream.started",
    FRONTEND_EVENT_STREAMING_STOPPING: "stream.stopping",
    FRONTEND_EVENT_STREAMING_STOPPED: "stream.stopped",
    FRONTEND_EVENT_RECORDING_STARTING: "record.starting",
    FRONTEND_EVENT_RECORDING_STARTED: "record.started",
    FRONTEND_EVENT_RECORDING_STOPPING: "record.stopping",
    FRONTEND_EVENT_RECORDING_STOPPED: "record.stopped",
    FRONTEND_EVENT_RECORDING_PAUSED: "record.paused",
    FRONTEND_EVENT_RECORDING_UNPAUSED: "record.unpaused",
    FRONTEND_EVENT_EXIT: "obs.exit",
}

_NAME_SAFE = re.compile(r"[^A-Za-z0-9_.@+-]+")

# 同名场景项检测最多数到几个（防御：一个场景里不该有几百个同名项，但别为此扫全表）
AMBIGUITY_PROBE_LIMIT = 8


# =============================================================================
# 错误类型
# =============================================================================
class NexusError(Exception):
    """结构化错误：会被序列化成响应里的 error 字段。"""

    def __init__(self, code, message, details=None, hint=None, retryable=False):
        Exception.__init__(self, message)
        self.code = code
        self.message = message
        self.details = details or {}
        self.hint = hint
        self.retryable = retryable

    def to_dict(self):
        out = {"code": self.code, "message": self.message, "retryable": self.retryable}
        if self.details:
            out["details"] = self.details
        if self.hint:
            out["hint"] = self.hint
        return out

    def __repr__(self):
        return "NexusError(%s: %s)" % (self.code, self.message)


def err(code, msg, **kw):
    return NexusError(code, msg, kw.get("details"), kw.get("hint"), kw.get("retryable", False))


# 常用错误码常量（Agent 侧可据此做自动重试 / 纠错）
E_PROTO = "PROTOCOL_ERROR"
E_NO_METHOD = "NO_METHOD"
E_UNKNOWN_OP = "UNKNOWN_OP"
E_BAD_PARAMS = "INVALID_PARAMS"
E_SOURCE_NOT_FOUND = "SOURCE_NOT_FOUND"
E_SOURCE_AMBIGUOUS = "SOURCE_AMBIGUOUS"
E_SCENE_NOT_FOUND = "SCENE_NOT_FOUND"
E_NOT_A_SCENE = "NOT_A_SCENE"
E_WRONG_TYPE = "WRONG_SOURCE_TYPE"
E_OBS_FAILED = "OBS_FAILED"
E_PRECONDITION = "PRECONDITION_FAILED"
E_TIMEOUT = "TIMEOUT"
E_UNSUPPORTED = "UNSUPPORTED"
E_OVERLOAD = "OVERLOADED"
E_UNAUTHORIZED = "UNAUTHORIZED"
E_FORBIDDEN = "FORBIDDEN"
E_SHUTTING_DOWN = "SHUTTING_DOWN"
E_TOO_LARGE = "TOO_LARGE"
E_INTERNAL = "INTERNAL_ERROR"


# =============================================================================
# 日志
# =============================================================================
class _Log(object):
    """双通道日志：OBS 脚本日志 + ~/.obs_nexus/logs/nexus.log。

    任何来自网络的文本都会先脱敏（token / password 等），避免凭证落盘。
    """

    MAX_BYTES = 1 << 20  # 1 MiB 后 rotate（rename 即可，无需额外 fd）

    def __init__(self):
        self.path = None
        self._fd = None
        self._lock = threading.Lock()
        self._errors = 0
        self._redact = (
            (re.compile(r'("(?:token|password|secret|auth)"\s*:\s*")(?:[^"\\]|\\.)*(")', re.I), r"\1***\2"),
            (re.compile(r"\b[A-Fa-f0-9]{64}\b"), "***redacted***"),
        )

    def open(self, path):
        try:
            parent = os.path.dirname(path)
            if parent:
                _ensure_dir(parent)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, FILE_MODE)
            with self._lock:
                self.close_locked()
                self._fd = fd
                self.path = path
            self.write(LOG_INFO, "---- log opened: %s (pid=%s, python=%s) ----" % (path, os.getpid(), sys.version.split()[0]))
        except Exception as exc:  # 日志不可用不能影响主功能
            self._fd = None
            self.emit(LOG_WARNING, "无法打开日志文件 %s: %r" % (path, exc))

    def close(self):
        with self._lock:
            self.close_locked()

    def close_locked(self):
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None

    def sanitize(self, text):
        try:
            for pat, rep in self._redact:
                text = pat.sub(rep, text)
        except Exception:
            pass
        return text

    def emit(self, level, msg):
        self.write(level, msg)

    def info(self, msg):
        self.write(LOG_INFO, msg)

    def warn(self, msg):
        self.write(LOG_WARNING, msg)

    def error(self, msg):
        self._errors += 1
        self.write(LOG_ERROR, msg)

    def debug(self, msg):
        if _LOG_DEBUG:
            self.write(LOG_DEBUG, msg)

    def write(self, level, msg):
        msg = self.sanitize("%s" % (msg,))
        if obs is not None and hasattr(obs, "script_log"):
            try:
                obs.script_log(level, "[nexus] " + msg)
            except Exception:
                pass
        else:  # pragma: no cover - 离线测试
            if level >= LOG_WARNING:
                sys.stderr.write("[nexus] %s\n" % msg)
        with self._lock:
            fd = self._fd
            if fd is None:
                return
            try:
                line = "%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
                os.write(fd, line.encode("utf-8", "replace"))
                if fd is self._fd:  # 锁内自轮转，避免悬挂 fd
                    try:
                        if os.fstat(fd).st_size > self.MAX_BYTES:
                            os.close(fd)
                            try:
                                os.rename(self.path, self.path + ".1")
                            except OSError:
                                pass
                            self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, FILE_MODE)
                    except OSError:
                        pass
            except OSError:
                pass

    @property
    def error_count(self):
        return self._errors


_LOG = _Log()
_LOG_DEBUG = False


# =============================================================================
# 小工具
# =============================================================================
def _bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        s = value.strip().lower()
        if s in ("1", "true", "yes", "y", "on", "开", "是"):
            return True
        if s in ("0", "false", "no", "n", "off", "关", "否"):
            return False
    return default


def _int(value, default=None):
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return int(value)
    try:
        return int(round(float(value)))
    except (TypeError, ValueError):
        raise err(E_BAD_PARAMS, "需要整数，收到 %r" % (value,))


def _float(value, default=None):
    if value is None or value == "":
        return default
    try:
        f = float(value)
    except (TypeError, ValueError):
        raise err(E_BAD_PARAMS, "需要数字，收到 %r" % (value,))
    if math.isnan(f) or math.isinf(f):
        raise err(E_BAD_PARAMS, "需要有限数字，收到 %r" % (value,))
    return f


def _clamp(v, lo, hi):
    return lo if v < lo else (hi if v > hi else v)


def vol_to_db(vol):
    """OBS 音量线性值(0..2) -> dB。0 记为 -100（与 OBS 表底一致）。"""
    try:
        vol = float(vol)
    except (TypeError, ValueError):
        return None
    if vol <= 0.0:
        return -100.0
    return round(20.0 * math.log10(vol), 2)


def db_to_vol(db):
    """dB -> 线性音量。"""
    try:
        db = float(db)
    except (TypeError, ValueError):
        raise err(E_BAD_PARAMS, "dB 需要数字")
    if db <= -100.0:
        return 0.0
    return _clamp(math.pow(10.0, db / 20.0), 0.0, 2.0)


def safe_name(text, limit=64):
    text = _NAME_SAFE.sub("_", ("%s" % (text,))[:limit])
    return text or "unnamed"


def now_ms():
    return int(time.time() * 1000.0)


def obs_alive():
    return obs is not None


def _fn(name):
    """取 obs 函数；不存在返回 None（用于跨版本兼容）。"""
    if obs is None:
        return None
    return getattr(obs, name, None)


def _has(*names):
    if obs is None:
        return False
    for n in names:
        if not hasattr(obs, n):
            return False
    return True


# ------------------------------- 文件系统 ---------------------------------
def _ensure_dir(path):
    try:
        os.makedirs(path, mode=DIR_MODE, exist_ok=True)
    except FileExistsError:
        pass
    except OSError as exc:
        if getattr(exc, "errno", None) != errno.EEXIST:
            raise
    try:
        os.chmod(path, DIR_MODE)
    except OSError:
        pass


def atomic_write_json(path, obj):
    """原子写：临时文件 + flush + fsync + os.replace。"""
    parent = os.path.dirname(path) or "."
    _ensure_dir(parent)
    data = (json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n").encode("utf-8")
    tmp = os.path.join(parent, ".%s.%d.tmp" % (os.path.basename(path), os.getpid()))
    fd = None
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, FILE_MODE)
        os.write(fd, data)
        os.fsync(fd)
        os.close(fd)
        fd = None
        os.chmod(tmp, FILE_MODE)
        os.replace(tmp, path)  # POSIX/Windows 都是原子替换
        tmp = None
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        if tmp and os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def read_json_file(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def pid_alive(pid):
    """跨平台判断 pid 是否存活（Windows 下 os.kill 不可用 -> 返回 None 表示未知）。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes  # 仅在 Windows 上用到

            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
            k32.CloseHandle(h)
            return bool(ok) and code.value == STILL_ACTIVE
        except Exception:
            return None  # 未知
    try:
        os.kill(pid, 0)
    except OSError as exc:
        if exc.errno == errno.EPERM:
            return True
        return False
    except Exception:
        return None
    return True


def nexus_dir():
    """Nexus 状态目录（默认 ~/.obs_nexus）。"""
    override = os.environ.get("OBS_NEXUS_DIR")
    if override:
        return os.path.abspath(os.path.expanduser(override))
    return os.path.join(os.path.expanduser("~"), ".obs_nexus")


def read_server_config():
    """读取 ~/.obs_nexus/config.json（重启后仍然生效的持久化配置）。"""
    cfg = read_json_file(os.path.join(nexus_dir(), "config.json")) or {}
    return cfg if isinstance(cfg, dict) else {}


def save_server_config(cfg):
    try:
        atomic_write_json(os.path.join(nexus_dir(), "config.json"), cfg)
        return True
    except Exception as exc:
        _LOG.warn("保存 config.json 失败: %r" % (exc,))
        return False


def file_sig(path):
    try:
        st = os.stat(path)
        return (int(st.st_size), int(getattr(st, "st_mtime_ns", 0) or 0))
    except OSError:
        return None


def _scan_new_images(dirs, since_t, exclude=None):
    """非阻塞扫描：返回 since_t 之后最新的图片文件路径（找不到返回 None）。

    必须在 OBS 主线程调用，但**绝不睡眠**：调用方（pump）按 tick 分片轮询，
    并且连续两次采样到同一个 size/mtime 才认为文件写完了。
    """
    exclude = exclude or set()
    best_path, best_t = None, -1.0
    for d in dirs:
        try:
            entries = list(os.scandir(d))
        except OSError:
            continue
        for e in entries:
            if not e.is_file():
                continue
            low = e.name.lower()
            if not low.endswith((".png", ".jpg", ".jpeg", ".bmp", ".webp")):
                continue
            if e.path in exclude:
                continue
            try:
                st = e.stat()
            except OSError:
                continue
            m = max(st.st_mtime, getattr(st, "st_ctime", 0))
            if m >= since_t - 1.0 and m > best_t:
                best_path, best_t = e.path, m
    return best_path
