

# =============================================================================
# Ops 注册表
# =============================================================================
EXEC_MAIN = 0    # 由主线程泵执行（唯一允许触碰 libobs 的路径）
EXEC_WORKER = 1  # 由网络线程执行（不碰 libobs，只读缓存 / 纯计算）


class OpSpec(object):
    def __init__(self, name, handler, summary, args, advanced=False, execution=EXEC_MAIN, mutating=False):
        self.name = name
        self.handler = handler
        self.summary = summary
        self.args = args          # {字段: (类型, 必填?, 说明)}
        self.advanced = advanced
        self.execution = execution
        self.mutating = mutating

    def describe(self):
        out = {
            "op": self.name,
            "summary": self.summary,
            "execution": "main_thread" if self.execution == EXEC_MAIN else "network_thread",
            "mutating": self.mutating,
        }
        if self.advanced:
            out["requires_advanced"] = True
        if self.args:
            out["args"] = {k: list(v) for k, v in self.args.items()}
        return out


OPS = {}


def op(name, summary, args=None, advanced=False, execution=EXEC_MAIN, mutating=False):
    def deco(fn):
        OPS[name] = OpSpec(name, fn, summary, args or {}, advanced, execution, mutating)
        return fn

    return deco


class Async(object):
    """op 处理器返回它表示「结果稍后产生」，由主线程泵按 tick 轮询。

    poll(ctx_state) -> None(继续等) / dict(完成) / 抛 NexusError(失败)。
    绝不阻塞主线程：poll 必须是非阻塞的（不能 sleep、不能 wait 子进程）。
    """

    def __init__(self, poll, timeout_ms=3000.0, note=None):
        self.poll = poll
        self.timeout_ms = float(timeout_ms)
        self.note = note or {}


# ------------------------------ 参数工具 ----------------------------------
def arg(a, key, default=None):
    v = a.get(key, default)
    return default if v is None else v


def need(a, key, what=None):
    if not isinstance(a, dict):
        raise err(E_BAD_PARAMS, "%s 的参数必须是对象" % (what or "op"))
    v = a.get(key)
    if v is None or (isinstance(v, str) and not v.strip()):
        raise err(E_BAD_PARAMS, "缺少必填参数 %r" % key, hint="字段说明见 conn.capabilities。")
    return v


def scene_ref(a):
    return a.get("scene") or a.get("scene_name") or a.get("target_scene")


# ============================== system.* ==================================
def _stream_state():
    st = {"active": None, "pending": None, "stopping": None, "reconnecting": None, "congestion": None}
    if _has("obs_frontend_streaming_active"):
        try:
            st["active"] = bool(obs.obs_frontend_streaming_active())
        except Exception:
            pass
    if _has("obs_frontend_streaming_pending"):
        try:
            st["pending"] = bool(obs.obs_frontend_streaming_pending())
        except Exception:
            pass
    if _has("obs_frontend_streaming_stopping"):
        try:
            st["stopping"] = bool(obs.obs_frontend_streaming_stopping())
        except Exception:
            pass
    for key, fn_name in (("reconnecting", "obs_frontend_streaming_reconnecting"), ("congestion", "obs_frontend_streaming_congestion")):
        fn = _fn(fn_name)
        if fn is not None:
            try:
                st[key] = bool(fn())
            except Exception:
                pass
    if st["active"] is None and st["pending"] is None:
        out = _fn("obs_frontend_get_streaming_output")
        if out is not None:
            o = out()
            if o is not None:
                AUDIT.acquire(o, "obs_output_release")
                active_fn = _fn("obs_output_active")
                try:
                    st["active"] = bool(active_fn(o)) if active_fn else True
                except Exception:
                    st["active"] = None
                _release("obs_output_release", o)
    return st


def _record_state():
    st = {"active": None, "paused": None, "path": None}
    if _has("obs_frontend_recording_active"):
        try:
            st["active"] = bool(obs.obs_frontend_recording_active())
        except Exception:
            pass
    if _has("obs_frontend_recording_paused"):
        try:
            st["paused"] = bool(obs.obs_frontend_recording_paused())
        except Exception:
            pass
    fn = _fn("obs_frontend_get_current_record_output_path")
    if fn is not None:
        try:
            p = fn()
            st["path"] = p or None
        except Exception:
            pass
    if st["active"] is None:
        out = _fn("obs_frontend_get_recording_output")
        if out is not None:
            o = out()
            if o is not None:
                AUDIT.acquire(o, "obs_output_release")
                active_fn = _fn("obs_output_active")
                try:
                    st["active"] = bool(active_fn(o)) if active_fn else True
                except Exception:
                    st["active"] = None
                _release("obs_output_release", o)
    return st


def _active_audio_tracks():
    """推流输出的六个混音轨（mixer 0..5）概况：哪几轨真的挂在推流输出上、码率多少。

    所有权（对着 obs-studio 32.2.2 源码逐行核过，别改）：
      * `obs_frontend_get_streaming_output()` —— 前端 API，返回**新引用**，
        必须 `obs_output_release()` 归还；
      * `obs_output_get_audio_encoder(output, idx)` —— libobs 里就是
        `return output->audio_encoders[idx];`（obs-output.c:1137），**借用**，
        绝对不能再 release，否则输出的编码器被提前 free；
      * 「某轨启用」的判定 = 该 mixer index 上挂了编码器（OBS 的设置界面同样这么判断）；
      * OBS 30 起已删除 obs_audio_encoder_get_next/get_track，所以不做多编码器串联遍历。
    没在推流时返回空列表（不是错误：Agent 需要先 stream.control start_stream）。
    """
    get_out = _fn("obs_frontend_get_streaming_output")
    get_enc = _fn("obs_output_get_audio_encoder")
    if get_out is None or get_enc is None:
        return []
    try:
        out = get_out()
    except Exception:
        out = None
    if out is None:
        return []
    tracks = []
    refs = Refs()
    refs.track(out, "obs_output_release")  # 只有 output 是我们持有的
    try:
        for idx in range(6):
            try:
                enc = get_enc(out, idx)  # 借用：不 track、不 release
            except Exception:
                enc = None
            if enc is None:
                continue
            row = {"index": idx, "enabled": True}
            try:
                if _has("obs_encoder_get_name"):
                    row["name"] = obs.obs_encoder_get_name(enc)
                if _has("obs_encoder_get_bitrate"):
                    row["bitrate_kbps"] = int(obs.obs_encoder_get_bitrate(enc))
                if _has("obs_encoder_active"):
                    row["active"] = bool(obs.obs_encoder_active(enc))
            except Exception:
                row["error"] = "read_failed"
            tracks.append(row)
    finally:
        refs.release_all()
    return tracks


def obs_version_string():
    fn = _fn("obs_frontend_get_version")
    if fn is not None:
        try:
            v = fn()
            if v:
                return "%s" % v
        except Exception:
            pass
    fn = _fn("obs_get_version_string")
    if fn is not None:
        try:
            v = fn()
            if v:
                return "%s" % v
        except Exception:
            pass
    if _obs_version_mod is not None:
        for name in ("obs_version", "python_version"):
            fn = getattr(_obs_version_mod, name, None)
            if callable(fn):
                try:
                    return "%s" % fn()
                except Exception:
                    pass
    return "unknown"


@op(
    "system.overview",
    "总览：OBS 版本、活动场景、推流/录制/虚拟摄像头状态、活动音轨、Nexus 运行指标",
    {"include_stats": ["bool", False, "附带 obs_frontend_get_stats() 文本（较长，默认关闭）"]},
)
def op_system_overview(rt, a, ctx):
    stats = None
    if _bool(a.get("include_stats"), False) and _has("obs_frontend_get_stats"):
        try:
            stats = obs.obs_frontend_get_stats()
            if isinstance(stats, str):
                stats = stats[:2048]
        except Exception as exc:
            stats = "unavailable:%r" % (exc,)
    snap = snapshot_capability()
    out = {
        "obs_version": obs_version_string(),
        "obs_api": _api_version_int(),
        "nexus_version": NEXUS_VERSION,
        "proto": NEXUS_PROTO,
        "platform": _platform_name(),
        "python": sys.version.split()[0],
        "active_scene": current_scene_name(),
        "studio_mode": bool(_fn("obs_frontend_preview_program_mode_active")()) if _has("obs_frontend_preview_program_mode_active") else None,
        "preview_scene": None,
        "streaming": _stream_state(),
        "recording": _record_state(),
        "virtualcam": None,
        "replay_buffer": None,
        "audio_tracks": _active_audio_tracks(),
        "snapshot": snap,
        "runtime": rt.metrics(),
        "stats_text": stats,
    }
    if _has("obs_frontend_get_current_preview_scene"):
        src = _fn("obs_frontend_get_current_preview_scene")()
        if src is not None:
            refs = Refs()
            refs.track(src, "obs_source_release")
            try:
                out["preview_scene"] = obs.obs_source_get_name(src)
            except Exception:
                pass
            refs.release_all()
    if _has("obs_frontend_virtualcam_active"):
        try:
            out["virtualcam"] = {"active": bool(obs.obs_frontend_virtualcam_active())}
        except Exception:
            pass
    if _has("obs_frontend_replay_buffer_active"):
        try:
            out["replay_buffer"] = {"active": bool(obs.obs_frontend_replay_buffer_active())}
        except Exception:
            pass
    if _has("obs_frontend_get_current_profile"):
        try:
            out["profile"] = obs.obs_frontend_get_current_profile()
        except Exception:
            pass
    if _has("obs_frontend_get_current_scene_collection"):
        try:
            out["scene_collection"] = obs.obs_frontend_get_current_scene_collection()
        except Exception:
            pass
    return out


def _api_version_int():
    fn = _fn("obs_get_version")
    if fn is None:
        return None
    try:
        raw = int(fn())
    except Exception:
        return None
    return ((raw >> 16) & 0xFF, (raw >> 8) & 0xFF, raw & 0xFF)


def _platform_name():
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    return "linux"


@op(
    "system.health",
    "健康检查：定时器是否存活、队列深度、引用计数审计、限流与错误统计（排障首选）",
    {},
)
def op_system_health(rt, a, ctx):
    h = rt.health()
    h["refs"] = AUDIT.snapshot()
    h["ok"] = (not h["refs"]["outstanding"]) and h["timer_alive"] and h["thread_alive"]
    if h["refs"]["outstanding"]:
        h["warnings"] = h.get("warnings", [])
        h["warnings"].append("检测到未释放的 OBS 引用，详见 refs.kinds（已自动回收，无需重启）")
    return h


@op("system.ping", "往返测试：经过主线程泵，返回各阶段耗时（用于判断卡死/延迟）", {"echo": ["any", False, "原样回带"]})
def op_system_ping(rt, a, ctx):
    return {"pong": True, "echo": a.get("echo"), "main_thread": threading.get_ident() == rt.main_thread_id, "t_ms": now_ms()}


@op("system.usage", "本连接的限流/用量与全局计数", {}, execution=EXEC_WORKER)
def op_system_usage(rt, a, ctx):
    conn = ctx.get("conn")
    out = rt.metrics()
    out["connection"] = conn.usage() if conn is not None else None
    return out


@op("system.log_tail", "读取 Nexus 日志尾部（排障用）", {"lines": ["int", False, "默认 80，最多 400"]}, advanced=True)
def op_log_tail(rt, a, ctx):
    n = _clamp(_int(a.get("lines"), 80) or 80, 1, 400)
    path = _LOG.path or os.path.join(nexus_dir(), "nexus.log")
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            data = fh.read(256 * 1024)
    except OSError as exc:
        raise err(E_OBS_FAILED, "无法读取日志: %r" % (exc,), details={"path": path})
    lines = _LOG.sanitize("\n".join(data.splitlines()[-n:]))
    return {"path": path, "lines": n, "text": lines}


# ============================== scene.* ===================================
@op(
    "scene.list",
    "列出所有场景（含当前活动场景、预览场景、场景数量、每个场景的源数量）",
    {"counts": ["bool", False, "是否附带每个场景的源数量（默认 true）"], "limit": ["int", False, "最多返回条数"]},
)
def op_scene_list(rt, a, ctx):
    refs = ctx["refs"]
    scenes = list_scenes(refs)
    cur = current_scene_name()
    preview = None
    if _has("obs_frontend_get_current_preview_scene"):
        src = _fn("obs_frontend_get_current_preview_scene")()
        if src is not None:
            refs.track(src, "obs_source_release")
            try:
                preview = obs.obs_source_get_name(src)
            except Exception:
                preview = None
    want_counts = _bool(a.get("counts"), True)
    limit = _clamp(_int(a.get("limit"), 200) or 200, 1, 1000)
    out = []
    total = len(scenes)
    for i, (name, scene) in enumerate(scenes[:limit]):
        row = {"index": i, "name": name, "current": (name == cur) if cur else False}
        if preview is not None:
            row["preview"] = name == preview
        if want_counts:
            try:
                row["source_count"] = count_items(scene)
            except Exception:
                row["source_count"] = None
        out.append(row)
    trans = None
    if _has("obs_frontend_get_transition_duration"):
        try:
            trans = int(obs.obs_frontend_get_transition_duration())
        except Exception:
            trans = None
    return {
        "scenes": out,
        "total": total,
        "returned": len(out),
        "truncated": total > len(out),
        "current_scene": cur,
        "preview_scene": preview,
        "transition_duration_ms": trans,
    }


def count_items(scene):
    """只数数量，不构造行数据（scene.list 用，避免 O(n) 读取属性）。"""
    fn = _fn("obs_scene_enum_items")
    if fn is None:
        return None
    n = [0]

    def cb(s, item, p):
        n[0] += 1
        return True

    try:
        fn(scene, cb, None)
    except Exception:
        return None
    return n[0]


@op(
    "scene.switch",
    "切换当前场景；mode=transition 时临时借用 OBS 的转场时长实现「平滑切换」",
    {
        "scene": ["str", True, "目标场景名（必须与 OBS 中一致）"],
        "mode": ['"cut"|"transition"', False, "cut=立即切换(默认)；transition=走转场动画"],
        "transition_duration_ms": ["int", False, "mode=transition 时临时使用的转场时长(50-20000)"],
    },
    mutating=True,
)
def op_scene_switch(rt, a, ctx):
    name = need(a, "scene")
    mode = str(arg(a, "mode", "cut")).strip().lower()
    if mode not in ("cut", "transition", "fade"):
        raise err(E_BAD_PARAMS, "mode 只能是 cut / transition / fade", details={"got": mode})
    refs = ctx["refs"]
    _, scene = resolve_scene(refs, name)
    src = _fn("obs_scene_get_source")(scene)
    if src is None:
        raise err(E_OBS_FAILED, "无法获取场景源对象")
    setter = _fn("obs_frontend_set_current_scene")
    if setter is None:
        raise err(E_UNSUPPORTED, "无 obs_frontend_set_current_scene")
    before = current_scene_name()
    used_ms = None
    if mode != "cut":
        used_ms = _clamp(_int(a.get("transition_duration_ms"), 600) or 600, 50, 20000)
        getd, setd = _fn("obs_frontend_get_transition_duration"), _fn("obs_frontend_set_transition_duration")
        if setd is not None and getd is not None:
            try:
                old_ms = int(getd())
            except Exception:
                old_ms = None
            setd(used_ms)
            if old_ms is not None:  # 转场启动后再恢复原时长，避免污染用户设置
                rt.defer(used_ms + 200, _restore_duration, old_ms)
        setter(src)
    else:
        setter(src)
    after = current_scene_name()
    if after != name:
        raise err(
            E_OBS_FAILED,
            "场景切换未生效（OBS 可能正在关闭或处于安全模式）",
            details={"requested": name, "current": after},
        )
    return {"previous_scene": before, "current_scene": after, "mode": mode, "transition_duration_ms": used_ms, "verified": True}


def _restore_duration(ms):
    fn = _fn("obs_frontend_set_transition_duration")
    if fn is not None:
        try:
            fn(int(ms))
        except Exception:
            pass


@op(
    "scene.create",
    "新建场景（advanced）。用 obs_source_create('scene') + obs_frontend_add_source，与 obs-websocket CreateScene 同路径",
    {"scene": ["str", True, "新场景名"], "set_current": ["bool", False, "是否切到该场景"]},
    advanced=True,
    mutating=True,
)
def op_scene_create(rt, a, ctx):
    name = ("%s" % need(a, "scene")).strip()[:128]
    if not name:
        raise err(E_BAD_PARAMS, "场景名不能为空")
    refs = ctx["refs"]
    try:
        resolve_scene(refs, name)
        exists = True
    except NexusError as exc:
        if exc.code != E_SCENE_NOT_FOUND:
            raise
        exists = False
    if exists and not _bool(a.get("reuse"), False):
        raise err(E_PRECONDITION, "场景已存在: %r" % name, details={"hint": "传 reuse:true 直接返回已有场景"})
    if _has("obs_source_create") and _has("obs_frontend_add_source"):
        src = obs.obs_source_create("scene", name, None, None)
        if src is None:
            raise err(E_OBS_FAILED, "obs_source_create('scene') 返回空")
        refs.track(src, "obs_source_release")
        obs.obs_frontend_add_source(src)
        created = "frontend"
    else:
        # 没有 obs_frontend_add_source 时，只能造出一个「不在前端场景列表里」的场景：
        # op 一结束引用归零，它立刻被 free —— 与其假装成功，不如明确说不支持。
        raise err(
            E_UNSUPPORTED,
            "当前 OBS 环境缺 obs_source_create/obs_frontend_add_source，无法安全地新建场景",
            details={"has_source_create": _has("obs_source_create"), "has_add_source": _has("obs_frontend_add_source")},
            hint="用完整版 OBS（含前端 API）跑脚本；只读类 op 不受影响。",
        )
    if _bool(a.get("set_current"), True):
        _fn("obs_frontend_set_current_scene")(src)
    return {"scene": name, "created": created != "frontend" or True, "via": created, "current_scene": current_scene_name()}


@op(
    "scene.remove",
    "删除场景（advanced，危险）。必须传 confirm:'DELETE' 才会执行",
    {"scene": ["str", True, "要删除的场景名"], "confirm": ["str", True, "必须为字面量 DELETE"]},
    advanced=True,
    mutating=True,
)
def op_scene_remove(rt, a, ctx):
    if ("%s" % arg(a, "confirm", "")).strip() != "DELETE":
        raise err(E_PRECONDITION, "删除场景需要显式确认：confirm 必须为 \"DELETE\"", hint="这是防止大模型误删用户工程的保护。")
    name = ("%s" % need(a, "scene")).strip()
    if name == current_scene_name():
        raise err(E_PRECONDITION, "不能删除当前活动场景，请先 scene.switch 切走")
    refs = ctx["refs"]
    scene_name, scene = resolve_scene(refs, name)
    src = obs.obs_scene_get_source(scene)
    if src is None:
        raise err(E_OBS_FAILED, "无法取得场景源")
    fn = _fn("obs_source_remove")
    if fn is None:
        raise err(E_UNSUPPORTED, "无 obs_source_remove")
    fn(src)
    rm = _fn("obs_frontend_remove_source")
    if rm is not None:
        try:
            rm(scene_name)
        except Exception:
            pass
    return {"removed": scene_name, "current_scene": current_scene_name()}


# ============================== source.* ==================================
def walk_scene_items(scene, recursive=True, limit=4000, max_depth=4):
    """把场景项快照成纯 python 结构（组内递归）。

    全部读取都在 obs_scene_enum_items 回调内完成，item 是**借用引用**，
    绝不 release；因此不存在跨回调悬挂指针，也不需要引用管理。
    layer 是同一层内的序号：0 = 最顶层（与 OBS UI 的上下顺序一致）。
    """
    enum = _fn("obs_scene_enum_items")
    if enum is None:
        raise err(E_UNSUPPORTED, "无 obs_scene_enum_items")
    budget = {"n": 0}

    def visit(sc, depth, parent):
        rows = []

        def cb(s, item, _p):
            if budget["n"] >= limit:
                return False
            budget["n"] += 1
            try:
                src = obs.obs_sceneitem_get_source(item)  # 借用引用
                name = (obs.obs_source_get_name(src) or "") if src is not None else ""
                rtype = (obs.obs_source_get_id(src) or "") if src is not None else ""
            except Exception as exc:
                rows.append({"name": "", "error": "read_failed:%s" % (exc,)})
                return True
            row = {"layer": len(rows), "depth": depth, "name": name, "type": rtype, "id": "%s%d" % (rtype[:8] or "src", _item_id(item) or 0)}
            try:
                row["item_id"] = _item_id(item)
            except Exception:
                row["item_id"] = None
            try:
                row["visible"] = bool(obs.obs_sceneitem_visible(item))
            except Exception:
                row["visible"] = None
            try:
                sel = _fn("obs_sceneitem_selected")
                row["selected"] = bool(sel(item)) if sel is not None else None
            except Exception:
                row["selected"] = None
            row["locked"] = item_locked(item)
            grouped = _is_group(item)
            if grouped:
                row["is_group"] = True
                if parent:
                    row["parent"] = parent
                if recursive and depth < max_depth:
                    gs = _fn("obs_sceneitem_group_get_scene")(item) if _has("obs_sceneitem_group_get_scene") else None
                    if gs is not None:
                        kids = visit(gs, depth + 1, name)
                        row["children"] = kids
                        row["child_count"] = len(kids)
            rows.append(row)
            return True

        try:
            enum(sc, cb, None)
        except Exception as exc:
            rows.append({"error": "enum_failed:%s" % (exc,)})
        return rows

    return visit(scene, 0, None)


def _is_group(item):
    try:
        fn = _fn("obs_sceneitem_is_group")
        if fn is not None:
            return bool(fn(item))
        c = _fn("obs_sceneitem_group_count_items")
        return bool(c and c(item) > 0)
    except Exception:
        return False


def flatten_rows(rows, out=None):
    out = [] if out is None else out
    for r in rows:
        out.append(r)
        kids = r.get("children")
        if isinstance(kids, list):
            flatten_rows(kids, out)
    return out


DEFAULT_ITEM_FIELDS = ("name", "type", "visible", "locked", "layer", "item_id")
ITEM_FIELD_DOC = "可选: name,type,visible,locked,layer,item_id,selected,transform,size,audio"


@op(
    "source.list",
    "列出场景内所有源（名称/类型/可见性/锁定/层级），支持分页与字段裁剪，避免撑爆上下文",
    {
        "scene": ["str", False, "场景名；留空 = 当前场景"],
        "limit": ["int", False, "默认 80，最大 400"],
        "offset": ["int", False, "分页偏移（顶层行序号；flatten:true 时是扁平序号）"],
        "recursive": ["bool", False, "是否展开组内子项（默认 true）"],
        "flatten": ["bool", False, "true = 把组内子项拉平成独立行（父行不再带 children）"],
        "fields": ["[str]", False, ITEM_FIELD_DOC],
        "detailed": ["bool", False, "true 时附带 transform/尺寸/音量等完整信息"],
    },
)
def op_source_list(rt, a, ctx):
    refs = ctx["refs"]
    sname, scene = resolve_scene(refs, scene_ref(a))
    limit = _clamp(_int(a.get("limit"), 80) or 80, 1, 400)
    offset = max(0, _int(a.get("offset"), 0) or 0)
    recursive = _bool(a.get("recursive"), True)
    detailed = _bool(a.get("detailed"), False)
    fields = a.get("fields")
    if fields is not None:
        if not isinstance(fields, (list, tuple)):
            raise err(E_BAD_PARAMS, "fields 必须是字符串数组")
        fields = tuple(str(f) for f in fields)
    else:
        fields = DEFAULT_ITEM_FIELDS + ("transform", "size", "audio") if detailed else DEFAULT_ITEM_FIELDS
    rows = walk_scene_items(scene, recursive=recursive, limit=min(4000, offset + limit + 8))
    if _bool(a.get("flatten"), False):
        # 拉平模式：子项成为独立行，父行不再带 children —— 同一份数据不会出现在两个地方
        rows = flatten_rows(rows)
        for r in rows:
            r.pop("children", None)
    total = len(rows)
    page = rows[offset : offset + limit]
    if page and ("transform" in fields or "size" in fields or "audio" in fields):
        _enrich_rows(scene, flatten_rows(page), fields)  # 复用同一批 dict，组内子项也会补齐
    keep = set(fields) | {"depth", "children", "child_count", "is_group", "parent", "error", "id"}

    def _trim(lst):
        for r in lst:
            for k in list(r.keys()):
                if k not in keep:
                    r.pop(k, None)
            kids = r.get("children")
            if isinstance(kids, list):
                _trim(kids)

    _trim(rows)
    out = {
        "scene": sname,
        "is_current": sname == current_scene_name(),
        "sources": page,
        "total": total,
        "returned": len(page),
        "offset": offset,
        "limit": limit,
        "truncated": total > offset + len(page),
    }
    if out["truncated"]:
        out["hint"] = "结果被截断：offset 翻页，或用 fields 裁剪字段省 token"
    return out


def _enrich_rows(scene, rows, fields):
    """只对本页（<=400 行）做额外读取，避免对全部源做 O(n) 昂贵查询。"""
    for row in rows:
        if row.get("error"):
            continue
        name = row.get("name")
        if not name:
            continue
        refs = Refs()
        try:
            item, src = _find_item_and_source(refs, scene, name)
            if src is None:
                continue
            if "transform" in fields and item is not None:
                info = _read_info(item)
                if info is not None:
                    row["transform"] = item_info_dict(item, info)
            if "size" in fields:
                w, h = source_size(src)
                row["width"], row["height"] = w, h
            if "audio" in fields:
                m = source_meta(src)
                if m.get("audio"):
                    row["audio"] = {k: m.get(k) for k in ("muted", "volume", "volume_db")}
        except Exception as exc:
            row["detail_error"] = "%r" % (exc,)
        finally:
            refs.release_all()


def _find_item_and_source(refs, scene, name):
    item = _find_scene_item(scene, name, refs)  # 借用引用已在内部 addref
    if item is None:
        return None, None
    try:
        src = obs.obs_sceneitem_get_source(item)
    except Exception:
        src = None
    return item, src


@op(
    "source.get",
    "读取单个源详情（设置项会被过滤、截断、脱敏）",
    {
        "source": ["str", True, "源名"],
        "scene": ["str", False, "场景名；留空 = 当前场景（找不到时回退全局查找）"],
        "settings": ["bool", False, "是否附带 obs_data 设置（默认 true）"],
        "keys": ["[str]", False, "只读取指定设置字段，省 token"],
        "filter": ["str", False, "附带读取该源上某个过滤器的设置"],
    },
)
def op_source_get(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    row = source_meta(src, include_settings=_bool(a.get("settings"), True), max_settings=_clamp(_int(a.get("max_settings"), 48) or 48, 1, 200))
    row["resolved_from"] = meta
    row["scene"] = sname
    keys = a.get("keys")
    if keys and isinstance(row.get("settings"), dict):
        wanted = set(str(k) for k in keys)
        row["settings"] = {k: v for k, v in row["settings"].items() if k in wanted or k == "_skipped"}
    fname = a.get("filter")
    if fname:
        fn = _fn("obs_source_get_filter_by_name")
        if fn is None:
            raise err(E_UNSUPPORTED, "无 obs_source_get_filter_by_name")
        f = fn(src, "%s" % fname)
        if f is None:
            raise err(E_OBS_FAILED, "找不到过滤器 %r" % fname, details={"source": name})
        refs.track(f, "obs_source_release")
        fm = source_meta(f, include_settings=True)
        fm["name"] = fname
        row["filter"] = fm
    return row


@op(
    "source.visibility",
    "设置/切换场景项可见性（AI 弹窗、贴图淡入淡出的基础动作）",
    {
        "source": ["str", True, "源名（组内源也支持）"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"],
        "scene": ["str", False, "场景名；留空 = 当前场景"],
        "visible": ["bool", False, "true=显示, false=隐藏"],
        "toggle": ["bool", False, "true=取反当前可见性（与 visible 二选一）"],
        "silent": ["bool", False, "不广播 source.visibility 事件（自己就是事件消费者时用，避免自激）"],
    },
    mutating=True,
)
def op_source_visibility(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    before = bool(obs.obs_sceneitem_visible(item))
    if _bool(a.get("toggle"), False):
        if a.get("visible") is not None:
            raise err(E_BAD_PARAMS, "toggle 与 visible 不能同时给")
        target = not before
    elif a.get("visible") is None:
        raise err(E_BAD_PARAMS, "需要 visible:true/false 或 toggle:true", details={"current": before})
    else:
        target = _bool(a.get("visible"), True)
    obs.obs_sceneitem_set_visible(item, bool(target))
    after = bool(obs.obs_sceneitem_visible(item))
    if after != bool(target):
        raise err(E_OBS_FAILED, "可见性设置未生效", details={"before": before, "wanted": target, "after": after})
    if after != before and not _bool(a.get("silent"), False):
        # 广播出去：别的 Agent / 前端就能同步「贴片被弹出来了」这件事，不用轮询 source.list
        rt.emit_event("source.visibility", {"scene": sname, "source": name, "visible": after, "by": "op"})
    return {"scene": sname, "source": name, "before": before, "visible": after, "changed": after != before}


@op(
    "source.lock",
    "给场景项打/解 Nexus 锁定标记（写入源私有设置 nexus_locked），供多 Agent 互斥",
    {"source": ["str", True, "源名"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"], "scene": ["str", False, "场景名"], "locked": ["bool", False, "true/false，缺省 true"]},
    mutating=True,
)
def op_source_lock(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    getp = _fn("obs_source_get_private_settings")
    if getp is None:
        raise err(E_UNSUPPORTED, "无 obs_source_get_private_settings（需要 OBS 26+）")
    data = getp(src)
    if data is None:
        raise err(E_OBS_FAILED, "无法取得源私有设置")
    refs.track(data, "obs_data_release")
    want = _bool(a.get("locked"), True)
    obs.obs_data_set_int(data, "nexus_locked", 1 if want else 0)
    return {"scene": sname, "source": name, "locked": bool(want), "note": "OBS 无原生场景项锁定 API，这是 Nexus 约定标记"}


@op(
    "source.transform",
    "修改场景项变换（位置/缩放/旋转/边界/裁剪）；读-改-写，未给出的字段保持原值",
    {
        "source": ["str", True, "源名"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"],
        "scene": ["str", False, "场景名"],
        "pos": ["[x,y]", False, "位置（像素）"],
        "scale": ["[sx,sy]", False, "缩放"],
        "scale_uniform": ["float", False, "等比缩放（优先于 scale）"],
        "rot": ["float", False, "旋转角度（度）"],
        "alignment": ["[x,y]", False, "对齐点（0/1 组合）"],
        "bounds_type": ["int", False, "OBS_BOUNDS_* 枚举"],
        "bounds_size": ["[w,h]", False, "边界尺寸"],
        "crop": ["{left,right,top,bottom}", False, "裁剪像素"],
    },
    mutating=True,
)
def op_source_transform(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    info = _read_info(item)
    if info is None:
        raise err(E_UNSUPPORTED, "无 obs_sceneitem_info_create/get_info（无法修改变换）")
    before = item_info_dict(item, info)
    touched = []

    def set_vec(attr, pair):
        v = getattr(info, attr, None)
        if v is None:
            raise err(E_UNSUPPORTED, "该 OBS 版本的 obs_sceneitem_info 没有字段 %s" % attr)
        try:
            v.x = float(pair[0])
            v.y = float(pair[1])
        except (TypeError, ValueError, IndexError):
            raise err(E_BAD_PARAMS, "%s 需要 [x, y] 两个数字" % attr, details={"got": pair})
        touched.append(attr)

    def set_num(attr, value):
        try:
            setattr(info, attr, value)
        except Exception as exc:
            raise err(E_UNSUPPORTED, "字段 %s 不可写: %r" % (attr, exc))
        touched.append(attr)

    if a.get("pos") is not None:
        set_vec("pos", a["pos"])
    if a.get("scale_uniform") is not None:
        f = _float(a.get("scale_uniform"), 1.0)
        set_vec("scale", [f, f])
    elif a.get("scale") is not None:
        set_vec("scale", a["scale"])
    if a.get("alignment") is not None:
        al = a["alignment"]
        if not isinstance(al, (list, tuple)) or len(al) < 2:
            raise err(E_BAD_PARAMS, "alignment 需要 [x, y]")
        set_vec("alignment", [int(_float(al[0], 0.0)), int(_float(al[1], 0.0))])
    if a.get("rot") is not None:
        set_num("rot", _float(a.get("rot"), 0.0))
    if a.get("bounds_size") is not None:
        bs = a["bounds_size"]
        if not isinstance(bs, (list, tuple)) or len(bs) < 2:
            raise err(E_BAD_PARAMS, "bounds_size 需要 [w, h]")
        set_vec("bounds", [_float(bs[0], 0.0), _float(bs[1], 0.0)])
    if a.get("bounds_type") is not None:
        set_num("bounds_type", _int(a.get("bounds_type"), 0))
    crop = a.get("crop")
    if isinstance(crop, dict):
        for key, attr in (("left", "crop_left"), ("right", "crop_right"), ("top", "crop_top"), ("bottom", "crop_bottom")):
            if crop.get(key) is not None:
                set_num(attr, max(0, _int(crop.get(key), 0) or 0))
    elif crop is not None:
        raise err(E_BAD_PARAMS, "crop 需要对象 {left,right,top,bottom}")
    if not touched:
        raise err(E_BAD_PARAMS, "没有给任何要修改的字段", hint="可用: pos/scale/scale_uniform/rot/alignment/bounds_type/bounds_size/crop")
    set_item_info(item, info)
    after = item_info_dict(item, _read_info(item))
    return {"scene": sname, "source": name, "set_fields": touched, "before": before, "after": after}


def _read_info(item):
    info = create_item_info()
    if info is None:
        return None
    fn = _fn("obs_sceneitem_get_info")
    if fn is None:
        return None
    try:
        fn(item, info)
    except Exception:
        return None
    return info


@op(
    "source.move",
    "调整层级顺序（置顶/置底/上移下移 N 步/绝对层号）",
    {
        "source": ["str", True, "源名"],
        "index": ["int", False, "有同名场景项时指定第几个（0 = z 序最上）；不给且同名 >1 → SOURCE_AMBIGUOUS"],
        "scene": ["str", False, "场景名"],
        "to": ['"top"|"bottom"', False, "置顶 / 置底"],
        "layer": ["int", False, "绝对层级（0=最顶层）"],
        "direction": ['"up"|"down"', False, "配合 steps 使用"],
        "steps": ["int", False, "上移/下移步数（1-200）"],
    },
    mutating=True,
)
def op_source_move(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    item, src = resolve_scene_item(refs, scene, name, a.get("index"))
    fn = _fn("obs_sceneitem_set_order")
    if fn is None:
        raise err(E_UNSUPPORTED, "无 obs_sceneitem_set_order")
    top, bottom, up, down = 0, 1, 2, 3
    applied = None
    if a.get("layer") is not None:
        total = count_items(scene) or 0
        want = _clamp(_int(a.get("layer"), 0) or 0, 0, max(0, total - 1))
        fn(item, top)
        for i in range(want):
            fn(item, down)
        applied = "layer=%d" % want
    else:
        to = str(arg(a, "to", "")).strip().lower()
        if to in ("top", "front"):
            fn(item, top)
            applied = "top"
        elif to in ("bottom", "back"):
            fn(item, bottom)
            applied = "bottom"
        else:
            d = str(arg(a, "direction", "")).strip().lower()
            steps = _clamp(_int(a.get("steps"), 1) or 1, 1, 200)
            if d not in ("up", "down"):
                raise err(E_BAD_PARAMS, "需要 to:top|bottom 或 direction:up|down 或 layer:int")
            for _ in range(steps):
                fn(item, up if d == "up" else down)
            applied = "%s*%d" % (d, steps)
    rows = [r for r in flatten_rows(walk_scene_items(scene, recursive=False, limit=500))]
    new_layer = None
    for r in rows:
        if r.get("name") == name:
            new_layer = r.get("layer")
            break
    return {"scene": sname, "source": name, "applied": applied, "layer": new_layer, "order": [r.get("name") for r in rows]}


# ============================ source.settings.* ===========================
@op(
    "source.settings_get",
    "读取源的原始设置（截断 + 脱敏）",
    {"source": ["str", True, "源名"], "scene": ["str", False, "场景名"], "keys": ["[str]", False, "字段白名单"]},
    advanced=True,
)
def op_settings_get(rt, a, ctx):
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    keys = a.get("keys")
    if keys is not None and not isinstance(keys, (list, tuple)):
        raise err(E_BAD_PARAMS, "keys 必须是字符串数组")
    st = source_settings(src, max_items=_clamp(_int(a.get("max_items"), 120) or 120, 1, 400), keys=list(keys) if keys else None)
    return {
        "scene": sname,
        "source": name,
        "type": meta.get("type") or "",  # 与 source.list 一致：类型 id 字符串（如 text_gdiplus_v2）
        "kind": meta.get("kind"),  # input / filter / transition（obs_source_get_type）
        "resolved_from": meta,
        "settings": st,
    }


@op(
    "source.settings_merge",
    "浅合并设置到源（obs_source_update）。危险动作，必须 confirm:true；长文本请用 text.set",
    {"source": ["str", True, "源名"], "settings": ["obj", True, "要合并的键值"], "confirm": ["bool", False, "必须 true"]},
    advanced=True,
    mutating=True,
)
def op_settings_merge(rt, a, ctx):
    if not _bool(a.get("confirm"), False):
        raise err(E_PRECONDITION, "source.settings_merge 需要 confirm:true（会直接改 OBS 源设置）")
    patch = a.get("settings")
    if not isinstance(patch, dict) or not patch:
        raise err(E_BAD_PARAMS, "settings 必须是非空对象")
    if len(patch) > 32:
        raise err(E_TOO_LARGE, "一次最多合并 32 个键", details={"got": len(patch)})
    long_keys = [k for k, v in patch.items() if isinstance(v, str) and len(v) > 2048]
    if long_keys:
        raise err(E_TOO_LARGE, "这些字段太长：%s；请改用 text.set" % ", ".join(long_keys[:4]))
    refs = ctx["refs"]
    name = need(a, "source")
    sname, scene = resolve_scene(refs, scene_ref(a))
    src, meta = resolve_source(refs, name, scene=scene, scope="auto")
    data = _fn("obs_data_create")()
    if data is None:
        raise err(E_UNSUPPORTED, "无 obs_data_create")
    refs.track(data, "obs_data_release")
    applied = []
    skipped = []
    for k, v in patch.items():
        k = "%s" % k
        # obs_data 的键其实很保守（字母数字下划线点冒号）；出现路径分隔符/空格/控制符
        # 基本都是大模型在乱编，直接跳过而不是写进工程，避免留下删不掉的垃圾设置。
        if not re.match(r"^[A-Za-z0-9_\-.:#\[\]]{1,64}$", k):
            skipped.append({"key": k, "why": "invalid_key"})
            continue
        try:
            _data_set(data, k, v, skipped)
            applied.append(k)
        except Exception as exc:
            skipped.append({"key": k, "why": repr(exc)})
    if not applied:
        raise err(E_BAD_PARAMS, "没有可应用的字段", details={"skipped": skipped[:8]})
    obs.obs_source_update(src, data)
    return {"scene": sname, "source": name, "applied": applied, "skipped": skipped[:8], "resolved_from": meta}


def _data_set(data, key, value, skipped=None):
    if isinstance(value, bool):
        obs.obs_data_set_bool(data, key, value)
    elif isinstance(value, int):
        obs.obs_data_set_int(data, key, value)
    elif isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            raise err(E_BAD_PARAMS, "%s: 数字非法" % key)
        obs.obs_data_set_double(data, key, value)
    elif isinstance(value, str):
        obs.obs_data_set_string(data, key, value)
    elif isinstance(value, (list, tuple)):
        create = _fn("obs_data_array_create")
        arr = create() if create else None
        if arr is None:
            raise err(E_UNSUPPORTED, "无 obs_data_array_create")
        rel_arr = _fn("obs_data_array_release")
        add = _fn("obs_data_array_push_back")
        for item in value[:256]:
            obj = _fn("obs_data_create")()
            try:
                _data_set(obj, "value", item if not isinstance(item, (list, tuple, dict)) else json.dumps(item, ensure_ascii=False))
                if obj is not None:
                    AUDIT.acquire(obj, "obs_data_release")
                add(arr, obj)
            finally:
                if obj is not None:
                    _release("obs_data_release", obj)
        try:
            AUDIT.acquire(arr, "obs_data_array_release")
            obs.obs_data_set_array(data, key, arr)
        finally:
            if rel_arr is not None:
                _release("obs_data_array_release", arr)
    elif value is None:
        obs.obs_data_set_string(data, key, "")
    else:
        obs.obs_data_set_string(data, key, json.dumps(value, ensure_ascii=False)[:4096])
