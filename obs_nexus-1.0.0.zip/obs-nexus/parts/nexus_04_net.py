

# =============================================================================
# 网络层：selectors 单线程事件循环（本文件内**严禁**出现任何 obs.* 调用）
# =============================================================================
class LineFramer(object):
    """按行切分 UTF-8 JSON 帧；超长立即报错并丢弃缓冲（防爆 + 防内存增长）。"""

    def __init__(self, max_bytes=MAX_LINE_BYTES):
        self.buf = bytearray()
        self.max_bytes = max_bytes
        self.overflow = False
        self.dropped_bytes = 0
        self.dropped_lines = 0

    def feed(self, data):
        """返回 [line_bytes, ...]；超限溢出后本连接会被强制断开。"""
        if self.overflow:
            return []
        if len(self.buf) + len(data) > self.max_bytes:
            take = self.max_bytes - len(self.buf)
            if take > 0:
                self.buf += data[:take]
            self.overflow = True
            self._drop_rest(data, take)
            return []
        self.buf += data
        out = []
        while True:
            i = self.buf.find(b"\n")
            if i < 0:
                break
            line = bytes(self.buf[:i])
            del self.buf[: i + 1]
            if line.endswith(b"\r"):
                line = line[:-1]
            if line.strip():
                out.append(line)
            else:
                self.dropped_lines += 1
        return out

    def _drop_rest(self, data, take):
        self.dropped_bytes += max(0, len(data) - max(0, take))
        self.buf = bytearray()

    def pending_overflow(self):
        if not self.overflow:
            return None
        return err(
            E_TOO_LARGE,
            "单行超过 %d 字节上限（已丢 %d 字节）" % (self.max_bytes, self.dropped_bytes),
            details={"max_line_bytes": self.max_bytes},
            hint="把大内容写进文件再用 text.set 的 file 参数；图片用 format:'file'。",
        )


class RateBudget(object):
    """滑动窗口限流：每秒行数。"""

    __slots__ = ("rate", "window", "hits")

    def __init__(self, rate=MAX_CONN_LINES_PER_SEC):
        self.rate = float(rate)
        self.window = deque()
        self.hits = 0

    def configure(self, rate):
        self.rate = float(rate)

    def allow(self, now=None, cost=1):
        now = time.time() if now is None else now
        self.hits += cost
        self.window.append(now)
        cutoff = now - 1.0
        while self.window and self.window[0] < cutoff:
            self.window.popleft()
        return len(self.window) <= max(1, self.rate)

    def usage(self):
        return {"rate_per_sec": self.rate, "window_hits": len(self.window), "hits_total": self.hits}


class Conn(object):
    """一条客户端连接的完整状态（只在网络线程与主线程间通过消息传递，不共享对象引用）。"""

    _ids = itertools.count(1)

    def __init__(self, sock, addr, runtime):
        self.id = next(self._ids)
        self.sock = sock
        self.addr = addr
        self.rt = runtime
        self.framer = LineFramer(MAX_LINE_BYTES)
        self.rate = RateBudget(runtime.props.get("rate_per_sec") or MAX_CONN_LINES_PER_SEC)
        self.outbox = deque()
        self.out_bytes = 0
        self.want_write = False
        self.authenticated = False
        self.created = time.time()
        self.last_read = time.time()
        self.last_activity = time.time()
        self.requests = 0
        self.errors = 0
        self.rejected = 0
        self.events_sent = 0
        self.events_dropped = 0
        self.subscribed = set()
        self.min_interval_ms = 0
        self._last_event_at = {}
        self.in_flight = False
        self.pending_capture = None
        self.close_after_flush = False
        self.closing = False
        self.read_paused = False
        self.label = "%s:%s" % (addr[0], addr[1]) if addr else "?"
        self.buf_max = 0

    # --------------------------- 发送 ---------------------------
    def send_obj(self, obj):
        """一帧 = 一行 JSON + \n（协议终止符，绝不能漏）。"""
        try:
            data = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n"
        except (TypeError, ValueError) as exc:
            data = json.dumps(
                {"v": NEXUS_PROTO, "type": "response", "ok": False, "error": {"code": E_INTERNAL, "message": "响应无法序列化: %r" % (exc,)}},
                separators=(",", ":"),
            ).encode("utf-8")
        if len(data) > self.rt.limits["max_result_bytes"]:
            data = json.dumps(
                {
                    "v": NEXUS_PROTO,
                    "type": "response",
                    "ok": False,
                    "error": {
                        "code": E_TOO_LARGE,
                        "message": "响应 %d 字节超过上限 %d" % (len(data), self.rt.limits["max_result_bytes"]),
                        "hint": "用 limit/offset/fields 裁剪结果，或把 canvas.snapshot 的 format 设为 file。",
                    },
                }
            ).encode("utf-8") + b"\n"
        if self.out_bytes + len(data) > OUTBOX_LIMIT:
            self.rt.stats["dropped_replies"] += 1
            self.close("outbox_overflow")
            return False
        self.outbox.append(data)
        self.out_bytes += len(data)
        self._set_write(True)
        return True

    def _set_write(self, want):
        self.want_write = want
        self.rt.net.update_write(self, want)

    # --------------------------- 关闭 ---------------------------
    def flush_then_close(self, reason="closed_by_server"):
        self.close_after_flush = True
        self._reason = reason

    def close(self, reason="closed"):
        self.closing = True
        self._reason = reason
        self.rt.net.drop_connection(self, reason)

    # --------------------------- 事件 ---------------------------
    def wants(self, name):
        return name in self.subscribed

    def subscribe(self, names, min_interval_ms=0):
        self.subscribed = set(names)
        self.min_interval_ms = max(0, int(min_interval_ms or 0))

    def push_event(self, name, data):
        if not self.authenticated or self.closing:
            return False
        if self.min_interval_ms:
            last = self._last_event_at.get(name, 0.0)
            if (time.time() - last) * 1000.0 < self.min_interval_ms:
                self.events_dropped += 1
                return False
            self._last_event_at[name] = time.time()
        payload = {
            "v": NEXUS_PROTO,
            "type": "event",
            "event": name,
            "seq": self.rt.stats["events"],
            "ts": round(time.time(), 3),
            "data": data,
        }
        self.events_sent += 1
        return self.send_obj(payload)

    def usage(self):
        return {
            "id": self.id,
            "peer": self.label,
            "authenticated": self.authenticated,
            "requests": self.requests,
            "errors": self.errors,
            "rejected": self.rejected,
            "events_sent": self.events_sent,
            "events_dropped": self.events_dropped,
            "subscribed": sorted(self.subscribed),
            "in_flight": self.in_flight,
            "outbox_bytes": self.out_bytes,
            "rx_buffer_bytes": len(self.framer.buf),
            "rx_buffer_peak": self.buf_max,
            "rate": self.rate.usage(),
            "idle_s": round(time.time() - self.last_activity, 2),
            "age_s": round(time.time() - self.created, 2),
        }


class NetServer(object):
    """后台守护线程：bind 127.0.0.1:随机端口 -> accept -> 行协议 -> 投递主线程。

    线程安全约定：本类只与 runtime 的两个 queue 交互（cmd_q / reply_q），
    绝不调用任何 obspython API。
    """

    def __init__(self, runtime):
        self.rt = runtime
        self.listen_sock = None
        self.port = 0
        self.conns = {}
        self.sel = None
        self._thread = None
        self._stopping = False
        self._force_stop = False
        self._wakeup_r = None
        self._wakeup_w = None
        self._auth_failures = {}
        self._accepted_total = 0
        self._rejected_preauth = 0
        self._by_fd = {}
        self.tick = 0

    # 由 Conn 调用：只调整 selector 的写兴趣（读兴趣保持常开，串行由 in_flight 保证）
    def update_write(self, conn, want):
        if self.sel is None or conn.closing:
            return
        try:
            events = selectors.EVENT_READ | (selectors.EVENT_WRITE if want else 0)
            self.sel.modify(conn.sock, events, conn.id)
        except (KeyError, ValueError, OSError):
            pass

    # ------------------------- 生命周期 -------------------------
    def start(self, host, port, prefer_range=True):
        self.port = self._bind(host, port, prefer_range)
        try:
            self._wakeup_r, self._wakeup_w = socket.socketpair()
            for s in (self._wakeup_r, self._wakeup_w):
                s.setblocking(False)
        except (OSError, AttributeError):  # pragma: no cover - 极少见
            self._wakeup_r = self._wakeup_w = None
        self.sel = selectors.DefaultSelector()
        self.sel.register(self.listen_sock, selectors.EVENT_READ, "listen")
        if self._wakeup_r is not None:
            self.sel.register(self._wakeup_r, selectors.EVENT_READ, "wakeup")
        self._thread = threading.Thread(target=self._guarded_loop, name="NexusNetworkThread", daemon=True)
        self._thread.start()
        return self.port

    def _bind(self, host, port, prefer_range):
        last = None
        candidates = []
        if port:
            candidates.append(int(port))
        elif prefer_range:
            lo, hi = self.rt.props.get("port_range") or PORT_RANGE
            try:
                lo, hi = int(lo), int(hi)
            except Exception:
                lo, hi = PORT_RANGE
            span = max(0, hi - lo)
            start = lo + (int.from_bytes(os.urandom(2), "big") % (span + 1))
            for i in range(min(span + 1, 120)):
                candidates.append(((start - lo + i) % (span + 1)) + lo)
        for cand in candidates or [0]:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind((host, int(cand)))
                sock.listen(16)
                sock.setblocking(False)
                self.listen_sock = sock
                return sock.getsockname()[1]
            except OSError as exc:
                last = exc
                try:
                    sock.close()
                except OSError:
                    pass
        raise err(E_OBS_FAILED, "无法在 127.0.0.1 上监听：%r" % (last,), details={"host": host, "tried": len(candidates) or 1})

    def _guarded_loop(self):  # pragma: no cover - 兜底：线程绝不因异常静默死掉
        try:
            self._loop()
        except Exception:
            _LOG.error("网络线程异常退出：\n%s" % traceback.format_exc())
        finally:
            self._cleanup_sockets("thread_exit")
            if self.rt is not None:
                self.rt.stats["net_thread_died"] = now_ms()

    def stop(self, force=False, timeout=1.5):
        self._stopping = True
        if force:
            self._force_stop = True
        self.wake()
        th = self._thread
        if th is not None and th is not threading.current_thread():
            th.join(timeout)
            if th.is_alive():  # 极端情况：网络线程卡死 -> 强杀，OBS 关闭不受影响
                _LOG.warn("网络线程未在 %.1fs 内退出，强制关闭" % timeout)
                self._cleanup_sockets("forced")
                try:
                    th._stop() if hasattr(th, "_stop") else None
                except Exception:
                    pass
        return not (th is not None and th.is_alive())

    def wake(self):
        w = self._wakeup_w
        if w is None:
            return
        try:
            w.send(b"\x01")
        except OSError:
            pass

    # --------------------------- 主循环 ---------------------------
    def _loop(self):
        sel = self.sel
        while not self._stopping:
            self.tick += 1
            timeout = 0.25
            if any(c.in_flight or c.pending_capture is not None or c.want_write for c in self.conns.values()):
                timeout = 0.02
            elif self.rt.cmd_backlog():
                timeout = 0.05
            try:
                events = sel.select(timeout)
            except OSError as exc:
                if getattr(exc, "errno", None) == errno.EINTR:
                    continue
                break
            except ValueError:  # selector 被关闭
                break
            for key, mask in events:
                tag = key.data
                try:
                    if tag == "listen":
                        self._accept()
                    elif tag == "wakeup":
                        self._drain_wakeup()
                        self._drain_replies()
                    else:
                        self._on_conn_event(key.fileobj, mask)
                except Exception as exc:
                    _LOG.warn("连接事件处理异常 (%s): %r" % (tag, exc))
                    conn = self.conns.get(key.fileobj)
                    if conn is not None:
                        conn.close("event_error")
            try:
                self._drain_replies()
                self._tick_conns()
            except Exception as exc:
                _LOG.warn("tick 异常: %r" % (exc,))
        self._cleanup_sockets("stopping")

    def _drain_wakeup(self):
        r = self._wakeup_r
        if r is None:
            return
        try:
            while r.recv(4096):
                pass
        except (OSError, BlockingIOError):
            pass

    def _cleanup_sockets(self, reason):
        for conn in list(self.conns.values()):
            try:
                conn.sock.close()
            except OSError:
                pass
        self.conns.clear()
        for attr in ("listen_sock", "_wakeup_r", "_wakeup_w"):
            obj = getattr(self, attr, None)
            if obj is not None:
                try:
                    obj.close()
                except OSError:
                    pass
        if self.sel is not None:
            try:
                self.sel.close()
            except Exception:
                pass
            self.sel = None

    # --------------------------- 连接管理 ---------------------------
    def _accept(self):
        if len(self.conns) >= self.rt.limits["max_connections"]:
            try:
                sock, addr = self.listen_sock.accept()
            except OSError:
                return
            self._rejected_preauth += 1
            self.rt.stats["rejected"] += 1
            try:
                sock.sendall(
                    json.dumps(
                        {
                            "v": NEXUS_PROTO,
                            "type": "error",
                            "error": {
                                "code": E_OVERLOAD,
                                "message": "连接数已达上限 %d" % self.rt.limits["max_connections"],
                                "retryable": True,
                            },
                        }
                    ).encode("utf-8")
                    + b"\n"
                )
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
            _LOG.warn("拒绝新连接 %s（连接数已满）" % (addr,))
            return
        try:
            sock, addr = self.listen_sock.accept()
        except (BlockingIOError, OSError):
            return
        try:
            sock.setblocking(False)
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass
            conn = Conn(sock, addr, self.rt)
            self.conns[conn.id] = conn
            self._by_fd[sock.fileno()] = conn.id
            self._accepted_total += 1
            self.rt.stats["connections_total"] += 1
            self.sel.register(sock, selectors.EVENT_READ, conn.id)
            # 预鉴权握手信息：故意不含 token / 场景内容，避免未鉴权信息泄露
            conn.send_obj(
                {
                    "v": NEXUS_PROTO,
                    "type": "hello",
                    "proto": NEXUS_PROTO,
                    "app": NEXUS_APP,
                    "nexus_version": NEXUS_VERSION,
                    "auth_required": bool(self.rt.token),
                    "auth_scheme": "nexus-token-v1",
                    "limits": {"max_line_bytes": MAX_LINE_BYTES, "max_batch_ops": MAX_BATCH_OPS},
                    "auth_hint": '{"t":"auth","token":"<connection.json 里的 token>"}',
                    "auth_deadline_ms": AUTH_TIMEOUT_MS,
                }
            )
        except Exception as exc:
            _LOG.warn("accept 失败: %r" % (exc,))
            try:
                sock.close()
            except OSError:
                pass

    def drop_connection(self, conn, reason):
        self.conns.pop(conn.id, None)
        try:
            self._by_fd.pop(conn.sock.fileno(), None)
        except OSError:
            pass
        try:
            self.sel.unregister(conn.sock)
        except Exception:
            pass
        try:
            conn.sock.close()
        except OSError:
            pass
        if conn.in_flight:
            self.rt.forget_connection(conn.id)
        conn.in_flight = False
        conn.pending_capture = None
        if reason not in ("eof", "closed_by_client", "idle_timeout", "stopping", "thread_exit", "client_shutdown"):
            _LOG.info("断开连接 %s: %s" % (conn.label, reason))
        conn.closing = True

    def _on_conn_event(self, sock, mask):
        conn = self.conns.get(self._by_fd.get(sock.fileno(), -1))
        if conn is None:
            try:
                sock.close()
            except OSError:
                pass
            return
        if mask & selectors.EVENT_READ:
            self._on_read(conn)
        if conn.closing:
            return
        if mask & selectors.EVENT_WRITE:
            self._on_write(conn)
            if conn.closing:
                return
        if conn.close_after_flush and not conn.outbox:
            self.drop_connection(conn, getattr(conn, "_reason", "flushed"))
            return
        if conn.want_write != conn.out_bytes > 0:
            conn.want_write = conn.out_bytes > 0
            conn._set_write(conn.want_write)

    def _on_read(self, conn):
        try:
            data = conn.sock.recv(65536)
        except (BlockingIOError, InterruptedError):
            return
        except (ConnectionResetError, ConnectionAbortedError, OSError) as exc:
            if getattr(exc, "errno", None) in (errno.EAGAIN, errno.EWOULDBLOCK):
                return
            self.drop_connection(conn, "read_error")
            return
        if not data:
            self.drop_connection(conn, "eof")
            return
        conn.last_read = time.time()
        conn.last_activity = conn.last_read
        lines = conn.framer.feed(data)
        conn.buf_max = max(conn.buf_max, len(conn.framer.buf))
        over = conn.framer.pending_overflow()
        if over is not None:
            self._send_error(conn, None, over)
            conn.flush_then_close("line_overflow")
            return
        for line in lines:
            if not conn.rate.allow():
                conn.rejected += 1
                self.rt.stats["rejected"] += 1
                self._send_error(
                    conn,
                    None,
                    err(
                        E_OVERLOAD,
                        "消息速率超过上限 %.0f 行/秒" % conn.rate.rate,
                        retryable=True,
                        hint="降低轮询频率，或改用 conn.subscribe 事件推送，或调大脚本属性 rate_per_sec。",
                    ),
                )
                if conn.rejected > 20:
                    conn.flush_then_close("rate_limit_abuse")
                    return
                continue
            self._handle_line(conn, line)
            if conn.closing:
                return

    def _on_write(self, conn):
        while conn.outbox:
            chunk = conn.outbox[0]
            try:
                n = conn.sock.send(chunk)
            except (BlockingIOError, InterruptedError):
                return
            except (BrokenPipeError, ConnectionResetError, OSError):
                self.drop_connection(conn, "write_error")
                return
            if n <= 0:
                self.drop_connection(conn, "write_zero")
                return
            if n == len(chunk):
                conn.outbox.popleft()
                conn.out_bytes -= len(chunk)
            else:
                conn.outbox[0] = chunk[n:]
                conn.out_bytes -= n
        if not conn.outbox:
            conn._set_write(False)

    # --------------------------- 消息处理 ---------------------------
    def _handle_line(self, conn, line):
        try:
            req = json.loads(line.decode("utf-8"))
        except UnicodeDecodeError as exc:
            self._send_error(conn, None, err(E_PROTO, "请求必须是 UTF-8: %r" % (exc,)))
            return
        except ValueError as exc:
            self.rt.stats["json_errors"] += 1
            self._send_error(
                conn,
                None,
                err(E_PROTO, "JSON 解析失败: %s" % (str(exc)[:180],), hint="每个请求必须是一行合法 JSON，且以 \\n 结尾。"),
            )
            return
        if not isinstance(req, dict):
            self._send_error(conn, None, err(E_PROTO, "顶层必须是 JSON 对象，收到 %s" % type(req).__name__))
            return
        rtype = str(req.get("t") or req.get("type") or "").strip().lower()
        if rtype in ("ping", "heartbeat"):
            conn.send_obj(
                {
                    "v": NEXUS_PROTO,
                    "type": "pong",
                    "ts": round(time.time(), 3),
                    "request_id": req.get("id"),
                    "authenticated": bool(conn.authenticated),
                }
            )
            return
        if rtype == "auth":
            self._handle_auth(conn, req)
            return
        if not conn.authenticated:
            self.rt.stats["unauth_attempts"] += 1
            self._send_error(
                conn,
                req.get("id") or req.get("request_id"),
                err(
                    E_UNAUTHORIZED,
                    "未鉴权：必须先发送 {\"t\":\"auth\",\"token\":...}",
                    hint="token 在 %s 里；若为 null 则无需鉴权。" % self.rt.conn_file,
                ),
            )
            conn.flush_then_close("unauthenticated")
            return
        if rtype in ("exit", "shutdown", "close"):
            conn.send_obj({"v": NEXUS_PROTO, "type": "bye", "ok": True, "request_id": req.get("id")})
            conn.flush_then_close("client_shutdown")
            return
        self._dispatch(conn, req)

    def _handle_auth(self, conn, req):
        provided = req.get("token")
        if provided is None:
            provided = req.get("auth") or req.get("password")
        expected = self.rt.token or ""
        ok = bool(expected) and isinstance(provided, str) and _const_eq(provided.strip(), expected)
        if not expected and self.rt.allow_no_auth:
            ok = True
        if ok:
            conn.authenticated = True
            self.rt.stats["auth_ok"] += 1
            conn.send_obj(
                {
                    "v": NEXUS_PROTO,
                    "type": "auth",
                    "ok": True,
                    "request_id": req.get("id") or req.get("request_id"),
                    "proto": NEXUS_PROTO,
                    "nexus_version": NEXUS_VERSION,
                    "obs_version": self.rt.cached("obs_version"),
                    "advanced": self.rt.advanced,
                    "limits": dict(self.rt.limits),
                    "ops": [n for n in sorted(OPS) if not OPS[n].advanced or self.rt.advanced],
                    "events": sorted(self.rt.event_names),
                    "note": "已鉴权。发送 {\"op\":\"...\"} 或 {\"ops\":[...]}，一行一条。",
                }
            )
            conn.push_event("connection.ready", {"peer": conn.label, "port": self.port})
            return
        self.rt.stats["auth_fail"] += 1
        now = time.time()
        fails = [t for t in self._auth_failures.get(conn.label, []) if now - t < 60.0]
        fails.append(now)
        self._auth_failures[conn.label] = fails
        if len(fails) > 8:
            _LOG.error("来自 %s 的 token 校验连续失败 %d 次，已断开并拉黑 60s" % (conn.label, len(fails)))
        self._send_error(
            conn,
            req.get("id"),
            err(
                E_UNAUTHORIZED,
                "Token 校验失败",
                details={"attempts_last_60s": len(fails), "expected_source": self.rt.conn_file},
                hint="重新点「写入连接文件」获取新 token；token 为 null 表示已关闭鉴权。",
            ),
        )
        conn.flush_then_close("auth_failed")

    def _dispatch(self, conn, req):
        if conn.in_flight:
            self._send_error(
                conn,
                req.get("id"),
                err(
                    E_PRECONDITION,
                    "上一条请求仍在执行中（同一连接串行）",
                    retryable=True,
                    hint="等待响应，或为并发请求另开一条 TCP 连接。",
                ),
            )
            return
        if not self.rt.cmd_space():
            self.rt.stats["rejected"] += 1
            self._send_error(
                conn,
                req.get("id"),
                err(
                    E_OVERLOAD,
                    "主线程队列已满（%d）" % self.rt.cmd_backlog(),
                    retryable=True,
                    details={"queue_depth": self.rt.cmd_backlog()},
                    hint="降低批量大小或放慢调用频率；OBS 主线程可能正忙。",
                ),
            )
            return
        try:
            parsed = parse_request(req, self.rt)
        except NexusError as exc:
            conn.errors += 1
            self._send_error(conn, req.get("id") or req.get("request_id"), exc)
            return
        conn.requests += 1
        conn.in_flight = True
        self.rt.submit_request(conn, parsed)

    def _send_error(self, conn, req_id, exc):
        if conn is not None:
            conn.errors += 1
        conn.send_obj(build_error_response(req_id, exc))

    # --------------------------- 主线程回包 ---------------------------
    def _drain_replies(self):
        q = self.rt.reply_q
        for _ in range(256):
            try:
                item = q.get_nowait()
            except Empty:
                break
            kind = item[0]
            if kind == "reply":
                _, conn_id, payload, capture = item
                conn = self.conns.get(conn_id)
                if conn is None:
                    continue
                conn.in_flight = False
                if capture is not None:
                    conn.pending_capture = {"payload": payload, "capture": capture, "conn_id": conn_id}
                    conn.pending_capture["deadline"] = time.time() + capture.get("timeout_ms", 3000) / 1000.0
                    conn.pending_capture["state"] = {"sig": None, "path": None, "tries": 0}
                else:
                    conn.send_obj(payload)
            elif kind == "close":
                conn = self.conns.get(item[1])
                if conn is not None:
                    conn.flush_then_close(item[2] if len(item) > 2 else "server_close")
            elif kind == "event":
                self._broadcast(item[1], item[2])
            elif kind == "force_close":
                conn = self.conns.get(item[1])
                if conn is not None:
                    self.drop_connection(conn, item[2] if len(item) > 2 else "closed")

    def _broadcast(self, name, data):
        for conn in list(self.conns.values()):
            if conn.wants(name):
                conn.push_event(name, data)

    def _tick_conns(self):
        now = time.time()
        idle_ms = self.rt.props.get("idle_timeout_ms") or IDLE_TIMEOUT_MS
        for conn in list(self.conns.values()):
            try:
                if not conn.closing and not conn.authenticated and (now - conn.created) * 1000.0 > AUTH_TIMEOUT_MS:
                    self._send_error(conn, None, err(E_UNAUTHORIZED, "%d ms 内未完成鉴权，断开" % AUTH_TIMEOUT_MS, retryable=True))
                    conn.flush_then_close("auth_timeout")
                    continue
                if not conn.closing and (now - conn.last_activity) * 1000.0 > idle_ms:
                    conn.send_obj({"v": NEXUS_PROTO, "type": "bye", "ok": True, "reason": "idle_timeout"})
                    conn.flush_then_close("idle_timeout")
                    continue
                if conn.pending_capture is not None:
                    self._advance_capture(conn, now)
            except Exception as exc:  # 单连接异常不能带崩整个事件循环
                _LOG.warn("tick 连接异常: %r" % (exc,))
                conn.close("tick_error")

    # ------------------ 截图收尾（文件等待 + 编码全在 worker 线程） ------------------
    def _advance_capture(self, conn, now=None):
        now = time.time() if now is None else now
        pc = conn.pending_capture
        cap = pc["capture"]
        st = pc["state"]
        st["tries"] += 1
        # command 后端：懒启动外部命令，之后按 tick 轮询其退出状态（永不阻塞事件循环）
        if cap.get("command"):
            if st.get("proc") is None:
                try:
                    st["proc"] = subprocess.Popen(
                        cap["command"],
                        shell=True,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.PIPE,
                        cwd=nexus_dir(),
                    )
                except Exception as exc:
                    self._resolve_capture(conn, pc, err(E_OBS_FAILED, "snapshot_command 启动失败: %r" % (exc,)))
                    return
                return
            rc = st["proc"].poll()
            if rc is None:
                if now > pc["deadline"]:
                    try:
                        st["proc"].kill()
                    except Exception:
                        pass
                    self._resolve_capture(conn, pc, err(E_TIMEOUT, "snapshot_command 超时未退出", retryable=True))
                return
            if rc != 0:
                txt = b""
                try:
                    txt = (st["proc"].stderr.read() or b"")[:400]
                except Exception:
                    pass
                self._resolve_capture(
                    conn, pc, err(E_OBS_FAILED, "snapshot_command 退出码 %s：%s" % (rc, txt.decode("utf-8", "replace").strip()[:256]))
                )
                return
            cand = cap.get("out_path")
            if cand and os.path.exists(cand):
                self._resolve_capture(conn, pc, None, cand)
            else:
                self._resolve_capture(conn, pc, err(E_TIMEOUT, "snapshot_command 没有产出文件 %s" % cand, retryable=True))
            return
        # native / dir：先看主线程刷新的 last_screenshot 缓存，再兜底扫目录
        cand = None
        cache = self.rt.shot_cache
        if cap.get("prev") is not None and cache.get("path") and cache["path"] != cap["prev"]:
            cand = cache["path"]
        if cand is None and st["tries"] % 3 == 1:
            cand = _scan_new_images(cap.get("dirs") or [], cap.get("t0") or now, exclude=cap.get("exclude") or set())
        settled = False
        if cand:
            sig = file_sig(cand)
            if sig is not None and st.get("sig") == (cand, sig):
                settled = True
            st["sig"] = (cand, sig)
            st["path"] = cand
        if not settled and st.get("path") and st.get("sig"):
            cand = st["path"]
            sig = file_sig(cand)
            if sig is not None and st["sig"][1] == sig:
                settled = True
        if settled:
            self._resolve_capture(conn, pc, None, cand)
            return
        if now > pc["deadline"]:
            self._resolve_capture(
                conn,
                pc,
                err(
                    E_TIMEOUT,
                    "等待 OBS 写出截图文件超时（%.1fs）" % (now - (cap.get("t0") or now)),
                    details={"dirs": cap.get("dirs"), "last_screenshot": self.rt.shot_cache.get("path")},
                    retryable=True,
                    hint="确认 OBS「设置-高级-截图」保存目录，并在脚本属性 snapshot_dir 填同一路径；"
                    "或改 mode:'dir' / format:'file'；OBS 主线程被卡住也会导致本超时（见 system.health）。",
                ),
            )

    def _resolve_capture(self, conn, pc, exc, path=None):
        payload = pc["payload"]
        cap = pc["capture"]
        conn.pending_capture = None
        idx = cap.get("index")
        if exc is None:
            try:
                result = finish_capture(path, cap)
                result["waited_ms"] = int((time.time() - (cap.get("t0") or time.time())) * 1000)
            except NexusError as exc2:
                exc, result = exc2, None
            except Exception as exc2:  # pragma: no cover
                exc, result = err(E_INTERNAL, "截图后处理失败: %r" % (exc2,)), None
        else:
            result = None
        results = payload.get("results")
        if isinstance(results, list) and idx is not None and 0 <= idx < len(results):
            if result is not None:
                results[idx] = {"ok": True, "op": "canvas.snapshot", "data": result}
            else:
                results[idx] = {"ok": False, "op": "canvas.snapshot", "error": exc.to_dict()}
            payload["ok"] = all(bool(r.get("ok")) for r in results if isinstance(r, dict))
            payload["result"] = results[idx]
            payload["error"] = None if result is not None else exc.to_dict()
            payload["batch"]["aborted"] = payload["batch"].get("aborted") or (result is None and not payload.get("ok", False))
        else:
            payload["ok"] = result is not None
            payload["result"] = {"ok": result is not None, "op": "canvas.snapshot", "data": result}
            if result is None:
                payload["error"] = exc.to_dict()
        payload.pop("pending_capture", None)
        self._send_final(conn, payload)
        if result is None:
            self.rt.stats.inc("captures_failed")
        else:
            self.rt.stats.inc("captures")


    def _send_final(self, conn, payload):
        try:
            conn.send_obj(payload)
        except Exception as exc:  # pragma: no cover
            _LOG.warn("发送失败: %r" % (exc,))


def _const_eq(a, b):
    try:
        return hmac.compare_digest(("%s" % a).encode("utf-8"), ("%s" % b).encode("utf-8"))
    except Exception:
        return ("%s" % a) == ("%s" % b)


def finish_capture(path, cap):
    """worker 线程里执行：读文件 + 可选转码/缩放 + base64（不碰 libobs）。"""
    fmt_want = cap.get("format", "jpeg")
    max_bytes = cap.get("max_bytes", MAX_SNAPSHOT_BYTES)
    out = {"path": path, "mode": cap.get("mode", "native"), "bytes": None}
    for echo in ("scene", "source", "width", "quality"):
        if cap.get(echo) is not None:
            out[echo] = cap[echo]
    if fmt_want == "file":
        try:
            out["bytes"] = os.path.getsize(path)
        except OSError as exc:
            raise err(E_TIMEOUT, "无法 stat 截图文件: %r" % (exc,), retryable=True)
        out["image_data"] = None
        out["note"] = "format=file：只返回路径，未内联 base64（省 token 推荐用法）"
        return out
    fmt, b64, nbytes, info = _encode_snapshot(path, fmt_want, max_bytes, cap.get("width") or 0, cap.get("quality") or 82)
    out.update({"format": fmt, "bytes": nbytes, "b64_chars": len(b64), "image_data": b64, "mime": "image/" + ("jpeg" if fmt == "jpeg" else fmt)})
    out.update(info)
    dest = cap.get("save_copy")
    if dest:
        try:
            _ensure_dir(os.path.dirname(os.path.abspath(os.path.expanduser(dest))) or ".")
            shutil.copyfile(path, os.path.abspath(os.path.expanduser(dest)))
            out["saved_copy"] = dest
        except Exception as exc:
            out["saved_copy_error"] = repr(exc)
    return out


def build_error_response(req_id, exc):
    return {
        "v": NEXUS_PROTO,
        "type": "response",
        "request_id": req_id,
        "ok": False,
        "elapsed_ms": 0,
        "result": None,
        "error": exc.to_dict() if isinstance(exc, NexusError) else {"code": E_INTERNAL, "message": "%r" % (exc,)},
        "batch": {"index": 0, "count": 1, "aborted": True, "continue_on_error": False},
    }


# ----------------------------- 请求解析（纯计算，可在网络线程执行） -----------------------------
REQ_KEYS_OP = ("op", "method", "action", "cmd", "name")
REQ_KEYS_OPS = ("ops", "batch", "commands")  # 注意：不要把 steps/params 之类常见参数名放进来
REQ_KEYS_ARGS = ("args", "params", "p", "data")


def parse_request(req, rt):
    """把一行 JSON 解析成 {"id","ops","continue_on_error","deadline","budget"}。

    同时提供「兼容层」：
      {"method":"call","params":[{"op":...},...]}
      {"action":"text.set","source":"字幕","text":"hi"}
      单个对象 {"op":"text.set","source":...,"text":...}
    """
    if not isinstance(req, dict):
        raise err(E_PROTO, "顶层必须是对象")
    req_id = req.get("id")
    if req_id is None:
        req_id = req.get("request_id")
    if req_id is not None and not isinstance(req_id, (str, int)):
        raise err(E_PROTO, "id 必须是字符串或整数")
    if req_id is not None:
        req_id = ("%s" % req_id)[:64]
    timeout_ms = req.get("timeout_ms", req.get("timeout"))
    try:
        timeout_ms = _int(timeout_ms, DEFAULT_REQUEST_TIMEOUT_MS) or DEFAULT_REQUEST_TIMEOUT_MS
    except NexusError:
        raise err(E_PROTO, "timeout_ms 必须是整数")
    timeout_ms = _clamp(timeout_ms, 50, MAX_REQUEST_TIMEOUT_MS)
    batch_cfg = req.get("batch") if isinstance(req.get("batch"), dict) else {}
    if isinstance(req.get("ops"), dict):  # {"ops":{...}} 这种写法也接受（等价单 op）
        req = dict(req)
        req["ops"] = [req["ops"]]
    ops_raw = None
    for k in REQ_KEYS_OPS:
        v = req.get(k)
        if v is None:
            continue
        if not isinstance(v, list):
            raise err(
                E_PROTO,
                "字段 %r 必须是数组（批量请求）" % k,
                details={"got": type(v).__name__},
                hint='例：{"ops":[{"op":"text.set","source":"字幕","text":"hi"}]}',
            )
        ops_raw = v
        break
    op_key = None
    if ops_raw is None:
        op_name = None
        for k in REQ_KEYS_OP:
            v = req.get(k)
            if isinstance(v, str) and v.strip():
                op_name = v.strip()
                op_key = k
                break
        if op_name is None:
            raise err(
                E_NO_METHOD,
                "请求里找不到 op / ops / method / action 字段",
                details={"keys_seen": sorted(str(k) for k in req.keys())[:16]},
                hint='例：{"op":"text.set","source":"字幕","text":"你好"} 或 {"ops":[{"op":"system.overview"}]}',
            )
        args = None
        for k in REQ_KEYS_ARGS:
            if isinstance(req.get(k), dict):
                args = req.get(k)
                break
        if args is not None and op_name not in OPS:
            inner = args.get("op") or args.get("method")
            if isinstance(inner, str) and inner.strip() in OPS:  # {"method":"call","params":{"op":...}}
                args = dict(args)
                args.pop("op", None)
                args.pop("method", None)
                op_name = inner.strip()
        if args is None:
            skip = set(("v", "t", "type", "id", "request_id", "timeout_ms", "timeout", "continue_on_error", "batch", "main_budget_ms"))
            skip.update(k for k in REQ_KEYS_ARGS if isinstance(req.get(k), dict))
            if op_key is not None:  # 只排除真正当作 op 名使用的键，其它动作字段（如 action）保留为参数
                skip.add(op_key)
            args = {k: v for k, v in req.items() if k not in skip}
        ops_raw = [dict(args or {}, op=op_name)]
    ops = normalize_ops(ops_raw, rt)
    coe = req.get("continue_on_error")
    if coe is None:
        coe = req.get("stop_on_error")
        coe = not _bool(coe, True) if coe is not None else False
    coe = _bool(coe, False) or _bool(batch_cfg.get("continue_on_error"), False)
    return {
        "id": req_id,
        "ops": ops,
        "continue_on_error": coe,
        "timeout_ms": timeout_ms,
        "main_budget_ms": _clamp(
            _int(req.get("main_budget_ms"), (rt.props or {}).get("max_batch_exec_ms") or MAX_BATCH_EXEC_MS) or MAX_BATCH_EXEC_MS, 20, 1000
        ),
        "client": req.get("client"),
    }


def normalize_ops(ops_raw, rt):
    if not isinstance(ops_raw, list) or not ops_raw:
        raise err(E_PROTO, "ops 必须是非空数组")
    if len(ops_raw) > MAX_OPS_FOR_SIZE:
        raise err(E_TOO_LARGE, "ops 数组过大（%d > %d）" % (len(ops_raw), MAX_OPS_FOR_SIZE), details={"split": True})
    if len(ops_raw) > MAX_BATCH_OPS:
        raise err(
            E_TOO_LARGE,
            "批量 op 数量 %d 超过上限 %d" % (len(ops_raw), MAX_BATCH_OPS),
            hint="拆成多次请求，或调大脚本属性 max_batch_ops（不建议）。",
        )
    out = []
    for i, item in enumerate(ops_raw):
        if isinstance(item, str):
            item = {"op": item}
        if not isinstance(item, dict):
            raise err(E_PROTO, "ops[%d] 必须是对象或字符串" % i, details={"got": type(item).__name__})
        item = dict(item)
        name = None
        name_key = None
        for k in REQ_KEYS_OP:
            v = item.get(k)
            if isinstance(v, str) and v.strip():
                name = v.strip()
                name_key = k
                break
        if name is None:
            raise err(E_NO_METHOD, "ops[%d] 缺少 op 字段" % i, details={"keys_seen": sorted(str(k) for k in item.keys())[:12]})
        spec = OPS.get(name)
        if spec is None:
            near = _closest(name, OPS.keys())
            raise err(
                E_UNKNOWN_OP,
                "未知 op: %r" % name,
                details={"did_you_mean": near, "known": sorted(OPS.keys())[:64]},
                hint="用 conn.capabilities 获取全部 op 与参数说明。",
            )
        if spec.advanced and not rt.advanced:
            raise err(
                E_FORBIDDEN,
                "op %r 需要开启 advanced_script_controls" % name,
                details={"op": name},
                hint="在脚本属性里勾选「允许高级控制」（仅本地调试建议）。",
            )
        args = {}
        for k in REQ_KEYS_ARGS:
            v = item.pop(k, None)
            if isinstance(v, dict):
                args.update(v)
        for k, v in item.items():
            if k == name_key and v == name:
                continue
            args.setdefault(k, v)
        out.append({"index": i, "op": name, "args": args, "spec": spec})
    return out


def _closest(word, candidates, n=3):
    low = ("%s" % word).lower()
    scored = []
    for c in candidates:
        cl = c.lower()
        s = 0
        if cl.startswith(low) or low in cl:
            s += 2
        common = len(set(low) & set(cl))
        s += common / max(1.0, float(len(set(low) | set(cl))))
        scored.append((s, c))
    scored.sort(reverse=True)
    return [c for _s, c in scored[:n]]
