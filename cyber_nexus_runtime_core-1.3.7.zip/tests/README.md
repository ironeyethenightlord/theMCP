# 1.3.7 回归测试

## 已执行的验证

环境：Linux，Python 3.13，**真实 Blender 5.2.2 LTS `bpy`**，headless，不使用 Blender API 替身。

- `blender_regression.py`：38 项测试，**37 通过、1 跳过、0 失败、0 错误**。
- 跳过项：GUI Undo/Redo，当前 headless 环境没有可用上下文。该测试不构成桌面 Undo/Redo 验证。
- 9 类生成器 smoke、求值网格检查、无损 compact 分页、cursor 无漏项、输出预算停止后续操作。
- 删除后 recovery、显式 purge、同 ID live 组件保护。
- 128 字符组件 ID 的完整对象引用。
- 材质规范化、清空材质、对象级材质槽覆盖及失败补偿。
- 集合属性与 registry 写入故障注入，成功后的清理 warning。
- 预检/执行 timeout、revision/session、native rigid root 条件、资源预算。
- 微小尺寸检查的原始数值保留、弦高约束、平移后的剖面面积/自交判断。
- 真正的 loopback TCP token 鉴权、request ID 去重/冲突、缓存淘汰后的 receipt，以及附带标准库 Agent 客户端。
- `preview_regression.py`：material / solid / wireframe 各 7 视角，另有 2 个 collection instance 预览，**共 23 次渲染通过**。验证 JPEG、临时对象/网格/相机/场景清理，并用顶视中心像素检查线框没有被实体面填满。

机器结果：`test_results_137.json`、`preview_results_137.json`。运行日志：`core_test.log`、`preview_test.log`。

## 重新运行

**这些脚本会清空测试进程中的对象、集合和材质。只在独立后台进程运行，不要放到当前工作文件的 GUI Text Editor 执行。脚本会拒绝非 background 环境。** 测试不会保存或覆盖用户 blend 文件。

解压扩展后，使用 Blender 自带 Python：

```bash
blender --background --factory-startup --python /path/to/extension/tests/blender_regression.py
blender --background --factory-startup --python /path/to/extension/tests/preview_regression.py
```

或者，在支持的独立 Python / 操作系统中安装相应版本的真实 bpy（Linux 还需要其图形系统库）：

```bash
python -m pip install bpy==5.2.2
python /path/to/extension/tests/blender_regression.py
python /path/to/extension/tests/preview_regression.py
```

脚本默认以自身父目录的父目录作为插件路径。单独移动脚本时，普通 Python 可追加插件路径；Blender CLI 在 `--` 后追加插件路径。

截图测试要求可用的 Workbench 图形后端；它在独立进程执行，避免潜在原生图形失败影响核心测试。运行时会在测试目录生成 `preview_samples/`，该目录只是测试输出，发行 ZIP 不包含它。

## 尚需桌面验证

- Blender 扩展安装 UI、侧栏交互、auto_start 偏好与升级后的用户配置。
- 连续修改、首个修改与复杂 operator 混合使用时的 Undo/Redo。
- Windows / macOS 文件 ACL、不同 GPU 驱动及全部后续 Blender 版本。
- 用户真实文件中的复杂 Geometry Nodes、collection overrides、隐藏层级、动画与共享数据依赖。

通过测试不等于制造级精度认证、原生 C 调用安全或全面兼容性保证。
