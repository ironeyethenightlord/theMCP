"""Separate process: a native graphics failure must not kill the core test runner."""
import base64, importlib.util, json, pathlib, sys
import bpy
if not bpy.app.background:
    raise RuntimeError('Destructive test fixtures require an isolated background process; do not run in an open GUI work file')
arguments = (sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else
             ([] if '--python' in sys.argv else sys.argv[1:]))
ROOT = pathlib.Path(arguments[0]) if arguments else pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cn137_preview',ROOT/'__init__.py',submodule_search_locations=[str(ROOT)])
addon=importlib.util.module_from_spec(spec);sys.modules[spec.name]=addon;spec.loader.exec_module(addon)
R=addon.runtime; C=R.C
for obj in list(bpy.data.objects):bpy.data.objects.remove(obj,do_unlink=True)
addon.register()
C.create('preview_box','box',{'size':[2,1,3]})
bpy.context.view_layer.update()
initial={'objects':len(bpy.data.objects),'scenes':len(bpy.data.scenes),'cameras':len(bpy.data.cameras),'meshes':len(bpy.data.meshes)}
result={'blender':bpy.app.version_string,'mode':'real bpy headless Workbench render','initial':initial,'cases':[]}
for mode in ('material','solid','wireframe'):
    try:
        images=R.preview.snapshots({'views':['persp','front','back','right','left','top','bottom'],'focus':['preview_box'], 'isolate':True,'resolution':128,'shading':mode})
        for image in images:
            folder=pathlib.Path(__file__).parent/'preview_samples';folder.mkdir(exist_ok=True)
            (folder/(mode+'_'+image['view']+'.jpg')).write_bytes(base64.b64decode(image['image']))
        if mode=='wireframe':
            top=bpy.data.images.load(str(folder/(mode+'_top.jpg')), check_existing=False)
            try:
                center=list(top.pixels[4*(64*128+64):4*(64*128+64)+3])
                background=list(top.pixels[4*(4*128+4):4*(4*128+4)+3])
                assert max(abs(a-b) for a,b in zip(center,background))<=3/255, 'wireframe must not contain a filled center face'
            finally:
                bpy.data.images.remove(top)
        assert len(images)==7
        assert all(base64.b64decode(image['image']).startswith(b'\xff\xd8') for image in images)
        result['cases'].append({'shading':mode,'status':'passed','views':[image['view'] for image in images]})
    except Exception as exc:result['cases'].append({'shading':mode,'status':'unavailable_or_failed','error':str(exc)})
    assert initial=={'objects':len(bpy.data.objects),'scenes':len(bpy.data.scenes),'cameras':len(bpy.data.cameras),'meshes':len(bpy.data.meshes)}
# Also exercise a collection instance which is not linked as direct geometry.
col=bpy.data.collections.new('instance_fixture')
R.CyberHelper.create_box('instance_geometry',collection=col)
inst=bpy.data.objects.new('instance_focus',None);inst.instance_type='COLLECTION';inst.instance_collection=col
bpy.context.scene.collection.objects.link(inst);inst.location=(5,0,0);bpy.context.view_layer.update()
instance_initial={'objects':len(bpy.data.objects),'scenes':len(bpy.data.scenes),'cameras':len(bpy.data.cameras),'meshes':len(bpy.data.meshes)}
for mode in ('material','wireframe'):
    images=R.preview.snapshots({'views':['persp'],'focus':['instance_focus'],'isolate':True,'resolution':128,'shading':mode})
    assert len(images)==1 and base64.b64decode(images[0]['image']).startswith(b'\xff\xd8')
    assert instance_initial=={'objects':len(bpy.data.objects),'scenes':len(bpy.data.scenes),'cameras':len(bpy.data.cameras),'meshes':len(bpy.data.meshes)}
    result['cases'].append({'fixture':'collection_instance','shading':mode,'status':'passed','views':['persp']})
result['cleanup_verified']=True
addon.unregister()
pathlib.Path(__file__).with_name('preview_results_137.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(any(c['status']!='passed' for c in result['cases']))
