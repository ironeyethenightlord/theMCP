"""Blender 5.2+ integration regressions. Requires real bpy, not API stubs.
Run in an isolated process: python tests/blender_regression.py [path/to/extension-directory]
"""
import importlib.util
import json
import math
import pathlib
import socket
import sys
import threading
import time
import unittest
from unittest.mock import patch
import bpy
from mathutils import Matrix

if not bpy.app.background:
    raise RuntimeError('Destructive test fixtures require an isolated background process; do not run in an open GUI work file')
arguments = (sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else
             ([] if '--python' in sys.argv else sys.argv[1:]))
ROOT = pathlib.Path(arguments[0]) if arguments else pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cn137_test', ROOT/'__init__.py', submodule_search_locations=[str(ROOT)])
addon = importlib.util.module_from_spec(spec); sys.modules[spec.name] = addon; spec.loader.exec_module(addon)
R, I = addon.runtime, addon.inspect
C, O, S, P, L = R.C, R.O, R.S, R.P, R.O.L
from cn137_test.transaction import Journal, CommitFailure
from cn137_test.ledger import ExecutionLedger, receipt

class RegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): addon.register()
    @classmethod
    def tearDownClass(cls): addon.unregister()
    def setUp(self):
        R.stop_server()
        for obj in list(bpy.data.objects): bpy.data.objects.remove(obj, do_unlink=True)
        for col in list(bpy.data.collections): bpy.data.collections.remove(col)
        for mat in list(bpy.data.materials): bpy.data.materials.remove(mat)
        for mesh in list(bpy.data.meshes): bpy.data.meshes.remove(mesh)
        for curve in list(bpy.data.curves): bpy.data.curves.remove(curve)
        if C.REGISTRY in bpy.context.scene: del bpy.context.scene[C.REGISTRY]
        I.reset(); S._VALIDATED_PROFILES.clear()
        bpy.context.view_layer.update()
    def request(self, ops=None, **options):
        raw={'token':'test-token', 'scene_summary':False, 'snapshot':False,
             'undo_push':False, 'expected_session':I.state().session}
        if ops is not None: raw['ops']=ops
        raw.update(options)
        return R.run_request(P.parse(json.dumps(raw).encode(), 'test-token'))
    def ok(self, ops=None, **options):
        result=self.request(ops, **options)
        self.assertEqual(result['status'],'success', result)
        return result
    def create(self, cid='box', generator='box', params=None):
        return self.ok([{'op':'component.create','id':cid,'generator':generator,'params':params or {}}])
    def test_01_register_lifecycle(self):
        self.assertTrue(addon.ui.CyberNexusPreferences.is_registered)
        addon.unregister(); self.assertNotIn(addon.on_load,bpy.app.handlers.load_post)
        addon.register(); self.assertIn(addon.on_load,bpy.app.handlers.load_post)
    def test_02_all_generators_and_mesh_checks(self):
        cases={'box':{}, 'cylinder':{}, 'cone':{}, 'sphere':{}, 'linear_array':{},
               'slatted_panel':{}, 'extrude':{'points':[[0,0],[2,0],[2,1],[0,1]]},
               'revolve':{'points':[[0,0],[1,0],[1,1],[0,1]]},
               'tube':{'path':[[0,0,0],[0,0,1],[1,0,1]]}}
        for generator,params in cases.items():
            with self.subTest(generator=generator):
                self.create(generator,generator,params)
                r=self.ok([{'op':'check.mesh','id':generator}])
                self.assertEqual(r['validation'],'not_applicable' if generator=='tube' else 'passed',r)
    def test_03_compact_default_page_is_lossless(self):
        self.create('arr','linear_array',{'count':20})
        r=self.ok([{'op':'object.describe','id':'arr'}])['op_results'][0]['result']
        self.assertEqual(len(r['objects']),20)
        self.assertEqual(r['returned'],20); self.assertEqual(r['total'],20)
        self.assertIsNone(r['next_cursor']); self.assertIn('session',r)
        self.assertNotIn('<omitted>',json.dumps(r))
        for row in r['objects']: self.assertIn('mesh',row); self.assertEqual(len(row['dimensions']),3)
    def test_04_large_page_and_cursor_have_no_gaps(self):
        self.create('arr','linear_array',{'count':70})
        cursor=None; ids=[]
        while True:
            op={'op':'object.describe','id':'arr','limit':40}
            if cursor: op['cursor']=cursor
            page=self.ok([op])['op_results'][0]['result']
            self.assertEqual(page['returned'],len(page['objects']))
            ids.extend(row['id'] for row in page['objects'])
            cursor=page['next_cursor']
            if not cursor: break
        self.assertEqual(len(ids),70);self.assertEqual(len(set(ids)),70)
    def test_05_output_budget_stops_later_operations(self):
        self.create('arr','linear_array',{'count':128})
        for obj in C.objects('arr'): obj.name='long_name_'+('n'*180)+obj[C.ROLE]
        r=self.request([{'op':'object.describe','id':'arr','detail':'full','limit':100},
                        {'op':'component.transform','id':'arr','location':[10,0,0]}])
        self.assertEqual(r['code'],'output_budget_exceeded',r)
        self.assertEqual(len(r['op_results']),1)
        self.assertFalse(r['op_results'][0]['result']['output_complete'])
        self.assertNotIn('next_cursor',r['op_results'][0]['result'])
        self.assertEqual(tuple(C.ensure_root('arr').location),(0,0,0))
        full=self.ok([{'op':'object.describe','id':'arr','detail':'full','limit':100}],result_mode='full')
        self.assertEqual(len(full['op_results'][0]['result']['objects']),100)
    def test_06_recovery_query_after_delete(self):
        self.create(); self.ok([{'op':'component.delete','id':'box','discard_manual':True}])
        self.assertNotIn('box',C.read_only())
        r=self.ok([{'op':'component.recovery','id':'box'}])['op_results'][0]['result']
        self.assertEqual(r['total'],2)
    def test_07_delete_and_recovery_same_batch(self):
        self.create()
        r=self.ok([{'op':'component.delete','id':'box','discard_manual':True}, {'op':'component.recovery','id':'box'}])
        self.assertEqual(r['op_results'][1]['result']['total'],2)
    def test_08_recovery_purge_confirmation_and_live_safety(self):
        self.create();self.ok([{'op':'component.delete','id':'box','discard_manual':True}]);self.create()
        r=self.request([{'op':'component.recovery.purge','id':'box','confirm':False}])
        self.assertFalse(r['executed'])
        r=self.ok([{'op':'component.recovery.purge','id':'box','confirm':True}])
        self.assertEqual(r['op_results'][0]['result']['purged'],2)
        self.assertEqual(len(C.objects('box')),1)
        self.assertEqual(C.recovery('box')['total'],0)
    def test_09_long_stable_object_id(self):
        cid='x'*128;self.create(cid)
        ref=cid+'/body'
        r=self.ok([{'op':'object.describe','id':ref},{'op':'object.transform','id':ref,'location':[1,2,3]}])
        self.assertEqual(r['op_results'][0]['result']['objects'][0]['id'],ref)
    def test_10_material_name_normalization(self):
        r=self.ok([{'op':'material.pbr','name':' Metal '},
                   {'op':'component.create','id':'box','generator':'box','params':{'material':' Metal '}},
                   {'op':'material.assign','id':'box','material':' Metal '}])
        self.assertEqual(C.objects('box')[0].data.materials[0].get('cn_material_key'),'Metal')
        self.assertEqual(r['op_results'][0]['result']['key'],'Metal')
    def test_11_blank_material_fails_before_mutation(self):
        r=self.request([{'op':'material.pbr','name':'   '}])
        self.assertEqual(r['code'],'validation_error');self.assertFalse(r['executed']);self.assertEqual(len(bpy.data.materials),0)
    def test_12_nested_material_normalization_and_clear(self):
        self.ok([{'op':'material.pbr','name':'M'}, {'op':'component.create','id':'arr','generator':'linear_array',
                 'params':{'shape_params':{'material':' M '}}}])
        self.assertEqual(C.get('arr')['params']['shape_params']['material'],'M')
        self.ok([{'op':'component.update','id':'arr','params':{'shape_params':{'material':None}}},
                 {'op':'component.rebuild','id':'arr','discard_manual':True}])
        for obj in C.objects('arr'):self.assertEqual(len(obj.material_slots),0)
    def test_13_collection_failure_compensates_live_data(self):
        self.create();body=C.objects('box')[0];ptr=body.as_pointer();data=body.data;raw=bpy.context.scene[C.REGISTRY]
        self.ok([{'op':'component.update','id':'box','params':{'size':[2,2,2]}}]);pending_raw=bpy.context.scene[C.REGISTRY]
        def fail(col,record,rename):
            col[C.OWNER]='corrupted';col.name='injected-name';raise RuntimeError('injected collection metadata failure')
        with patch.object(C,'_set_collection_metadata',fail):
            r=self.request([{'op':'component.rebuild','id':'box','discard_manual':True}])
        self.assertEqual(r['status'],'error');self.assertTrue(r['commit_recovery']['compensation_clean'])
        self.assertEqual(C.objects('box')[0].as_pointer(),ptr);self.assertEqual(body.data,data)
        self.assertEqual(bpy.context.scene[C.REGISTRY],pending_raw)
        self.assertTrue(any(c.name=='CN · box' and c.get(C.OWNER)==C.get('box')['owner'] for c in body.users_collection))
        self.assertFalse(any(c.name.startswith('__CNStage_') for c in bpy.data.collections))
    def test_14_registry_write_failure_compensates(self):
        self.create();body=C.objects('box')[0];data=body.data
        self.ok([{'op':'component.update','id':'box','params':{'size':[2,2,2]}}])
        raw=bpy.context.scene[C.REGISTRY]
        with patch.object(C,'setattr_scene_registry',side_effect=RuntimeError('injected registry failure')):
            r=self.request([{'op':'component.rebuild','id':'box','discard_manual':True}])
        self.assertEqual(r['status'],'error');self.assertTrue(r['commit_recovery']['compensation_clean'])
        self.assertEqual(body.data,data);self.assertEqual(bpy.context.scene[C.REGISTRY],raw)
    def test_15_cleanup_failure_is_committed_warning(self):
        self.create();self.ok([{'op':'component.update','id':'box','params':{'size':[2,2,2]}}])
        with patch.object(C,'_remove_object',side_effect=RuntimeError('injected cleanup failure')):
            r=self.ok([{'op':'component.rebuild','id':'box','discard_manual':True}])
        result=r['op_results'][0]['result'];self.assertTrue(result['committed']);self.assertTrue(result['warnings'])
        self.assertEqual(C.get('box')['generation'],2)
    def test_16_committed_journal_cannot_claim_rollback(self):
        j=Journal();state=[];j.step(lambda:state.append(1),lambda:state.clear());j.commit()
        self.assertTrue(j.rollback());self.assertEqual(state,[1])
        with self.assertRaises(RuntimeError):j.step(lambda:None,lambda:None)
    def test_17_preflight_timeout_is_not_executed(self):
        def expensive(ops):
            while True: pass
        old=sys.gettrace()
        with patch.object(O,'validate',expensive): r=self.request([{'op':'scene.overview'}],timeout=0.02)
        self.assertEqual(r['code'],'preflight_timeout');self.assertFalse(r['executed']);self.assertIs(sys.gettrace(),old)
        self.assertFalse(I.BUSY)
    def test_18_execution_timeout_and_trace_cleanup(self):
        r=self.request(code='while True:\n    pass',timeout=0.02)
        self.assertEqual(r['code'],'execution_timeout');self.assertTrue(r['executed']);self.assertFalse(I.BUSY)
        self.assertIsNone(sys.gettrace())
    def test_19_reflected_root_attach_is_rejected(self):
        self.create('a');self.create('b');self.ok([{'op':'component.transform','id':'a','scale':[-1,1,1]}])
        r=self.request([{'op':'component.attach','id':'a','target':'b'}])
        self.assertEqual(r['status'],'error');self.assertLess(C.ensure_root('a').matrix_world.to_3x3().determinant(),0)
    def test_20_sheared_root_attach_is_rejected(self):
        self.create('a');self.create('b');root=C.ensure_root('a')
        root.matrix_world=Matrix(((1,0.25,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1)))
        r=self.request([{'op':'component.attach','id':'a','target':'b'}]);self.assertEqual(r['status'],'error')
    def test_21_rigid_attach_and_local_dimensions(self):
        self.create('a',params={'size':[2,3,4],'rotation_euler':[0.2,0.3,0.7]});self.create('b')
        self.ok([{'op':'component.transform','id':'b','location':[5,6,7],'rotation_euler':[0.1,0.2,0.3]},
                 {'op':'component.attach','id':'a','target':'b'}])
        r=self.ok([{'op':'check.dimensions','id':'a','space':'local','target':[2,3,4],'tolerance':1e-4}])
        self.assertEqual(r['validation'],'passed',r)
        self.ok([{'op':'component.transform','id':'a','scale':[2,3,4]}])
        with self.assertRaises(ValueError):I.local_bbox('a',C.objects('a'))  # parent nonuniform scale + body rotation produces shear
        self.create('scaled',params={'size':[2,3,4]})
        r=self.ok([{'op':'component.transform','id':'scaled','scale':[2,3,4]}, {'op':'check.dimensions','id':'scaled','space':'local','target':[4,9,16]}])
        self.assertEqual(r['validation'],'passed',r)
    def test_22_request_geometry_budget_rejects_without_allocating(self):
        r=self.request([{'op':'component.create','id':'heavy','generator':'linear_array',
                         'params':{'count':128,'shape':'sphere','shape_params':{'segments':256,'rings':256}}}])
        self.assertEqual(r['code'],'validation_error');self.assertFalse(r['executed']);self.assertEqual(len(bpy.data.objects),0)
    def test_23_archive_limit_and_purge(self):
        self.create()
        with patch.dict(L.LIMITS,{'archived_objects':1}):
            r=self.request([{'op':'component.delete','id':'box','discard_manual':True}])
        self.assertEqual(r['code'],'validation_error');self.assertFalse(r['executed']);self.assertIn('box',C.read_only())
    def test_24_managed_scene_peak_guard(self):
        self.create()
        with patch.dict(L.LIMITS,{'managed_scene_peak_cost':20}):r=self.request([{'op':'component.create','id':'second','generator':'box'}])
        self.assertEqual(r['code'],'validation_error');self.assertNotIn('second',C.read_only())
    def test_25_chord_error_and_profile_translation(self):
        p=S.generator_params('cylinder',{'radius':1,'vertices':3,'max_chord_error':0.001})
        self.assertLessEqual(1-math.cos(math.pi/p['vertices']),0.001+1e-12)
        local=[[0,0],[0.001,0],[0.001,0.001],[0,0.001]]
        distant=[[x+1e6,y+1e6] for x,y in local]
        a=S.generator_params('extrude',{'points':local});b=S.generator_params('extrude',{'points':distant})
        self.assertAlmostEqual(S.profile_area2(a['points']),S.profile_area2(b['points']),places=10)
        for shift in (0,1e6):
            with self.assertRaises(ValueError):S.generator_params('extrude',{'points':[[shift,0],[shift+1,1],[shift,1],[shift+1,0]]})
    def test_26_rebuild_roles_and_obsolete_recovery(self):
        self.create('arr','linear_array',{'count':4});old={o[C.ROLE]:o.as_pointer() for o in C.objects('arr')}
        self.ok([{'op':'component.update','id':'arr','params':{'count':2}}, {'op':'component.rebuild','id':'arr','discard_manual':True}])
        self.assertEqual(C.recovery('arr')['total'],2)
        for obj in C.objects('arr'):self.assertEqual(obj.as_pointer(),old[obj[C.ROLE]])
    def test_27_protocol_and_stale_cursor_rejection(self):
        for packet in (b'{"token":"test-token","code":"","code":"x"}',b'{"token":"wrong","code":""}',b'{"token":"test-token","code":"","timeout":NaN}'):
            with self.assertRaises(P.RequestError):P.parse(packet,'test-token')
        self.create('arr','linear_array',{'count':4})
        page=self.ok([{'op':'object.describe','id':'arr','limit':2}])['op_results'][0]['result']
        self.ok([{'op':'component.transform','id':'arr','location':[1,0,0]}])
        r=self.request([{'op':'object.describe','id':'arr','limit':2,'cursor':page['next_cursor']}]);self.assertEqual(r['status'],'error')
    def test_28_revision_and_scene_binding_rejections(self):
        r=self.request([{'op':'component.create','id':'x','generator':'box'}],expected_rev=99)
        self.assertEqual(r['code'],'revision_conflict');self.assertFalse(r['executed'])
        r=self.request([{'op':'component.create','id':'x','generator':'box'}],expected_session='other')
        self.assertEqual(r['code'],'scene_changed');self.assertFalse(r['executed'])
    def test_29_capabilities_are_not_recursively_truncated(self):
        r=self.ok([{'op':'system.capabilities','operations':list(S.OPERATIONS),'generators':list(S.GENERATORS)}])
        caps=r['op_results'][0]['result'];self.assertEqual(caps['schema_version'],'1.3.7')
        self.assertEqual(set(caps['operations']),set(S.OPERATIONS));self.assertNotIn('<omitted>',json.dumps(caps))
    def test_30_mesh_precision_and_multi_component_alignment(self):
        self.create('a','slatted_panel');self.create('b','linear_array',{'count':3})
        r=self.ok([{'op':'objects.align','ids':['a','b'],'axis':'X','mode':'MIN','coordinate':0},
                   {'op':'check.mesh','id':'a'}])
        self.assertEqual(r['validation'],'passed')
        self.assertAlmostEqual(I.combined_bbox(C.objects('a'))[0][0],0,places=5)
        self.assertAlmostEqual(I.combined_bbox(C.objects('b'))[0][0],0,places=5)
    def test_31_network_token_dedup_conflict_and_receipt(self):
        server=R.start_server(0)
        def rpc(raw):
            raw={'token':server.token,'scene_summary':False,'snapshot':False,'undo_push':False,**raw}
            received={}
            def client():
                try:
                    with socket.create_connection(('127.0.0.1',server.port),timeout=3) as sock:
                        sock.sendall(json.dumps(raw).encode()+b'\n');data=b''
                        while not data.endswith(b'\n'):
                            chunk=sock.recv(65536)
                            if not chunk:break
                            data+=chunk
                        received['value']=json.loads(data)
                except Exception as exc:received['error']=exc
            thread=threading.Thread(target=client);thread.start();end=time.monotonic()+4
            while thread.is_alive() and time.monotonic()<end:server.tick();time.sleep(0.002)
            thread.join(timeout=0.1)
            self.assertFalse(thread.is_alive());self.assertNotIn('error',received)
            return received['value']
        try:
            raw={'request_id':'stable-id','expected_session':I.state().session,
                 'ops':[{'op':'component.create','id':'netbox','generator':'box'}]}
            first=rpc(raw);self.assertEqual(first['status'],'success',first)
            second=rpc(raw);self.assertEqual(first,second);self.assertEqual(C.get('netbox')['generation'],1)
            bad=rpc({**raw,'ops':[{'op':'component.create','id':'another','generator':'box'}]})
            self.assertEqual(bad['code'],'request_id_conflict');self.assertNotIn('another',C.read_only())
            server.pump.cache.clear();server.pump.cache_bytes=0  # test-only after no active clients
            old=rpc(raw);self.assertTrue(old['response_details_expired']);self.assertEqual(C.get('netbox')['generation'],1)
            denied=rpc({'token':'wrong','ops':[{'op':'scene.overview'}]});self.assertEqual(denied['status'],'error')
        finally:R.stop_server()
    def test_32_receipt_preserves_execution_state(self):
        r=self.request([{'op':'scene.overview'}],expected_session='wrong')
        saved=json.loads(receipt(P.encode_response(r)))
        self.assertFalse(saved['executed']);self.assertEqual(saved['execution_state'],'not_executed')
    def test_34_object_material_override_rebuild_and_compensation(self):
        self.ok([{'op':'material.pbr','name':'old'},{'op':'material.pbr','name':'new'},
                 {'op':'component.create','id':'box','generator':'box','params':{'material':'old'}}])
        obj=C.objects('box')[0];old=obj.material_slots[0].material
        obj.material_slots[0].link='OBJECT';obj.material_slots[0].material=old
        self.ok([{'op':'component.update','id':'box','params':{'material':'new'}}])
        with patch.object(C,'_set_collection_metadata',side_effect=RuntimeError('injected failure')):
            r=self.request([{'op':'component.rebuild','id':'box','discard_manual':True}])
        self.assertTrue(r['commit_recovery']['compensation_clean'])
        self.assertEqual(obj.material_slots[0].link,'OBJECT');self.assertEqual(obj.material_slots[0].material,old)
        self.ok([{'op':'component.rebuild','id':'box','discard_manual':True}])
        self.assertEqual(obj.material_slots[0].link,'DATA');self.assertEqual(obj.material_slots[0].material.get('cn_material_key'),'new')
        self.ok([{'op':'component.update','id':'box','params':{'material':None}},{'op':'component.rebuild','id':'box','discard_manual':True}])
        self.assertEqual(len(obj.material_slots),0)
    def test_35_local_frame_rejects_reflection_instead_of_wrong_dimensions(self):
        self.create();self.ok([{'op':'component.transform','id':'box','scale':[-1,1,1]}])
        r=self.request([{'op':'check.dimensions','id':'box','space':'local','target':[1,1,1]}])
        self.assertEqual(r['status'],'error');self.assertIn('non-reflected',r['traceback'])
        r=self.ok([{'op':'check.dimensions','id':'box','space':'world','target':[1,1,1]}])
        self.assertEqual(r['validation'],'passed')
    def test_36_submicron_checks_preserve_measured_numbers(self):
        self.create('tiny',params={'size':[2e-7,2e-7,2e-7]})
        r=self.ok([{'op':'check.dimensions','id':'tiny','target':[2e-7,2e-7,2e-7],'tolerance':1e-12}])
        measured=r['op_results'][0]['result'];self.assertTrue(measured['pass'])
        self.assertGreater(measured['actual'][0],0);self.assertAlmostEqual(measured['actual'][0],2e-7,places=12)
        self.assertEqual(measured['tolerance'],1e-12);self.assertLessEqual(measured['max_error'],1e-12)
        self.create('other',params={'size':[2e-7,2e-7,2e-7],'location':[4e-7,0,0]})
        r=self.ok([{'op':'check.clearance','a':'tiny','b':'other','minimum':1e-7}])
        self.assertGreater(r['op_results'][0]['result']['aabb_distance'],1e-7)
    def test_37_standard_library_agent_client(self):
        from cn137_test.examples import agent_client as client
        server=R.start_server(0)
        try:
            connection=client.load_connection(R.connection_paths()[1])
            payload=client.make_request([{'op':'scene.overview'}])
            saved=json.dumps(payload,sort_keys=True);received={}
            def worker():
                try:received['value']=client.send_request(connection,payload,socket_timeout=3)
                except Exception as exc:received['error']=exc
            thread=threading.Thread(target=worker);thread.start();end=time.monotonic()+4
            while thread.is_alive() and time.monotonic()<end:server.tick();time.sleep(0.002)
            thread.join(timeout=0.1);self.assertFalse(thread.is_alive());self.assertNotIn('error',received)
            self.assertEqual(received['value']['status'],'success');self.assertEqual(json.dumps(payload,sort_keys=True),saved)
        finally:R.stop_server()
    def test_38_global_response_limit_preserves_ops_or_reports_error(self):
        operations=[{'index':0,'op':'scene.overview','result':{'components':[],'returned':0,'total':0,'next_cursor':None}}]
        payload={'status':'success','code':'ok','executed':True,'execution_state':'completed',
                 'request_id':'limit-test','op_results':operations,'scene_summary':{'huge':'x'*5000}}
        with patch.object(P,'MAX_RESPONSE',2048):
            decoded=json.loads(P.encode_response(payload))
        self.assertEqual(decoded['op_results'],operations);self.assertEqual(decoded['status'],'success')
        self.assertIsNone(decoded['scene_summary']);self.assertIn('scene_summary_error',decoded)
        payload['op_results']=[{'result':'x'*5000}]
        with patch.object(P,'MAX_RESPONSE',2048):
            decoded=json.loads(P.encode_response(payload))
        self.assertEqual(decoded['status'],'error');self.assertEqual(decoded['code'],'response_too_large')
        self.assertFalse(decoded['response_details_complete']);self.assertTrue(decoded['executed'])
    def test_33_undo_redo_if_available(self):
        if not bpy.ops.ed.undo.poll():self.skipTest('headless bpy has no usable GUI undo context')
        bpy.ops.ed.undo_push(message='before fixture')
        self.create()
        self.ok([{'op':'component.transform','id':'box','location':[5,0,0]}],undo_push=True)
        bpy.ops.ed.undo()
        I.reset()
        self.assertAlmostEqual(C.ensure_root('box').location.x,0)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(RegressionTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'blender':bpy.app.version_string,'mode':'real bpy headless integration, not stubs',
            'tests_run':result.testsRun,'failures':[(str(t),e) for t,e in result.failures],
            'errors':[(str(t),e) for t,e in result.errors], 'skipped':[(str(t),reason) for t,reason in result.skipped]}
    pathlib.Path(__file__).with_name('test_results_137.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    sys.exit(not result.wasSuccessful())
