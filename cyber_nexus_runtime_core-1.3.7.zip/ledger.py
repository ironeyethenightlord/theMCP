"""Small non-evicting execution ledger, separate from expendable asset cache.
Process-local only. Full capacity refuses NEW IDs rather than losing dedupe records.
"""
import json
import time
from collections import OrderedDict
from . import protocol as P


class LedgerFull(RuntimeError):
    pass


def receipt(encoded):
    response = json.loads(encoded)
    keep = ("status", "code", "request_id", "session", "rev", "validation", "checks",
            "failed_op_index", "undo_push_applied", "message", "execution_state", "commit_recovery", "response_details_complete", "op_results_omitted")
    out = {key: response[key] for key in keep if key in response}
    out.update(image=None, images=[], executed=response.get("executed", response.get("code") not in {
        "validation_error", "preflight_timeout", "scene_changed", "scene_binding_required", "revision_conflict", "request_expired"}),
               response_details_expired=True, assets_expired=bool(response.get("images") or response.get("image")))
    for key in ("stdout", "traceback", "result", "note"):
        if response.get(key):
            out[key] = P.truncate(response[key], 384)
    if response.get("issues"):
        out["issues"] = response["issues"][:3]
    out["message"] = P.truncate(str(out.get("message", "")) + " Original response evicted; request is NOT re-executed. Query scene/details if needed.", 1024)
    data = P.encode_response(out)
    if len(data) > 4096:
        for key in ("issues", "checks", "stdout", "traceback", "result", "note"):
            out.pop(key, None)
        data = P.encode_response(out)
    return data


class ExecutionLedger:
    def __init__(self, max_entries=4096, ttl=3600, clock=time.monotonic):
        self.max_entries, self.ttl, self.clock = max_entries, ttl, clock
        self.entries = OrderedDict()

    def prune(self):
        now = self.clock()
        for rid in list(self.entries):
            entry = self.entries[rid]
            # Never expire an outstanding job, including a native call hung for hours.
            if entry["state"] == "completed" and now >= entry["expires"]:
                del self.entries[rid]

    def lookup(self, rid):
        self.prune()
        return self.entries.get(rid)

    def reserve(self, rid, fingerprint):
        self.prune()
        if rid in self.entries:
            raise ValueError("request ID already reserved")
        if len(self.entries) >= self.max_entries:
            raise LedgerFull("execution ledger full; new request refused, nothing executed")
        self.entries[rid] = {"fingerprint": fingerprint, "state": "queued", "receipt": None, "expires": None}

    def complete(self, rid, encoded):
        entry = self.entries[rid]
        entry.update(state="completed", receipt=receipt(encoded), expires=self.clock()+self.ttl)
