"""Revision-bound cursors and field projection, independent of Blender."""
import base64
import hashlib
import json


def _key(query):
    return hashlib.sha256(json.dumps(query, sort_keys=True, ensure_ascii=True).encode()).hexdigest()[:20]


def page(items, limit, cursor, session, rev, query):
    offset = 0
    if cursor:
        try:
            if len(cursor) > 1024:
                raise ValueError()
            raw = json.loads(base64.urlsafe_b64decode(cursor.encode()).decode())
            if raw["session"] != session or raw["rev"] != rev or raw["query"] != _key(query):
                raise ValueError()
            offset = raw["offset"]
            if type(offset) is not int or not 0 <= offset <= len(items):
                raise ValueError()
        except Exception:
            raise ValueError(
                "invalid/stale cursor: session, revision or the query parameters differ from the "
                "call that produced it; repeat the identical query (same prefix/under/detail/fields) "
                "or restart without cursor") from None
    chunk = items[offset:offset+limit]
    next_cursor = None
    if offset+len(chunk) < len(items):
        raw = {"session": session, "rev": rev, "query": _key(query), "offset": offset+len(chunk)}
        next_cursor = base64.urlsafe_b64encode(json.dumps(raw, separators=(",", ":")).encode()).decode()
    return chunk, {"returned": len(chunk), "total": len(items), "next_cursor": next_cursor,
                   "session": session, "rev": rev}


def project(data, fields=None, brief=(), mandatory=("id",)):
    if fields is not None:
        unknown = set(fields)-set(data)
        if unknown:
            raise ValueError("unknown query fields: " + str(sorted(unknown)))
        selected = set(fields) | set(mandatory)
    else:
        selected = set(brief) | set(mandatory) if brief else set(data)
    return {k: v for k, v in data.items() if k in selected}
