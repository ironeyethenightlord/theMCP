"""Network thread owns sockets; bpy execution exclusively on timer/main thread.
Authenticated Python has full process privileges. Tracing is NOT a sandbox/kill switch.
"""
import atexit
import builtins
import contextlib
import json
import math
import os
import queue
import secrets
import selectors
import socket
import sys
import tempfile
import threading
import time
import traceback
from collections import OrderedDict
import bmesh
import bpy
import mathutils
from mathutils import Vector
from . import protocol as P, inspect as I, operations as O, components as C, preview
from .helpers import CyberHelper, cyber_helper, window_context
from . import schema as S
from .ledger import ExecutionLedger, LedgerFull
from .transaction import CommitFailure

SERVER_KEY = "__CYBER_NEXUS_RUNTIME_SERVER_V2__"
HOST, DEFAULT_PORT = "127.0.0.1", 8192
CONNECTION_DIR = os.path.join(os.path.expanduser("~"), ".cyber_nexus")
USER_FILENAME = "<CyberNexus agent code>"


def connection_paths():
    return [os.path.join(CONNECTION_DIR, "connection.json"),
            os.path.join(CONNECTION_DIR, f"connection-{os.getpid()}.json")]


def write_connection(server):
    os.makedirs(CONNECTION_DIR, mode=0o700, exist_ok=True)
    if os.name == "posix":
        os.chmod(CONNECTION_DIR, 0o700)
    payload = {"protocol_version": 5, "host": HOST, "port": server.port, "token": server.token,
               "pid": os.getpid(), "instance_id": server.instance_id, "blend_file": bpy.data.filepath,
               "started_at": server.started_at, "extension_version": "1.3.7", "scene_session": I.state().session}
    text = json.dumps(payload, ensure_ascii=True, indent=2)+"\n"
    for path in connection_paths():
        fd, temporary = tempfile.mkstemp(prefix=".connection-", suffix=".tmp", dir=CONNECTION_DIR)
        try:
            if os.name == "posix":
                os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                fd = None
                handle.write(text)
            os.replace(temporary, path)
        finally:
            if fd is not None:
                os.close(fd)
            with contextlib.suppress(OSError):
                os.unlink(temporary)


def remove_connection(server):
    for path in connection_paths():
        try:
            with open(path, encoding="utf-8") as handle:
                payload = json.load(handle)
            if payload.get("token") == server.token and payload.get("instance_id") == server.instance_id:
                os.unlink(path)
        except (OSError, ValueError, AttributeError):
            pass


class Client:
    def __init__(self, sock):
        self.sock, self.buffer = sock, bytearray()
        self.phase, self.outbound, self.sent = "read", b"", 0
        self.created = time.monotonic()
        self.deadline = self.created+8


class NetworkPump(threading.Thread):
    """All fields below (except queues/Event/error) belong exclusively to this thread."""
    def __init__(self, listener, token, jobs, results):
        super().__init__(name="CyberNexus TCP", daemon=True)
        self.listener, self.token, self.jobs, self.results = listener, token, jobs, results
        self.stop_event = threading.Event()
        self.error = ""
        self.clients, self.pending, self.cache = {}, {}, OrderedDict()
        self.cache_bytes = 0
        self.ledger = ExecutionLedger()
        self.current_session = None  # Main thread publishes a string; no bpy in this thread.
        self.selector = selectors.DefaultSelector()

    def drop(self, client):
        self.clients.pop(client.sock, None)
        with contextlib.suppress(Exception):
            self.selector.unregister(client.sock)
        with contextlib.suppress(OSError):
            client.sock.close()

    def output(self, client, encoded):
        if client.sock not in self.clients:
            return
        client.outbound, client.sent, client.phase = encoded, 0, "write"
        client.deadline = time.monotonic()+8
        try:
            self.selector.modify(client.sock, selectors.EVENT_WRITE, client)
        except KeyError:
            self.selector.register(client.sock, selectors.EVENT_WRITE, client)

    def prune(self):
        now = time.monotonic()
        for rid in list(self.cache):
            fp, data, expiry = self.cache[rid]
            if now >= expiry:
                del self.cache[rid]
                self.cache_bytes -= len(data)
        while len(self.cache) > 32 or self.cache_bytes > 8*1024*1024:
            _, (_, data, _) = self.cache.popitem(last=False)
            self.cache_bytes -= len(data)

    def submit(self, client, packet):
        try:
            request = P.parse(packet, self.token)
        except P.RequestError as exc:
            self.output(client, P.encode_response(P.error(str(exc))))
            return
        except Exception:
            self.output(client, P.encode_response(P.error("invalid request")))
            return
        rid, fp = request["request_id"], P.fingerprint(request)
        self.prune()
        entry = self.ledger.lookup(rid) if rid else None
        if entry is not None:
            if entry["fingerprint"] != fp:
                self.output(client, P.encode_response(P.error("request_id content conflict", "request_id_conflict", rid)))
                return
            if entry["state"] == "completed":
                cached = self.cache.get(rid)
                if cached is not None:
                    self.cache.move_to_end(rid)
                self.output(client, cached[1] if cached else entry["receipt"])
                return
            for pending_fp, waiters, pending_rid in self.pending.values():
                if pending_rid == rid:
                    waiters.append(client)
                    client.phase, client.deadline = "wait", time.monotonic()+1800
                    self.selector.unregister(client.sock)
                    return
            self.output(client, P.encode_response(P.error("request accepted; execution state unknown, not re-executed", "execution_unknown", rid)))
            return
        try:
            P.check_fresh(request)
        except P.RequestError as exc:
            self.output(client, P.encode_response(P.error(str(exc), "request_expired", rid)))
            return
        if len(self.pending) >= 32:
            self.output(client, P.encode_response(P.error("request queue full; nothing executed", "busy", rid)))
            return
        job_id = secrets.token_hex(12)
        request["_admitted_session"] = self.current_session
        if rid:
            try:
                self.ledger.reserve(rid, fp)
            except LedgerFull as exc:
                self.output(client, P.encode_response(P.error(str(exc), "busy", rid)))
                return
        try:
            self.jobs.put_nowait((job_id, request))
        except queue.Full:
            if rid:
                self.ledger.entries.pop(rid, None)
            self.output(client, P.encode_response(P.error("request queue full; nothing executed", "busy", rid)))
            return
        self.pending[job_id] = (fp, [client], rid)
        client.phase, client.deadline = "wait", time.monotonic()+1800
        self.selector.unregister(client.sock)

    def read(self, client):
        now = time.monotonic()
        if now >= client.deadline or now-client.created >= 30:
            self.drop(client)
            return
        for _ in range(16):
            try:
                chunk = client.sock.recv(min(65536, P.MAX_PACKET+16-len(client.buffer)))
            except (BlockingIOError, InterruptedError):
                return
            except OSError:
                self.drop(client)
                return
            if not chunk:
                if client.buffer.strip():
                    self.submit(client, bytes(client.buffer).strip())
                else:
                    self.drop(client)
                return
            client.buffer.extend(chunk)
            client.deadline = time.monotonic()+8
            newline = client.buffer.find(b"\n")
            if newline >= 0:
                if client.buffer[newline+1:].strip():
                    self.output(client, P.encode_response(P.error("one request per connection")))
                else:
                    self.submit(client, bytes(client.buffer[:newline]).rstrip(b"\r"))
                client.buffer.clear()
                return
            if len(client.buffer) > P.MAX_PACKET:
                self.output(client, P.encode_response(P.error("request exceeds 1 MiB or missing newline")))
                return

    def write(self, client):
        if time.monotonic() >= client.deadline:
            self.drop(client)
            return
        try:
            sent = client.sock.send(memoryview(client.outbound)[client.sent:client.sent+262144])
        except (BlockingIOError, InterruptedError):
            return
        except OSError:
            self.drop(client)
            return
        if sent <= 0:
            self.drop(client)
            return
        client.sent += sent
        if client.sent == len(client.outbound):
            self.drop(client)

    def accept(self):
        for _ in range(16):
            try:
                sock, address = self.listener.accept()
            except (BlockingIOError, InterruptedError):
                return
            if address[0] != HOST or len(self.clients) >= 16:
                sock.close()
                continue
            sock.setblocking(False)
            client = Client(sock)
            self.clients[sock] = client
            self.selector.register(sock, selectors.EVENT_READ, client)

    def completed(self):
        for _ in range(32):
            try:
                job_id, encoded = self.results.get_nowait()
            except queue.Empty:
                return
            pending = self.pending.pop(job_id, None)
            if pending is None:
                continue
            fp, clients, rid = pending
            if rid is not None:
                self.ledger.complete(rid, encoded)
                self.cache[rid] = (fp, encoded, time.monotonic()+600)
                self.cache_bytes += len(encoded)
                self.prune()
            for client in clients:
                if client.sock in self.clients:
                    self.output(client, encoded)

    def run(self):
        try:
            self.selector.register(self.listener, selectors.EVENT_READ, None)
            while not self.stop_event.is_set():
                self.completed()
                self.prune()
                now = time.monotonic()
                for client in list(self.clients.values()):
                    if now >= client.deadline or (client.phase == "read" and now-client.created >= 30):
                        self.drop(client)
                for key, mask in self.selector.select(0.02):
                    if key.data is None:
                        self.accept()
                    elif key.data.sock in self.clients:
                        self.read(key.data) if mask & selectors.EVENT_READ else self.write(key.data)
        except Exception as exc:
            self.error = f"{type(exc).__name__}: {exc}"
        finally:
            for client in list(self.clients.values()):
                self.drop(client)
            with contextlib.suppress(Exception):
                self.selector.unregister(self.listener)
            self.listener.close()
            self.selector.close()
            self.pending.clear()
            self.cache.clear()
        self.ledger.entries.clear()


def safe_result(value, depth=0, budget=None):
    """Never call user-defined repr/iteration; bound aggregate nodes and string data."""
    budget = [128, 8192] if budget is None else budget
    budget[0] -= 1
    if budget[0] < 0 or depth > 5:
        return "<limit>"
    kind = type(value)
    if value is None or kind is bool:
        return value
    if kind is str:
        size = min(2048, max(0, budget[1]))
        budget[1] -= min(len(value), size)
        return P.truncate(value, size)
    if kind is int:
        return value if value.bit_length() <= 1024 else "<large integer>"
    if kind is float:
        return value if math.isfinite(value) else str(value)
    if kind in (list, tuple):
        out = []
        for item in value[:32]:
            if budget[0] <= 0:
                break
            out.append(safe_result(item, depth+1, budget))
        if len(out) < len(value):
            out.append("<items omitted>")
        return out
    if kind is dict:
        out = {}
        for i, (key, item) in enumerate(value.items()):
            if i >= 32 or budget[0] <= 0:
                out["<omitted>"] = True
                break
            if type(key) is not str:
                key = "<non-string key " + str(i) + ">"
            out[P.truncate(key, 128)] = safe_result(item, depth+1, budget)
        return out
    return "<non-JSON object; query explicitly>"


def deadline_tracer(deadline):
    def trace(frame, event, arg):
        if time.monotonic() > deadline:
            raise P.CodeTimeout("Python time budget exceeded; scene may be partially modified")
        return trace
    return trace


def request_traceback(request):
    """Keep model-facing errors short by default; full mode is intended for debugging."""
    limit = 4096 if request.get("result_mode", "compact") == "compact" else P.MAX_TEXT
    return P.truncate(traceback.format_exc(), limit)


def undo_checkpoint(label):
    if bpy.context.mode != "OBJECT":
        return False
    try:
        # modal_operators lives on the WindowManager; iterating windows never found it.
        if any(getattr(bpy.context.window_manager, "modal_operators", ())):
            return False
        with window_context():
            return "FINISHED" in bpy.ops.ed.undo_push(message=label)
    except Exception:
        return False


def run_request(request):
    started = time.perf_counter()
    deadline = time.monotonic()+request["timeout"]
    st = I.flush_external()
    start_rev, start_session = st.rev, st.session
    rid = request.get("request_id")
    mutating_request = "code" in request or any(op.get("op") in S.MUTATIONS for op in request.get("ops", []))
    admitted = request.get("_admitted_session")
    if (admitted is not None and admitted != st.session) or (request.get("expected_session") is not None and request["expected_session"] != st.session):
        result = P.error("scene changed; nothing executed", "scene_changed", rid)
        result.update(session=st.session, rev=st.rev, executed=False, execution_state="not_executed")
        return result
    if mutating_request and request.get("expected_session") is None:
        result = P.error("mutation/code requires expected_session; query overview first", "scene_binding_required", rid)
        result.update(session=st.session, rev=st.rev, executed=False, execution_state="not_executed")
        return result
    try:
        P.check_fresh(request)
    except P.RequestError as exc:
        result = P.error(str(exc), "request_expired", rid)
        result.update(rev=st.rev, session=st.session, executed=False, execution_state="not_executed")
        return result
    if request.get("expected_rev") is not None and (request["expected_rev"] != st.rev or request["expected_session"] != st.session):
        result = P.error("scene revision/session changed; nothing executed", "revision_conflict", rid)
        result.update(rev=st.rev, session=st.session, executed=False, execution_state="not_executed")
        return result
    preflight_started = time.perf_counter()
    preflight_trace = sys.gettrace()
    try:
        sys.settrace(deadline_tracer(deadline))
        compiled = compile(request["code"], USER_FILENAME, "exec") if "code" in request else None
        if "ops" in request:
            request["ops"] = O.validate(request["ops"])
    except (Exception, P.CodeTimeout) as exc:
        timed_out = isinstance(exc, P.CodeTimeout)
        result = P.error("preflight deadline exceeded; nothing executed" if timed_out else
                         "compile/operation validation failed; nothing executed",
                         "preflight_timeout" if timed_out else "validation_error", rid)
        result["traceback"] = request_traceback(request)
        result.update(rev=st.rev, session=st.session, executed=False, execution_state="not_executed")
        return result
    finally:
        sys.settrace(preflight_trace)
    preflight_elapsed_ms = int((time.perf_counter()-preflight_started)*1000)
    response = {"status": "success", "code": "ok", "request_id": rid,
                "stdout": "", "traceback": "", "result": None, "result_json": None,
                "image": None, "images": [], "snapshot_error": None, "scene_summary": None,
                "scene_summary_error": None, "op_results": [], "note": "", "undo_push_applied": False,
                "preflight_elapsed_ms": preflight_elapsed_ms,
                "exec_elapsed_ms": 0, "snapshot_elapsed_ms": 0, "summary_elapsed_ms": 0,
                "executed": True, "execution_state": "completed", "validation": "unchecked",
                "checks": {"passed": 0, "failed": 0, "inconclusive": 0, "not_applicable": 0}, "issues": []}
    output = P.BoundedOutput()
    old_trace = sys.gettrace()
    mutated, failed_index = False, None
    I.BUSY = True
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output), window_context():
            exec_start = time.perf_counter()
            sys.settrace(deadline_tracer(deadline))
            try:
                if compiled is not None:
                    # Conservative: arbitrary code may mutate even if it later throws.
                    mutated = True
                    ns = {"__name__": "__cyber_nexus_agent__", "__package__": None,
                          "__builtins__": builtins.__dict__, "bpy": bpy, "bmesh": bmesh,
                          "mathutils": mathutils, "Vector": Vector, "math": math,
                          "CyberHelper": CyberHelper, "cyber_helper": cyber_helper,
                          "components": C}
                    exec(compiled, ns, ns)
                    if "result" in ns:
                        # Disable expensive recursion by bounded builtin-only formatting.
                        value = safe_result(ns["result"])
                        response["result_json"] = value
                        response["result"] = P.truncate(repr(value), 4096 if request.get("result_mode", "compact") == "compact" else 16384)
                else:
                    compact = request.get("result_mode", "compact") == "compact"
                    result_budget = 256*1024 if compact else 2*1024*1024
                    for index, op in enumerate(request["ops"]):
                        failed_index = index
                        is_mutation = op["op"] in O.MUTATIONS
                        mutated |= is_mutation
                        op_result = O.run(op)
                        if op["op"].startswith("check."):
                            check_status = op_result.get("status", "inconclusive")
                            response["checks"][check_status] += 1
                            for issue in op_result.get("issues", []):
                                if len(response["issues"]) < 20:
                                    response["issues"].append({"op_index": index, **issue})
                        # Built-in structured operations return exact JSON. Never
                        # use safe_result() here: it would corrupt pages and cursors.
                        wire_result = op_result
                        result_size = len(json.dumps(wire_result, ensure_ascii=True, allow_nan=False).encode("ascii"))
                        per_op_limit = 64*1024 if compact else 512*1024
                        allowed = min(per_op_limit, result_budget)
                        if result_size > allowed:
                            response["op_results"].append({"index": index, "op": op["op"], "result": {
                                "output_complete": False, "code": "output_budget_exceeded",
                                "original_bytes": result_size, "allowed_bytes": allowed,
                                "retry_input_cursor": op.get("cursor"),
                                "retry": "Repeat this READ with smaller limit/fields or result_mode=full. Do not advance the cursor or repeat already-applied mutations."}})
                            response.update(status="error", code="output_budget_exceeded", execution_state="partial_batch", failed_op_index=index,
                                            note="Operation ran but its result exceeded the output budget; later operations were NOT executed. Earlier mutations may remain.")
                            bpy.context.view_layer.update()
                            break
                        result_budget -= result_size
                        response["op_results"].append({"index": index, "op": op["op"], "result": wire_result})
                        bpy.context.view_layer.update()
                    else:
                        failed_index = None
            except BaseException as exc:
                response.update(status="error", code="execution_timeout" if isinstance(exc, P.CodeTimeout) else "execution_error",
                                traceback=request_traceback(request), failed_op_index=failed_index,
                                execution_state="partial_or_failed",
                                note="Execution failed; earlier operations/partial changes may remain. Not a transaction.")
                if isinstance(exc, CommitFailure):
                    response["commit_recovery"] = {
                        "committed": False, "compensation_attempted": True,
                        "compensation_clean": exc.restored, "recovery_errors": exc.recovery_errors[:5],
                        "full_rollback_guaranteed": False}
                    response["note"] += " Failed operation attempted compensation; earlier batch operations are not rolled back."
            finally:
                sys.settrace(old_trace)
                response["exec_elapsed_ms"] = int((time.perf_counter()-exec_start)*1000)
        if compiled is not None:
            I.record(invalidated=True, reason="arbitrary_python")
        elif response["status"] == "error" and mutated:
            I.record(invalidated=True, reason="partially_failed_operation")
        # Explicit flush before measurement, separate from user execution budget.
        bpy.context.view_layer.update()
        if request["scene_summary"]:
            stamp = time.perf_counter()
            try:
                opts = request["scene_summary_options"]
                if opts["mode"] == "diff":
                    response["scene_summary"] = I.changes(opts.get("since_rev", start_rev),
                                                          opts.get("session", start_session), opts["max_objects"])
                elif opts["mode"] == "overview":
                    response["scene_summary"] = I.overview(opts["max_objects"])
                else:
                    response["scene_summary"] = I.full_summary(opts["max_objects"], opts["focus"])
            except Exception as exc:
                response["scene_summary_error"] = P.truncate(f"{type(exc).__name__}: {exc}", 4096)
            response["summary_elapsed_ms"] = int((time.perf_counter()-stamp)*1000)
        if request["snapshot"]:
            stamp = time.perf_counter()
            try:
                response["images"] = preview.snapshots(request["snapshot_options"])
                response["image"] = response["images"][0]["image"] if response["images"] else None
            except Exception as exc:
                response["snapshot_error"] = P.truncate(f"{type(exc).__name__}: {exc}", 4096)
            response["snapshot_elapsed_ms"] = int((time.perf_counter()-stamp)*1000)
        if mutated and request["undo_push"]:
            response["undo_push_applied"] = undo_checkpoint("Cyber Nexus agent edit")
            if not response["undo_push_applied"]:
                response["note"] += " Undo checkpoint unavailable."
        checks = response["checks"]
        response["validation"] = ("failed" if checks["failed"] else "inconclusive" if checks["inconclusive"] else
                                  "passed" if checks["passed"] else "not_applicable" if checks["not_applicable"] else "unchecked")
        current = I.state()
        response.update(session=current.session, rev=current.rev)
    finally:
        sys.settrace(old_trace)
        I.BUSY = False
    stdout_limit = 4096 if request.get("result_mode", "compact") == "compact" else P.MAX_TEXT
    response["stdout"] = P.truncate(output.getvalue(), stdout_limit)
    response["elapsed_ms"] = int((time.perf_counter()-started)*1000)
    return response


class CyberRuntimeServer:
    def __init__(self, port):
        self.host, self.port = HOST, int(port)
        self.token, self.instance_id = secrets.token_hex(32), secrets.token_hex(8)
        self.running, self.last_error = False, ""
        self.started_at = time.time()
        self.jobs, self.results = queue.Queue(maxsize=32), queue.Queue(maxsize=64)
        self.pump = None
        self._timer_callback = self.tick

    def start(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            elif os.name != "nt":
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((HOST, self.port))
            sock.listen(16)
            sock.setblocking(False)
            self.port = sock.getsockname()[1]
            write_connection(self)
            self.pump = NetworkPump(sock, self.token, self.jobs, self.results)
            self.pump.current_session = I.state().session
            self.running = True
            bpy.app.timers.register(self._timer_callback, first_interval=0.02, persistent=True)
            self.pump.start()
        except BaseException:
            self.stop()
            sock.close()
            raise

    def stop(self):
        self.running = False
        with contextlib.suppress(Exception):
            if bpy.app.timers.is_registered(self._timer_callback):
                bpy.app.timers.unregister(self._timer_callback)
        if self.pump:
            self.pump.stop_event.set()
            if self.pump.is_alive() and threading.current_thread() is not self.pump:
                self.pump.join(timeout=1)
            if not self.pump.is_alive():
                with contextlib.suppress(Exception):
                    self.pump.listener.close()
                    self.pump.selector.close()
        remove_connection(self)
        for q in (self.jobs, self.results):
            while True:
                try:
                    q.get_nowait()
                except queue.Empty:
                    break

    def scene_changed(self):
        """Main-thread cancellation; network pending/ledger state remains thread-owned."""
        session = I.state().session
        self.pump.current_session = session
        while True:
            try:
                job_id, request = self.jobs.get_nowait()
            except queue.Empty:
                break
            response = P.error("scene switched/loaded; queued request cancelled before execution", "scene_changed", request.get("request_id"))
            response.update(session=session, rev=I.state().rev, executed=False)
            try:
                self.results.put_nowait((job_id, P.encode_response(response)))
            except queue.Full:
                # Waiting clients would otherwise hang until their 1800s wait deadline.
                self.last_error = "response queue full while cancelling queued jobs; service stopped"
                self.stop()
                return

    def tick(self):
        if not self.running:
            return None
        if self.pump is None or not self.pump.is_alive():
            self.last_error = self.pump.error if self.pump else "network thread missing"
            self.stop()
            return None
        if self.pump.current_session != I.state().session:
            self.scene_changed()
        try:
            job_id, request = self.jobs.get_nowait()
        except queue.Empty:
            return 0.02
        try:
            response = run_request(request)
            encoded = P.encode_response(response)
        except BaseException:
            # Still respond after internal failure; never retry execution automatically.
            response = P.error("internal error; execution state may be partial", "internal_error", request.get("request_id"))
            response["traceback"] = request_traceback(request)
            response.update(executed=True, execution_state="unknown", session=I.state().session, rev=I.state().rev)
            encoded = P.encode_response(response)
            I.BUSY = False
        if self.running:
            try:
                self.results.put_nowait((job_id, encoded))
            except queue.Full:
                self.last_error = "response queue full; service stopped"
                self.stop()
                return None
        with contextlib.suppress(Exception):
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    area.tag_redraw()
        return 0.02 if self.running else None


def get_server():
    return builtins.__dict__.get(SERVER_KEY)


def start_server(port=DEFAULT_PORT):
    old = get_server()
    if old and old.running:
        raise RuntimeError("service already running")
    if old:
        old.stop()
    server = CyberRuntimeServer(port)
    server.start()
    builtins.__dict__[SERVER_KEY] = server
    bpy.app.driver_namespace[SERVER_KEY] = server
    return server


def stop_server():
    server = get_server()
    if server:
        server.stop()
    builtins.__dict__.pop(SERVER_KEY, None)
    bpy.app.driver_namespace.pop(SERVER_KEY, None)


def exit_signal_only():
    # Interpreter shutdown: never call bpy here.
    server = get_server()
    if server:
        if server.pump:
            server.pump.stop_event.set()
        remove_connection(server)


atexit.register(exit_signal_only)
