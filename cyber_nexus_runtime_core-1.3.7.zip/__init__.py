"""Cyber Nexus Runtime Core Extension 1.3.7."""
import contextlib
import bpy
from bpy.app.handlers import persistent
from . import runtime, ui, inspect


@persistent
def on_load(_dummy):
    inspect.reset()
    server = runtime.get_server()
    if server and server.running:
        server.scene_changed()
        bpy.app.driver_namespace[runtime.SERVER_KEY] = server
        if not bpy.app.timers.is_registered(server._timer_callback):
            bpy.app.timers.register(server._timer_callback, first_interval=0.02, persistent=True)
        with contextlib.suppress(Exception):
            runtime.write_connection(server)


@persistent
def on_depsgraph(scene, depsgraph):
    inspect.external_change(scene, depsgraph)


@persistent
def on_exit(_dummy=None):
    runtime.stop_server()


def register():
    runtime.stop_server()
    registered = []
    try:
        for cls in ui.CLASSES:
            bpy.utils.register_class(cls)
            registered.append(cls)
        if on_load not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(on_load)
        if on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)
        exit_pre = getattr(bpy.app.handlers, "exit_pre", None)
        if exit_pre is not None and on_exit not in exit_pre:
            exit_pre.append(on_exit)
    except BaseException:
        for cls in reversed(registered):
            with contextlib.suppress(Exception):
                bpy.utils.unregister_class(cls)
        raise
    prefs = bpy.context.preferences.addons.get(ui.ADDON_ID)
    if prefs and prefs.preferences.auto_start:
        try:
            runtime.start_server(prefs.preferences.port)
        except Exception as exc:
            print(f"[CyberNexus] 自动启动失败：{exc}")


def unregister():
    runtime.stop_server()
    for handlers, fn in ((bpy.app.handlers.load_post, on_load),
                         (bpy.app.handlers.depsgraph_update_post, on_depsgraph)):
        if fn in handlers:
            handlers.remove(fn)
    exit_pre = getattr(bpy.app.handlers, "exit_pre", None)
    if exit_pre is not None and on_exit in exit_pre:
        exit_pre.remove(on_exit)
    inspect.reset()
    for cls in reversed(ui.CLASSES):
        with contextlib.suppress(Exception):
            bpy.utils.unregister_class(cls)
