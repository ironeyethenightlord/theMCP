"""Semantic components with roots, stable roles and compensating staged commits.
Not a full Blender transaction; crashes/C failures cannot be rolled back reliably.
"""
import copy
import json
import secrets
import bpy
from mathutils import Matrix, Euler, Vector
from .helpers import CyberHelper as H, main_thread, BEVEL, NORMAL
from . import schema, resource_limits as L
from .transaction import Journal, protected_commit, CommitFailure

REGISTRY = "cn_components_v1"
OWNER, COMPONENT, OBJECT_ID = "cn_owner", "cn_component", "cn_object_id"
ROLE, ROOT, ARCHIVED, LEGACY = "cn_role", "cn_root", "cn_archived", "cn_legacy_id"
GENERATORS = schema.GENERATORS
MOD_ATTRS = {"BEVEL": ("width", "segments", "limit_method", "angle_limit", "profile", "use_clamp_overlap"),
             "WEIGHTED_NORMAL": ("keep_sharp", "weight", "thresh", "use_face_influence")}


_CACHE = {"raw": None, "parsed": None}


def _parse(raw):
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError("corrupt component registry")
    return parsed


def read_only():
    """Cached registry mapping. TREAT AS READ-ONLY: mutating it corrupts the cache.
    Callers that write must use load() (deep copy) and save() the result."""
    main_thread()
    raw = bpy.context.scene.get(REGISTRY, "{}")
    if raw != _CACHE["raw"] or _CACHE["parsed"] is None:
        _CACHE["raw"], _CACHE["parsed"] = raw, _parse(raw)
    return _CACHE["parsed"]


def invalidate_cache():
    _CACHE["raw"], _CACHE["parsed"] = None, None


def load():
    """Deep copy for callers that mutate the mapping before save()."""
    main_thread()
    return copy.deepcopy(read_only())


def serialized(registry):
    text = json.dumps(registry, ensure_ascii=True, allow_nan=False, separators=(",", ":"))
    if len(text) > 4*1024*1024:
        raise ValueError("component registry exceeds 4 MiB")
    return text


def save(registry):
    bpy.context.scene[REGISTRY] = serialized(registry)


def component_id(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 128 or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-" for c in value):
        raise ValueError("component ID must use ASCII letters/digits/._-")
    return value


def get(cid):
    cid = component_id(cid)
    record = read_only().get(cid)
    if record is None:
        raise ValueError("unknown component: " + cid)
    # Copy only the selected record; copying the entire registry on every lookup made
    # paginated scene queries scale poorly as component counts grew.
    return copy.deepcopy(record)


def _owned(record, roots=False):
    return [o for o in bpy.context.scene.objects if o.get(OWNER) == record["owner"] and
            o.get(COMPONENT) == record["id"] and not o.get(ARCHIVED) and (roots or not o.get(ROOT))]


def objects(cid):
    return _owned(get(cid))


def _root(record):
    roots = [o for o in _owned(record, True) if o.get(ROOT)]
    if len(roots) > 1:
        raise ValueError("duplicate component roots; resolve copies before editing")
    return roots[0] if roots else None


def _meta(obj, rec, role, root=False):
    previous = obj.get(OBJECT_ID)
    if previous and previous != rec["id"]+"/"+role and not obj.get(LEGACY):
        obj[LEGACY] = previous
    obj[OWNER], obj[COMPONENT], obj[ROLE] = rec["owner"], rec["id"], role
    obj[OBJECT_ID], obj[ROOT], obj[ARCHIVED] = rec["id"]+"/"+role, root, False


def _role(obj, record):
    if obj.get(ROLE):
        return obj[ROLE]
    legacy = obj.get(OBJECT_ID, "")
    suffix = legacy.rsplit("/", 1)[-1] if "/" in legacy else ""
    if record["generator"] == "slatted_panel":
        if suffix.isdigit():
            return "slat."+str(int(suffix)).zfill(3)
        if suffix.startswith("slat.") and suffix[5:].isdigit():
            return "slat."+str(int(suffix[5:])).zfill(3)
    if record["generator"] == "linear_array":
        if suffix.isdigit():
            return "item."+str(int(suffix)).zfill(3)
        if suffix.startswith("item.") and suffix[5:].isdigit():
            return "item."+str(int(suffix[5:])).zfill(3)
    if suffix in ("body", "root"):
        return suffix
    return "body"


def _build(cid, generator, params, target):
    p = copy.deepcopy(params)
    material, bevel = p.pop("material", None), p.pop("bevel", 0)
    # Resolution hints are consumed during schema preflight and converted to actual
    # vertices/segments before reaching the Blender helper functions.
    p.pop("max_chord_error", None)
    if generator == "box":
        result = {"body": H.create_box(cid, **p, collection=target)}
    elif generator == "cylinder":
        result = {"body": H.create_cylinder(cid, **p, collection=target)}
    elif generator == "cone":
        result = {"body": H.create_cone(cid, **p, collection=target)}
    elif generator == "sphere":
        result = {"body": H.create_uv_sphere(cid, **p, collection=target)}
    elif generator == "linear_array":
        result = {}
        shape, shape_params = p["shape"], p["shape_params"]
        origin, rot = p.get("location", [0, 0, 0]), p.get("rotation_euler", [0, 0, 0])
        base = shape_params.get("location", [0, 0, 0])
        has_rot = any(abs(r) > 1e-12 for r in rot)
        rot_mat = Euler(rot, "XYZ").to_matrix() if has_rot else None
        for i in range(p["count"]):
            role = "item."+str(i).zfill(3)
            item_params = copy.deepcopy(shape_params)
            if has_rot:
                offset = rot_mat @ Vector([base[axis]+i*p["step"][axis] for axis in range(3)])
                item_params["location"] = [origin[axis]+offset[axis] for axis in range(3)]
                item_rot = (rot_mat @ Euler(shape_params.get("rotation_euler", [0, 0, 0]), "XYZ").to_matrix()).to_euler("XYZ")
                item_params["rotation_euler"] = [item_rot.x, item_rot.y, item_rot.z]
            else:
                item_params["location"] = [origin[axis]+base[axis]+i*p["step"][axis] for axis in range(3)]
            result[role] = _build(cid+"."+role, shape, item_params, target)["body"]
    elif generator == "extrude":
        result = {"body": H.extrude_profile(cid, **p, collection=target)}
    elif generator == "revolve":
        result = {"body": H.revolve_profile(cid, **p, collection=target)}
    elif generator == "tube":
        result = {"body": H.sweep_path(cid, **p, collection=target)}
    else:
        width, count, gap = p["width"], p["slats"], p["gap"]
        slat_width, loc = (width-gap*(count-1))/count, p["location"]
        rot = p.get("rotation_euler", [0, 0, 0])
        rot_mat = Euler(rot, "XYZ").to_matrix() if any(abs(r) > 1e-12 for r in rot) else None
        result = {}
        for i in range(count):
            x = -width/2+slat_width/2+i*(slat_width+gap)
            offset = rot_mat @ Vector((x, 0, 0)) if rot_mat else Vector((x, 0, 0))
            role = "slat."+str(i).zfill(3)
            result[role] = H.create_box(cid+"."+role, (slat_width, p["thickness"], p["height"]),
                                      (loc[0]+offset.x, loc[1]+offset.y, loc[2]+offset.z),
                                      rotation_euler=rot, collection=target)
    for obj in result.values():
        if bevel and obj.type == "MESH":
            H.add_bevel_weighted_normal(obj, width=bevel)
        if material:
            H.assign_material(obj, material)
    return result


def resource_usage():
    """Managed scene base data only; no expensive modifier evaluation here."""
    main_thread()
    objects_count = archived = cost = 0
    for obj in bpy.context.scene.objects:
        if not obj.get(OWNER):
            continue
        objects_count += 1
        archived += bool(obj.get(ARCHIVED))
        if obj.type == "MESH":
            cost += len(obj.data.vertices)+len(obj.data.polygons)
        elif obj.type == "CURVE":
            points = sum(len(s.points)+len(s.bezier_points) for s in obj.data.splines)
            cost += points*32+2
    return {"objects": objects_count, "archived": archived, "cost": cost}


def _remove_object(obj):
    data = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    _remove_unused(data)


def _remove_unused(data):
    if data is not None and data.users == 0 and not data.use_fake_user:
        if isinstance(data, bpy.types.Mesh):
            bpy.data.meshes.remove(data)
        elif isinstance(data, bpy.types.Curve):
            bpy.data.curves.remove(data)


def _remove_collection_if_empty(col):
    if col is not None and not col.objects and not col.children:
        bpy.data.collections.remove(col)


def _check_editable(members):
    for obj in members:
        if obj.mode != "OBJECT" or obj.library or obj.override_library:
            raise ValueError("requires local Object Mode objects")
        if any(s != bpy.context.scene and s.objects.get(obj.name) == obj for s in bpy.data.scenes):
            raise ValueError("component shared by another Scene; make single-user first")


def _mod_specs(obj):
    result = []
    for key, kind in ((BEVEL, "BEVEL"), (NORMAL, "WEIGHTED_NORMAL")):
        mod = obj.modifiers.get(key)
        if mod:
            if mod.type != kind:
                raise ValueError("reserved helper modifier name occupied by another type")
            result.append((key, kind, {a: getattr(mod, a) for a in MOD_ATTRS[kind] if hasattr(mod, a)}))
    return result


def _apply_specs(obj, specs):
    keep = {s[0] for s in specs}
    for key in (BEVEL, NORMAL):
        mod = obj.modifiers.get(key)
        if mod and key not in keep:
            obj.modifiers.remove(mod)
    for key, kind, values in specs:
        mod = obj.modifiers.get(key)
        if mod is None:
            mod = obj.modifiers.new(key, kind)
        for attr, value in values.items():
            setattr(mod, attr, value)


def _snapshot(obj):
    keys = (OWNER, COMPONENT, OBJECT_ID, ROLE, ROOT, ARCHIVED, LEGACY)
    return {"data": obj.data, "parent": obj.parent, "basis": obj.matrix_basis.copy(),
            "inverse": obj.matrix_parent_inverse.copy(), "mods": _mod_specs(obj),
            "meta": {key: obj.get(key) for key in keys}, "links": list(obj.users_collection),
            "hide": (obj.hide_render, obj.hide_viewport),
            "material_slots": [(slot.link, slot.material) for slot in obj.material_slots]}


def _restore(obj, snapshot):
    obj.data, obj.parent = snapshot["data"], snapshot["parent"]
    obj.matrix_parent_inverse, obj.matrix_basis = snapshot["inverse"], snapshot["basis"]
    for slot, (link, material) in zip(obj.material_slots, snapshot["material_slots"]):
        slot.link, slot.material = link, material
    _apply_specs(obj, snapshot["mods"])
    obj.hide_render, obj.hide_viewport = snapshot["hide"]
    for key, value in snapshot["meta"].items():
        if value is None:
            if key in obj:
                del obj[key]
        else:
            obj[key] = value
    _restore_links(obj, snapshot["links"])


def _restore_links(obj, links):
    for col in list(obj.users_collection):
        if col not in links:
            col.objects.unlink(obj)
    for col in links:
        if col.objects.get(obj.name) != obj:
            col.objects.link(obj)


def _recovery_collection(cid):
    col = bpy.data.collections.new("CN Recovery · "+cid+" · "+secrets.token_hex(3))
    col.hide_render = col.hide_viewport = True
    col[ARCHIVED] = True
    bpy.context.scene.collection.children.link(col)
    return col


def _archive(obj, col):
    col.objects.link(obj)
    for current in list(obj.users_collection):
        if current != col:
            current.objects.unlink(obj)
    obj[ARCHIVED] = True
    obj.hide_render = obj.hide_viewport = True


def _write_raw(scene, old):
    if old is None:
        if REGISTRY in scene:
            del scene[REGISTRY]
    else:
        scene[REGISTRY] = old


def _rebuild(record):
    main_thread()
    cid, registry, scene = record["id"], load(), bpy.context.scene
    params = schema.generator_params(record["generator"], record["params"])
    cost = L.geometry_cost(record["generator"], params)
    L.check_request(cost)
    L.check_planned({**registry, cid: {**record, "params": params}})
    L.check_scene(resource_usage(), extra_cost=cost,
                  extra_objects=L.object_count(record["generator"], params)+1)
    old = _owned(record) if cid in registry else []
    old_root = _root(record) if cid in registry else None
    _check_editable(old+([old_root] if old_root else []))
    old_roles = {}
    for obj in old:
        role = _role(obj, record)
        if role in old_roles:
            raise ValueError("duplicate owned role: "+role)
        old_roles[role] = obj
        _mod_specs(obj)
    stage = bpy.data.collections.new("__CNStage_"+secrets.token_hex(4))
    scene.collection.children.link(stage)
    committed, recovery_ok = False, True
    recovery_col, journal = None, Journal()
    generated, backups = {}, {}
    result = None
    try:
        generated = _build(cid, record["generator"], params, stage)
        root_obj = old_root
        if root_obj is None:
            root_obj = bpy.data.objects.new(cid+".root", None)
            stage.objects.link(root_obj)
            root_obj.empty_display_type = "PLAIN_AXES"
            _meta(root_obj, record, "root", True)
        target = next((c for o in ([old_root] if old_root else old) for c in o.users_collection
                       if c.get(OWNER) == record["owner"] and not c.get(ARCHIVED)), stage)
        obsolete = [obj for role, obj in old_roles.items() if role not in generated]
        if obsolete:
            L.check_scene(resource_usage(), extra_archived=len(obsolete))
            recovery_col = _recovery_collection(cid)
        updated = copy.deepcopy(record)
        updated.update(params=params, built_params=copy.deepcopy(params), format_version=2,
                       object_count=len(generated), generation=record.get("generation", 0)+1)
        updated.setdefault("anchors", {})
        registry[cid] = updated
        new_raw, old_raw = serialized(registry), scene.get(REGISTRY)
        # Complete all snapshots/validation BEFORE touching live data.
        for role, gen in generated.items():
            existing = old_roles.get(role)
            if existing is not None:
                if existing.type != gen.type:
                    raise ValueError("role type changed; explicit migration required")
                backups[role] = _snapshot(existing)
        obsolete_backups = {o: _snapshot(o) for o in obsolete}
        with protected_commit():
            try:
                if root_obj != old_root and target != stage:
                    journal.step(lambda: _restore_links(root_obj, [target]), lambda: _restore_links(root_obj, [stage]))
                for role, gen in generated.items():
                    existing = old_roles.get(role)
                    basis, specs = gen.matrix_basis.copy(), _mod_specs(gen)
                    if existing is not None:
                        snapshot = backups[role]
                        def apply(obj=existing, source=gen, local=basis, mods=specs, role_name=role):
                            obj.data, obj.parent = source.data, root_obj
                            # discard_manual=true: generator material owns these slots;
                            # stale object-linked overrides must not mask new mesh data.
                            for slot in obj.material_slots:
                                slot.link = "DATA"
                            obj.matrix_parent_inverse, obj.matrix_basis = Matrix.Identity(4), local
                            _apply_specs(obj, mods)
                            _meta(obj, record, role_name)
                            if target.objects.get(obj.name) != obj:
                                target.objects.link(obj)
                        journal.step(apply, lambda obj=existing, snap=snapshot: _restore(obj, snap))
                    else:
                        snapshot = _snapshot(gen)
                        def apply(obj=gen, local=basis, role_name=role):
                            obj.parent = root_obj
                            obj.matrix_parent_inverse, obj.matrix_basis = Matrix.Identity(4), local
                            _meta(obj, record, role_name)
                            if target != stage:
                                _restore_links(obj, [target])
                        journal.step(apply, lambda obj=gen, snap=snapshot: _restore(obj, snap))
                for obj in obsolete:
                    journal.step(lambda obj=obj: _archive(obj, recovery_col),
                                 lambda obj=obj: _restore(obj, obsolete_backups[obj]))
                journal.step(lambda: setattr_scene_registry(scene, new_raw), lambda: _write_raw(scene, old_raw))
                # These writes can fail, so they belong BEFORE journal.commit().
                old_collection_name = target.name
                old_collection_meta = {key: target.get(key) for key in (OWNER, COMPONENT)}
                def apply_collection():
                    _set_collection_metadata(target, record, target == stage)
                def undo_collection():
                    target.name = old_collection_name
                    for key, value in old_collection_meta.items():
                        if value is None:
                            if key in target:
                                del target[key]
                        else:
                            target[key] = value
                journal.step(apply_collection, undo_collection)
                result = {"id": cid, "generation": updated["generation"], "objects": len(generated),
                          "reused": len(backups), "archived": len(obsolete), "committed": True}
                journal.commit()
                committed = True
            except BaseException as exc:
                errors = journal.rollback()
                recovery_ok = not errors
                if errors:
                    stage.name = "CN Recovery · FAILED COMMIT · "+cid
                    stage.hide_render = stage.hide_viewport = True
                raise CommitFailure(exc, errors) from exc
            # Cleanup cannot reverse a committed operation. Any cleanup failure is a warning.
            warnings = []
            for role, gen in generated.items():
                if role in backups:
                    try:
                        _remove_object(gen)
                        _remove_unused(backups[role]["data"])
                    except Exception as exc:
                        warnings.append(str(exc))
            if target != stage:
                try:
                    if stage.objects:
                        stage.hide_render = stage.hide_viewport = True
                        stage[ARCHIVED] = True
                        for obj in stage.objects:
                            obj[ARCHIVED] = True
                    else:
                        _remove_collection_if_empty(stage)
                except Exception as exc:
                    warnings.append(str(exc))
            if warnings:
                result["warnings"] = warnings[:5]
        return result
    finally:
        if not committed and recovery_ok:
            with protected_commit():
                for obj in list(stage.objects):
                    _remove_object(obj)
                _remove_collection_if_empty(stage)
                _remove_collection_if_empty(recovery_col)


def _set_collection_metadata(collection, record, rename):
    """Fault-injection seam; compensations are still active at this point."""
    collection[OWNER], collection[COMPONENT] = record["owner"], record["id"]
    if rename:
        collection.name = "CN · "+record["id"]


def setattr_scene_registry(scene, text):
    """Single write point intentionally exposed for Blender fault-injection tests."""
    scene[REGISTRY] = text


def create(cid, generator, params=None, label=None, parent=None):
    cid, registry = component_id(cid), read_only()
    if cid in registry:
        raise ValueError("component already exists")
    if parent is not None and parent not in registry:
        raise ValueError("parent component not found")
    rec = {"id": cid, "label": label or cid, "parent": parent, "owner": secrets.token_hex(16),
           "generator": generator, "generator_version": 1, "params": params or {}, "generation": 0, "anchors": {}}
    schema.simulate([{"op": "component.create", "id": cid, "generator": generator, "params": rec["params"], **({"parent": parent} if parent else {})}],
                    registry, [m.name for m in bpy.data.materials]+[m.get("cn_material_key", "") for m in bpy.data.materials])
    return _rebuild(rec)


def update(cid, params):
    cid = component_id(cid)
    registry = load()
    rec = registry.get(cid)
    if rec is None:
        raise ValueError("unknown component: " + cid)
    rec["params"] = schema.merge_params(rec["generator"], rec["params"], params)
    save(registry)
    return {"id": cid, "pending": rec["params"] != rec.get("built_params")}


def rebuild(cid, discard_manual=False):
    if discard_manual is not True:
        raise ValueError("rebuild requires discard_manual=true")
    return _rebuild(get(cid))


def ensure_root(cid):
    rec, scene = get(cid), bpy.context.scene
    root_obj = _root(rec)
    if root_obj:
        _check_editable([root_obj])
        return root_obj
    members = objects(cid)
    _check_editable(members)
    with protected_commit():
        root_obj = bpy.data.objects.new(cid+".root", None)
        col = next((c for o in members for c in o.users_collection if c.get(OWNER) == rec["owner"]), scene.collection)
        col.objects.link(root_obj)
        _meta(root_obj, rec, "root", True)
        journal = Journal()
        try:
            for obj in members:
                previous_parent, inverse, basis = obj.parent, obj.matrix_parent_inverse.copy(), obj.matrix_basis.copy()
                world = obj.matrix_world.copy()
                def apply(obj=obj, world=world):
                    obj.parent, obj.matrix_parent_inverse = root_obj, Matrix.Identity(4)
                    obj.matrix_world = world
                def undo(obj=obj, parent=previous_parent, inv=inverse, basis=basis):
                    obj.parent, obj.matrix_parent_inverse, obj.matrix_basis = parent, inv, basis
                journal.step(apply, undo)
            journal.commit()
        except BaseException as exc:
            errors = journal.rollback()
            if not errors:
                _remove_object(root_obj)
            raise CommitFailure(exc, errors) from exc
    return root_obj


def transform(cid, location=None, rotation_euler=None, scale=None):
    root_obj = ensure_root(cid)
    H.set_transform(root_obj, location, rotation_euler, scale)
    return {"id": cid, "root": root_obj.name}


def anchor_set(cid, name, location=(0, 0, 0), rotation_euler=(0, 0, 0)):
    if name == "origin":
        raise ValueError("origin anchor is reserved")
    registry, rec = load(), get(cid)
    anchors = rec.setdefault("anchors", {})
    if name not in anchors and len(anchors) >= 64:
        raise ValueError("anchor limit (64) exceeded")
    anchors[name] = {"location": list(location), "rotation_euler": list(rotation_euler)}
    registry[cid] = rec
    save(registry)
    return {"id": cid, "anchor": name}


def _anchor_matrix(rec, key):
    if key == "origin":
        return Matrix.Identity(4)
    frame = rec.get("anchors", {}).get(key)
    if frame is None:
        raise ValueError("unknown anchor")
    return Matrix.Translation(frame["location"]) @ Euler(frame["rotation_euler"], "XYZ").to_matrix().to_4x4()


def _require_rigid_root(root_obj):
    matrix = root_obj.matrix_world.to_3x3()
    columns = [Vector(matrix.col[i]) for i in range(3)]
    if (not all(abs(c.length-1) <= 1e-4 for c in columns)
            or any(abs(columns[i].dot(columns[j])) > 1e-4
                   for i in range(3) for j in range(i+1, 3))
            or not 0 < matrix.determinant()
            or abs(matrix.determinant()-1) > 4e-4):
        raise ValueError("anchor attach requires proper rigid roots; scale, reflection and shear are not supported")


def attach(cid, target, anchor="origin", target_anchor="origin", gap=0):
    if cid == target:
        raise ValueError("cannot attach to self")
    bpy.context.view_layer.update()
    source_rec, target_rec = get(cid), get(target)
    # Reject invalid roots BEFORE ensure_root() can create any objects.
    for rec in (source_rec, target_rec):
        existing_root = _root(rec)
        if existing_root is not None:
            _require_rigid_root(existing_root)
    source_root, target_root = ensure_root(cid), ensure_root(target)
    for root_obj in (source_root, target_root):
        _require_rigid_root(root_obj)
    world = target_root.matrix_world @ _anchor_matrix(get(target), target_anchor) @ Matrix.Translation((0, 0, gap))
    aligned = world @ _anchor_matrix(get(cid), anchor).inverted()
    loc, quat, _ = aligned.decompose()
    source_root.matrix_world = Matrix.Translation(loc) @ quat.normalized().to_matrix().to_4x4()
    return {"id": cid, "target": target, "attached": True, "mode": "one_shot_frame_alignment"}


def delete(cid, discard_manual=False):
    if discard_manual is not True:
        raise ValueError("delete requires discard_manual=true")
    registry, rec, scene = load(), get(cid), bpy.context.scene
    if any(r.get("parent") == cid for r in registry.values()):
        raise ValueError("delete child components first")
    members = _owned(rec, True)
    _check_editable(members)
    L.check_scene(resource_usage(), extra_archived=len(members))
    backups = {obj: _snapshot(obj) for obj in members}
    col = _recovery_collection(cid)
    del registry[cid]
    new_raw, old_raw = serialized(registry), scene.get(REGISTRY)
    with protected_commit():
        journal = Journal()
        try:
            for obj in members:
                journal.step(lambda obj=obj: _archive(obj, col), lambda obj=obj: _restore(obj, backups[obj]))
            journal.step(lambda: setattr_scene_registry(scene, new_raw), lambda: _write_raw(scene, old_raw))
            journal.commit()
        except BaseException as exc:
            errors = journal.rollback()
            if not errors:
                _remove_collection_if_empty(col)
            raise CommitFailure(exc, errors) from exc
    return {"deleted": cid, "archived": len(members), "recovery_collection": col.name}


def recovery(cid, limit=20, cursor=None):
    from . import inspect as I
    from .pagination import page
    component_id(cid)
    archived = sorted([o for o in bpy.context.scene.objects if o.get(COMPONENT) == cid and o.get(ARCHIVED)], key=lambda o: o.name)
    st = I.state()
    rows, info = page(archived, limit, cursor, st.session, st.rev, {"recovery": cid})
    return {"id": cid, "objects": [{"name": o.name, "role": o.get(ROLE), "type": o.type} for o in rows], **info}


def recovery_purge(cid, confirm=False):
    """Explicit, irreversible cleanup. Only archived objects for the exact ID."""
    main_thread()
    component_id(cid)
    if confirm is not True:
        raise ValueError("purge requires confirm=true; this permanently removes archived data")
    members = [o for o in bpy.context.scene.objects if o.get(COMPONENT) == cid and o.get(ARCHIVED)]
    _check_editable(members)
    collections = {c for obj in members for c in obj.users_collection if c.get(ARCHIVED)}
    removed = 0
    with protected_commit():
        # No fictitious rollback: native deletion cannot be compensated here.
        for obj in members:
            _remove_object(obj)
            removed += 1
        for col in collections:
            _remove_collection_if_empty(col)
    return {"id": cid, "purged": removed, "irreversible": True}


def describe(cid, detail="brief", fields=None, limit=20, cursor=None, depsgraph=None):
    from . import inspect as I
    from .pagination import page, project
    rec = get(cid)
    all_owned, st = _owned(rec, True), I.state()
    roots = [o for o in all_owned if o.get(ROOT)]
    if len(roots) > 1:
        raise ValueError("duplicate component roots; resolve copies before editing")
    root_obj = roots[0] if roots else None
    members = [o for o in all_owned if not o.get(ROOT)]
    need_bbox = fields is None or "bbox_world" in fields or "dimensions" in fields
    bbox = I.combined_bbox(members, depsgraph) if need_bbox else None
    data = {"id": cid, "label": rec["label"], "parent": rec.get("parent"), "generator": rec["generator"],
            "generation": rec["generation"], "params": rec["params"], "pending": rec["params"] != rec.get("built_params"),
            "object_count": len(members), "objects_missing": max(0, rec.get("object_count", 0)-len(members)),
            "bbox_world": I.rounded(bbox) if bbox else None,
            "dimensions": I.rounded([bbox[1][i]-bbox[0][i] for i in range(3)]) if bbox else None,
            "root_matrix": [I.rounded(tuple(row)) for row in root_obj.matrix_world] if root_obj else None,
            "anchors": rec.get("anchors", {}), "objects": None}
    if detail == "full" or (fields and "objects" in fields) or cursor:
        selected, info = page(sorted(members, key=lambda o: (o.get(ROLE, ""), o.name)), limit, cursor,
                              st.session, st.rev, {"component": cid, "fields": fields, "detail": detail})
        data["objects"] = [{"id": o.get(OBJECT_ID), "role": _role(o, rec), "name": o.name, "type": o.type} for o in selected]
    else:
        info = {"session": st.session, "rev": st.rev}
    result = project(data, fields, ("id", "label", "generator", "generation", "params", "pending", "object_count", "dimensions") if detail == "brief" else ())
    return {**result, **info}
