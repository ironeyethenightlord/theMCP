"""Conservative BASE geometry budgets, not a native-memory or modifier sandbox.
All costs count vertices + faces (tube costs estimate future curve tessellation).
Keep pure Python so preflight uses the same formulas as runtime checks.
"""
LIMITS = {
    "components": 500,
    "live_generated_objects": 4096,
    "request_build_cost": 2_000_000,
    "live_planned_cost": 8_000_000,
    "managed_scene_peak_cost": 8_000_000,
    "managed_scene_peak_objects": 16384,
    "archived_objects": 4096,
}


def object_count(generator, params):
    if generator == "linear_array":
        return params.get("count", 3)
    if generator == "slatted_panel":
        return params.get("slats", 7)
    return 1


def geometry_cost(generator, p):
    if generator == "box":
        cost = 8 + 6
    elif generator in ("cylinder", "cone"):
        n = p.get("vertices", 32)
        cost = 2*n + n + 2  # conservative even for pointed cones
    elif generator == "sphere":
        u, v = p.get("segments", 32), p.get("rings", 16)
        cost = u*(v-1)+2 + u*v
    elif generator == "linear_array":
        cost = p.get("count", 3)*geometry_cost(p.get("shape", "box"), p.get("shape_params", {}))
    elif generator == "slatted_panel":
        cost = p.get("slats", 7)*14
    elif generator == "extrude":
        cost = 3*len(p.get("points", []))+2
    elif generator == "revolve":
        cost = 2*len(p.get("points", []))*p.get("segments", 64)+2
    elif generator == "tube":
        cost = max(1, len(p.get("path", [])))*32+2
    else:
        raise ValueError("unknown generator for resource estimate")
    # A coarse allowance for the helper bevel, not a bound on arbitrary modifiers.
    return cost * (8 if p.get("bevel", 0) > 0 else 1)


def check_planned(registry):
    if len(registry) > LIMITS["components"]:
        raise ValueError("component budget exceeded (500)")
    objects = sum(object_count(r["generator"], r.get("params", {})) for r in registry.values())
    cost = sum(geometry_cost(r["generator"], r.get("params", {})) for r in registry.values())
    if objects > LIMITS["live_generated_objects"]:
        raise ValueError("generated object budget exceeded (4096)")
    if cost > LIMITS["live_planned_cost"]:
        raise ValueError("planned geometry budget exceeded; lower subdivision/count")
    return {"objects": objects, "cost": cost}


def check_request(cost):
    if cost > LIMITS["request_build_cost"]:
        raise ValueError("request build geometry budget exceeded; lower subdivision/count or split the batch")


def check_scene(usage, extra_cost=0, extra_objects=0, extra_archived=0):
    if usage["cost"] + extra_cost > LIMITS["managed_scene_peak_cost"]:
        raise ValueError("managed scene peak geometry budget exceeded; purge unneeded recovery objects or lower detail")
    if usage["objects"] + extra_objects > LIMITS["managed_scene_peak_objects"]:
        raise ValueError("managed scene peak object budget exceeded")
    if usage["archived"] + extra_archived > LIMITS["archived_objects"]:
        raise ValueError("recovery archive object budget exceeded; explicitly purge unneeded archives first")
