# Cyber Nexus Runtime Core 1.3.7 — Agent 接入与精度约定

本插件是 **Blender 5.2+ 的本机建模运行时**。外部 Agent 调用模型 API，将计划转成结构化 `ops` 或 Python `code`，通过 token 保护的本机 TCP 连接交给 Blender 执行。包内不包含模型供应商 API 客户端，也不需要 MCP 协议。

## 安装与连接

1. 保存现有 `.blend`，停止旧版服务，停用/更新同 ID 的插件；建议重启 Blender 后安装 1.3.7 ZIP。
2. 使用 Blender 的扩展“从磁盘安装 / Install from Disk”入口选择 ZIP，**无需解压或修改后缀**。最低版本是 5.2.0。
3. 3D 视图侧栏 `Cyber Nexus` → 启动服务。默认仅监听 `127.0.0.1:8192`。
4. 外部客户端读取 `~/.cyber_nexus/connection.json`。多 Blender 实例时明确选择 `connection-<pid>.json`。
5. 每个连接发送一条 UTF-8 JSON，末尾换行；读到响应换行/连接关闭。请求上限 1 MiB、响应上限 4 MiB。

**Token 等同 Blender 进程权限。** 不要发送给模型供应商、公开日志或网页，不要把监听地址改成公网。任意 `code` 有完整 Python 权限；timeout 不是沙箱或原生调用强杀。

## 推荐流程

1. `scene.overview` 获取 scene session、revision、单位设置。
2. 在客户端把用户尺寸确定性换算成 BU；将旋转角换成弧度。
3. 用参数化组件创建/更新，修改请求携带 `expected_session`，推荐同时携带 `expected_rev`。
4. `component.update` 只更新待构建参数；再用 `component.rebuild(discard_manual=true)` 落地几何。重建保留角色匹配的 Object，但替换其生成几何、局部基准、helper 修改器和材质槽所有权。不要把手工修改当作参数来源。
5. 运行 `check.dimensions`、`check.mesh`，检查顶层 `validation` 和各检查的 `status`。操作执行成功不等于几何验证通过。
6. 检查失败时让 Agent 修正参数再验证；截图仅辅助轮廓、布局判断。

父组件关系是逻辑元数据，不是实际 Blender parent 层级装配。attach 是一次性刚体锚点对齐，不会形成持久约束。

## 请求示例

先读取概览：

```json
{"token":"<connection token>","request_id":"read-overview-01","ops":[{"op":"scene.overview","limit":20}],"scene_summary":false}
```

把返回的 session/revision 代入修改：

```json
{"token":"<connection token>","request_id":"build-shaft-01","issued_at":<current Unix timestamp>,"expected_session":"<session>","expected_rev":<revision>,"ops":[{"op":"component.create","id":"shaft","generator":"cylinder","params":{"radius":0.25,"depth":2.0,"vertices":24,"max_chord_error":0.0005}},{"op":"check.dimensions","id":"shaft","target":[0.5,0.5,2.0],"tolerance":0.001,"space":"local"},{"op":"check.mesh","id":"shaft"}],"snapshot":false,"result_mode":"compact"}
```

上述 `<...>` 是模板占位符，不是可直接发送的 JSON。包内 `examples/agent_client.py` 展示标准库 TCP 客户端，可直接生成合法 payload；它不调用任何模型供应商 API。

## 稳定重试与场景绑定

- 内容完全相同的网络重试：复用 **同一 payload**，包括 request_id、issued_at、expected_session 和 expected_rev；不要重新生成 ID。
- 修改了 ops、投影字段、游标或任何请求参数：用新 request_id，否则得到 `request_id_conflict`。
- 建议发送 issued_at，过旧请求在执行前拒绝。已完成 ID 的去重记录默认保留 3600 秒，详细响应缓存较短且可被容量淘汰。
- 去重是进程内、有保留期的保证，不是跨重启永久 exactly-once。不能在很久以后或重启后盲目重发旧修改请求。
- `scene_changed` / `revision_conflict`：先重新读取状态、重做计划，不是自动替换 revision 然后强行执行旧计划。

## 1.3.7 的完整结构化输出

- 默认 `snapshot=false`、`scene_summary=compact diff`、`result_mode=compact`。
- **ops 的结构化结果在 compact/full 下都保持完整**：不截掉数组、不改写分页 cursor、不丢控制字段。
- compact：每条结果最多 64 KiB，整批 256 KiB；full：512 KiB / 2 MiB。响应仍有 4 MiB 总限制。
- 超过预算返回 `status=error`、`code=output_budget_exceeded`，当前 op 的结果为 `output_complete=false`；后续操作停止。它不是完整的一页，不能推进 cursor。
- 之前的修改可能已经执行。只为必要的读取生成新 request_id，减小 limit、指定 fields 或切换 full；不要重复整个修改批次。
- 总响应过大时优先舍弃图片/摘要；极端情况下返回 `response_too_large` / `response_details_complete=false`，不把丢失的操作结果伪装成成功空页。按执行状态重新查询场景，不自动重放修改。
- 任意 Python `result` 仍使用有限的 builtin-only 安全格式化；需要精确结果时使用结构化查询。
- 查询游标绑定 session/revision/查询条件。场景变化后重新开始分页。

读取组件对象的稳定分页：

```json
{"token":"<token>","ops":[{"op":"object.describe","id":"columns","limit":20,"detail":"brief"}],"scene_summary":false}
```

## 执行与恢复状态

`executed=false` 表示在执行前拒绝。`executed=true` 不表示批次全成功。

- `execution_state=not_executed`：场景绑定、revision、预检等拒绝。
- `completed`：执行流程完成；仍需看 validation。
- `partial_batch`：输出预算使批次中止。
- `partial_or_failed`：执行阶段发生异常，前序/局部修改可能存在。
- `unknown`：内部异常，需重新读取场景，不自动重执行。

`commit_recovery.compensation_clean=true` 仅表示失败操作的补偿未报告错误，**不保证 Blender 所有副作用恢复，也不回滚前序操作**。成功提交后清理失败，以 committed=true 和 warnings 报告。

## 恢复查询与不可逆清理

删除组件或减少角色数后，对象保留在隐藏恢复集合：

```json
{"token":"<token>","ops":[{"op":"component.recovery","id":"deleted_component","limit":20}],"scene_summary":false}
```

只有用户明确确认不再需要这些归档对象后，才能永久清理：

```json
{"token":"<token>","request_id":"purge-confirmed-01","expected_session":"<session>","ops":[{"op":"component.recovery.purge","id":"deleted_component","confirm":true}],"scene_summary":false}
```

purge 不删除同 ID 的新 live 组件，只删除 archived 对象，但可能使依赖它们的手工引用失效。该操作不可补偿；不要自动 purge。清理和后续构建建议分成两批。

## 几何与精度边界

- 线性输入、公差、间隙均为 **BU**，Euler 角为**弧度**。不自动根据显示单位换算毫米/英寸。
- `max_chord_error` 是 cylinder/cone/sphere/revolve 的可选弦高误差约束，0 保持固定细分。超出细分上限明确拒绝。
- `profile_tolerance` 校验近零边与剖面自交；相交和面积计算改为更稳健的局部基准，但最终 Blender mesh 仍受浮点存储、坐标量级影响。大坐标处的小特征应移到局部原点附近建模。
- 对精确机器判断使用 `check.dimensions` 的原始 `actual` / `absolute_errors` / `max_error` / `tolerance`；其数值及 clearance 距离不做 6 位小数裁剪。普通描述/摘要为了显示仍四舍五入到 6 位小数，不应用来代替精度检查。
- `check.mesh` 默认含求值修改器、按世界 BU 检查退化项，不检测自交。
- `check.clearance` 是世界 AABB 粗查，不是精确表面距离，也不能从 AABB 重叠推导真实碰撞。
- `space=local` 保留实际缩放，但要求可靠的非反射正交基准；父级非均匀缩放叠加子件旋转可能产生剪切，此时拒绝 local 检查，可改 world 或清理变换。
- attach 要求 proper rigid roots：单位缩放、无镜像、无剪切。
- 这不是 CAD B-rep、制造认证或持久装配求解器。严格制造级任务需要额外几何内核与验证。

## 资源与超时

通过 `system.capabilities` 查询 resource_limits。默认：

| 项目 | 上限 |
|---|---:|
| live 组件 | 500 |
| live 生成对象 | 4096 |
| 单批构建成本 | 2,000,000 |
| live planned / managed peak 成本 | 8,000,000 |
| managed peak 对象 | 16384 |
| archived 对象 | 4096 |

成本是估计顶点 + 面，曲线含粗略 tessellation 成本、helper bevel 留有余量；managed usage 包括归档 base data。预检为整批构建保留保守峰值，可能提前拒绝可分批完成的任务。预算不是任意修改器、外部 Python、显存或原生内存的硬上限，也不做全场景碰撞检测。

请求 timeout 对 Python 预检和执行共用一个 deadline。截图/摘要另计；保护 commit/rollback 暂时关闭追踪；Blender 原生 C 调用不能被安全强杀。

## 预览

`material` 是 Workbench 材质基础颜色，不是最终材质/灯光渲染；`solid` 是单色实体。`wireframe` 冻结求值后的 polygon geometry，建立临时世界坐标边线网格，结束后清理。非 polygon 或不支持转换的类型明确报错。极复杂实例/Geometry Nodes 依赖、collection override 与多层可见性仍需在具体文件中验证。

## 升级与测试

registry key 与 protocol 5 保持不变；不要同时启用两个同 ID 版本。先备份文件，再停服务并更新。新 API 是 additive，但错误码、结果完整性和资源拒绝行为有所变化，Agent 应按本说明处理。

测试脚本与结果位于 `tests/`，详见 `tests/README.md`。真实 5.2.2 LTS bpy headless 回归不代替桌面安装、侧栏交互、GUI Undo/Redo 及全部后续 Blender 版本测试。
