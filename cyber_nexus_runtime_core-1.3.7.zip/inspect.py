"""Queries and conservative revision log; never claims arbitrary Python diffs are complete."""
import math
import secrets
from collections import deque
import bmesh
import bpy
from mathutils import Matrix, Vector
from .helpers import main_thread, integer
from . import components
from .pagination import page, project

_STATES = {}
BUSY = False


class SceneState:
    def __init__(self):
        self.session = secrets.token_hex(12)
        self.rev = 0
        self.events = deque(maxlen=256)
        self.dirty = False


def state():
    main_thread()
    key = bpy.context.scene.as_pointer()
    if key not in _STATES:
        _STATES[key] = SceneState()
    return _STATES[key]


def reset():
    _STATES.clear()
    components.invalidate_cache()


def external_change(scene, depsgraph):
    if BUSY:
        return
    key = scene.as_pointer()
    if key in _STATES:
        # Conservative invalidation: never use a name/count-only fingerprint as truth.
        if any(isinstance(update.id, (bpy.types.Object, bpy.types.Mesh, bpy.types.Curve,
                                      bpy.types.Material, bpy.types.Collection, bpy.types.Scene))
               for update in depsgraph.updates):
            _STATES[key].dirty = True


def record(changed=(), deleted=(), invalidated=False, reason=None):
    st = state()
    st.rev += 1
    st.events.append({"rev": st.rev, "changed": list(changed), "deleted": list(deleted),
                      "invalidated": invalidated, "reason": reason})
    return st.rev


def flush_external():
    st = state()
    if st.dirty:
        st.dirty = False
        record(invalidated=True, reason="external_or_manual_edit")
    return st


def resolve(reference):
    main_thread()
    scene = bpy.context.scene
    if reference in components.read_only():
        return components.objects(reference)
    candidates = [o for o in scene.objects if not o.get(components.ARCHIVED) and (o.get(components.OBJECT_ID) == reference or o.get(components.LEGACY) == reference)]
    if len(candidates) > 1:
        raise ValueError("ambiguous object ID: " + reference)
    if candidates:
        return candidates
    obj = scene.objects.get(reference)
    if obj is None or obj.get(components.ARCHIVED):
        raise ValueError("live object/component not found: " + str(reference))
    return [obj]


def world_bbox(obj, depsgraph=None):
    main_thread()
    try:
        if obj.type in ("EMPTY", "CAMERA", "LIGHT", "SPEAKER", "ARMATURE"):
            return None
        depsgraph = depsgraph or bpy.context.evaluated_depsgraph_get()
        target = obj.evaluated_get(depsgraph)
        corners = list(target.bound_box)
        if not corners or all(tuple(c) == (-1, -1, -1) for c in corners):
            return None
        points = [target.matrix_world @ Vector(c) for c in corners]
        if not all(math.isfinite(v) for p in points for v in p):
            return None
        return [[min(p[i] for p in points) for i in range(3)],
                [max(p[i] for p in points) for i in range(3)]]
    except (ReferenceError, RuntimeError, AttributeError):
        return None


def combined_bbox(objs, depsgraph=None):
    graph = depsgraph or bpy.context.evaluated_depsgraph_get()
    boxes = [b for o in objs if (b := world_bbox(o, graph)) is not None]
    if not boxes:
        return None
    return [[min(b[0][i] for b in boxes) for i in range(3)],
            [max(b[1][i] for b in boxes) for i in range(3)]]


def rounded(value):
    if isinstance(value, (list, tuple)):
        return [rounded(x) for x in value]
    value = float(value)
    return round(value, 6) if math.isfinite(value) else None


def describe_object(obj, detail="full", fields=None, depsgraph=None):
    main_thread()
    need_bbox = fields is None or "bbox_world" in fields or "dimensions" in fields
    bbox = world_bbox(obj, depsgraph) if need_bbox else None
    data = {
        "id": obj.get(components.OBJECT_ID), "component": obj.get(components.COMPONENT),
        "name": obj.name, "type": obj.type, "parent": obj.parent.name if obj.parent else None,
        "location": rounded(tuple(obj.location)), "rotation_mode": obj.rotation_mode,
        "rotation_euler": rounded(tuple(obj.rotation_euler)),
        "rotation_quaternion": rounded(tuple(obj.rotation_quaternion)),
        "scale": rounded(tuple(obj.scale)), "matrix_world": [rounded(tuple(row)) for row in obj.matrix_world],
        "dimensions": rounded([bbox[1][i]-bbox[0][i] for i in range(3)] if bbox else tuple(obj.dimensions)) if need_bbox else None,
        "bbox_world": rounded(bbox) if bbox else None,
        "materials": [s.material.name if s.material else None for s in obj.material_slots],
        "modifiers": [{"name": m.name, "type": m.type, "viewport": m.show_viewport, "render": m.show_render} for m in obj.modifiers],
        "mesh": {"vertices": len(obj.data.vertices), "edges": len(obj.data.edges), "faces": len(obj.data.polygons)} if obj.type == "MESH" else None,
        "hide_render": obj.hide_render, "hide_viewport": obj.hide_viewport,
    }
    return project(data, fields, ("id", "name", "type", "component", "dimensions", "mesh") if detail == "brief" else (), ("id", "name"))


def overview(limit=100, cursor=None):
    st, scene = state(), bpy.context.scene
    registry = components.read_only()
    counts, archived = {}, 0
    for obj in scene.objects:
        if obj.get(components.ARCHIVED):
            # Deleted components live on in hidden recovery collections; counting them
            # as scene content would contradict scene.query and component.recovery.
            archived += 1
            continue
        counts[obj.type] = counts.get(obj.type, 0)+1
    rows = [{"id": r["id"], "label": r["label"], "parent": r["parent"],
             "generator": r["generator"], "pending": r["params"] != r.get("built_params")}
            for r in sorted(registry.values(), key=lambda r: r["id"])]
    selected, info = page(rows, limit, cursor, st.session, st.rev, {"overview": True})
    return {"mode": "overview", "session": st.session, "rev": st.rev,
            "scene": scene.name, "blend_file": bpy.data.filepath, "object_count": sum(counts.values()),
            "archived_count": archived, "types": counts, "units": scene.unit_settings.system, "unit_scale": scene.unit_settings.scale_length,
            "components": selected, "component_count": len(rows), "truncated": info["next_cursor"] is not None, **info}


def full_summary(limit=100, focus=(), detail="full", fields=None):
    main_thread()
    integer(limit, "limit", 1, 500)
    objs, seen = [], set()
    for ref in focus:
        for obj in resolve(ref):
            if obj.as_pointer() not in seen:
                seen.add(obj.as_pointer())
                objs.append(obj)
    for obj in bpy.context.scene.objects:
        if obj.get(components.ARCHIVED):
            continue
        if obj.as_pointer() not in seen:
            objs.append(obj)
            seen.add(obj.as_pointer())
    result = overview(limit)
    graph = bpy.context.evaluated_depsgraph_get()
    result.update(mode="full", objects=[describe_object(o, detail, fields, graph) for o in objs[:limit]],
                  objects_returned=min(limit, len(objs)), objects_truncated=len(objs) > limit)
    return result


def changes(since_rev, session, limit=100):
    st = state()
    if session != st.session or since_rev > st.rev:
        return {"mode": "diff", "session": st.session, "rev": st.rev, "resync_required": True,
                "reason": "session_changed_or_future_revision", "changed": [], "deleted": [], "del": []}
    if st.events and since_rev < st.events[0]["rev"]-1:
        return {"mode": "diff", "session": st.session, "rev": st.rev, "resync_required": True,
                "reason": "revision_history_expired", "changed": [], "deleted": [], "del": []}
    events = [e for e in st.events if e["rev"] > since_rev]
    changed, deleted = set(), set()
    for event in events:
        for cid in event["changed"]:
            changed.add(cid)
            deleted.discard(cid)
        for cid in event["deleted"]:
            deleted.add(cid)
            changed.discard(cid)
    registry = components.read_only()
    rows = [{"id": cid, "generation": registry[cid]["generation"],
             "pending": registry[cid]["params"] != registry[cid].get("built_params")}
            for cid in sorted(changed) if cid in registry]
    truncated = len(rows) > limit or len(deleted) > limit
    invalid = any(e["invalidated"] for e in events)
    deleted_rows = sorted(deleted)[:limit]
    return {"mode": "diff", "session": st.session, "from_rev": since_rev, "rev": st.rev,
            "changed": rows[:limit], "changed_count": len(rows), "deleted": deleted_rows, "del": deleted_rows,
            "deleted_count": len(deleted), "truncated": truncated,
            "resync_required": invalid or truncated,
            "reason": "untracked_edit" if invalid else "truncated; query details/full" if truncated else None,
            "note": "Known component events only; no claim of complete arbitrary-Python object diff."}


def validate_mesh(obj, evaluated=True, tolerance=1e-7):
    """Validate the actual modifier-evaluated mesh by default; raw mesh is opt-in."""
    main_thread()
    if obj.type != "MESH":
        raise ValueError("mesh check requires a mesh")
    if obj.mode != "OBJECT":
        raise ValueError("mesh check requires Object Mode; exit Edit Mode first")
    if type(tolerance) not in (int, float) or not math.isfinite(tolerance) or tolerance <= 0:
        raise ValueError("mesh tolerance must be a finite positive number")
    evaluated_obj, mesh_data = None, obj.data
    world_matrix = obj.matrix_world
    if evaluated:
        try:
            graph = bpy.context.evaluated_depsgraph_get()
            evaluated_obj = obj.evaluated_get(graph)
            world_matrix = evaluated_obj.matrix_world
            mesh_data = evaluated_obj.to_mesh()
            if mesh_data is None:
                raise ValueError("evaluated mesh unavailable")
        except (ReferenceError, RuntimeError, AttributeError, TypeError) as exc:
            raise ValueError("evaluated mesh unavailable: " + str(exc)[:200]) from exc
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh_data)
        # Measure tolerances in world-space BU, accounting for object/root scale.
        bm.transform(world_matrix)
        result = {"object": obj.name, "source": "evaluated" if evaluated else "base",
                  "tolerance_space": "world",
                  "vertices": len(bm.verts), "edges": len(bm.edges), "faces": len(bm.faces),
                  "non_manifold_edges": sum(not e.is_manifold for e in bm.edges),
                  "zero_length_edges": sum(e.calc_length() <= tolerance for e in bm.edges),
                  "boundary_edges": sum(e.is_boundary for e in bm.edges),
                  "loose_edges": sum(not e.link_faces for e in bm.edges),
                  "loose_vertices": sum(not v.link_edges for v in bm.verts),
                  "degenerate_faces": sum(f.calc_area() <= tolerance*tolerance for f in bm.faces)}
    finally:
        bm.free()
        if evaluated_obj is not None:
            try:
                evaluated_obj.to_mesh_clear()
            except Exception:
                pass
    result["closed_manifold"] = bool(result["faces"]) and result["non_manifold_edges"] == 0 and result["loose_vertices"] == 0
    result["note"] = "Evaluated modifiers included when source=evaluated; no self-intersection test."
    return result


def local_bbox(reference, objs):
    """AABB in an orthonormal (unit-scale) local frame so rotated components/objects
    report their uninflated dimensions while preserving actual scale in BU."""
    record = components.read_only().get(reference)
    root = components._root(record) if record else None
    frame_obj = objs[0] if len(objs) == 1 else root
    if frame_obj is None:
        raise ValueError("space=local requires a component with a root or a single object")
    try:
        matrix = frame_obj.matrix_world.to_3x3()
        cols = [Vector(matrix.col[i]) for i in range(3)]
        if (matrix.determinant() <= 0 or any(c.length <= 1e-12 for c in cols)
                or any(abs(cols[i].normalized().dot(cols[j].normalized())) > 1e-4
                       for i in range(3) for j in range(i+1, 3))):
            raise ValueError("space=local requires a nonsingular non-reflected orthogonal frame; use world or remove shear/reflection")
        loc, quat, _ = frame_obj.matrix_world.decompose()
        frame = Matrix.Translation(loc) @ quat.normalized().to_matrix().to_4x4()
        inverse = frame.inverted()
    except (ValueError, ReferenceError) as exc:
        raise ValueError("cannot measure reliable local frame: " + str(exc)) from exc
    graph, points = bpy.context.evaluated_depsgraph_get(), []
    for obj in objs:
        if obj.type in ("EMPTY", "CAMERA", "LIGHT", "SPEAKER", "ARMATURE"):
            continue
        try:
            target = obj.evaluated_get(graph)
            corners = list(target.bound_box)
        except (ReferenceError, RuntimeError, AttributeError):
            continue
        if not corners or all(tuple(c) == (-1, -1, -1) for c in corners):
            continue
        matrix = inverse @ target.matrix_world
        points.extend(matrix @ Vector(c) for c in corners)
    points = [p for p in points if all(math.isfinite(v) for v in p)]
    if not points:
        return None
    return [[min(p[i] for p in points) for i in range(3)],
            [max(p[i] for p in points) for i in range(3)]]


def dimensions_check(reference, target, tolerance=0.001, space="world"):
    from .helpers import vec, number
    target, tolerance = vec(target), number(tolerance, "tolerance", 0)
    if space not in ("world", "local"):
        raise ValueError("space must be world or local")
    objs = resolve(reference)
    bbox = local_bbox(reference, objs) if space == "local" else combined_bbox(objs)
    if bbox is None:
        raise ValueError("no measurable bounds (instances not included)")
    actual = [bbox[1][i]-bbox[0][i] for i in range(3)]
    errors = [abs(a-b) for a, b in zip(actual, target)]
    return {"id": reference, "space": space, "actual": actual, "target": list(target),
            "tolerance": tolerance, "absolute_errors": errors, "max_error": max(errors),
            "units": "BU", "measurement_source": "evaluated_bounds",
            "pass": all(error <= tolerance for error in errors)}


def clearance_check(a, b, minimum=0):
    from .helpers import number
    minimum = number(minimum, "minimum", 0)
    box_a, box_b = combined_bbox(resolve(a)), combined_bbox(resolve(b))
    if box_a is None or box_b is None:
        raise ValueError("no measurable bounds")
    gaps = [max(box_b[0][i]-box_a[1][i], box_a[0][i]-box_b[1][i], 0) for i in range(3)]
    distance = math.sqrt(sum(g*g for g in gaps))
    overlap = all(box_a[0][i] < box_b[1][i] and box_b[0][i] < box_a[1][i] for i in range(3))
    return {"a": a, "b": b, "aabb_distance": distance, "aabb_overlap": overlap,
            "minimum": minimum, "conservative_pass": distance >= minimum and not overlap,
            "note": "World AABB broad-phase only; overlap is not proof of mesh intersection."}


def subtree(cid):
    registry = components.read_only()
    if cid not in registry:
        raise ValueError("unknown component subtree")
    ids, frontier = {cid}, [cid]
    while frontier:
        parent = frontier.pop()
        for key, rec in registry.items():
            if rec.get("parent") == parent and key not in ids:
                ids.add(key)
                frontier.append(key)
    return ids


def query(kind="components", prefix="", under=None, limit=20, cursor=None, detail="brief", fields=None):
    st = state()
    scope = subtree(under) if under else None
    graph = bpy.context.evaluated_depsgraph_get() if (fields is None or "bbox_world" in fields or "dimensions" in fields) else None
    if kind == "components":
        candidates = sorted([cid for cid in components.read_only() if cid.startswith(prefix) and (scope is None or cid in scope)])
        chunk, info = page(candidates, limit, cursor, st.session, st.rev,
                           {"kind": kind, "prefix": prefix, "under": under, "detail": detail, "fields": fields})
        rows = [components.describe(cid, detail, fields, limit=limit, depsgraph=graph) for cid in chunk]
    else:
        candidates = sorted([o for o in bpy.context.scene.objects if not o.get(components.ARCHIVED)
                             and (o.get(components.OBJECT_ID, o.name)).startswith(prefix)
                             and (scope is None or o.get(components.COMPONENT) in scope)],
                            key=lambda o: (o.get(components.OBJECT_ID, o.name), o.name))
        chunk, info = page(candidates, limit, cursor, st.session, st.rev,
                           {"kind": kind, "prefix": prefix, "under": under, "detail": detail, "fields": fields})
        rows = [describe_object(obj, detail, fields, graph) for obj in chunk]
    return {"kind": kind, "items": rows, **info}


def object_page(reference, detail="brief", fields=None, limit=20, cursor=None):
    st = state()
    candidates = sorted(resolve(reference), key=lambda o: (o.get(components.OBJECT_ID, o.name), o.name))
    chunk, info = page(candidates, limit, cursor, st.session, st.rev,
                       {"object": reference, "detail": detail, "fields": fields})
    graph = bpy.context.evaluated_depsgraph_get()
    return {"objects": [describe_object(o, detail, fields, graph) for o in chunk], **info}


def mesh_check(reference, require_closed=True, evaluated=True, tolerance=1e-7,
               limit=20, cursor=None, detail="brief", fields=None):
    st, candidates = state(), [o for o in resolve(reference) if o.type == "MESH"]
    if not candidates:
        return {"id": reference, "status": "not_applicable", "checked": 0, "evaluated": evaluated,
                "issues": [{"id": reference, "type": "not_a_mesh", "message": "No mesh objects; check not performed."}]}
    candidates.sort(key=lambda o: (o.get(components.OBJECT_ID, o.name), o.name))
    reports, failures, skipped = [], [], []
    for obj in candidates:
        try:
            report = validate_mesh(obj, evaluated=evaluated, tolerance=tolerance)
        except ValueError as exc:
            skipped.append({"id": obj.get(components.OBJECT_ID, obj.name), "type": "not_checked",
                            "message": str(exc)[:200]})
            continue
        bad = (report["degenerate_faces"] or report["zero_length_edges"] or report["loose_edges"]
               or report["loose_vertices"] or not report["faces"])
        bad |= report["non_manifold_edges"] > (0 if require_closed else report["boundary_edges"])
        report["pass"] = not bool(bad)
        reports.append(report)
        if bad:
            failures.append({"id": obj.get(components.OBJECT_ID, obj.name), "type": "mesh_quality",
                             "message": "Mesh fails selected closed/open-surface policy.",
                             "counts": {key: report[key] for key in ("zero_length_edges", "degenerate_faces",
                                                                        "non_manifold_edges", "boundary_edges",
                                                                        "loose_edges", "loose_vertices")}})
    chunk, info = page(reports, limit, cursor, st.session, st.rev,
                       {"mesh": reference, "closed": require_closed, "evaluated": evaluated,
                        "tolerance": tolerance, "detail": detail, "fields": fields})
    issues = failures+skipped
    result = {"id": reference, "evaluated": evaluated,
              # A skipped member makes the whole check inconclusive, never silently "passed".
              "status": "failed" if failures else ("inconclusive" if skipped else "passed"),
              "checked": len(reports), "failed": len(failures), "skipped": len(skipped),
              "issues": issues[:10], "issues_truncated": len(issues) > 10, **info}
    if detail == "full" or fields:
        result["items"] = [project(row, fields) for row in chunk]
    return result
