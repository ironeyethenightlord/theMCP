# Cyber Nexus Runtime Core 1.3.7

目标：Blender **5.2+** 的本机 Agent 建模运行时。沿用 protocol 5、现有场景 registry 和参数化组件；不内置模型供应商 API / MCP 服务。

## 修复

1. **结构化结果不再经过递归裁剪**：compact/full 都保持完整操作结果、对象记录和分页控制字段。超过输出预算会返回 `output_budget_exceeded` 并停止后续操作，而不是悄悄丢项或推进游标。整个响应超限时先丢弃图片与摘要，保留操作结果；最后兜底若无法完整交付，明确报 response_too_large，不伪装成成功空页。任意 Python 的 `result` 仍使用安全、有限的 builtin-only 格式化。
2. **删除后的恢复查询**：`component.recovery` 不再要求 live registry 中存在组件，可查询删除后留存的归档对象。
3. **提交边界**：集合元数据与命名写入放在 commit 之前，并有补偿。提交后清理失败返回已提交结果及 warnings；已提交 Journal 明确拒绝伪回滚。
4. **执行状态**：新增 `execution_state`、`preflight_elapsed_ms`，提交补偿错误附带 `commit_recovery`。不会把补偿无报错宣传为完整 Blender 事务回滚。
5. **ID 限制统一**：Component ID 保持 128 字符；对象/检查/材质分配引用支持 256 字符，容纳生成角色后缀。
6. **材质名统一**：预检、创建和引用统一去除前后空白；全空白名称在执行前拒绝。嵌套阵列材质亦规范化。重建时清除对象级材质槽覆盖，避免旧材质遮盖新的生成材质；失败补偿恢复原覆盖。
7. **精度校验稳定性**：2D 相交判断使用局部边长而非全局坐标幅值；面积以第一点为原点并用 fsum，减少平移造成的数值抵消。尺寸检查新增原始测量值、tolerance、absolute_errors 和 max_error；间距检查保留原始距离，不再四舍五入到 6 位小数。这不改变 Blender mesh 的浮点存储精度。
8. **刚体装配保护**：attach 明确拒绝反射、非单位缩放及剪切；local 尺寸校验拒绝无法可靠定义正交局部基准的反射/剪切，而不返回貌似可信的数值。
9. **真实线框预览**：实测 Workbench render 不会因为 viewport `shading.type=WIREFRAME` 就变成线框。现在使用临时、世界坐标下的求值网格与 Wireframe 修改器输出真实边线；不修改源对象。无法转换的对象类型明确报错。
10. **隔离截图**：显式排除 focus 后代中的归档对象。

## 新增保护

- 请求的 Python deadline 覆盖 **预检 + 执行**，预检超时返回 `preflight_timeout` / `executed=false`。摘要、截图及原生 C 调用不保证硬截止；小型 commit/rollback 仍暂时关闭 tracer。
- 保守几何成本预算：单批构建成本 2,000,000、live planned / managed scene peak 成本 8,000,000。成本单位是估计顶点 + 面，曲线含粗略转换成本，helper bevel 有粗略余量；不是内存保证，也不约束任意 Python / 外部修改器。
- live 组件 500、live 生成对象 4096、managed peak 对象 16384、归档对象 4096。
- 新增 `component.recovery.purge`：必须 `confirm=true`，只删除指定 ID 的 archived 对象，**不可逆**。不是回滚式事务，不应由 Agent 未经用户确认自动使用。

## 客户端行为变更

- compact 不再把合法 JSON 数组换成 `<items omitted>`。每操作预算仍为 64 KiB，整批 256 KiB；full 为 512 KiB / 2 MiB。使用 brief/fields/分页控制成本。
- `output_budget_exceeded` 表示该操作已运行、输出未完整交付、后续操作未执行；之前的修改可能已生效。只用新的 request_id 重发缩小后的读取，不要重新执行整个修改批次。
- 同内容网络重试复用同一 request_id、issued_at、session/revision；变更请求内容时必须换 ID。
- purge 与下一批构建建议分开提交，让峰值预算基于实际释放后的数据重算。

## 验证与限制

在真实 **Blender 5.2.2 LTS bpy** 的 headless 环境中执行注册、9 类生成器、查询、尺寸/网格检查、重建故障注入、材质槽覆盖、TCP token/去重等回归。GUI Undo/Redo、桌面扩展安装入口和全部复杂 Geometry Nodes / collection override 场景不因此视为已验证。

保留：所有线性输入是 BU、旋转是弧度、clearance 是 AABB 粗查、mesh check 不查自交、attach 是一次性对齐、Token 等价于 Blender 进程权限。这不是 CAD B-rep 求解器或执行沙箱。
