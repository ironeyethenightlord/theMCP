import os
import bpy
from bpy.props import BoolProperty, IntProperty
from . import runtime

ADDON_ID = __package__
PORT_LABEL = "端口"
AUTO_START_LABEL = "自动开启服务（允许本机代码执行）"


class CyberNexusPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_ID
    port: IntProperty(name=PORT_LABEL, default=8192, min=1024, max=65535)
    auto_start: BoolProperty(name=AUTO_START_LABEL, default=False)

    def draw(self, context):
        self.layout.prop(self, "port")
        self.layout.prop(self, "auto_start")
        self.layout.label(text="持有 Token 等同拥有 Blender 进程权限。不是沙箱。", icon="ERROR")


def configured_port():
    try:
        return bpy.context.preferences.addons[ADDON_ID].preferences.port
    except (KeyError, AttributeError):
        return 8192


class CYBER_OT_server_start(bpy.types.Operator):
    bl_idname = "cyber_nexus.server_start"
    bl_label = "启动服务"

    def execute(self, context):
        try:
            server = runtime.start_server(configured_port())
        except Exception as exc:
            self.report({"ERROR"}, f"启动失败：{exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"运行中 {server.host}:{server.port}")
        return {"FINISHED"}


class CYBER_OT_server_stop(bpy.types.Operator):
    bl_idname = "cyber_nexus.server_stop"
    bl_label = "停止服务"

    def execute(self, context):
        runtime.stop_server()
        return {"FINISHED"}


class CYBER_OT_copy_token(bpy.types.Operator):
    bl_idname = "cyber_nexus.copy_token"
    bl_label = "复制 Token"

    def execute(self, context):
        server = runtime.get_server()
        if server is None or not server.running:
            self.report({"WARNING"}, "服务未运行")
            return {"CANCELLED"}
        context.window_manager.clipboard = server.token
        return {"FINISHED"}


class CYBER_PT_runtime(bpy.types.Panel):
    bl_label = "Cyber Nexus Runtime 1.3.7"
    bl_idname = "CYBER_PT_runtime"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Cyber Nexus"

    def draw(self, context):
        layout, server = self.layout, runtime.get_server()
        running = server is not None and server.running
        layout.label(text=f"运行中 {server.host}:{server.port}" if running else "未运行",
                     icon="CHECKMARK" if running else "CANCEL")
        layout.operator("cyber_nexus.server_stop" if running else "cyber_nexus.server_start")
        if server:
            layout.label(text=f"PID {os.getpid()} · {server.instance_id}")
            if server.last_error:
                layout.label(text=server.last_error[:100], icon="ERROR")
        layout.operator("cyber_nexus.copy_token", icon="COPYDOWN")
        layout.label(text="~/.cyber_nexus/connection.json")
        layout.label(text="多实例：connection-<pid>.json")
        layout.label(text="LLM 默认：无图 + diff + compact")


CLASSES = (CyberNexusPreferences, CYBER_OT_server_start, CYBER_OT_server_stop,
           CYBER_OT_copy_token, CYBER_PT_runtime)
