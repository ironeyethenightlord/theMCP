"""Context-light geometry tools. All Blender access must stay on the main thread."""
import contextlib
import math
import threading
import bmesh
import bpy
from mathutils import Vector

BEVEL = "CyberHelper Bevel"
NORMAL = "CyberHelper Weighted Normal"


def main_thread():
    if threading.current_thread() is not threading.main_thread():
        raise RuntimeError("Blender API is main-thread only")


def number(value, label, low=None, high=None):
    if isinstance(value, bool):
        raise TypeError(label + " must be numeric, not bool")
    result = float(value)
    if not math.isfinite(result) or (low is not None and result < low) or (high is not None and result > high):
        raise ValueError(label + " outside allowed range")
    return result


def integer(value, label, minimum=1, maximum=4096):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError(f"{label} must be integer in [{minimum}, {maximum}]")
    return value


def vec(value, label="vector", count=3):
    result = tuple(number(x, label) for x in value)
    if len(result) != count:
        raise ValueError(f"{label} needs {count} values")
    return result


def positive(value, label):
    result = number(value, label)
    if result <= 0:
        raise ValueError(label + " must be positive")
    return result


def name(value):
    if not isinstance(value, str) or not value.strip() or len(value) > 256:
        raise ValueError("name must be a non-empty string, max 256 characters")
    return value.strip()


def collection(value=None):
    if value is None:
        return bpy.context.scene.collection
    if isinstance(value, str):
        found = bpy.data.collections.get(name(value))
        if found is None:
            found = bpy.data.collections.new(value)
            bpy.context.scene.collection.children.link(found)
        return found
    if not isinstance(value, bpy.types.Collection):
        raise TypeError("collection must be a Collection or name")
    return value


def mesh_object(object_name, vertices, faces, location=(0, 0, 0), rotation_euler=(0, 0, 0), target=None):
    main_thread()
    object_name = name(object_name)
    loc, rot = vec(location), vec(rotation_euler)
    target = collection(target)
    mesh = bpy.data.meshes.new(object_name)
    obj = None
    try:
        mesh.from_pydata(vertices, [], faces)
        mesh.update()
        obj = bpy.data.objects.new(object_name, mesh)
        obj.location, obj.rotation_euler = loc, rot
        target.objects.link(obj)
        return obj
    except BaseException:
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)
        raise


def from_bmesh(object_name, bm, location, rotation_euler, target):
    main_thread()
    object_name = name(object_name)
    loc, rot = vec(location), vec(rotation_euler)
    target = collection(target)
    mesh = bpy.data.meshes.new(object_name)
    obj = None
    try:
        bm.to_mesh(mesh)
        mesh.update()
        obj = bpy.data.objects.new(object_name, mesh)
        obj.location, obj.rotation_euler = loc, rot
        target.objects.link(obj)
        return obj
    except BaseException:
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)
        raise


@contextlib.contextmanager
def window_context():
    wm = bpy.context.window_manager
    window = bpy.context.window or (wm.windows[0] if wm and wm.windows else None)
    if window is None:
        yield
        return
    area = next((a for a in window.screen.areas if a.type == "VIEW_3D"), None)
    override = {"window": window}
    if area:
        override["area"] = area
        region = next((r for r in area.regions if r.type == "WINDOW"), None)
        if region:
            override["region"] = region
    with bpy.context.temp_override(**override):
        yield


@contextlib.contextmanager
def active_object(obj):
    layer = bpy.context.view_layer
    if bpy.context.mode != "OBJECT":
        raise RuntimeError("operator helper requires Object Mode")
    if layer.objects.get(obj.name) != obj:
        raise RuntimeError("object is not in the current View Layer")
    selected, active = list(bpy.context.selected_objects), layer.objects.active
    try:
        for item in selected:
            item.select_set(False)
        obj.select_set(True)
        layer.objects.active = obj
        with window_context():
            yield
    finally:
        with contextlib.suppress(Exception):
            obj.select_set(False)
        for item in selected:
            with contextlib.suppress(Exception):
                item.select_set(True)
        with contextlib.suppress(Exception):
            layer.objects.active = active


class CyberHelper:
    @staticmethod
    def create_box(name, size=(1, 1, 1), location=(0, 0, 0), rotation_euler=(0, 0, 0), collection=None):
        main_thread()
        dims = vec(size, "size")
        if any(x <= 0 for x in dims):
            raise ValueError("size must be positive")
        bm = bmesh.new()
        try:
            bmesh.ops.create_cube(bm, size=1.0, calc_uvs=True)
            for vert in bm.verts:
                for i in range(3):
                    vert.co[i] *= dims[i]
            return from_bmesh(name, bm, location, rotation_euler, collection)
        finally:
            bm.free()

    @staticmethod
    def create_cone(name, radius_bottom=0.5, radius_top=0.0, depth=1.0, location=(0, 0, 0),
                    rotation_euler=(0, 0, 0), vertices=32, collection=None):
        main_thread()
        bottom, top = number(radius_bottom, "radius_bottom", 0), number(radius_top, "radius_top", 0)
        depth = positive(depth, "depth")
        if bottom + top <= 0:
            raise ValueError("at least one radius must be positive")
        vertices = integer(vertices, "vertices", 3)
        bm = bmesh.new()
        try:
            bmesh.ops.create_cone(bm, cap_ends=True, segments=vertices,
                                 radius1=bottom, radius2=top, depth=depth, calc_uvs=True)
            return from_bmesh(name, bm, location, rotation_euler, collection)
        finally:
            bm.free()

    @staticmethod
    def create_cylinder(name, radius=0.5, depth=1.0, location=(0, 0, 0),
                        rotation_euler=(0, 0, 0), vertices=32, collection=None):
        return CyberHelper.create_cone(name, radius, radius, depth, location, rotation_euler, vertices, collection)

    @staticmethod
    def create_uv_sphere(name, radius=0.5, location=(0, 0, 0), rotation_euler=(0, 0, 0),
                         segments=32, rings=16, collection=None):
        main_thread()
        bm = bmesh.new()
        try:
            bmesh.ops.create_uvsphere(bm, u_segments=integer(segments, "segments", 3),
                                     v_segments=integer(rings, "rings", 3), radius=positive(radius, "radius"), calc_uvs=True)
            return from_bmesh(name, bm, location, rotation_euler, collection)
        finally:
            bm.free()

    @staticmethod
    def cylinder_between(name, start, end, radius=0.05, vertices=24, collection=None):
        main_thread()
        a, b = Vector(vec(start)), Vector(vec(end))
        direction = b - a
        if direction.length <= 1e-9:
            raise ValueError("start and end coincide")
        obj = CyberHelper.create_cylinder(name, radius, direction.length, (a+b)*0.5,
                                          vertices=vertices, collection=collection)
        obj.rotation_mode = "QUATERNION"
        obj.rotation_quaternion = direction.to_track_quat("Z", "Y")
        return obj

    @staticmethod
    def add_bevel_weighted_normal(obj, width=0.03, segments=3, angle_limit_deg=30):
        main_thread()
        if obj.type != "MESH" or obj.mode != "OBJECT":
            raise ValueError("requires an Object Mode mesh")
        width = number(width, "width", 0)
        segments = integer(segments, "segments", 1, 128)
        angle = number(angle_limit_deg, "angle", 0, 180)
        for key, kind in ((BEVEL, "BEVEL"), (NORMAL, "WEIGHTED_NORMAL")):
            current = obj.modifiers.get(key)
            if current is not None and current.type != kind:
                raise ValueError(f"modifier name conflict: {key}; no changes made")
        if obj.data.users > 1:
            obj.data = obj.data.copy()
        if hasattr(obj.data, "shade_smooth"):
            obj.data.shade_smooth()
        else:
            obj.data.polygons.foreach_set("use_smooth", [True]*len(obj.data.polygons))
        bevel = obj.modifiers.get(BEVEL) or obj.modifiers.new(BEVEL, "BEVEL")
        bevel.width, bevel.segments = width, segments
        bevel.limit_method, bevel.angle_limit = "ANGLE", math.radians(angle)
        old = obj.modifiers.get(NORMAL)
        if old:
            obj.modifiers.remove(old)
        weighted = obj.modifiers.new(NORMAL, "WEIGHTED_NORMAL")
        weighted.keep_sharp = True
        return obj

    @staticmethod
    def set_transform(obj, location=None, rotation_euler=None, scale=None):
        main_thread()
        loc = vec(location) if location is not None else None
        rot = vec(rotation_euler) if rotation_euler is not None else None
        scl = vec(scale) if scale is not None else None
        if scl and any(x == 0 for x in scl):
            raise ValueError("zero scale is not allowed")
        if loc is not None:
            obj.location = loc
        if rot is not None:
            obj.rotation_mode = "XYZ"
            obj.rotation_euler = rot
        if scl is not None:
            obj.scale = scl
        return obj

    @staticmethod
    def apply_transforms(obj, location=True, rotation=True, scale=True):
        main_thread()
        if getattr(obj, "data", None) is not None and obj.data.users > 1:
            obj.data = obj.data.copy()
        with active_object(obj):
            result = bpy.ops.object.transform_apply(location=location, rotation=rotation, scale=scale)
        if "FINISHED" not in result:
            raise RuntimeError("transform_apply did not finish")
        return obj

    @staticmethod
    def add_mirror(obj, axis="X", mirror_object=None, use_clip=True, name=None):
        main_thread()
        axis = axis.upper()
        if axis not in ("X", "Y", "Z"):
            raise ValueError("invalid mirror axis")
        mod = obj.modifiers.new(name or "CyberHelper Mirror", "MIRROR")
        mod.use_axis = tuple(a == axis for a in ("X", "Y", "Z"))
        mod.use_clip, mod.mirror_object = bool(use_clip), mirror_object
        return obj

    @staticmethod
    def add_array(obj, count=2, constant_offset=None, relative_offset=None, name=None):
        main_thread()
        count = integer(count, "count", 1, 10000)
        if constant_offset is not None and relative_offset is not None:
            raise ValueError("choose constant_offset OR relative_offset")
        offset = vec(relative_offset if relative_offset is not None else (constant_offset or (2, 0, 0)))
        mod = obj.modifiers.new(name or "CyberHelper Array", "ARRAY")
        mod.count = count
        mod.use_relative_offset = relative_offset is not None
        mod.use_constant_offset = relative_offset is None
        if relative_offset is not None:
            mod.relative_offset_displace = offset
        else:
            mod.constant_offset_displace = offset
        return obj

    @staticmethod
    def boolean_operation(obj, cutter, operation="DIFFERENCE", apply=False, name=None, solver="EXACT"):
        main_thread()
        if obj == cutter or any(x.type != "MESH" or x.mode != "OBJECT" for x in (obj, cutter)):
            raise ValueError("boolean requires two distinct Object Mode meshes")
        operation = operation.upper()
        if operation not in ("DIFFERENCE", "UNION", "INTERSECT"):
            raise ValueError("invalid boolean operation")
        solver = solver.upper()
        mod = obj.modifiers.new(name or "CyberHelper Boolean", "BOOLEAN")
        try:
            mod.operation, mod.object, mod.solver = operation, cutter, solver
            if apply:
                with active_object(obj):
                    result = bpy.ops.object.modifier_apply(modifier=mod.name)
                if "FINISHED" not in result:
                    raise RuntimeError("modifier_apply did not finish")
        except BaseException:
            if mod.name in obj.modifiers:
                obj.modifiers.remove(mod)
            raise
        return obj

    @staticmethod
    def boolean_difference(obj, cutter, apply=False):
        return CyberHelper.boolean_operation(obj, cutter, "DIFFERENCE", apply)

    @staticmethod
    def boolean_union(obj, cutter, apply=False):
        return CyberHelper.boolean_operation(obj, cutter, "UNION", apply)

    @staticmethod
    def boolean_intersect(obj, cutter, apply=False):
        return CyberHelper.boolean_operation(obj, cutter, "INTERSECT", apply)

    @staticmethod
    def create_pbr_material(name, color=(0.8, 0.8, 0.8, 1), metallic=0, roughness=0.5,
                            emission_color=None, emission_strength=0):
        main_thread()
        logical = globals()["name"](name)
        rgba = vec(color, "color", 4)
        emit = rgba if emission_color is None else vec(emission_color, "emission_color", 4)
        if any(x < 0 or x > 1 for x in rgba):
            raise ValueError("color components must be in [0, 1]")
        if any(x < 0 or x > 1 for x in emit):
            raise ValueError("emission_color components must be in [0, 1]")
        metal, rough = number(metallic, "metallic", 0, 1), number(roughness, "roughness", 0, 1)
        strength = number(emission_strength, "emission_strength", 0, 1e6)
        mat = next((m for m in bpy.data.materials if m.get("cn_material_key") == logical), None)
        if mat is None:
            mat = bpy.data.materials.new(logical)
        mat["cn_material_key"], mat["cyber_helper_pbr"] = logical, True
        mat.use_fake_user, mat.diffuse_color = True, rgba
        if bpy.app.version < (5, 0, 0) or mat.node_tree is None:
            mat.use_nodes = True
        tree = mat.node_tree
        if tree is None:
            raise RuntimeError("material node tree unavailable")
        bsdf = next((n for n in tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
        if bsdf is None:
            bsdf = tree.nodes.new("ShaderNodeBsdfPrincipled")
        outputs = [n for n in tree.nodes if n.type == "OUTPUT_MATERIAL"]
        out = next((n for n in outputs if n.is_active_output), None)
        if out is None:
            out = outputs[0] if outputs else tree.nodes.new("ShaderNodeOutputMaterial")
        for socket, value in (("Base Color", rgba), ("Metallic", metal), ("Roughness", rough),
                              ("Emission Color", emit), ("Emission Strength", strength)):
            target = bsdf.inputs.get(socket)
            if target is None:
                raise RuntimeError("unsupported Principled socket: " + socket)
            for link in list(target.links):
                tree.links.remove(link)
            target.default_value = value
        for link in list(out.inputs["Surface"].links):
            tree.links.remove(link)
        tree.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
        return mat

    @staticmethod
    def create_cyber_emissive_mat(name, color=(0, 1, 0.8, 1), strength=10):
        mat = CyberHelper.create_pbr_material(name, color, metallic=0.15, roughness=0.25,
                                              emission_color=color, emission_strength=strength)
        mat["cyber_helper_emissive"] = True
        return mat

    @staticmethod
    def assign_material(obj, material, slot_index=0):
        main_thread()
        slot_index = integer(slot_index, "slot_index", 0, 4096)
        if isinstance(material, str):
            from .schema import material_name
            material = material_name(material)
            material = next((m for m in bpy.data.materials if m.get("cn_material_key") == material), None) or bpy.data.materials.get(material)
        if material is None or not isinstance(material, bpy.types.Material):
            raise ValueError("material not found")
        if obj.data is None or not hasattr(obj.data, "materials"):
            raise ValueError("object does not support materials")
        if slot_index > len(obj.material_slots):
            raise ValueError("cannot skip material slots")
        if slot_index == len(obj.material_slots):
            obj.data.materials.append(material)
        else:
            obj.material_slots[slot_index].material = material
        return obj

    @staticmethod
    def assign_pbr_material(obj, name, color=(0.8, 0.8, 0.8, 1), metallic=0, roughness=0.5, slot_index=0):
        mat = CyberHelper.create_pbr_material(name, color, metallic, roughness)
        CyberHelper.assign_material(obj, mat, slot_index)
        return mat

    @staticmethod
    def extrude_profile(name, points, depth=1, location=(0, 0, 0), rotation_euler=(0, 0, 0),
                        collection=None, profile_tolerance=1e-7):
        """Simple CCW XY polygon, centered extrusion along Z. Holes are not supported."""
        main_thread()
        points = [vec(p, "profile point", 2) for p in points]
        if not 3 <= len(points) <= 4096:
            raise ValueError("profile needs 3..4096 points")
        from .schema import validate_profile, profile_area2
        validate_profile(points, closed=True, tolerance=profile_tolerance, label="extrude profile")
        depth = positive(depth, "depth")
        area = profile_area2(points)
        if abs(area) < profile_tolerance*profile_tolerance:
            raise ValueError("degenerate profile")
        if area < 0:
            points.reverse()
        n = len(points)
        verts = [(x, y, z) for z in (-depth/2, depth/2) for x, y in points]
        faces = [tuple(reversed(range(n))), tuple(range(n, 2*n))]
        faces += [(i, (i+1)%n, (i+1)%n+n, i+n) for i in range(n)]
        return mesh_object(name, verts, faces, location, rotation_euler, target=collection)

    @staticmethod
    def revolve_profile(name, points, segments=64, location=(0, 0, 0), rotation_euler=(0, 0, 0),
                        collection=None, profile_tolerance=1e-7):
        """Open radius/Z polyline revolved around Z; endpoints capped. No holes."""
        main_thread()
        points = [vec(p, "radius/z", 2) for p in points]
        segments = integer(segments, "segments", 3, 512)
        if not 2 <= len(points) <= 1024 or any(p[0] < 0 for p in points):
            raise ValueError("profile needs 2..1024 non-negative radius/Z points")
        from .schema import validate_revolve_profile
        validate_revolve_profile(points, tolerance=profile_tolerance, label="revolve profile")
        verts, rings, faces = [], [], []
        for radius, z in points:
            if radius <= profile_tolerance:
                rings.append([len(verts)])
                verts.append((0, 0, z))
            else:
                rings.append(list(range(len(verts), len(verts)+segments)))
                verts.extend((radius*math.cos(2*math.pi*i/segments), radius*math.sin(2*math.pi*i/segments), z) for i in range(segments))
        for a, b in zip(rings, rings[1:]):
            if len(a) == len(b) == 1:
                raise ValueError("consecutive axis points create zero-area surface")
            for i in range(segments):
                j = (i+1)%segments
                if len(a) == 1:
                    faces.append((a[0], b[j], b[i]))
                elif len(b) == 1:
                    faces.append((a[i], a[j], b[0]))
                else:
                    faces.append((a[i], a[j], b[j], b[i]))
        if len(rings[0]) > 1:
            faces.append(tuple(reversed(rings[0])))
        if len(rings[-1]) > 1:
            faces.append(tuple(rings[-1]))
        # Recalculate normals for consistently connected profile surfaces.
        obj = mesh_object(name, verts, faces, location, rotation_euler, target=collection)
        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            bm.to_mesh(obj.data)
        finally:
            bm.free()
        return obj

    @staticmethod
    def sweep_path(name, path, radius=0.05, location=(0, 0, 0), rotation_euler=(0, 0, 0), collection=None):
        """Polyline tube using a 3D Curve; smoothness follows path density."""
        main_thread()
        path = [vec(p, "path point") for p in path]
        loc, rot = vec(location), vec(rotation_euler)
        radius = positive(radius, "radius")
        if not 2 <= len(path) <= 10000 or any((Vector(a)-Vector(b)).length <= 1e-9 for a, b in zip(path, path[1:])):
            raise ValueError("path needs 2..10000 distinct neighboring points")
        target = globals()["collection"](collection)
        data = bpy.data.curves.new(globals()["name"](name), "CURVE")
        obj = None
        try:
            data.dimensions, data.bevel_depth, data.bevel_resolution = "3D", radius, 3
            data.use_fill_caps = True
            spline = data.splines.new("POLY")
            spline.points.add(len(path)-1)
            for point, xyz in zip(spline.points, path):
                point.co = (*xyz, 1)
            obj = bpy.data.objects.new(name, data)
            obj.location, obj.rotation_euler = loc, rot
            target.objects.link(obj)
            return obj
        except BaseException:
            if obj is not None:
                bpy.data.objects.remove(obj, do_unlink=True)
            if data.users == 0:
                bpy.data.curves.remove(data)
            raise

    @staticmethod
    def align_objects(objects, axis="X", mode="CENTER", coordinate=None):
        from .inspect import world_bbox, combined_bbox
        main_thread()
        axis, mode = axis.upper(), mode.upper()
        if axis not in "XYZ" or len(axis) != 1 or mode not in ("MIN", "CENTER", "MAX"):
            raise ValueError("invalid axis/mode")
        idx, entries = "XYZ".index(axis), []
        bpy.context.view_layer.update()
        graph = bpy.context.evaluated_depsgraph_get()
        for item in objects:
            if isinstance(item, tuple):
                obj, members, label = item
                bbox = combined_bbox(members, graph)
            else:
                obj, label = item, item.name
                bbox = world_bbox(obj, graph)
            if bbox:
                value = bbox[0][idx] if mode == "MIN" else bbox[1][idx] if mode == "MAX" else (bbox[0][idx]+bbox[1][idx])/2
                entries.append((obj, value, label))
        if not entries:
            return []
        target = entries[0][1] if coordinate is None else number(coordinate, "coordinate")
        for obj, value, _ in entries:
            matrix = obj.matrix_world.copy()
            matrix.translation[idx] += target-value
            obj.matrix_world = matrix
        return [label for _, _, label in entries]

    @staticmethod
    def distribute_objects(objects, axis="X", spacing=None):
        from .inspect import world_bbox, combined_bbox
        main_thread()
        if axis.upper() not in ("X", "Y", "Z"):
            raise ValueError("invalid axis")
        idx, entries = "XYZ".index(axis.upper()), []
        bpy.context.view_layer.update()
        graph = bpy.context.evaluated_depsgraph_get()
        for item in objects:
            if isinstance(item, tuple):
                obj, members, label = item
                bbox = combined_bbox(members, graph)
            else:
                obj, label = item, item.name
                bbox = world_bbox(obj, graph)
            if bbox:
                entries.append((obj, (bbox[0][idx]+bbox[1][idx])/2, label))
        entries.sort(key=lambda e: e[1])
        if len(entries) < 2:
            return [label for _, _, label in entries]
        step = (entries[-1][1]-entries[0][1])/(len(entries)-1) if spacing is None else number(spacing, "spacing")
        for i, (obj, center, _) in enumerate(entries):
            matrix = obj.matrix_world.copy()
            matrix.translation[idx] += entries[0][1]+i*step-center
            obj.matrix_world = matrix
        return [label for _, _, label in entries]

    @staticmethod
    def describe_object(obj):
        from .inspect import describe_object
        return describe_object(obj)

    @staticmethod
    def describe_scene(max_objects=100):
        from .inspect import full_summary
        return full_summary(integer(max_objects, "max_objects", 1, 500))

    @staticmethod
    def validate_mesh(obj):
        from .inspect import validate_mesh
        return validate_mesh(obj)


cyber_helper = CyberHelper()
