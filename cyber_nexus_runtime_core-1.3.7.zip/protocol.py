"""Pure Python protocol: safe to test outside Blender. Not an execution sandbox."""
import hashlib
import json
import math
import time
import secrets

MAX_PACKET = 1024 * 1024
MAX_RESPONSE = 4 * 1024 * 1024
MAX_TEXT = 65536
VIEWS = {"persp", "front", "back", "left", "right", "top", "bottom"}
KEYS = {"token", "code", "ops", "snapshot", "scene_summary", "timeout",
        "undo_push", "request_id", "issued_at", "expected_rev", "expected_session", "result_mode"}


class RequestError(Exception):
    pass


class CodeTimeout(BaseException):
    pass


class BoundedOutput:
    def __init__(self, limit=MAX_TEXT):
        self.limit, self.size = limit, 0
        self.parts, self.truncated = [], False

    def write(self, text):
        if not isinstance(text, str):
            raise TypeError("write requires str")
        room = max(0, self.limit - self.size)
        if room:
            part = text[:room]
            self.parts.append(part)
            self.size += len(part)
        self.truncated |= len(text) > room
        return len(text)

    def flush(self):
        pass

    def isatty(self):
        return False

    def getvalue(self):
        return "".join(self.parts) + ("\n[output truncated]" if self.truncated else "")


def truncate(text, size=MAX_TEXT):
    text = str(text)
    return text if len(text) <= size else text[:size] + "\n[truncated]"


def error(message, code="request_error", request_id=None):
    return {"status": "error", "code": code, "message": truncate(message, 4096),
            "request_id": request_id, "stdout": "", "traceback": "",
            "result": None, "image": None, "images": [], "scene_summary": None}


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def _constant(value):
    raise ValueError("non-finite JSON constant")


def _finite_json(value, depth=0):
    if depth > 32:
        raise RequestError("JSON nesting exceeds 32 levels")
    kind = type(value)
    if kind is float:
        if not math.isfinite(value):
            raise RequestError("non-finite number")
    elif kind is str:
        if not value.isascii():
            try:
                value.encode("utf-8")
            except UnicodeError:
                raise RequestError("unpaired Unicode surrogate") from None
    elif kind is dict:
        for key, item in value.items():
            _finite_json(key, depth + 1)
            _finite_json(item, depth + 1)
    elif kind is list:
        for item in value:
            _finite_json(item, depth + 1)


def names(value, label):
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list) or len(value) > 64 or any(
        not isinstance(x, str) or not x or len(x) > 256 for x in value
    ):
        raise RequestError(label + " must be an array of up to 64 names/IDs")
    return value


def integer(value, label, low, high):
    if type(value) is not int or not low <= value <= high:
        raise RequestError(f"{label} must be an integer in [{low}, {high}]")
    return value


def parse(packet, token):
    if len(packet) > MAX_PACKET:
        raise RequestError("request exceeds 1 MiB")
    try:
        raw = json.loads(packet.decode("utf-8"), object_pairs_hook=_pairs,
                         parse_constant=_constant)
    except (ValueError, UnicodeError, RecursionError):
        raise RequestError("invalid UTF-8 JSON") from None
    if not isinstance(raw, dict):
        raise RequestError("top level must be an object")
    supplied = raw.get("token")
    if not isinstance(supplied, str) or not supplied.isascii() or not secrets.compare_digest(supplied, token):
        raise RequestError("authentication failed")
    _finite_json(raw)
    if set(raw) - KEYS:
        raise RequestError("unknown request keys: " + str(sorted(set(raw) - KEYS)))
    if ("code" in raw) == ("ops" in raw):
        raise RequestError("provide exactly one of code / ops")
    if "code" in raw and not isinstance(raw["code"], str):
        raise RequestError("code must be a string")
    if "ops" in raw:
        if not isinstance(raw["ops"], list) or not 1 <= len(raw["ops"]) <= 128:
            raise RequestError("ops must contain 1..128 operations")
        if any(not isinstance(op, dict) or not isinstance(op.get("op"), str) for op in raw["ops"]):
            raise RequestError("each operation needs a string op")
    timeout = raw.get("timeout", 30.0)
    if type(timeout) not in (int, float) or not 0 < timeout <= 300:
        raise RequestError("timeout must be in (0, 300]")
    undo = raw.get("undo_push", True)
    if type(undo) is not bool:
        raise RequestError("undo_push must be bool")
    rid = raw.get("request_id")
    if rid is not None and (not isinstance(rid, str) or not 1 <= len(rid) <= 128 or
                            any(not 33 <= ord(c) <= 126 for c in rid)):
        raise RequestError("request_id must contain 1..128 visible ASCII characters")
    issued = raw.get("issued_at")
    if issued is not None and (type(issued) not in (int, float) or issued <= 0):
        raise RequestError("issued_at must be a positive Unix timestamp")
    if "expected_session" in raw and (not isinstance(raw["expected_session"], str) or not 1 <= len(raw["expected_session"]) <= 128):
        raise RequestError("expected_session must be a non-empty string")
    rev = raw.get("expected_rev")
    if rev is not None:
        integer(rev, "expected_rev", 0, 2**63-1)
        if not isinstance(raw.get("expected_session"), str):
            raise RequestError("expected_rev also requires expected_session")
    # LLM-oriented defaults: avoid rendering unless the client explicitly asks.
    snap = raw.get("snapshot", False)
    snap_opts = {"views": ["persp"], "focus": [], "isolate": False, "resolution": 512, "shading": "material"}
    if isinstance(snap, dict):
        if set(snap) - {"enabled", "views", "focus", "isolate", "resolution", "shading"}:
            raise RequestError("unknown snapshot option")
        snap_opts.update({k: v for k, v in snap.items() if k != "enabled"})
        enabled = snap.get("enabled", True)
        if type(enabled) is not bool or type(snap_opts["isolate"]) is not bool:
            raise RequestError("snapshot enabled/isolate must be bool")
        views = snap_opts["views"]
        if isinstance(views, str):
            views = [views]
        if not isinstance(views, list) or not 1 <= len(views) <= 7 or any(
            not isinstance(v, str) or v not in VIEWS for v in views
        ):
            raise RequestError("unknown/invalid snapshot views")
        snap_opts["views"] = list(dict.fromkeys(views))
        snap_opts["focus"] = names(snap_opts["focus"], "snapshot.focus")
        integer(snap_opts["resolution"], "resolution", 128, 2048)
        if snap_opts["isolate"] and not snap_opts["focus"]:
            raise RequestError("isolate requires focus")
        if snap_opts["shading"] not in ("solid", "material", "wireframe"):
            raise RequestError("snapshot shading must be solid/material/wireframe")
    elif type(snap) is bool:
        enabled = snap
    else:
        raise RequestError("snapshot must be bool or object")
    # Default to a compact request-local diff. The client can request overview/full
    # explicitly, and subsequent calls can provide a previous session/revision.
    summary = raw.get("scene_summary", {"mode": "diff", "max_objects": 20})
    opts = {"mode": "full", "max_objects": 100, "focus": []}
    if isinstance(summary, dict):
        if set(summary) - {"mode", "max_objects", "focus", "since_rev", "session"}:
            raise RequestError("unknown scene_summary option")
        opts.update(summary)
        opts["mode"] = summary.get("mode", "diff")
        opts["max_objects"] = summary.get("max_objects", 20 if opts["mode"] == "diff" else 100)
        if opts["mode"] not in ("full", "diff", "overview", "off"):
            raise RequestError("invalid summary mode")
        integer(opts["max_objects"], "max_objects", 1, 500)
        opts["focus"] = names(opts["focus"], "scene_summary.focus")
        if "since_rev" in opts:
            integer(opts["since_rev"], "since_rev", 0, 2**63-1)
        if "session" in opts and not isinstance(opts["session"], str):
            raise RequestError("summary.session must be str")
        summary_enabled = opts["mode"] != "off"
    elif type(summary) is bool:
        summary_enabled = summary
    else:
        raise RequestError("scene_summary must be bool or object")
    result_mode = raw.get("result_mode", "compact")
    if result_mode not in ("compact", "full"):
        raise RequestError("result_mode must be compact or full")
    out = {k: raw[k] for k in ("code", "ops") if k in raw}
    out.update(timeout=float(timeout), undo_push=undo, request_id=rid, issued_at=issued,
               expected_rev=rev, expected_session=raw.get("expected_session"),
               snapshot=enabled, snapshot_options=snap_opts,
               scene_summary=summary_enabled, scene_summary_options=opts,
               result_mode=result_mode)
    return out


def check_fresh(request, now=None):
    now = time.time() if now is None else now
    issued = request.get("issued_at")
    if issued is not None:
        if issued > now + 60:
            raise RequestError("issued_at is in the future")
        if now - issued > 300:
            raise RequestError("request expired before execution")


def fingerprint(request):
    canonical = {k: v for k, v in request.items() if k != "request_id"}
    return hashlib.sha256(json.dumps(canonical, sort_keys=True, ensure_ascii=True,
                                    separators=(",", ":"), allow_nan=False).encode("ascii")).hexdigest()


def _encode(payload):
    return (json.dumps(payload, ensure_ascii=True, allow_nan=False,
                       separators=(",", ":")) + "\n").encode("ascii")


def encode_response(payload):
    """Identical size handling for success/error; return the actual cached wire bytes."""
    encoded = _encode(payload)
    if len(encoded) <= MAX_RESPONSE:
        return encoded
    slim = dict(payload)
    slim["image"] = None
    encoded = _encode(slim)
    if len(encoded) <= MAX_RESPONSE:
        slim["note"] = truncate(str(slim.get("note", "")) + " Legacy image alias omitted; use images.", 4096)
        encoded = _encode(slim)
        if len(encoded) <= MAX_RESPONSE:
            return encoded
    slim["images"] = []
    slim["snapshot_error"] = "images omitted to meet response limit"
    encoded = _encode(slim)
    if len(encoded) <= MAX_RESPONSE:
        return encoded
    slim["scene_summary"] = None
    slim["scene_summary_error"] = "summary omitted to meet response limit; query explicitly"
    # Drop expendable summary BEFORE any structured operation results.
    encoded = _encode(slim)
    if len(encoded) <= MAX_RESPONSE:
        return encoded
    for field in ("stdout", "traceback", "note", "message"):
        if field in slim:
            slim[field] = truncate(slim[field], 8192)
    encoded = _encode(slim)
    if len(encoded) <= MAX_RESPONSE:
        return encoded
    # Pathological final fallback must never look like a complete success page.
    slim.update(status="error", code="response_too_large", response_details_complete=False,
                op_results_omitted=True, op_results=[], result=None, result_json=None,
                message="Execution may have completed; result details could not be delivered. Query scene; do not blindly repeat mutations.")
    encoded = _encode(slim)
    if len(encoded) <= MAX_RESPONSE:
        return encoded
    fallback = error("response too large; execution may already have changed the scene",
                     "response_too_large", payload.get("request_id"))
    fallback.update(executed=payload.get("executed", True),
                    execution_state=payload.get("execution_state", "unknown"),
                    response_details_complete=False)
    for key in ("session", "rev"):
        if key in payload:
            fallback[key] = payload[key]
    return _encode(fallback)
