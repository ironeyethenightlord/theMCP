"""Shared-schema preflight and explicit operation dispatcher."""
import bpy
from . import components as C, inspect as I, schema as S
from . import protocol as P, resource_limits as L
from .helpers import CyberHelper as H

MUTATIONS = S.MUTATIONS
SCHEMAS = S.OPERATIONS


def validate(ops):
    normalized = S.normalize_ops(ops)
    for op in normalized:
        if op["op"].startswith("component."):
            C.component_id(op["id"])
            if op.get("parent") is not None:
                C.component_id(op["parent"])
            if op.get("target") is not None:
                C.component_id(op["target"])
    materials = [m.name for m in bpy.data.materials]+[m.get("cn_material_key", "") for m in bpy.data.materials]
    virtual = S.simulate(normalized, C.read_only(), materials)
    registry_mutations = {"component.create", "component.update", "component.rebuild",
                          "component.delete", "component.anchor.set", "component.attach"}
    if any(op["op"] in registry_mutations for op in normalized):
        C.serialized(virtual)
        # Reserve a conservative peak for ALL builds in a batch, before mutations.
        future = dict(C.read_only())
        cost = objects = archive = 0
        for op in normalized:
            kind, cid = op["op"], op.get("id")
            if kind == "component.create":
                future[cid] = {"generator": op["generator"], "params": S.generator_params(op["generator"], op["params"])}
            elif kind == "component.update":
                rec = future[cid]
                future[cid] = {**rec, "params": S.merge_params(rec["generator"], rec["params"], op["params"])}
            elif kind == "component.delete":
                rec = future.pop(cid)
                archive += rec.get("object_count", L.object_count(rec["generator"], rec["params"]))+1
            if kind in ("component.create", "component.rebuild"):
                rec = future[cid]
                cost += L.geometry_cost(rec["generator"], rec["params"])
                objects += L.object_count(rec["generator"], rec["params"])+1
        L.check_scene(C.resource_usage(), extra_cost=cost, extra_objects=objects, extra_archived=archive)
    return normalized


def capabilities(operations=None, generators=None):
    out = {"protocol": 5, "schema_version": "1.3.7",
           "units": "All linear inputs/tolerances are Blender Units (BU); angles are radians; no auto-conversion from scene display units.",
           "binding": "mutations/code require expected_session; expected_rev is optional",
           "response": {"snapshot_default": False, "scene_summary_default": "compact diff",
                        "result_mode_default": "compact", "result_modes": ["compact", "full"]},
           "precision": {"max_chord_error": "optional for cylinder/cone/sphere/revolve; in BU; 0 preserves fixed segment counts",
                         "profile_tolerance": "in BU; extrude/revolve profiles (including implicit revolve end-caps) reject near-zero edges and self-intersections",
                         "mesh_check_default": "evaluated modifiers; world-space BU tolerance checks near-zero edges/degenerate faces; self-intersections are not tested",
                         "clearance": "AABB broad-phase only; not exact mesh distance",
                         "reported_numbers": "check.dimensions/clearance preserve raw measured floats; display summaries round to 6 decimals"},
           "roots": "root transforms affect direct geometry members; parent metadata remains logical",
           "attach": "one-shot rigid anchor alignment, unit root scales; not a persistent constraint",
           "rebuild": "role-matched Objects reused; owned geometry/local basis/helper modifiers replaced",
           "timeout": "shared preflight/execution Python deadline; summary/snapshot excluded; protected commit may exceed deadline; C calls not killable",
           "resource_limits": {**L.LIMITS, "cost_unit": "estimated vertices + faces; base geometry, not arbitrary evaluated modifiers/native memory"},
           "recovery": "query after delete; recovery.purge requires confirm=true and permanently removes archived objects",
           "structured_results": "lossless in compact/full; over-budget result stops the batch with output_budget_exceeded; retry the read with smaller limit/fields or full mode",
           "snapshot": {"enabled_default": False, "views": sorted(P.VIEWS), "shading": ["solid", "material", "wireframe"],
                        "options": ["views", "focus", "isolate", "resolution", "shading"],
                        "note": "isolate requires focus; wireframe freezes evaluated polygon geometry into temporary edge meshes; unsupported types fail loudly; not a final shaded render"}}
    for requested, catalog, key in ((operations, S.OPERATIONS, "operations"), (generators, S.GENERATORS, "generators")):
        if requested is None:
            out[key] = sorted(catalog)
        else:
            unknown = set(requested)-set(catalog)
            if unknown:
                raise ValueError("unknown capabilities: "+str(sorted(unknown)))
            out[key] = {name: catalog[name] for name in requested}
    return out


COMPONENT_ACTIONS = ("create", "update", "rebuild", "delete", "transform", "anchor_set", "attach")


def run(op):
    kind = op.get("op")
    if kind not in SCHEMAS:
        # run() is also reachable directly (tests/smoke); fail cleanly, never AttributeError/KeyError.
        raise ValueError("unknown operation: " + str(kind))
    # Normalize here too: run_request() already did it, but a direct caller must not get
    # KeyError for a legitimate op that simply omitted an optional field.
    p = S.normalize({k: v for k, v in op.items() if k != "op"}, SCHEMAS[kind])
    if kind == "system.capabilities":
        return capabilities(**p)
    if kind == "scene.overview":
        return I.overview(**p)
    if kind == "scene.describe":
        return I.full_summary(**p)
    if kind == "scene.query":
        return I.query(**p)
    if kind == "scene.changes":
        return I.changes(p["since_rev"], p["session"], p.get("limit", 20))
    if kind == "component.describe":
        return C.describe(p.pop("id"), **p)
    if kind == "component.recovery":
        return C.recovery(p.pop("id"), **p)
    if kind == "component.recovery.purge":
        result = C.recovery_purge(p.pop("id"), **p)
        I.record(invalidated=True, reason="irreversible_recovery_purge")
        return result
    if kind.startswith("component."):
        action = kind.split(".", 1)[1].replace(".", "_")
        if action not in COMPONENT_ACTIONS:
            raise ValueError("unknown operation: " + kind)
        cid = p.pop("id", None)
        if not isinstance(cid, str):
            raise ValueError(kind + " requires a string id")
        result = getattr(C, action)(cid, **p)
        I.record(deleted=[cid] if action == "delete" else [], changed=[] if action == "delete" else [cid])
        return result
    if kind == "object.describe":
        return I.object_page(p.pop("id"), **p)
    if kind == "object.transform":
        ref = p.pop("id")
        members = I.resolve(ref)
        if len(members) != 1:
            raise ValueError("object.transform requires one object; use component.transform for groups")
        H.set_transform(members[0], **p)
        I.record(invalidated=True, reason="direct_transform; generator params unchanged")
        return {"id": ref, "transformed": True}
    if kind in ("objects.align", "objects.distribute"):
        refs, objs, seen, changed_cids, raw_objs = p.pop("ids"), [], set(), [], False
        registry = C.read_only()
        for ref in refs:
            if ref in registry:
                root_obj = C.ensure_root(ref)
                if root_obj.as_pointer() not in seen:
                    objs.append((root_obj, C.objects(ref), ref))
                    seen.add(root_obj.as_pointer())
                    changed_cids.append(ref)
            else:
                members = I.resolve(ref)
                if len(members) != 1:
                    raise ValueError("align/distribute refs must resolve to single objects or components")
                obj = members[0]
                if obj.as_pointer() not in seen:
                    objs.append(obj)
                    seen.add(obj.as_pointer())
                    raw_objs = True
        result = getattr(H, "align_objects" if kind == "objects.align" else "distribute_objects")(objs, **p)
        I.record(changed=changed_cids, invalidated=raw_objs,
                 reason="direct_transform; generator params unchanged" if raw_objs else None)
        return result
    if kind == "material.pbr":
        mat = H.create_pbr_material(**p)
        I.record(invalidated=True, reason="material_update")
        return {"material": mat.name, "key": mat.get("cn_material_key")}
    if kind == "material.assign":
        ref = p.pop("id")
        for obj in I.resolve(ref):
            H.assign_material(obj, **p)
        I.record(invalidated=True, reason="material_assignment; generator params unchanged")
        return {"id": ref, "assigned": True}
    if kind == "check.mesh":
        return I.mesh_check(p.pop("id"), **p)
    if kind == "check.dimensions":
        report = I.dimensions_check(p["id"], p["target"], p["tolerance"], p["space"])
        report["status"] = "passed" if report["pass"] else "failed"
        report["issues"] = [] if report["pass"] else [{"id": p["id"], "type": "dimensions", "actual": report["actual"], "target": report["target"]}]
        return report
    if kind == "check.clearance":
        report = I.clearance_check(**p)
        report["status"] = "passed" if report["conservative_pass"] else "inconclusive"
        report["issues"] = [] if report["conservative_pass"] else [{"type": "aabb_clearance_inconclusive", "a": p["a"], "b": p["b"], "message": "AABB cannot certify clearance; not proof of collision."}]
        return report
    raise ValueError("unknown operation")
