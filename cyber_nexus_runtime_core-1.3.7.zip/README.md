# Cyber Nexus Runtime Core 1.3.7

**Blender 5.2+ 本机 Agent 建模运行时**：使用 token 保护的 loopback TCP，让外部 Agent / 大模型 API 客户端执行结构化参数化建模与验证，不依赖 MCP。

## 安装

1. 先备份 `.blend`，停止旧版服务。
2. 停用旧版，并通过 Blender 扩展“从磁盘安装 / Install from Disk”更新同 ID 的 ZIP。建议更新后重启 Blender，不要同时启用两份版本。
3. 启用插件，在 3D 视图侧栏 `Cyber Nexus` 点击启动服务。
4. Agent 读取 `~/.cyber_nexus/connection.json`；多实例明确选择 `connection-<pid>.json`。

ZIP 保持现代 Extension 布局，最低版本为 5.2.0。没有额外运行时 Python 依赖；examples 客户端只使用标准库。

## 1.3.7 要点

- ops 结果无损，不再因 compact 截断对象记录、分页字段或 cursor。
- 正确处理删除后 recovery、提交补偿与提交后 warning。
- 统一 ID / 材质名称；重建正确处理对象级材质覆盖。
- 加入共享预检 deadline、保守几何/归档预算及显式不可逆 purge。
- 稳健的剖面数值判断与原始尺寸/间距检查数值。
- attach / local 测量拒绝不可靠的反射或剪切基准。
- 实测并修复真实 Workbench 线框渲染。

## 文档与示例

- `CHANGELOG.md`：1.3.7 改动及客户端行为变更。
- `LLM_INTEGRATION.md`：协议、绑定、重试、输出预算、恢复与精度约定。
- `examples/agent_client.py`：读取概览的标准库 TCP 示例；只有显式 `--demo` 才创建测试组件。
- `tests/README.md`：真实 5.2.2 LTS bpy 的测试范围、机器结果及重跑方法。

```bash
# 只读当前 Blender 概览；不要把 token 发送给模型供应商
python examples/agent_client.py

# 多实例选择明确的 connection 文件
python examples/agent_client.py --connection ~/.cyber_nexus/connection-12345.json
```

## 安全与能力边界

Token 等价于 Blender 进程权限，Python code 不是沙箱。预算和 timeout 不是原生内存/执行的硬隔离。线性单位为 BU、角度为弧度；AABB clearance 不是精确距离；mesh check 不检测自交；一次性 attach 不是持久装配约束。需要制造级保证时仍需 CAD 内核与独立验证。

许可证：GPL-3.0-or-later，见 `LICENSE`。
