"""Workbench geometry previews. Fresh flat scene; never inherit compositing/sequencing.
Uses source View Layer visibility when choosing links. Collection hierarchy is not copied;
complex collection overrides/Geometry Nodes dependencies require real Blender testing.
"""
import base64
import contextlib
import math
import os
import secrets
import tempfile
import bpy
from mathutils import Matrix, Vector
from .helpers import main_thread, window_context
from .inspect import resolve
from . import components, resource_limits as L

DIRECTIONS = {"persp": (4, -6, 4), "front": (0, -1, 0), "back": (0, 1, 0),
              "right": (1, 0, 0), "left": (-1, 0, 0), "top": (0, 0, 1), "bottom": (0, 0, -1)}
GEOMETRY = {"MESH", "CURVE", "SURFACE", "META", "FONT", "CURVES", "POINTCLOUD", "VOLUME", "GREASEPENCIL"}


def renderable(obj):
    return obj.type in GEOMETRY or (obj.type == "EMPTY" and obj.instance_type == "COLLECTION")


@contextlib.contextmanager
def material_colors():
    saved = []
    try:
        for mat in bpy.data.materials:
            tree = mat.node_tree
            bsdf = next((n for n in tree.nodes if n.type == "BSDF_PRINCIPLED"), None) if tree else None
            if bsdf is None:
                continue
            socket = bsdf.inputs.get("Base Color")
            if socket and not socket.is_linked:
                saved.append((mat, tuple(mat.diffuse_color)))
                mat.diffuse_color = socket.default_value
        yield
    finally:
        for mat, rgba in saved:
            with contextlib.suppress(Exception):
                mat.diffuse_color = rgba


def wire_proxies(scene, linked, graph, thickness, owned_objects, owned_meshes):
    """Actual edge geometry: Workbench render ignores viewport shading.type.
    Freeze evaluated geometry into disposable world-space meshes, never change
    source object modifiers/transforms. Unsupported non-mesh data fails loudly.
    """
    cost = 0
    names = {obj.name_full for obj in linked}

    def add(evaluated, matrix):
        nonlocal cost
        if evaluated.type not in {"MESH", "CURVE", "SURFACE", "FONT", "META"}:
            raise ValueError("wireframe conversion is unavailable for " + evaluated.type)
        mesh = bpy.data.meshes.new_from_object(evaluated, depsgraph=graph)
        owned_meshes.append(mesh)
        cost += len(mesh.vertices)+len(mesh.polygons)
        L.check_request(cost)
        if not mesh.polygons:
            return
        mesh.transform(matrix)
        mesh.materials.clear()
        proxy = bpy.data.objects.new("__CNWire_"+secrets.token_hex(4), mesh)
        owned_objects.append(proxy)
        scene.collection.objects.link(proxy)
        wire = proxy.modifiers.new("CN Preview Wire", "WIREFRAME")
        wire.thickness, wire.use_replace = thickness, True
        wire.use_even_offset, wire.use_boundary = True, True

    for obj in linked:
        if obj.type != "EMPTY":
            evaluated = obj.evaluated_get(graph)
            add(evaluated, evaluated.matrix_world)
    count = 0
    for inst in graph.object_instances:
        if not inst.is_instance:
            continue
        parent = inst.parent.original if inst.parent else None
        if parent is None or parent.name_full not in names or parent.hide_render:
            continue
        original = inst.object.original
        if original.hide_render or original.get(components.ARCHIVED):
            continue
        count += 1
        if count > 20000:
            raise ValueError("wireframe instance budget exceeded (20000)")
        add(inst.object, inst.matrix_world)
    if not owned_objects:
        raise ValueError("no polygon surfaces available for wireframe preview")


def snapshots(options):
    main_thread()
    source = bpy.context.scene
    if getattr(bpy.app, "is_job_running", lambda job: False)("RENDER"):
        raise RuntimeError("another render job is running")
    graph, layer = bpy.context.evaluated_depsgraph_get(), bpy.context.view_layer
    focus, seen = [], set()
    for ref in options["focus"]:
        for obj in resolve(ref):
            for candidate in [obj, *obj.children_recursive]:
                if candidate.as_pointer() not in seen:
                    seen.add(candidate.as_pointer())
                    focus.append(candidate)
    for obj in source.objects:
        if obj.mode == "EDIT":
            obj.update_from_editmode()
    layer.update()
    # Archived (deleted-component) objects are hidden but a user could re-show the
    # recovery collection; never let them leak into a preview.
    visible = [o for o in source.objects if renderable(o) and not o.hide_render
               and not o.get(components.ARCHIVED) and o.visible_get(view_layer=layer)]
    linked = [o for o in focus if renderable(o) and not o.hide_render and not o.get(components.ARCHIVED)] if options["isolate"] else visible
    if not linked:
        raise ValueError("no renderable objects for snapshot")
    framing = focus if focus else visible
    frame_names = {o.name_full for o in framing}
    points = []

    def add_bounds(matrix, corners):
        if not corners or all(tuple(c) == (-1, -1, -1) for c in corners):
            return
        for corner in corners:
            p = matrix @ Vector(corner)
            if all(math.isfinite(x) for x in p):
                points.append(p)

    for obj in framing:
        if obj.type not in GEOMETRY:
            continue
        evaluated = obj.evaluated_get(graph)
        add_bounds(evaluated.matrix_world, evaluated.bound_box)
    instance_count = 0
    bounds_truncated = False
    for inst in graph.object_instances:
        if not inst.is_instance:
            continue
        instance_count += 1
        if instance_count > 20000:
            bounds_truncated = True
            break
        parent = inst.parent.original if inst.parent else None
        original = inst.object.original
        if focus and original.name_full not in frame_names and (parent is None or parent.name_full not in frame_names):
            continue
        if original.hide_render or (parent and parent.hide_render):
            continue
        add_bounds(inst.matrix_world, inst.object.bound_box)
    if points:
        low = Vector(tuple(min(p[i] for p in points) for i in range(3)))
        high = Vector(tuple(max(p[i] for p in points) for i in range(3)))
        center, diagonal = (low+high)/2, max((high-low).length, 0.05)
    else:
        center, diagonal = Vector((0, 0, 0)), 2.0
    fd, path = tempfile.mkstemp(prefix="cyber_nexus_", suffix=".jpg")
    os.close(fd)
    scene = camera = camera_data = None
    owned_objects, owned_meshes = [], []
    mode = options.get("shading", "material")
    try:
        scene = bpy.data.scenes.new("__CNPreview_"+secrets.token_hex(4))
        scene.world = source.world
        if mode == "wireframe":
            wire_proxies(scene, linked, graph, max(diagonal/options["resolution"]*0.65, 1e-6),
                         owned_objects, owned_meshes)
        else:
            for obj in linked:
                scene.collection.objects.link(obj)
        render = scene.render
        render.engine = "BLENDER_WORKBENCH"
        render.resolution_x = render.resolution_y = options["resolution"]
        render.resolution_percentage = 100
        render.filepath, render.use_file_extension = path, False
        render.use_compositing, render.use_sequencer, render.use_border = False, False, False
        render.image_settings.file_format = "JPEG"
        render.image_settings.color_mode = "RGB"
        render.image_settings.quality = 80
        with contextlib.suppress(Exception):
            scene.view_settings.view_transform = "Standard"
        shading = scene.display.shading
        shading.light, shading.background_type = "STUDIO", "WORLD"
        mode = options.get("shading", "material")
        if mode == "solid":
            shading.color_type, shading.single_color = "SINGLE", (0.62, 0.62, 0.62)
        elif mode == "wireframe":
            shading.color_type, shading.single_color = "SINGLE", (0.8, 0.8, 0.8)
        elif mode != "material":
            raise ValueError("unknown shading mode")

        camera_data = bpy.data.cameras.new("__CNPreviewCamera")
        camera = bpy.data.objects.new("__CNPreviewCamera", camera_data)
        scene.collection.objects.link(camera)
        scene.camera = camera
        camera.rotation_mode = "QUATERNION"
        images = []
        with material_colors(), window_context():
            for view in options["views"]:
                direction = Vector(DIRECTIONS[view]).normalized()
                camera_data.type = "PERSP" if view == "persp" else "ORTHO"
                camera_data.lens = 50
                camera_data.sensor_fit = "HORIZONTAL"
                distance = max(diagonal*3, 2.0)
                if view == "persp":
                    half_fov = min(camera_data.angle_x, camera_data.angle_y)/2
                    distance = max(diagonal/2/max(math.sin(half_fov), 0.05)*1.2, 0.2)
                camera.location = center+direction*distance
                world_up = Vector((0, 1, 0) if view == "top" else (0, -1, 0) if view == "bottom" else (0, 0, 1))
                cam_x = world_up.cross(direction).normalized()
                cam_y = direction.cross(cam_x).normalized()
                quat = Matrix((cam_x, cam_y, direction)).transposed().to_quaternion()
                camera.rotation_quaternion = quat
                inverse = quat.inverted()
                projected = [inverse @ (p-center) for p in points]
                scale = max((2*max(abs(p.x), abs(p.y)) for p in projected), default=diagonal)
                camera_data.ortho_scale = max(scale*1.18, 0.1)
                camera_data.clip_start = max(0.001, min(0.01, diagonal*0.0001))
                camera_data.clip_end = max(1000, distance+diagonal*10)
                with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
                    result = bpy.ops.render.render(write_still=True, scene=scene.name)
                if "FINISHED" not in result:
                    raise RuntimeError("snapshot render failed")
                with open(path, "rb") as handle:
                    data = handle.read()
                if not data.startswith(b"\xff\xd8"):
                    raise RuntimeError("render did not produce JPEG")
                images.append({"view": view, "image": base64.b64encode(data).decode("ascii"),
                               "resolution": options["resolution"], "focus": options["focus"],
                               "isolate": options["isolate"], "bounds_truncated": bounds_truncated,
                               "kind": "workbench_"+mode+"_preview"})
        return images
    finally:
        if camera is not None:
            bpy.data.objects.remove(camera, do_unlink=True)
        if camera_data is not None and camera_data.users == 0:
            bpy.data.cameras.remove(camera_data)
        if scene is not None:
            bpy.data.scenes.remove(scene, do_unlink=True)
        for obj in owned_objects:
            bpy.data.objects.remove(obj, do_unlink=True)
        for mesh in owned_meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        with contextlib.suppress(OSError):
            os.unlink(path)
