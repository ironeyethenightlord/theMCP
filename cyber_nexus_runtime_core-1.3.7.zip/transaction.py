"""Compensating journal, not a Blender/database transaction. No bpy dependency."""
import contextlib
import sys


class CommitFailure(RuntimeError):
    """Commit failed. restored=True means compensations reported cleanly; it is NOT
    a guarantee that every Blender side effect was undone.
    """
    def __init__(self, original, recovery_errors):
        self.original = original
        self.recovery_errors = list(recovery_errors or [])
        self.restored = not self.recovery_errors
        detail = "compensations reported cleanly (not a full Blender rollback guarantee)" if self.restored else f"recovery errors: {recovery_errors}"
        super().__init__(f"commit failed: {original}; {detail}")


class Journal:
    def __init__(self):
        self.undos = []
        self.committed = False

    def step(self, action, undo):
        if self.committed:
            raise RuntimeError("cannot add actions to a committed journal")
        # Register compensation BEFORE a potentially partially failing action.
        self.undos.append(undo)
        return action()

    def rollback(self):
        if self.committed:
            return ["journal already committed; rollback was NOT attempted"]
        errors = []
        for undo in reversed(self.undos):
            try:
                undo()
            except BaseException as exc:
                errors.append(f"{type(exc).__name__}: {exc}")
        self.undos.clear()
        return errors

    def commit(self):
        self.committed = True
        self.undos.clear()


@contextlib.contextmanager
def protected_commit():
    """Avoid injected Python deadline exceptions during a SMALL commit/rollback.
    Does not prevent native crashes, MemoryError or all Blender side effects.
    """
    old_trace = sys.gettrace()
    sys.settrace(None)
    try:
        yield
    finally:
        sys.settrace(old_trace)
