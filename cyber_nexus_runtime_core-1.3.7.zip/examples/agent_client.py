"""Standard-library TCP example. No MCP/model-provider API dependency.
Run without --demo to READ overview only. --demo explicitly creates a component.
A network timeout is NOT proof that nothing executed. Retry the exact payload.
"""
import argparse
import json
import pathlib
import socket
import time
import uuid

MAX_PACKET, MAX_RESPONSE = 1024*1024, 4*1024*1024


def load_connection(path=None):
    path = pathlib.Path(path).expanduser() if path else pathlib.Path.home()/'.cyber_nexus'/'connection.json'
    connection = json.loads(path.read_text(encoding='utf-8'))
    if connection.get('host') != '127.0.0.1':
        raise ValueError('This example only connects to the local loopback service')
    port = connection.get('port')
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('Invalid port in connection file')
    token = connection.get('token')
    if not isinstance(token, str) or not token.isascii() or len(token) != 64:
        raise ValueError('Invalid session token in connection file')
    return connection  # never send this token to a model-provider API


def make_request(ops, *, expected_session=None, expected_rev=None,
                 request_id=None, result_mode='compact', timeout=30.0):
    """Create ONCE per logical request; keep it for exact-content retries."""
    payload = {'request_id': request_id or uuid.uuid4().hex, 'issued_at': time.time(),
               'ops': ops, 'timeout': timeout, 'snapshot': False,
               'scene_summary': False, 'result_mode': result_mode}
    if expected_session is not None:
        payload['expected_session'] = expected_session
    if expected_rev is not None:
        payload['expected_rev'] = expected_rev
    return payload


def send_request(connection, payload, *, socket_timeout=60.0):
    """No automatic mutation retry, no ID/timestamp/revision refresh.
    Reinvoke with exactly the same payload after a transient network failure.
    Altered/narrower queries require a NEW request_id, not the cached failed ID.
    """
    packet = json.dumps({**payload, 'token': connection['token']},
                        ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')
    if len(packet) > MAX_PACKET:
        raise ValueError('Request exceeds 1 MiB; split the operation batch')
    with socket.create_connection((connection['host'], connection['port']), timeout=socket_timeout) as sock:
        sock.sendall(packet+b'\n')
        response = bytearray()
        while True:
            chunk = sock.recv(min(65536, MAX_RESPONSE+1-len(response)))
            if not chunk:
                break
            response.extend(chunk)
            if len(response)>MAX_RESPONSE:
                raise ValueError('Response exceeds protocol limit')
            if b'\n' in response:
                break
    if not response:
        raise ConnectionError('Connection closed without a receipt; execution state is unknown')
    line, separator, remainder = bytes(response).partition(b'\n')
    if not separator or remainder.strip():
        raise ValueError('Incomplete or unexpected response framing; execution state may be unknown')
    return json.loads(line.decode('ascii'))


def main():
    parser = argparse.ArgumentParser(description='Read Cyber Nexus overview, optionally create an explicit demo component')
    parser.add_argument('--connection', help='Choose connection-<pid>.json for a specific Blender instance')
    parser.add_argument('--demo', action='store_true', help='Explicitly CREATE agent_demo_base in the current scene')
    args = parser.parse_args()
    connection = load_connection(args.connection)
    overview = send_request(connection, make_request([{'op':'scene.overview','limit':20}]))
    if overview.get('status') != 'success':
        print(json.dumps(overview, ensure_ascii=False, indent=2)); return
    print(json.dumps(overview, ensure_ascii=False, indent=2))
    if args.demo:
        # In a real Agent: send only scene/capability information to the model,
        # never the connection token. Validate its planned operations locally.
        payload = make_request([
            {'op':'component.create','id':'agent_demo_base','generator':'box','params':{'size':[2,1,0.2]}},
            {'op':'check.dimensions','id':'agent_demo_base','space':'local','target':[2,1,0.2],'tolerance':1e-5},
            {'op':'check.mesh','id':'agent_demo_base'}],
            expected_session=overview['session'], expected_rev=overview['rev'])
        result = send_request(connection, payload)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if result.get('status') != 'success' or result.get('validation') != 'passed':
            raise RuntimeError('Demo was rejected, partial, or not validated; inspect scene before deciding the next action')


if __name__ == '__main__':
    main()
