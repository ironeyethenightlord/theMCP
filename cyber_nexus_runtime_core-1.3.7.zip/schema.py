"""One pure-Python schema shared by validation, capabilities and preflight tests."""
from collections import OrderedDict
import copy
import math
from . import resource_limits as L

_VALIDATED_PROFILES = OrderedDict()


def rule(kind, **kwargs):
    return {"type": kind, **kwargs}


ID = rule("str", max_length=128)
REF = rule("str", max_length=256)
VEC = rule("vec3")
BOOL = rule("bool")
LIMIT = rule("int", min=1, max=100, default=20)
FIELDS = rule("strings", max_items=32)
QUERY = {"detail": rule("str", enum=["brief", "full"], default="brief"), "fields": FIELDS}
TRANSFORM = {"location": VEC, "rotation_euler": VEC, "scale": rule("vec3", nonzero=True)}
MATERIAL = {"color": rule("vec4", default=[0.8, 0.8, 0.8, 1]),
            "metallic": rule("number", min=0, max=1, default=0),
            "roughness": rule("number", min=0, max=1, default=0.5),
            "emission_color": rule("vec4"), "emission_strength": rule("number", min=0, max=1e6, default=0)}


def spec(required=(), **fields):
    return {"required": list(required), "fields": fields}


OPERATIONS = {
    "system.capabilities": spec(operations=rule("strings", max_items=32), generators=rule("strings", max_items=16)),
    "scene.overview": spec(limit=LIMIT, cursor=rule("str")),
    "scene.describe": spec(limit=LIMIT, focus=rule("strings", max_items=64), **QUERY),
    "scene.query": spec(kind=rule("str", enum=["components", "objects"], default="components"),
                        prefix=rule("str", default=""), under=ID, limit=LIMIT, cursor=rule("str"), **QUERY),
    "scene.changes": spec(("since_rev", "session"), since_rev=rule("int", min=0, max=2**63-1), session=ID, limit=LIMIT),
    "component.describe": spec(("id",), id=ID, limit=LIMIT, cursor=rule("str"), **QUERY),
    "component.create": spec(("id", "generator"), id=ID, generator=rule("str"), params=rule("dict", default={}), label=rule("str", max_length=256), parent=ID),
    "component.update": spec(("id", "params"), id=ID, params=rule("dict")),
    "component.rebuild": spec(("id", "discard_manual"), id=ID, discard_manual=rule("bool", const=True)),
    "component.delete": spec(("id", "discard_manual"), id=ID, discard_manual=rule("bool", const=True)),
    "component.transform": spec(("id",), id=ID, **TRANSFORM),
    "component.anchor.set": spec(("id", "name"), id=ID, name=ID, location=rule("vec3", default=[0, 0, 0]), rotation_euler=rule("vec3", default=[0, 0, 0])),
    "component.attach": spec(("id", "target"), id=ID, target=ID, anchor=rule("str", default="origin"), target_anchor=rule("str", default="origin"), gap=rule("number", default=0)),
    "component.recovery": spec(("id",), id=ID, limit=LIMIT, cursor=rule("str")),
    "component.recovery.purge": spec(("id", "confirm"), id=ID, confirm=rule("bool", const=True)),
    "object.describe": spec(("id",), id=REF, limit=LIMIT, cursor=rule("str"), **QUERY),
    "object.transform": spec(("id",), id=REF, **TRANSFORM),
    "objects.align": spec(("ids",), ids=rule("strings", min_items=1, max_items=128), axis=rule("str", enum=["X", "Y", "Z"], default="X"), mode=rule("str", enum=["MIN", "CENTER", "MAX"], default="CENTER"), coordinate=rule("number")),
    "objects.distribute": spec(("ids",), ids=rule("strings", min_items=1, max_items=128), axis=rule("str", enum=["X", "Y", "Z"], default="X"), spacing=rule("number")),
    "material.pbr": spec(("name",), name=rule("str", max_length=256), **MATERIAL),
    "material.assign": spec(("id", "material"), id=REF, material=rule("str", max_length=256), slot_index=rule("int", min=0, max=128, default=0)),
    "check.mesh": spec(("id",), id=REF, require_closed=rule("bool", default=True),
                        evaluated=rule("bool", default=True), tolerance=rule("number", exclusive_min=0, default=1e-7),
                        limit=LIMIT, cursor=rule("str"), **QUERY),
    "check.dimensions": spec(("id", "target"), id=REF, target=rule("vec3", nonnegative=True),
                             tolerance=rule("number", min=0, default=0.001),
                             space=rule("str", enum=["world", "local"], default="world")),
    "check.clearance": spec(("a", "b"), a=REF, b=REF, minimum=rule("number", min=0, default=0)),
}
MUTATIONS = {"component.create", "component.update", "component.rebuild", "component.delete", "component.transform",
             "component.anchor.set", "component.attach", "component.recovery.purge", "object.transform", "objects.align", "objects.distribute", "material.pbr", "material.assign"}
GEOM_COMMON = {"location": rule("vec3", default=[0, 0, 0]), "rotation_euler": rule("vec3", default=[0, 0, 0]),
               "bevel": rule("number", min=0, default=0), "material": rule("str", max_length=256, nullable=True)}
GENERATORS = {
    "box": spec(size=rule("vec3", positive=True, default=[1, 1, 1]), **GEOM_COMMON),
    "cylinder": spec(radius=rule("number", exclusive_min=0, default=0.5), depth=rule("number", exclusive_min=0, default=1), vertices=rule("int", min=3, max=512, default=32), max_chord_error=rule("number", min=0, default=0), **GEOM_COMMON),
    "cone": spec(radius_bottom=rule("number", min=0, default=0.5), radius_top=rule("number", min=0, default=0), depth=rule("number", exclusive_min=0, default=1), vertices=rule("int", min=3, max=512, default=32), max_chord_error=rule("number", min=0, default=0), **GEOM_COMMON),
    "sphere": spec(radius=rule("number", exclusive_min=0, default=0.5), segments=rule("int", min=3, max=256, default=32), rings=rule("int", min=3, max=256, default=16), max_chord_error=rule("number", min=0, default=0), **GEOM_COMMON),
    "linear_array": spec(shape=rule("str", enum=["box", "cylinder", "cone", "sphere"], default="box"),
                         shape_params=rule("dict", default={}), count=rule("int", min=1, max=128, default=3),
                         step=rule("vec3", default=[1.2, 0, 0]), **GEOM_COMMON),
    "slatted_panel": spec(width=rule("number", exclusive_min=0, default=0.48), height=rule("number", exclusive_min=0, default=0.62), thickness=rule("number", exclusive_min=0, default=0.025), slats=rule("int", min=1, max=128, default=7), gap=rule("number", min=0, default=0.015), **GEOM_COMMON),
    "extrude": spec(("points",), points=rule("points2", min_items=3, max_items=1024), depth=rule("number", exclusive_min=0, default=1), profile_tolerance=rule("number", exclusive_min=0, default=1e-7), **GEOM_COMMON),
    "revolve": spec(("points",), points=rule("points2", min_items=2, max_items=512), segments=rule("int", min=3, max=512, default=64), max_chord_error=rule("number", min=0, default=0), profile_tolerance=rule("number", exclusive_min=0, default=1e-7), **GEOM_COMMON),
    "tube": spec(("path",), path=rule("points3", min_items=2, max_items=4096), radius=rule("number", exclusive_min=0, default=0.05), location=rule("vec3", default=[0, 0, 0]), rotation_euler=rule("vec3", default=[0, 0, 0]), material=rule("str", max_length=256, nullable=True)),
}


def required_circle_segments(radius, max_chord_error, minimum=3, maximum=512):
    """Smallest regular polygon count whose radial sagitta is within the requested error."""
    if max_chord_error <= 0 or radius <= 0 or max_chord_error >= radius:
        return minimum
    angle = math.acos(max(-1.0, min(1.0, 1.0-max_chord_error/radius)))
    required = math.ceil(math.pi/angle) if angle > 0 else maximum+1
    if required > maximum:
        raise ValueError(f"requested chord error needs {required} segments; maximum is {maximum}")
    return max(minimum, required)


def required_sphere_rings(radius, max_chord_error, minimum=3, maximum=256):
    """Conservative latitude-ring count for a UV sphere under a sagitta bound."""
    if max_chord_error <= 0 or radius <= 0 or max_chord_error >= radius:
        return minimum
    angle = math.acos(max(-1.0, min(1.0, 1.0-max_chord_error/radius)))
    required = math.ceil(math.pi/(2*angle))+1 if angle > 0 else maximum+1
    if required > maximum:
        raise ValueError(f"requested chord error needs {required} sphere rings; maximum is {maximum}")
    return max(minimum, required)


def _orient(p, q, r):
    return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])


def _on_segment(p, q, r, tolerance):
    return (min(p[0], q[0])-tolerance <= r[0] <= max(p[0], q[0])+tolerance and
            min(p[1], q[1])-tolerance <= r[1] <= max(p[1], q[1])+tolerance)


def _segments_intersect(a, b, c, d, tolerance):
    if (max(a[0], b[0])+tolerance < min(c[0], d[0]) or
        max(c[0], d[0])+tolerance < min(a[0], b[0]) or
        max(a[1], b[1])+tolerance < min(c[1], d[1]) or
        max(c[1], d[1])+tolerance < min(a[1], b[1])):
        return False
    eps_ab = tolerance*max(math.hypot(b[0]-a[0], b[1]-a[1]), tolerance)
    eps_cd = tolerance*max(math.hypot(d[0]-c[0], d[1]-c[1]), tolerance)
    o1, o2, o3, o4 = _orient(a, b, c), _orient(a, b, d), _orient(c, d, a), _orient(c, d, b)
    if ((o1 > eps_ab and o2 < -eps_ab or o1 < -eps_ab and o2 > eps_ab) and
        (o3 > eps_cd and o4 < -eps_cd or o3 < -eps_cd and o4 > eps_cd)):
        return True
    return ((abs(o1) <= eps_ab and _on_segment(a, b, c, tolerance)) or
            (abs(o2) <= eps_ab and _on_segment(a, b, d, tolerance)) or
            (abs(o3) <= eps_cd and _on_segment(c, d, a, tolerance)) or
            (abs(o4) <= eps_cd and _on_segment(c, d, b, tolerance)))


def profile_area2(points):
    """Twice signed area, translated to the first point to avoid cancellation."""
    ox, oy = points[0]
    return math.fsum((a[0]-ox)*(b[1]-oy)-(b[0]-ox)*(a[1]-oy)
                     for a, b in zip(points, points[1:]+points[:1]))


def validate_profile(points, closed, tolerance=1e-7, label="profile"):
    """Reject repeated/near-zero edges and non-adjacent segment intersections in 2D."""
    if type(tolerance) not in (int, float) or not math.isfinite(tolerance) or tolerance <= 0:
        raise ValueError("profile_tolerance must be a finite positive number")
    n = len(points)
    minimum = 3 if closed else 2
    if n < minimum:
        raise ValueError(f"{label} needs at least {minimum} points")
    cache_key = (bool(closed), float(tolerance), tuple((float(p[0]), float(p[1])) for p in points))
    if cache_key in _VALIDATED_PROFILES:
        _VALIDATED_PROFILES.move_to_end(cache_key)
        return
    if closed and math.hypot(points[0][0]-points[-1][0], points[0][1]-points[-1][1]) <= tolerance:
        raise ValueError(f"{label} must not repeat its first point at the end")
    edge_count = n if closed else n-1
    for i in range(edge_count):
        a, b = points[i], points[(i+1) % n]
        if math.hypot(a[0]-b[0], a[1]-b[1]) <= tolerance:
            raise ValueError(f"{label} has a zero/near-zero edge at {i}")
    for i in range(edge_count):
        a, b = points[i], points[(i+1) % n]
        for j in range(i+1, edge_count):
            if j == i+1 or (closed and i == 0 and j == edge_count-1):
                continue
            c, d = points[j], points[(j+1) % n]
            if _segments_intersect(a, b, c, d, tolerance):
                raise ValueError(f"{label} self-intersects at edges {i} and {j}")
    _VALIDATED_PROFILES[cache_key] = True
    while len(_VALIDATED_PROFILES) > 32:
        _VALIDATED_PROFILES.popitem(last=False)


def validate_revolve_profile(points, tolerance=1e-7, label="revolve profile"):
    """Validate open RZ profile together with its implicit Z-axis end-caps."""
    validate_profile(points, closed=False, tolerance=tolerance, label=label)
    if any(r < 0 for r, _ in points) or any(a[0] <= tolerance and b[0] <= tolerance for a, b in zip(points, points[1:])):
        raise ValueError("invalid revolved radius/axis segment")
    if any(r <= tolerance for r, _ in points[1:-1]):
        raise ValueError("revolve profile cannot touch axis at interior points")
    capped = ([] if points[0][0] <= tolerance else [(0.0, float(points[0][1]))])
    capped.extend((float(r), float(z)) for r, z in points)
    if points[-1][0] > tolerance:
        capped.append((0.0, float(points[-1][1])))
    if len(capped) < 3 or abs(capped[0][1]-capped[-1][1]) <= tolerance:
        raise ValueError(f"{label} caps coincide or collapse on Z axis")
    validate_profile(capped, closed=True, tolerance=tolerance, label=label)
    area = profile_area2(capped)
    if abs(area) < tolerance*tolerance:
        raise ValueError("degenerate revolve profile")


def check(value, definition, label):
    if value is None and definition.get("nullable"):
        return
    kind = definition["type"]
    if kind == "bool":
        good = type(value) is bool
    elif kind == "int":
        good = type(value) is int
    elif kind == "number":
        good = type(value) in (float, int) and math.isfinite(value)
    elif kind == "str":
        good = isinstance(value, str) and len(value) <= definition.get("max_length", 512)
        if label not in ("prefix",) and value == "":
            good = False
    elif kind == "dict":
        good = isinstance(value, dict)
    elif kind.startswith("vec"):
        count = int(kind[-1])
        good = isinstance(value, (list, tuple)) and len(value) == count
        if good:
            for item in value:
                check(item, rule("number"), label)
                if abs(item) > 1e7:
                    raise ValueError(label + " component exceeds 1e7 Blender units/radians")
            good = not (definition.get("positive") and any(x <= 0 for x in value))
            good &= not (definition.get("nonnegative") and any(x < 0 for x in value))
            good &= not (definition.get("nonzero") and any(x == 0 for x in value))
    elif kind in ("strings", "points2", "points3"):
        good = isinstance(value, (list, tuple)) and definition.get("min_items", 0) <= len(value) <= definition.get("max_items", 128)
        if good:
            for item in value:
                check(item, rule("str") if kind == "strings" else rule("vec"+kind[-1]), label)
    else:
        raise ValueError("unknown schema type")
    if kind == "vec4" and label in ("color", "emission_color") and good and any(x < 0 or x > 1 for x in value):
        raise ValueError(label + " components must be in [0, 1]")
    if not good:
        raise ValueError(label + " must match " + kind)
    if "const" in definition and value != definition["const"]:
        raise ValueError(label + " must be " + str(definition["const"]))
    if "enum" in definition and value not in definition["enum"]:
        raise ValueError(label + " must be one of " + str(definition["enum"]))
    for key, bad in (("min", lambda x: value < x), ("max", lambda x: value > x), ("exclusive_min", lambda x: value <= x)):
        if key in definition and bad(definition[key]):
            raise ValueError(label + " outside allowed range")


def material_name(value):
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > 256:
        raise ValueError("material name must contain 1..256 non-whitespace characters")
    return value.strip()


def normalize(data, definition):
    if not isinstance(data, dict):
        raise ValueError("parameters must be an object")
    unknown = set(data)-set(definition["fields"])
    missing = set(definition["required"])-set(data)
    if unknown or missing:
        raise ValueError(f"unknown={sorted(unknown)}, missing={sorted(missing)}")
    out = copy.deepcopy(data)
    for key, field in definition["fields"].items():
        if key in out:
            check(out[key], field, key)
            if out[key] is None and field.get("nullable"):
                del out[key]
        elif "default" in field:
            out[key] = copy.deepcopy(field["default"])
    # Match helper material creation. Normalize references, too, including nested
    # generator params through generator_params()/merge_params().
    material_fields = ("material",) + (("name",) if definition is OPERATIONS["material.pbr"] else ())
    for key in material_fields:
        if key in out:
            out[key] = material_name(out[key])
    return out


def generator_params(generator, params):
    if not isinstance(generator, str) or generator not in GENERATORS:
        raise ValueError("unknown generator")
    p = normalize(params, GENERATORS[generator])
    if generator == "slatted_panel" and p["gap"]*(p["slats"]-1) >= p["width"]:
        raise ValueError("gaps exceed panel width")
    if generator == "cone" and p["radius_bottom"] + p["radius_top"] <= 0:
        raise ValueError("at least one cone radius must be positive")
    if generator in ("cylinder", "cone") and p["max_chord_error"] > 0:
        radius = p["radius"] if generator == "cylinder" else max(p["radius_bottom"], p["radius_top"])
        p["vertices"] = max(p["vertices"], required_circle_segments(radius, p["max_chord_error"], 3, 512))
    if generator == "sphere" and p["max_chord_error"] > 0:
        # Split the radial error budget between longitude and latitude so their
        # combined faceting error remains below the requested tolerance.
        local_error = p["max_chord_error"]*0.5
        p["segments"] = max(p["segments"], required_circle_segments(p["radius"], local_error, 3, 256))
        p["rings"] = max(p["rings"], required_sphere_rings(p["radius"], local_error, 3, 256))
    if generator == "linear_array":
        p["shape_params"] = generator_params(p["shape"], p["shape_params"])
        if p["count"] > 1 and not any(abs(value) > 1e-9 for value in p["step"]):
            raise ValueError("linear_array step must be non-zero when count is greater than one")
    if generator == "extrude":
        pts = p["points"]
        tolerance = p["profile_tolerance"]
        validate_profile(pts, closed=True, tolerance=tolerance, label="extrude profile")
        area = profile_area2(pts)
        if abs(area) < tolerance*tolerance:
            raise ValueError("degenerate profile")
    if generator == "revolve":
        pts = p["points"]
        tolerance = p["profile_tolerance"]
        validate_revolve_profile(pts, tolerance=tolerance, label="revolve profile")
        if p["max_chord_error"] > 0:
            max_radius = max(r for r, _ in pts)
            p["segments"] = max(p["segments"], required_circle_segments(max_radius, p["max_chord_error"], 3, 512))
        if len(pts)*p["segments"] > 100000:
            raise ValueError("revolve geometry budget exceeded")
    if generator == "tube" and any(math.dist(a, b) <= 1e-9 for a, b in zip(p["path"], p["path"][1:])):
        raise ValueError("duplicate neighboring path points")
    return p


def _strip_chord_derived(generator, current, patch):
    merged = {**current, **patch}
    if current.get("max_chord_error", 0) > 0:
        fields = GENERATORS[generator]["fields"]
        for key in ("vertices", "segments", "rings"):
            if key in fields and key not in patch:
                merged[key] = copy.deepcopy(fields[key]["default"])
    return merged


def merge_params(generator, current, patch):
    if not isinstance(patch, dict):
        raise ValueError("parameters must be an object")
    if not isinstance(generator, str) or generator not in GENERATORS:
        raise ValueError("unknown generator")
    merged = _strip_chord_derived(generator, current, patch)
    if generator == "linear_array":
        old_shape = current.get("shape", "box")
        new_shape = merged.get("shape", old_shape)
        if new_shape not in GENERATORS:
            raise ValueError("unknown generator")
        if isinstance(patch.get("shape_params"), dict) and new_shape == old_shape and isinstance(current.get("shape_params"), dict):
            merged["shape_params"] = _strip_chord_derived(new_shape, current["shape_params"], patch["shape_params"])
    return generator_params(generator, merged)


def normalize_ops(ops):
    result = []
    for index, op in enumerate(ops):
        kind = op.get("op")
        if kind not in OPERATIONS:
            raise ValueError(f"op {index}: unknown operation")
        try:
            normalized = normalize({k: v for k, v in op.items() if k != "op"}, OPERATIONS[kind])
            if kind in ("component.transform", "object.transform") and not set(normalized) & set(TRANSFORM):
                raise ValueError("provide at least one transform field")
            result.append({"op": kind, **normalized})
        except ValueError as exc:
            raise ValueError(f"op {index} ({kind}): {exc}") from None
    return result


def simulate(ops, registry, materials=()):
    """Validate future component/material references and merged params without bpy changes.
    The registry is copied shallowly; records are deep-copied only when actually modified,
    so validating a 128-op batch against a large registry stays cheap.
    """
    virtual, touched, known_materials = dict(registry), set(), set(materials)
    build_cost = 0

    def mutable(cid):
        if cid not in touched:
            virtual[cid] = copy.deepcopy(virtual[cid])
            touched.add(cid)
        return virtual[cid]
    for index, op in enumerate(ops):
        kind, cid = op["op"], op.get("id")
        try:
            if kind == "material.pbr":
                known_materials.add(op["name"])
            elif kind == "component.create":
                if cid in virtual:
                    raise ValueError("component already exists")
                if op.get("parent") is not None and op["parent"] not in virtual:
                    raise ValueError("parent component not found")
                p = generator_params(op["generator"], op["params"])
                virtual[cid] = {"generator": op["generator"], "params": p, "parent": op.get("parent"), "anchors": {}}
            elif kind in ("component.recovery", "component.recovery.purge"):
                # Recovery objects outlive their live registry record.
                pass
            elif kind.startswith("component."):
                if cid not in virtual:
                    raise ValueError("component not found")
                rec = mutable(cid) if kind in ("component.update", "component.rebuild", "component.anchor.set") else virtual[cid]
                if kind == "component.update":
                    rec["params"] = merge_params(rec["generator"], rec["params"], op["params"])
                elif kind == "component.rebuild":
                    rec["params"] = generator_params(rec["generator"], rec["params"])
                elif kind == "component.delete":
                    if any(r.get("parent") == cid for r in virtual.values()):
                        raise ValueError("delete child components first")
                    del virtual[cid]
                elif kind == "component.anchor.set":
                    if op["name"] == "origin":
                        raise ValueError("origin anchor is reserved")
                    anchors = rec.setdefault("anchors", {})
                    if op["name"] not in anchors and len(anchors) >= 64:
                        raise ValueError("anchor limit (64) exceeded")
                    anchors[op["name"]] = {}
                elif kind == "component.attach":
                    if op["target"] == cid:
                        raise ValueError("cannot attach to self")
                    if op["target"] not in virtual:
                        raise ValueError("target component not found")
                    for record, key in ((rec, op["anchor"]), (virtual[op["target"]], op["target_anchor"])):
                        if key != "origin" and key not in record.get("anchors", {}):
                            raise ValueError("anchor not found: " + key)
            if kind in ("component.create", "component.update", "component.rebuild"):
                record = virtual[cid]
                params = record.get("params", {})
                materials_to_check = [params.get("material")]
                if record.get("generator") == "linear_array":
                    materials_to_check.append(params.get("shape_params", {}).get("material"))
                for material in materials_to_check:
                    if material and material not in known_materials:
                        raise ValueError("material not found: " + material)
            if kind == "material.assign" and op["material"] not in known_materials:
                raise ValueError("material not found: " + op["material"])
            if kind in ("component.create", "component.rebuild"):
                rec = virtual[cid]
                build_cost += L.geometry_cost(rec["generator"], rec["params"])
                L.check_request(build_cost)
            if kind in ("component.create", "component.update", "component.rebuild", "component.delete"):
                L.check_planned(virtual)
        except (ValueError, KeyError) as exc:
            raise ValueError(f"op {index} ({kind}): {exc}") from None
    return virtual
