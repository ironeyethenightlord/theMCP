#!/usr/bin/env python3
"""Standard-library client for Krita Nexus (plugin 1.2.2, protocol 1)."""
import argparse
import json
import socket
import sys
import time
from pathlib import Path

MAX_RESPONSE = 32 * 1024 * 1024
DEFAULT_TIMEOUT = 35.0
WRITE_OPS = {"layer.create", "layer.transform", "layer.modify", "layer.delete",
             "selection.rect", "edit.undo", "edit.redo"}


def connection_info(path=None):
    path = Path(path).expanduser() if path else Path.home() / ".krita_nexus" / "connection.json"
    with path.open("r", encoding="utf-8") as stream:
        info = json.load(stream)
    for key in ("host", "port", "token"):
        if key not in info:
            raise RuntimeError("connection.json lacks %s" % key)
    if info["host"] != "127.0.0.1":
        raise RuntimeError("Refusing non-loopback endpoint")
    info["port"] = int(info["port"])
    return info


def call(info, ops, request_id=1, timeout=DEFAULT_TIMEOUT, continue_on_error=False):
    request = {"id": request_id, "token": info["token"], "ops": ops, "continue_on_error": continue_on_error}
    wire = json.dumps(request, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n"
    deadline = time.monotonic() + timeout
    with socket.create_connection((info["host"], info["port"]), timeout=timeout) as sock:
        if len(wire) - 1 > 1024 * 1024:
            raise ValueError("Request exceeds 1 MiB")
        sock.settimeout(max(0.001, deadline - time.monotonic()))
        sock.sendall(wire)
        data = bytearray()
        while b"\n" not in data:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("Overall request deadline exceeded; write outcome may be unknown")
            sock.settimeout(remaining)
            chunk = sock.recv(65536)
            if not chunk:
                raise ConnectionError("Krita closed the connection before replying")
            data.extend(chunk)
            if len(data) > MAX_RESPONSE:
                raise RuntimeError("Response exceeded safety limit")
    return json.loads(bytes(data).split(b"\n", 1)[0].decode("utf-8"))


def _is_write(op):
    return isinstance(op, dict) and op.get("op") in WRITE_OPS


def inject_latest_session(info, ops, timeout):
    """Opt-in only (--latest-session). Uses the canvas session as it is *now*, which
    uses the document identity guard, not a content revision check."""
    if not any(_is_write(op) and not op.get("expected_session") for op in ops):
        return ops
    overview = call(info, [{"op": "document.overview"}], timeout=timeout)
    first = (overview.get("results") or [{}])[0]
    if first.get("status") != "success":
        raise RuntimeError("cannot read current session: %s" % first.get("message", first.get("code")))
    for op in ops:
        if _is_write(op) and not op.get("expected_session"):
            op["expected_session"] = first["document_session"]
    return ops


def succeeded(response):
    if response.get("status") != "success":
        return False
    return all(item.get("status") == "success" for item in response.get("results", []))


def build_parser():
    parser = argparse.ArgumentParser(description="Call the local Krita Nexus runtime")
    parser.add_argument("--connection", help="Path to connection.json")
    parser.add_argument("--ops", help="JSON array of operations, or '-' to read it from stdin")
    parser.add_argument("--tree", action="store_true", help="Overview plus first page of the layer tree")
    parser.add_argument("--latest-session", action="store_true",
                        help="Fill missing expected_session on write ops with the current session "
                             "(document identity only; not a content freshness check)")
    parser.add_argument("--continue-on-error", action="store_true", help="Continue a batch after failed operations")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        import math
        if not math.isfinite(args.timeout) or args.timeout <= 0:
            raise ValueError("--timeout must be finite and positive")
        info = connection_info(args.connection)
        if args.tree:
            ops = [{"op": "document.overview"}, {"op": "layer.tree", "offset": 0, "limit": 200}]
        elif args.ops is not None:
            text = sys.stdin.read() if args.ops == "-" else args.ops
            ops = json.loads(text)
            if not isinstance(ops, list) or not ops:
                raise ValueError("--ops must be a non-empty JSON array")
        else:
            ops = [{"op": "document.overview"}]
        if args.latest_session:
            ops = inject_latest_session(info, ops, args.timeout)
        response = call(info, ops, timeout=args.timeout, continue_on_error=args.continue_on_error)
    except Exception as exc:
        print("agent_client error: %s" % exc, file=sys.stderr)
        return 2
    print(json.dumps(response, ensure_ascii=False, indent=2))
    return 0 if succeeded(response) else 1


if __name__ == "__main__":
    sys.exit(main())
