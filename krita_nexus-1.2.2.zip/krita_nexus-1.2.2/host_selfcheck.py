"""Run INSIDE Krita's Scripter, not with system Python.
Document-read-only: does not create/move/delete layers or invoke undo.
Prints diagnostics only; does not import another Qt binding or expose tokens.
Covers every host method the 1.2.2 dispatcher actually calls, plus the
optional nodeByUniqueID fast path. This is an API presence check, NOT a
full integration/stability test.
"""
import json
import sys
from krita import Krita, Node, Document, Selection

# Methods the dispatcher calls on every relevant op (must all exist).
NODE_METHODS = (
    'childNodes', 'parentNode', 'remove', 'addChildNode', 'uniqueId',
    'name', 'type', 'visible', 'locked', 'opacity', 'blendingMode',
    'position', 'move', 'thumbnail',
    'setName', 'setOpacity', 'setVisible', 'setLocked', 'setBlendingMode',
)
DOCUMENT_METHODS = (
    'rootNode', 'topLevelNodes', 'createNode', 'setActiveNode',
    'refreshProjection', 'waitForDone', 'thumbnail',
    'name', 'width', 'height', 'resolution',
    'colorModel', 'colorDepth', 'colorProfile', 'setSelection',
)
# Nice-to-have: node lookup without tree traversal. operations.py falls
# back to a bounded walk when this is missing.
DOCUMENT_OPTIONAL_METHODS = ('nodeByUniqueID',)
SELECTION_METHODS = ('select',)
ACTION_CANDIDATES = {'undo': ('edit_undo', 'undo'), 'redo': ('edit_redo', 'redo')}


def main():
    app = Krita.instance()
    report = {
        'krita_version': app.version(),
        'python_version': sys.version.split()[0],
        'loaded_qt_bindings': sorted(n for n in ('PyQt5.QtCore', 'PyQt6.QtCore',
                                    'PySide6.QtCore') if n in sys.modules),
        'node_methods': {name: callable(getattr(Node, name, None))
                         for name in NODE_METHODS},
        'document_methods': {name: callable(getattr(Document, name, None))
                             for name in DOCUMENT_METHODS},
        'document_optional_methods': {name: callable(getattr(Document, name, None))
                                      for name in DOCUMENT_OPTIONAL_METHODS},
        'selection_methods': {name: callable(getattr(Selection, name, None))
                              for name in SELECTION_METHODS},
        'actions': {role: {c: app.action(c) is not None for c in candidates}
                    for role, candidates in ACTION_CANDIDATES.items()},
    }
    # QUuid powers Document.nodeByUniqueID lookups in operations.py.
    try:
        from PyQt5.QtCore import QUuid
        report['quuid_import'] = str(QUuid('00000000-0000-0000-0000-000000000000').isNull())
        report['quuid_importable'] = True
    except Exception as exc:
        report['quuid_importable'] = False
        report['quuid_error'] = '%s: %s' % (type(exc).__name__, exc)

    qt = sys.modules.get('PyQt5.QtCore')
    if qt is not None:
        report['qt_version'] = getattr(qt, 'QT_VERSION_STR', 'unknown')
        report['pyqt_version'] = getattr(qt, 'PYQT_VERSION_STR', 'unknown')
    loaded = sys.modules.get('krita_nexus.runtime')
    report['loaded_nexus_version'] = getattr(loaded, '__version__', None)
    doc = app.activeDocument()
    report['document_open'] = doc is not None
    if doc is not None:
        report['canvas'] = {'width': doc.width(), 'height': doc.height(),
                            'color_model': doc.colorModel(), 'color_depth': doc.colorDepth()}
        node = doc.activeNode()
        report['active_node_type'] = node.type() if node is not None else None
        if node is not None:
            p = node.position()
            report['active_node_position'] = {'x': p.x(), 'y': p.y()}

    missing = ([name for name, ok in report['node_methods'].items() if not ok]
               + [name for name, ok in report['document_methods'].items() if not ok]
               + [name for name, ok in report['selection_methods'].items() if not ok]
               + ([] if report['quuid_importable'] else ['PyQt5.QtCore.QUuid']))
    report['missing_required'] = missing
    report['required_methods_present'] = not missing
    print(json.dumps(report, ensure_ascii=True, indent=2))
    print('Presence checks only. Passing does NOT certify movement, undo, rendering or stability.')


main()
