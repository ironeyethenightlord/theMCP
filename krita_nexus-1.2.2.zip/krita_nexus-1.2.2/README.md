# Krita Nexus 1.2.2

本版本在 1.2.1 基础上修复大文档遍历、节点查找与调度健壮性问题；原始源码版本为 1.10.0（1.2.x 命名系沿用自 1.2.0）。注意：按通常的版本排序，1.2.2 小于 1.10.0；请手动覆盖安装，不依赖版本号自动升级。

本插件提供本地 token 认证的 TCP 接口，供外部工具查看和修改 Krita 当前文档。本发行版明确面向 **Krita 5 / PyQt5**（用户目标版本 5.3.4.1），不再尝试双 Qt 主版本兼容；**本交付未在真实 Krita 中验证兼容性与稳定性**。检测到非 Krita 5 宿主或已加载 Qt6 Python 绑定时拒绝加载。系统 Python 安装过 PyQt6 不影响本包：本包不会导入它。

## 安装

1. 关闭 Krita，备份原插件和重要作品。
2. 将本包中的 `krita_nexus.desktop` 和整个 `krita_nexus/` 文件夹复制到 Krita 资源目录下的 `pykrita/`，覆盖旧版本。不要只复制文件夹内部的 Python 文件。
3. 打开 Krita，在 Python 插件管理器启用 Krita Nexus，然后重启。
4. 独立客户端 `agent_client.py` 可放在任意目录。`tests/` 不需要安装。

```text
pykrita/
├── krita_nexus.desktop
└── krita_nexus/
    ├── __init__.py
    ├── _qt.py
    ├── runtime.py
    ├── operations.py
    └── Manual.html
```

首次请使用空白测试文档，不要直接在唯一一份正式作品上测试。

## 1.2.2 相对 1.2.1 的修复

- 节点查找改用 `Document.nodeByUniqueID(QUuid)`（Krita 4.4.5+），O(1) 且不遍历图层树；宿主缺少该方法时退回有界遍历。`layer.create/modify/delete/snapshot(node_id)` 从此不受遍历上限影响。
- 整树遍历上限从 4096 提高到 65536，且超限时不再让 `document.overview` / `layer.tree` 整体失败：
  - `document.overview` 返回 `total_layer_count`（下界）与 `layer_count_capped: true`；
  - `layer.tree` 只为请求页构建条目（内存随页大小而非树大小增长），触顶返回 `capped: true`，`total` 为已遍历数量；触顶后 `has_more` 到达已遍历末尾即为 false，客户端应结合 `capped` 判断结果被截断。
- `layer.create` 的 `parent_id` 现为严格校验：空字符串或非字符串报 `INVALID_PARAMS`，不再静默回退到根节点。
- 混合模式校验用的游离 probe 节点在读回后立即显式释放（`remove()`，失败忽略），不再依赖垃圾回收。
- GUI 定时器对响应队列 `put_nowait` 增加 `queue.Full` 防护：极端计数异常下延迟到下个 tick 重试，不使 Qt slot 抛异常、不丢弃已完成批次的响应、不把 `_active_request` 卡死。
- `host_selfcheck.py` 扩展为覆盖 dispatcher 实际调用的全部宿主方法（Node/Document/Selection 各方法、undo/redo action 候选、QUuid 可导入性），并单独报告可选的 `nodeByUniqueID`；新增 `missing_required` 字段，缺失即为失败清单。
- 新增 session 正向契约测试（同一活动文档连续读取 session 不得轮换）、节点查找两条路径测试、4096/65536 截断降级测试、空 `parent_id` 拒绝测试、根层创建测试与响应队列满守护测试。总计 35 项自动化测试。
- 仍**未在真实 Krita 中验收**；session 稳定性的宿主行为请按 `VALIDATION.md` 的正向检查项在实机确认。

## 1.2.1 相对 1.2.0 的修复

- 图层移动改为实际 Node API `move(x, y)`；dx/dy 在 Python 中换算为最终坐标后再移动。
- Qt shim 固定 PyQt5，先检查宿主主版本与已加载 Qt6 绑定，不再试导入 PyQt6。
- 截图默认 `sync: true`，先完成参数校验，再调用 `doc.waitForDone()`，最后调用 thumbnail。`sync: false` 可跳过等待，但可能得到旧投影。
- 混合模式验证成功后缓存；缓存键包含会话、色彩模型、深度、配置文件和模式；切换/关闭文档清空，缓存最多 256 项。
- 新增严格 Node 接口替身测试，实际执行 layer_modify；另覆盖截图等待顺序、缓存隔离及 Qt 选择约束。总计 27 项自动化测试。
- 新增 `host_selfcheck.py`，在 Krita 内只读检查宿主版本、Qt 信息与所需 API 是否存在。不等于实机功能验收。

## 保留的 1.2.0 安全改进

- 批处理默认遇错停止，剩余操作返回 `SKIPPED`；显式 `continue_on_error: true` 才继续。非事务，不回滚已完成的操作。
- 连接关闭被网络线程检测到后，通过线程安全 Event 取消尚未开始的操作；已经开始的 API 调用不强行中断。
- 每次 GUI 定时器处理最多 8 个操作，而非 8 个完整批次；采用约 6ms 协作式时间预算。
- 每个操作开始前检查请求 deadline；不把排队超时当作运行中的 API 调用超时。
- 全局最多 32 个已接受但尚未被网络线程消费响应的请求；每连接最多 4 个。请求与响应队列均有界。
- 最多 8 个连接，空闲连接约 60 秒后关闭。
- 严格整数校验，拒绝小数、数字字符串、布尔值；JSON 入口拒绝 NaN / Infinity 字面量。
- 限制请求 id 长度、整数范围和操作名称长度；禁止图层名称中的控制字符与代理码位。
- 混合模式在修改目标图层前，用当前文档创建的游离 paintlayer 做设置/读回校验。不插入图层树。具体宿主行为仍需实机验证。
- 非法配置文件拒绝启动，避免只读配置拼写错误时默默以可写模式运行。
- 全局 undo/redo 默认禁用，需要显式启用。并不保证插件写操作进入 Krita 撤销栈。
- 客户端响应读取使用整体时间预算，避免每次收到少量数据就无限续时。

## 配置

`~/.krita_nexus/config.json`，修改后重启 Krita：

```json
{
  "read_only": true,
  "allow_history_actions": false
}
```

缺少配置文件时：`read_only` 为 false，`allow_history_actions` 为 false。
字段必须是 JSON 布尔值，不能写成字符串 `"true"`。格式错误会阻止插件启动；详情查看 Krita Python 控制台日志。

全局 undo/redo 可能撤销用户先前的绘画，而不是插件刚才的修改。只有确认宿主版本行为并接受这一风险后，才设置 `allow_history_actions: true`。

## 客户端使用

```bash
python agent_client.py
python agent_client.py --tree
python agent_client.py --ops '[{"op":"layer.create","name":"Test","expected_session":"读取到的会话值"}]'
python agent_client.py --latest-session --ops '[{"op":"layer.create","name":"Test"}]'
python agent_client.py --continue-on-error --ops '[{"op":"document.overview"},{"op":"layer.tree"}]'
```

Windows shell 引号规则不同；复杂请求建议保存为 JSON 文件，然后通过 `--ops -` 从 stdin 输入。

`--latest-session` 只补齐文档身份标识，不保证内容未变化。客户端不自动重试写操作。发生超时、断线或响应丢失时，**执行结果可能未知**；先重新检查文档，不要盲目重复创建或相对位移操作。

## 协议

监听 `127.0.0.1` 的随机端口。连接信息和 bearer token 存放在 `~/.krita_nexus/connection.json`。一行一个 UTF-8 JSON 对象：

```json
{"id":1,"token":"…","continue_on_error":false,"ops":[{"op":"document.overview"}]}
```

- 单行最多 1MiB；每批 1–64 个操作，每批最多 2 个截图。
- id 为最多 128 字符的字符串，或有符号 64 位整数。id 仅用于响应关联，**不是幂等键**。
- 接受并处理批次后，外层 `status: success` 表示已生成批处理响应；新增 `batch_status` 表示是否全部成功。务必检查每个 `results` 元素的 status/code。
- 请求格式、认证或准入失败直接返回外层 `status: error`。
- 批次失败默认停止；不支持跨操作回滚。时间预算让出 GUI 后，用户可能在批次中途修改或切换文档，故批次也不是隔离事务。
- 检测到断线后，尚未开始的操作返回内部 CANCELLED 结果并跳过；由于连接已关闭，结果不会送达该客户端。断线检测与操作开始之间存在不可消除的竞态。
- 30 秒期限从请求被接受时起算，每个操作开始前检查。单个 Krita API 调用不能被强行打断。

### 操作

`document.overview`、`layer.tree`、`layer.create`、`layer.modify`、`layer.transform`（modify 别名）、`layer.delete`、`canvas.snapshot`、`selection.rect`、`edit.undo`、`edit.redo`。

- 写操作要求 `expected_session`，只读模式拒绝所有写操作。
- **session 是活动文档身份检查，不是内容版本号。** 同一文档内绘画、改层、撤销不会自动使 session 失效；本版未实现 expected_revision。
- document.overview：`total_layer_count` 在遍历超过 65536 节点时为下界，并以 `layer_count_capped: true` 标记；其余字段不受影响。
- layer.tree：offset/limit 分页，默认 200、最多 500；遍历安全上限 65536 节点，触顶返回 `capped: true`（见上文 1.2.2 说明）。
- layer.create：name、type（paintLayer/groupLayer）、parent_id、above_id、blending_mode。`parent_id` 必须是存在的节点 id 或省略；空字符串/非字符串会被拒绝。
- layer.modify：node_id，以及 name、opacity（0–255）、visible、locked、blending_mode、x/y、dx/dy。x 与 dx 同时提供时，以 x 为基础加 dx。参数预验证不等于宿主执行失败时可以回滚。
- layer.delete：node_id，可选 expected_name；非空组须 recursive: true。
- canvas.snapshot：可选 sync（默认 true）、node_id、max_width/max_height（1–2048）、format（jpeg/png）、quality（1–100）。编码图像最多 6MiB，JPEG 透明区域合成白色。
- selection.rect：x、y、width、height，与画布求交集。
- edit.undo/redo：只有显式启用 allow_history_actions 后可用。

## 安全与限制

- token 允许读写当前画布；同用户进程能读取 token，不防同账户恶意程序。
- POSIX 下目录 0700、连接文件 0600；Windows 的 chmod 不等价于配置 Windows ACL。
- 仅建议同时运行一个启用插件的 Krita 实例，多个实例会覆盖连接信息。
- 32 个在途请求是数量限制，并非严格的全进程内存字节配额。每连接输出缓存最多 32MiB，总体仍可能占用较大内存，截图编码和宿主已有数据还会带来额外开销。
- 未实现请求幂等去重、持久执行日志、重连后结果查询或完整画布 revision 追踪。
- 未保证所有写操作可撤销。同步截图等待已有图像任务完成，但不是隔离事务，也不能阻止其他事件产生后续变动。
- 截图同步等待与单个耗时 API 调用仍可能卡住 GUI；协作预算不提供硬实时保证。

## 测试

```bash
python -m unittest discover -s tests -v
```

包含 35 项标准库测试：批次遇错停止/显式继续、断线取消、deadline、数值校验、配置 fail-closed、历史操作默认关闭、认证隔离、id 限制、截图预拒绝、在途预算释放、响应队列满延迟重试、同一文档 session 稳定性、nodeByUniqueID 查找及遍历回退、遍历截断的 capped 降级、空 parent_id 拒绝与根层创建。

Krita/Qt API 在测试中被严格替身替代；真实 TCP、核心调度以及移动/截图的实际方法体被测试，但 C++ API 和渲染行为未实测。请继续按 `VALIDATION.md` 做宿主实机验收。

在 Krita 的 Scripter 中打开并运行发行包根目录 `host_selfcheck.py`；它只读取信息并打印结果，不改动文档、不执行 undo、不输出 token，覆盖 dispatcher 依赖的全部 Node/Document/Selection 方法、undo/redo action 候选与 QUuid 可导入性，`missing_required` 非空即存在缺失。可将输出提供给维护者排查。
