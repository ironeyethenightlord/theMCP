# 1.2.2

相对 1.2.1：
- 节点查找优先 `Document.nodeByUniqueID(QUuid)`（Krita 4.4.5+），不再遍历图层树；缺该方法时退回有界遍历。大文档的按 id 写操作不再受遍历上限影响。
- 整树遍历上限 4096 → 65536；`document.overview` 与 `layer.tree` 在触顶时改为带 `layer_count_capped` / `capped` 标志的降级返回，不再整体失败。layer.tree 只为请求页构建条目。
- `layer.create` 拒绝空/非字符串 `parent_id`，不再静默回退根节点。
- 混合模式校验 probe 节点用后立即显式 remove（异常忽略），不依赖 GC。
- 定时器响应投递增加 queue.Full 防护：延迟重试、告警一次，不崩 Qt slot、不丢已完成批次。
- `host_selfcheck.py` 覆盖 dispatcher 实际使用的全部宿主方法与 action 候选，报告 `missing_required`；`nodeByUniqueID` 单列为可选。
- 测试 27 → 35 项：新增 session 正向稳定性、unique-id 查找/回退、截断 capped、空 parent_id、根层创建、响应队列满守护。
- 未在真实 Krita 中验收。session 稳定性属宿主 sip 行为，务必按 VALIDATION.md 正向检查项实机确认。

# 1.2.1

相对 1.2.0：
- 修复 Node.setX/setY 不存在的问题，使用 Node.move。
- 面向 Krita 5 / PyQt5 的单绑定发行版，不试导入 PyQt6；非 Krita 5 宿主或已加载 Qt6 Python 绑定时拒绝启动。
- canvas.snapshot 增加 sync 布尔参数，默认等待 doc.waitForDone 后截图；校验参数后才等待。
- 混合模式预验证按会话及色彩条件缓存，限制 256 项，文档切换清空。
- 新增 13 项 API 调用契约测试（总计 27 项），包括没有 setX/setY 的严格 Node 替身。
- 新增宿主内只读自检脚本。

未在真实 Krita 中验收。waitForDone 可能阻塞 GUI；缓存/替身测试不能证明真实 C++ 节点行为。保留 1.2.0 的非事务、无幂等与撤销限制。

# 1.2.0

以用户提供的 1.10.0 为基础，按要求指定版本号。

- 默认批次遇错停止，增加 continue_on_error 和 batch_status。
- 逐操作检查取消与 deadline；GUI 协作预算和有界端到端在途计数。
- 全局 32 请求、每连接 4 请求、8 个连接、60 秒空闲关闭。
- 严格整数、非有限 JSON、id、操作名与图层名校验。
- 混合模式通过游离节点预验证与读回检查。
- 无效配置拒绝启动；undo/redo 改为显式启用。
- 客户端整体读超时、请求大小检查与批次继续选项。
- Qt shim 优先复用已加载的 PyQt5，避免在 Qt5 宿主误加载 Qt6。
- 添加 14 项标准库回归测试和实机验收清单。

未实现：内容 revision、幂等请求、执行日志、操作回滚、可靠的撤销命令整合。未进行真实 Krita 集成测试。
