"""API-contract tests: strict fakes exercise real dispatcher method bodies.
These verify call paths, NOT the behavior of the real C++/SIP host.
"""
import ast
from pathlib import Path
import types
import unittest
from unittest.mock import patch
import test_core as core

o = core.o

import re
UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')


class Point:
    def __init__(self, x, y): self._x, self._y = x, y
    def x(self): return self._x
    def y(self): return self._y


class UidString:
    def __init__(self, text): self.text = text
    def toString(self): return self.text


class Node:
    # Intentionally no setX/setY and no permissive __getattr__.
    __slots__ = ('x', 'y', 'moves', 'name_value', 'blend', 'children', 'uid_value', 'removed')
    def __init__(self, uid_value='{AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE}'):
        self.x, self.y = 10, 20
        self.moves, self.name_value, self.blend = [], 'Original', 'normal'
        self.children, self.uid_value, self.removed = [], uid_value, False
    def position(self): return Point(self.x, self.y)
    def move(self, x, y): self.x, self.y = x, y; self.moves.append((x, y))
    def setName(self, value): self.name_value = value
    def setBlendingMode(self, value):
        if value in ('normal', 'multiply'): self.blend = value
    def blendingMode(self): return self.blend
    def name(self): return self.name_value
    def type(self): return 'paintlayer'
    def visible(self): return True
    def locked(self): return False
    def opacity(self): return 255
    def childNodes(self): return list(self.children)
    def uniqueId(self): return UidString(self.uid_value)
    def addChildNode(self, child, above=None): self.children.append(child); return True
    def remove(self): self.removed = True; return True


class EmptyImage:
    def isNull(self): return True


class Document:
    def __init__(self):
        self.calls = []; self.created = 0; self.profile = 'profile-a'
        self.active = None; self.root = Node('{00000000-0000-0000-0000-000000000001}')
    def refreshProjection(self): self.calls.append('refresh')
    def waitForDone(self): self.calls.append('wait')
    def thumbnail(self, w, h): self.calls.append('thumbnail'); return EmptyImage()
    def colorModel(self): return 'RGBA'
    def colorDepth(self): return 'U8'
    def colorProfile(self): return self.profile
    def createNode(self, name, kind): self.created += 1; node = Node(); node.name_value = name; return node
    def rootNode(self): return self.root
    def topLevelNodes(self): return list(self.root.children)
    def setActiveNode(self, node): self.active = node; self.calls.append('active')
    def name(self): return 'Doc'
    def width(self): return 100
    def height(self): return 80
    def resolution(self): return 300


class Dispatcher(o.OperationDispatcher):
    def __init__(self):
        super().__init__(); self.doc = Document(); self.node = Node(); self._session = 's'
    def _document(self): return self.doc
    def _node(self, doc, node_id):
        # Mirrors the real validation guard before the fake lookup.
        if not isinstance(node_id, str) or not node_id:
            raise o.OpError('INVALID_PARAMS', 'node_id must be a non-empty string')
        return self.node
    def _uid(self, node): return 'node-id'
    def _assert_main_thread(self): pass

class HostContractTests(unittest.TestCase):
    def test_absolute_move(self):
        d = Dispatcher(); result = d.layer_modify({'node_id':'n', 'x':30, 'y':40})
        self.assertEqual(d.node.moves, [(30, 40)])
        self.assertEqual(result['status'], 'success')
    def test_relative_move(self):
        d = Dispatcher(); d.layer_modify({'node_id':'n', 'dx':-3, 'dy':5})
        self.assertEqual(d.node.moves, [(7, 25)])
    def test_mixed_move(self):
        d = Dispatcher(); d.layer_modify({'node_id':'n', 'x':100, 'dx':2})
        self.assertEqual(d.node.moves, [(102, 20)])
    def test_invalid_position_does_not_rename(self):
        d = Dispatcher()
        with self.assertRaises(o.OpError): d.layer_modify({'node_id':'n', 'name':'new', 'dx':0.5})
        self.assertEqual(d.node.name_value, 'Original'); self.assertEqual(d.node.moves, [])
    def test_snapshot_wait_precedes_thumbnail(self):
        d = Dispatcher()
        with self.assertRaises(o.OpError) as e: d.canvas_snapshot({})
        self.assertEqual(e.exception.code, 'SNAPSHOT_FAILED')  # deliberate null fake image
        self.assertEqual(d.doc.calls, ['wait', 'thumbnail'])
    def test_snapshot_async_opt_out(self):
        d = Dispatcher()
        with self.assertRaises(o.OpError): d.canvas_snapshot({'sync':False})
        self.assertEqual(d.doc.calls, ['thumbnail'])
    def test_snapshot_validates_before_wait(self):
        for op in ({'quality':0}, {'sync':'true'}, {'max_width':1.2}):
            d = Dispatcher()
            with self.assertRaises(o.OpError): d.canvas_snapshot(op)
            self.assertEqual(d.doc.calls, [])
    def test_blend_cache_hit(self):
        d = Dispatcher()
        for _ in range(50): d._validate_blend(d.doc, 'multiply')
        self.assertEqual(d.doc.created, 1)
    def test_blend_profile_isolation(self):
        d = Dispatcher(); d._validate_blend(d.doc, 'multiply')
        d.doc.profile = 'profile-b'; d._validate_blend(d.doc, 'multiply')
        self.assertEqual(d.doc.created, 2)
    def test_invalid_blend_no_target_change(self):
        d = Dispatcher()
        with self.assertRaises(o.OpError):
            d.layer_modify({'node_id':'n', 'name':'new', 'blending_mode':'invalid'})
        self.assertEqual(d.node.name_value, 'Original')
        self.assertFalse(d._validated_blends)
    def test_session_switch_clears_cache(self):
        d = Dispatcher(); d._validate_blend(d.doc, 'multiply')
        app = types.SimpleNamespace(activeDocument=lambda: d.doc)
        with patch.object(o, 'Krita', types.SimpleNamespace(instance=lambda: app)):
            d.update_document_session()
        self.assertFalse(d._validated_blends)

    def test_session_stable_for_same_document(self):
        # Positive session contract: the SAME live document must keep one
        # session across reads (otherwise every write hits SESSION_MISMATCH).
        d = Dispatcher()
        state = {'current': Document()}
        app = types.SimpleNamespace(activeDocument=lambda: state['current'])
        with patch.object(o, 'Krita', types.SimpleNamespace(instance=lambda: app)):
            d.update_document_session()
            first = d._session
            self.assertIsNotNone(first)
            d.update_document_session()          # same wrapper again
            self.assertEqual(d._session, first)  # ...session must not rotate
            state['current'] = Document()        # switch documents
            d.update_document_session()
            self.assertNotEqual(d._session, first)

    def test_overview_count_capped(self):
        d = Dispatcher()
        d.doc.root.children = [Node('{%08d-0000-0000-0000-00000000000%d}' % (i, i))
                               for i in range(4)]
        with patch.object(o, 'MAX_TREE_NODES', 2):
            result = d.document_overview({})
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['total_layer_count'], 2)
        self.assertTrue(result['layer_count_capped'])
        result = d.document_overview({})          # small tree: exact count
        self.assertEqual(result['total_layer_count'], 4)
        self.assertFalse(result['layer_count_capped'])

    def test_layer_tree_capped_flag(self):
        d = Dispatcher()
        d.doc.root.children = [Node('{%08d-0000-0000-0000-00000000000%d}' % (i, i))
                               for i in range(4)]
        with patch.object(o, 'MAX_TREE_NODES', 2):
            result = d.layer_tree({})
        self.assertEqual(result['status'], 'success')
        self.assertEqual(len(result['layers']), 2)
        self.assertEqual(result['total'], 2)
        self.assertTrue(result['capped'])
        result = d.layer_tree({})
        self.assertEqual(len(result['layers']), 4)
        self.assertFalse(result['capped'])

    def test_parent_id_empty_rejected(self):
        d = Dispatcher()
        with self.assertRaises(o.OpError) as e:
            d.layer_create({'name': 'L', 'parent_id': ''})
        self.assertEqual(e.exception.code, 'INVALID_PARAMS')
        self.assertEqual(d.doc.created, 0)

    def test_layer_create_root(self):
        d = Dispatcher()
        result = d.layer_create({'name': 'Agent Layer'})
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['layer']['type'], 'paintlayer')
        self.assertEqual(result['layer']['name'], 'Agent Layer')
        self.assertEqual(d.doc.created, 1)
        self.assertIsNotNone(d.doc.active)
        self.assertIn('refresh', d.doc.calls)

    def test_node_lookup_by_unique_id(self):
        class FakeUuid:
            def __init__(self, text): self.text = str(text)
            def isNull(self): return UUID_RE.match(self.text) is None
        sentinel = Node()
        key = 'abcdef01-2222-3333-4444-555555555555'
        class LookupDoc:
            def __init__(self): self.table = {key: sentinel}; self.lookups = []
            def nodeByUniqueID(self, uid): self.lookups.append(uid.text); return self.table.get(uid.text)
        doc = LookupDoc()
        d = o.OperationDispatcher()
        with patch.object(o, 'QUuid', FakeUuid):
            found = d._node(doc, '{ABCDEF01-2222-3333-4444-555555555555}')
            self.assertIs(found, sentinel)               # braces/case normalised
            self.assertEqual(doc.lookups[-1], key)
            with self.assertRaises(o.OpError) as e:      # valid uuid, absent node
                d._node(doc, '00000000-0000-0000-0000-000000000042')
            self.assertEqual(e.exception.code, 'LAYER_NOT_FOUND')
            before = list(doc.lookups)
            with self.assertRaises(o.OpError) as e:      # malformed id, no lookup call
                d._node(doc, 'not-a-uuid')
            self.assertEqual(e.exception.code, 'LAYER_NOT_FOUND')
            self.assertEqual(doc.lookups, before)

    def test_node_lookup_falls_back_to_walk(self):
        child = Node('{11111111-2222-3333-4444-555555555555}')
        root = Node()
        root.children = [child]
        class WalkDoc:  # host without nodeByUniqueID
            def rootNode(self): return root
        d = o.OperationDispatcher()
        self.assertIs(d._node(WalkDoc(), '11111111-2222-3333-4444-555555555555'), child)
        with self.assertRaises(o.OpError) as e:
            d._node(WalkDoc(), '99999999-2222-3333-4444-555555555555')
        self.assertEqual(e.exception.code, 'LAYER_NOT_FOUND')

    def test_qt_host_version_guard(self):
        source = (Path(__file__).resolve().parents[1]/'krita_nexus/_qt.py').read_text()
        tree = ast.parse(source)
        guard = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_check_host')
        env = {}; exec(compile(ast.Module(body=[guard], type_ignores=[]), '<guard>', 'exec'), env)
        env['_check_host']('5.3.4.1')
        for version in ('6.0.0', 'unknown'):
            with self.assertRaises(ImportError): env['_check_host'](version)

    def test_qt_guard_and_no_cross_major_import(self):
        source = (Path(__file__).resolve().parents[1]/'krita_nexus/_qt.py').read_text()
        tree = ast.parse(source)
        imports = [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
        self.assertFalse(any(n.startswith('PyQt6') for n in imports))
        guard = next(n for n in tree.body if isinstance(n, ast.FunctionDef))
        env = {}; exec(compile(ast.Module(body=[guard], type_ignores=[]), '<guard>', 'exec'), env)
        env['_check_binding']({'PyQt5.QtCore': object()})
        for module in ('PyQt6', 'PyQt6.QtCore', 'PySide6.QtWidgets'):
            with self.assertRaises(ImportError): env['_check_binding']({module: object()})

if __name__ == '__main__': unittest.main(verbosity=2)
