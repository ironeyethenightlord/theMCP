"""Standard-library regression tests; no Krita/PyQt installation required.
The host API is stubbed: these tests do NOT certify Krita runtime behavior.
"""
import importlib
import json
from pathlib import Path
import queue
import socket
import sys
import tempfile
import threading
import time
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]
pkg = types.ModuleType('nexus_test'); pkg.__path__ = [str(ROOT / 'krita_nexus')]
sys.modules['nexus_test'] = pkg
krita = types.ModuleType('krita')
krita.Extension = object; krita.Krita = object; krita.Selection = object
sys.modules['krita'] = krita
qt = types.ModuleType('nexus_test._qt')
for name in ('FORMAT_RGB32 QApplication QBuffer QByteArray QColor QImage QPainter QRect QThread QUuid WRITE_ONLY QTimer').split():
    setattr(qt, name, object)
sys.modules['nexus_test._qt'] = qt
r = importlib.import_module('nexus_test.runtime')
o = importlib.import_module('nexus_test.operations')

class Dispatcher:
    def __init__(self): self.calls = []
    def dispatch(self, op):
        self.calls.append(op['op'])
        if op['op'] == 'fail': raise o.OpError('TEST_FAILURE', 'expected')
        return {'status': 'success'}

class CoreTests(unittest.TestCase):
    def state(self, ops, **extra):
        return dict(ops=[{'op': op} for op in ops], next=0, results=[], failed=False,
                    deadline=time.monotonic()+30, **extra)
    def run_steps(self, request):
        host = types.SimpleNamespace(dispatcher=Dispatcher())
        while request['next'] < len(request['ops']):
            r.KritaNexusExtension._step_request(host, request)
        return host.dispatcher.calls
    def test_stop_on_error(self):
        req = self.state(['fail', 'layer.delete'])
        self.assertEqual(self.run_steps(req), ['fail'])
        self.assertEqual(req['results'][1]['code'], 'SKIPPED')
    def test_continue_opt_in(self):
        req = self.state(['fail', 'layer.delete'], continue_on_error=True)
        self.assertEqual(self.run_steps(req), ['fail', 'layer.delete'])
    def test_cancelled_before_start(self):
        event = threading.Event(); event.set()
        req = self.state(['layer.delete'], cancelled=event)
        self.assertEqual(self.run_steps(req), [])
        self.assertEqual(req['results'][0]['code'], 'CANCELLED')
    def test_expiry(self):
        req = self.state(['layer.delete']); req['deadline'] = 0
        self.assertEqual(self.run_steps(req), [])
        self.assertEqual(req['results'][0]['code'], 'REQUEST_TIMEOUT')
    def test_integer_rejects_coercion(self):
        for value in (True, 1.9, '12', float('inf'), None):
            with self.subTest(value=value), self.assertRaises(o.OpError):
                o._clamp_int(value, 0, 255, 'opacity')
        self.assertEqual(o._clamp_int(255, 0, 255, 'opacity'), 255)
    def test_nonfinite_json(self):
        for value in ('NaN', 'Infinity', '-Infinity'):
            with self.assertRaises(ValueError): r._strict_json('{"x":'+value+'}')
    def test_name_surrogate(self):
        with self.assertRaises(o.OpError): o._name('\ud800')
    def test_config_fail_closed(self):
        with tempfile.TemporaryDirectory() as home:
            folder = Path(home)/'.krita_nexus'; folder.mkdir()
            self.assertEqual(r.load_config(home), {})
            (folder/'config.json').write_text('{"read_only":"true"}')
            with self.assertRaises(ValueError): r.load_config(home)
            (folder/'config.json').write_text('{bad')
            with self.assertRaises(RuntimeError): r.load_config(home)
    def test_history_disabled(self):
        with self.assertRaises(o.OpError) as ctx: o.OperationDispatcher().edit_action('undo')
        self.assertEqual(ctx.exception.code, 'HISTORY_DISABLED')
    def test_pump_defers_on_full_response_queue(self):
        import contextlib
        import io
        full = queue.Queue(1); full.put({'placeholder': True})
        requests_q = queue.Queue()
        req = self.state(['layer.delete'], id=7, client_id=1)
        requests_q.put(req)
        host = types.SimpleNamespace(dispatcher=Dispatcher(), requests=requests_q,
                                     responses=full, _active_request=None)
        host._step_request = lambda request: r.KritaNexusExtension._step_request(host, request)
        # A full response queue must not crash the Qt slot or drop accounting:
        # the request stays active and the response is retried on a later tick.
        with contextlib.redirect_stdout(io.StringIO()) as captured:
            r.KritaNexusExtension._pump_main_thread(host)
        self.assertIs(host._active_request, req)
        self.assertEqual(full.qsize(), 1)
        self.assertIn('response queue full', captured.getvalue())
        full.get()  # consumer catches up
        r.KritaNexusExtension._pump_main_thread(host)
        self.assertIsNone(host._active_request)
        delivered = full.get()
        self.assertEqual(delivered['id'], req['id'])
        self.assertEqual(delivered['batch_status'], 'success')
        self.assertEqual(delivered['results'][0]['status'], 'success')

class NetworkTests(unittest.TestCase):
    def setUp(self):
        self.requests = queue.Queue(r.MAX_PENDING_REQUESTS)
        self.responses = queue.Queue(r.MAX_PENDING_REQUESTS)
        ready = queue.Queue()
        self.net = r.NetworkThread(b'test', self.requests, self.responses, ready)
        self.net.start()
        ok, self.port, error = ready.get(timeout=3)
        self.assertTrue(ok, error)
        self.sock = socket.create_connection(('127.0.0.1', self.port), timeout=3)
        self.reader = self.sock.makefile('rb')
    def tearDown(self):
        self.reader.close(); self.sock.close()
        self.net.stop(); self.net.join(3)
        self.assertFalse(self.net.is_alive())
    def send(self, **kwargs):
        obj = dict(id=1, token='test', ops=[{'op':'document.overview'}]); obj.update(kwargs)
        self.sock.sendall(json.dumps(obj).encode()+b'\n')
    def response(self): return json.loads(self.reader.readline())
    def test_auth_nonascii_isolated(self):
        self.send(token='中文'); self.assertEqual(self.response()['code'], 'AUTH_FAILED')
        self.send(); self.assertEqual(self.requests.get(timeout=3)['id'], 1)
    def test_long_id_rejected(self):
        self.send(id='x'*129); self.assertEqual(self.response()['code'], 'INVALID_REQUEST')
    def test_snapshot_rejected_before_queue(self):
        self.send(ops=[{'op':'canvas.snapshot'}]*3)
        self.assertEqual(self.response()['code'], 'OUTPUT_LIMIT')
        self.assertTrue(self.requests.empty())
    def test_per_client_budget_and_release(self):
        for i in range(5): self.send(id=i)
        self.assertEqual(self.response()['code'], 'SERVER_BUSY')
        req = self.requests.get(timeout=3)
        self.responses.put({'id': req['id'], 'status':'success', '_client_id':req['client_id']})
        self.assertEqual(self.response()['status'], 'success')
        self.send(id=6)
        # Receiving the admitted request proves the slot was released.
        ids = [self.requests.get(timeout=3)['id'] for _ in range(4)]
        self.assertIn(6, ids)
    def test_disconnect_sets_cancellation(self):
        self.send(); req = self.requests.get(timeout=3)
        self.reader.close(); self.sock.close()
        self.assertTrue(req['cancelled'].wait(3))

if __name__ == '__main__': unittest.main(verbosity=2)
