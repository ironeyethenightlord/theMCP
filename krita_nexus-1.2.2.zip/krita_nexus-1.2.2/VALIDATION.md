# Krita 实机验收清单

本包已通过 Python 语法检查及 35 项无 Krita 依赖的自动化测试。下列项尚未实机验收；不要据此把本包视为已验证的生产版本。

## 安装与兼容
- 在目标 Krita 5 / PyQt5 版本启动，确认插件无导入异常、定时器正常。
- 若系统同时存在 PyQt5 与 PyQt6，确认实际使用的绑定与 Krita 宿主一致。本发行版只导入 PyQt5，并在宿主主版本不为 5 或检测到已加载 Qt6 绑定时拒绝加载；不支持在同一进程混用 Qt 主版本。
- 确认 connection.json 指向当前实例，关闭 Krita 后仅删除自己的连接文件。
- 设置 read_only=true，确认所有写操作均被拒绝。
- 配置写入字符串 "true" 或无效 JSON，确认插件拒绝启动而非进入可写模式。
- Python 插件管理器能打开使用手册（Krita 按 `.desktop` 同目录 + 插件文件夹 + 文件名解析，即 `pykrita/krita_nexus/Manual.html`）。

## session 正向稳定性（1.2.2 关键项，写操作的前提）
用同一活动文档连续调用两次 `document.overview`，两次返回的 `document_session` 必须相同；切换到另一文档后必须变化。在 Scripter 中可先用最小代码验证宿主 wrapper 行为：

```python
from krita import Krita
d1 = Krita.instance().activeDocument()
d2 = Krita.instance().activeDocument()
print('same wrapper:', d1 == d2, 'is:', d1 is d2)
```

期望 `True`。若同一活动文档两次返回不相等的 wrapper，插件的 session 会在每次操作时轮换，所有写操作都会返回 SESSION_MISMATCH——这是本版最需要实机排除的风险（自动化测试仅能证明插件侧逻辑，证明不了宿主 sip wrapper 行为）。

## 只读自检
在 Krita 的 Scripter 中运行发行包根目录 host_selfcheck.py，保留输出。它不创建、移动或删除节点；`missing_required` 必须为空；`document_optional_methods.nodeByUniqueID` 为 False 时节点查找走遍历回退（大文档应确认该方法存在）。检查通过仅说明必要方法存在，不代表行为正确或版本稳定。

## 功能
- 获取 overview、分层分页、UUID、位置和混合模式。
- 创建普通层与组，指定父层和 above_id，确认叠放顺序；`parent_id: ""` 必须被拒绝（INVALID_PARAMS）而非落到根。
- 在 RGB、CMYK、灰度等实际使用的色彩模型下，验证游离层混合模式校验不会产生树节点或标脏文档等意外副作用（1.2.2 起校验后显式 remove probe，确认 remove 无副作用）；有效/无效模式均测试。
- 修改名称、透明度、可见、锁定、位置，确认绝对与相对坐标规则。
- 删除非空组，确认必须显式 recursive=true。
- 批次第一步失败，确认后续删除为 SKIPPED；显式继续时才执行后续。
- 测试切换文档后旧 expected_session 被拒绝；同一文档内容变化不会更新 session，此为已知限制。
- 大文档（>4096 节点，有条件造 >65536 更佳）：overview 返回 `layer_count_capped: true` 且不报错；layer.tree 返回 `capped: true`；按 node_id 的创建/修改/删除仍可执行（unique-id 查找不遍历）。
- 大文档 JPEG/PNG 截图、透明白底、节点截图和连续修改后截图，检查颜色和投影新鲜度；默认 sync=true，应先等待已有图像任务。另测 sync=false，确认接受可能旧帧的语义。
- 选择范围与画布交集正确。

## 执行、断线与撤销
- 在 GUI 忙时提交写请求并断开连接，恢复 GUI 后确认尚未开始的写操作被取消；已开始的操作不承诺取消。
- 模拟响应丢失，确认客户端不会自动重试写操作。
- 检查批次中途用户操作的行为；批次不隔离、不回滚。
- 检查各写操作是否入撤销栈。在副本上启用 allow_history_actions，确认 undo/redo 实际撤销对象；若不是刚才的插件操作，保持禁用。
- 连续大批次和截图压力测试，记录 GUI 延迟、RSS 内存与请求超时情况。单个宿主 API 调用可能超出 6ms。日志出现 "response queue full; response deferred" 视为准入不变量被打破，记录并反馈。

## 建议发布门槛
至少在主要使用的 Krita 版本、操作系统和色彩模型完成上述检查。未验收前保留文档备份，避免依赖 Ctrl+Z 恢复破坏性操作。
