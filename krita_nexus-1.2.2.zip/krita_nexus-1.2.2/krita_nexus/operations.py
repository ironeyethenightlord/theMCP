# SPDX-License-Identifier: MIT
"""Main-thread-only, defensive wrappers around the Krita Python API."""
import base64
import uuid

from krita import Krita, Selection

from ._qt import (FORMAT_RGB32, QApplication, QBuffer, QByteArray, QColor,
                  QImage, QPainter, QRect, QThread, QUuid, WRITE_ONLY)

WRITE_OPS = frozenset({
    "layer.create", "layer.transform", "layer.modify", "layer.delete",
    "selection.rect", "edit.undo", "edit.redo",
})
# Krita has used different action ids across versions; try each in order.
ACTION_CANDIDATES = {"undo": ("edit_undo", "undo"), "redo": ("edit_redo", "redo")}
KIND_MAP = {"paintLayer": "paintlayer", "paintlayer": "paintlayer",
            "groupLayer": "grouplayer", "grouplayer": "grouplayer"}
COORD_MIN, COORD_MAX = -1000000, 1000000
MAX_NAME_LENGTH = 255
# Hard cap for any full-tree traversal (overview counts, layer.tree pages,
# node lookup fallback). Node lookup normally uses Document.nodeByUniqueID
# and does not traverse, so write ops keep working on larger documents.
MAX_TREE_NODES = 65536
PREVIEW_MAX_EDGE = 2048
PREVIEW_MAX_PIXELS = 4 * 1024 * 1024
PREVIEW_MAX_BYTES = 6 * 1024 * 1024      # raw bytes; ~8 MiB after base64


class OpError(Exception):
    def __init__(self, code, message, details=None):
        super().__init__(message)
        self.code, self.message, self.details = code, message, details


def _ok(**data):
    out = {"status": "success"}
    out.update(data)
    return out


def _clamp_int(value, low, high, field):
    if isinstance(value, bool):
        raise OpError("INVALID_PARAMS", "%s must be an integer" % field)
    if not isinstance(value, int):
        raise OpError("INVALID_PARAMS", "%s must be an integer" % field)
    if value < low or value > high:
        raise OpError("INVALID_PARAMS", "%s must be between %d and %d" % (field, low, high))
    return value


def _name(value, field="name"):
    if not isinstance(value, str) or not value or len(value) > MAX_NAME_LENGTH or any(ord(c) < 32 or 0xD800 <= ord(c) <= 0xDFFF for c in value):
        raise OpError("INVALID_PARAMS", "%s must contain 1..%d characters" % (field, MAX_NAME_LENGTH))
    return value


def _flag(value, field):
    if not isinstance(value, bool):
        raise OpError("INVALID_PARAMS", "%s must be boolean" % field)
    return value


def _blend(value):
    if not isinstance(value, str) or not value:
        raise OpError("INVALID_PARAMS", "blending_mode must be a non-empty string")
    return value


def _flatten_on_white(image):
    """JPEG has no alpha channel; composite onto white instead of letting transparent pixels go black."""
    out = QImage(image.size(), FORMAT_RGB32)
    out.fill(QColor(255, 255, 255))
    painter = QPainter(out)
    painter.drawImage(0, 0, image)
    painter.end()
    return out


class OperationDispatcher:
    MAX_TREE_NODES = MAX_TREE_NODES

    def __init__(self, read_only=False, allow_history_actions=False):
        self._doc = None
        self._session = None
        self.read_only = bool(read_only)
        self.allow_history_actions = bool(allow_history_actions)
        self._validated_blends = set()

    def _assert_main_thread(self):
        app = QApplication.instance()
        if app is None or QThread.currentThread() != app.thread():
            raise RuntimeError("Krita API dispatch attempted outside the Qt main thread")

    def update_document_session(self):
        self._assert_main_thread()
        doc = Krita.instance().activeDocument()
        # Wrapper equality is intentional: switching or closing a document rotates the nonce.
        if doc is None:
            self._doc, self._session = None, None
            self._validated_blends.clear()
        elif self._doc is None or doc != self._doc:
            self._doc = doc
            self._session = uuid.uuid4().hex
            self._validated_blends.clear()
        return self._session

    def _document(self):
        self.update_document_session()
        if self._doc is None:
            raise OpError("NO_DOCUMENT", "No active document is open")
        return self._doc

    def _verify_session(self, op):
        if self._session is None:
            raise OpError("NO_DOCUMENT", "No active document is open")
        if op.get("expected_session") != self._session:
            raise OpError("SESSION_MISMATCH", "expected_session does not match the active canvas",
                          {"current_session": self._session})

    @staticmethod
    def _uid(node):
        return str(node.uniqueId().toString()).strip("{}").lower()

    def _walk(self, root):
        """Pre-order walk yielding (node, depth, parent_uid, uid). Compares ids, never wrappers."""
        root_uid = self._uid(root)
        stack = [(child, 0, root_uid) for child in reversed(list(root.childNodes()))]
        seen = 0
        while stack:
            node, depth, parent_uid = stack.pop()
            seen += 1
            if seen > MAX_TREE_NODES:
                raise OpError("OUTPUT_LIMIT", "Layer tree exceeds the safety limit",
                              {"max_nodes": MAX_TREE_NODES})
            uid = self._uid(node)
            yield node, depth, parent_uid, uid
            children = list(node.childNodes())
            stack.extend((child, depth + 1, uid) for child in reversed(children))

    def _count_nodes(self, root):
        """Count descendants of root, stopping at the traversal cap.
        Returns (count, capped); a capped count is a lower bound."""
        count = 0
        try:
            for _ in self._walk(root):
                count += 1
        except OpError as exc:
            if exc.code != "OUTPUT_LIMIT":
                raise
            return count, True
        return count, False

    def _node(self, doc, node_id):
        if not isinstance(node_id, str) or not node_id:
            raise OpError("INVALID_PARAMS", "node_id must be a non-empty string")
        wanted = node_id.strip("{}").lower()
        lookup = getattr(doc, "nodeByUniqueID", None)
        if callable(lookup):
            # Krita 4.4.5+: O(1) lookup, no traversal, so large trees keep working.
            # QUuid(...) yields a null uuid for malformed input, which we report
            # as LAYER_NOT_FOUND to match the fallback path's behaviour.
            uid = QUuid(wanted)
            node = None if uid.isNull() else lookup(uid)
            if node is None:
                raise OpError("LAYER_NOT_FOUND", "Layer does not exist", {"node_id": node_id})
            return node
        # Fallback for hosts without nodeByUniqueID: bounded walk (rare).
        for node, _depth, _parent, found in self._walk(doc.rootNode()):
            if found == wanted:
                return node
        raise OpError("LAYER_NOT_FOUND", "Layer does not exist", {"node_id": node_id})

    def _parent_uid(self, doc, node):
        parent = node.parentNode()
        return self._uid(parent) if parent is not None else self._uid(doc.rootNode())

    def dispatch(self, op):
        self._assert_main_thread()
        self.update_document_session()
        if not isinstance(op, dict) or not isinstance(op.get("op"), str):
            raise OpError("INVALID_PARAMS", "Each operation must be an object with an op string")
        name = op["op"]
        handlers = {
            "document.overview": self.document_overview,
            "layer.tree": self.layer_tree,
            "layer.create": self.layer_create,
            "layer.transform": self.layer_modify,
            "layer.modify": self.layer_modify,
            "layer.delete": self.layer_delete,
            "canvas.snapshot": self.canvas_snapshot,
            "selection.rect": self.selection_rect,
            "edit.undo": lambda _op: self.edit_action("undo"),
            "edit.redo": lambda _op: self.edit_action("redo"),
        }
        handler = handlers.get(name)
        if handler is None:
            raise OpError("UNKNOWN_OP", "Unsupported operation: %s" % name)
        if name in WRITE_OPS:
            if self.read_only:
                raise OpError("READ_ONLY", "Server is in read-only mode (config.json: read_only=true)")
            self._verify_session(op)
        return handler(op)

    def document_overview(self, op):
        doc = self._document()
        total, capped = self._count_nodes(doc.rootNode())
        return _ok(document_session=self._session, name=doc.name(), width=doc.width(),
                   height=doc.height(), resolution=doc.resolution(), color_model=doc.colorModel(),
                   color_depth=doc.colorDepth(), color_profile=doc.colorProfile(),
                   top_level_layer_count=len(doc.topLevelNodes()),
                   total_layer_count=total, layer_count_capped=capped)

    def layer_tree(self, op):
        doc = self._document()
        offset = _clamp_int(op.get("offset", 0), 0, MAX_TREE_NODES, "offset")
        limit = _clamp_int(op.get("limit", 200), 1, 500, "limit")
        root_uid = self._uid(doc.rootNode())
        # Stream the walk: only build dicts for the requested page, so memory
        # stays bounded by page size instead of total tree size.
        page = []
        stop = offset + limit
        index = 0
        capped = False
        try:
            for node, depth, parent_uid, uid in self._walk(doc.rootNode()):
                if offset <= index < stop:
                    pos = node.position()
                    page.append({
                        "id": uid,
                        "parent_id": None if parent_uid == root_uid else parent_uid,
                        "depth": depth, "name": node.name(), "type": node.type(),
                        "visible": bool(node.visible()), "locked": bool(node.locked()),
                        "opacity": int(node.opacity()), "blending_mode": node.blendingMode(),
                        "x": int(pos.x()), "y": int(pos.y()),
                        "child_count": len(node.childNodes()),
                    })
                index += 1
        except OpError as exc:
            if exc.code != "OUTPUT_LIMIT":
                raise
            capped = True
        total = index
        return _ok(document_session=self._session, layers=page, offset=offset, limit=limit,
                   total=total, has_more=offset + len(page) < total, capped=capped)

    def _validate_blend(self, doc, value):
        value = _blend(value)
        if len(value) > 128 or not value.isascii():
            raise OpError("INVALID_PARAMS", "Invalid blending_mode identifier")
        key = (self._session, doc.colorModel(), doc.colorDepth(), doc.colorProfile(), value)
        if key in self._validated_blends:
            return value
        # Detached node: test host acceptance without modifying the target layer.
        probe = doc.createNode("Nexus blend validation", "paintlayer")
        if probe is None:
            raise OpError("VALIDATION_FAILED", "Cannot validate blending mode")
        try:
            probe.setBlendingMode(value)
            accepted = probe.blendingMode() == value
        finally:
            # Detached probe: release it explicitly instead of waiting for GC.
            # remove() on a never-inserted node is a harmless no-op/failure.
            try:
                probe.remove()
            except Exception:
                pass
        if not accepted:
            raise OpError("INVALID_PARAMS", "Unsupported blending_mode: " + value)
        # Keep the cache bounded, including when profiles change in place.
        if len(self._validated_blends) >= 256:
            self._validated_blends.clear()
        self._validated_blends.add(key)
        return value

    def layer_create(self, op):
        doc = self._document()
        root = doc.rootNode()
        root_uid = self._uid(root)
        kind = op.get("type", "paintLayer")
        if not isinstance(kind, str) or kind not in KIND_MAP:
            raise OpError("INVALID_PARAMS", "type must be paintLayer or groupLayer")
        name = _name(op.get("name", "Agent Layer"))
        blend = op.get("blending_mode")
        if blend is not None:
            blend = self._validate_blend(doc, blend)
        parent_id = op.get("parent_id")
        if parent_id is None:
            parent = root
        else:
            # Strict: a present-but-empty or non-string parent_id is an error,
            # never a silent fallback to the root.
            parent = self._node(doc, parent_id)
        if self._uid(parent) != root_uid and parent.type().lower() != "grouplayer":
            raise OpError("INVALID_PARENT", "parent_id must refer to a group layer")
        above = None
        if op.get("above_id"):
            above = self._node(doc, op["above_id"])
            if self._parent_uid(doc, above) != self._uid(parent):
                raise OpError("INVALID_POSITION", "above_id is not a child of the requested parent")
        node = doc.createNode(name, KIND_MAP[kind])
        if node is None:
            raise OpError("CREATE_FAILED", "Krita did not create the layer")
        if blend is not None:
            node.setBlendingMode(blend)
        if not parent.addChildNode(node, above):
            try:
                node.remove()
            except Exception:
                pass
            raise OpError("CREATE_FAILED", "Krita refused to insert the layer")
        doc.setActiveNode(node)
        doc.refreshProjection()
        return _ok(document_session=self._session,
                   layer={"id": self._uid(node), "name": node.name(), "type": node.type()})

    def layer_modify(self, op):
        doc = self._document()
        node = self._node(doc, op.get("node_id"))
        # Phase 1: validate everything. Phase 2: apply. A bad field leaves the layer untouched.
        plan = {}
        if "name" in op:
            plan["name"] = _name(op["name"])
        if "opacity" in op:
            plan["opacity"] = _clamp_int(op["opacity"], 0, 255, "opacity")
        if "visible" in op:
            plan["visible"] = _flag(op["visible"], "visible")
        if "locked" in op:
            plan["locked"] = _flag(op["locked"], "locked")
        if "blending_mode" in op:
            plan["blending_mode"] = self._validate_blend(doc, op["blending_mode"])
        if any(key in op for key in ("x", "y", "dx", "dy")):
            pos = node.position()
            x = _clamp_int(op["x"], COORD_MIN, COORD_MAX, "x") if "x" in op else int(pos.x())
            y = _clamp_int(op["y"], COORD_MIN, COORD_MAX, "y") if "y" in op else int(pos.y())
            if "dx" in op:
                x += _clamp_int(op["dx"], COORD_MIN, COORD_MAX, "dx")
            if "dy" in op:
                y += _clamp_int(op["dy"], COORD_MIN, COORD_MAX, "dy")
            plan["position"] = (_clamp_int(x, COORD_MIN, COORD_MAX, "x"),
                                _clamp_int(y, COORD_MIN, COORD_MAX, "y"))
        if not plan:
            raise OpError("INVALID_PARAMS", "No supported modification field was supplied")

        changed = []
        if "name" in plan:
            node.setName(plan["name"]); changed.append("name")
        if "opacity" in plan:
            node.setOpacity(plan["opacity"]); changed.append("opacity")
        if "visible" in plan:
            node.setVisible(plan["visible"]); changed.append("visible")
        if "locked" in plan:
            node.setLocked(plan["locked"]); changed.append("locked")
        if "blending_mode" in plan:
            node.setBlendingMode(plan["blending_mode"]); changed.append("blending_mode")
        if "position" in plan:
            x, y = plan["position"]
            node.move(x, y); changed.extend(["x", "y"])
        doc.refreshProjection()
        return _ok(document_session=self._session, node_id=self._uid(node), changed=changed)

    def layer_delete(self, op):
        doc = self._document()
        root_uid = self._uid(doc.rootNode())
        node = self._node(doc, op.get("node_id"))
        expected = op.get("expected_name")
        if expected is not None and expected != node.name():
            raise OpError("PRECONDITION_FAILED", "expected_name does not match")
        if list(node.childNodes()) and op.get("recursive") is not True:
            raise OpError("HAS_CHILDREN", "Group is not empty; pass recursive=true to confirm deletion")
        parent = node.parentNode()
        parent_uid = self._uid(parent) if parent is not None else root_uid
        node_id, node_name = self._uid(node), node.name()
        if not node.remove():
            raise OpError("DELETE_FAILED", "Krita refused to remove the layer")
        if parent_uid != root_uid:
            doc.setActiveNode(parent)
        elif doc.topLevelNodes():
            doc.setActiveNode(doc.topLevelNodes()[0])
        doc.refreshProjection()
        return _ok(document_session=self._session, deleted={"id": node_id, "name": node_name})

    def canvas_snapshot(self, op):
        doc = self._document()
        width = _clamp_int(op.get("max_width", 512), 1, PREVIEW_MAX_EDGE, "max_width")
        height = _clamp_int(op.get("max_height", 512), 1, PREVIEW_MAX_EDGE, "max_height")
        if width * height > PREVIEW_MAX_PIXELS:
            raise OpError("OUTPUT_LIMIT", "Requested preview has too many pixels")
        fmt = str(op.get("format", "jpeg")).lower()
        if fmt not in ("jpeg", "jpg", "png"):
            raise OpError("INVALID_PARAMS", "format must be jpeg or png")
        quality = _clamp_int(op.get("quality", 85), 1, 100, "quality")
        node_id = op.get("node_id")
        sync = _flag(op.get("sync", True), "sync")
        target = self._node(doc, node_id) if node_id else doc
        # Validate first; waiting can block the GUI and cannot be preempted.
        # Wait after projection invalidation from prior writes, before thumbnail.
        if sync:
            doc.waitForDone()
        image = target.thumbnail(width, height)
        if image is None or image.isNull():
            raise OpError("SNAPSHOT_FAILED", "Krita returned an empty image")
        png = fmt == "png"
        if not png:
            image = _flatten_on_white(image)
        data = QByteArray()
        buffer = QBuffer(data)
        if not buffer.open(WRITE_ONLY):
            raise OpError("SNAPSHOT_FAILED", "Could not allocate preview buffer")
        ok = image.save(buffer, "PNG" if png else "JPEG", quality)
        buffer.close()
        if not ok:
            raise OpError("SNAPSHOT_FAILED", "Image encoder failed")
        raw = bytes(data)
        if len(raw) > PREVIEW_MAX_BYTES:
            raise OpError("OUTPUT_LIMIT", "Encoded preview exceeds byte budget")
        return _ok(document_session=self._session, mime_type="image/png" if png else "image/jpeg",
                   width=image.width(), height=image.height(), byte_length=len(raw),
                   data_base64=base64.b64encode(raw).decode("ascii"))

    def selection_rect(self, op):
        doc = self._document()
        x = _clamp_int(op.get("x"), COORD_MIN, COORD_MAX, "x")
        y = _clamp_int(op.get("y"), COORD_MIN, COORD_MAX, "y")
        w = _clamp_int(op.get("width"), 1, COORD_MAX, "width")
        h = _clamp_int(op.get("height"), 1, COORD_MAX, "height")
        rect = QRect(x, y, w, h).intersected(QRect(0, 0, doc.width(), doc.height()))
        if rect.isEmpty():
            raise OpError("INVALID_RECT", "Selection does not intersect the canvas")
        selection = Selection()
        selection.select(rect.x(), rect.y(), rect.width(), rect.height(), 255)
        doc.setSelection(selection)
        return _ok(document_session=self._session,
                   rect={"x": rect.x(), "y": rect.y(), "width": rect.width(), "height": rect.height()})

    def edit_action(self, name):
        if not self.allow_history_actions:
            raise OpError("HISTORY_DISABLED", "Global undo/redo disabled; opt in with allow_history_actions")
        doc = self._document()
        app = Krita.instance()
        for candidate in ACTION_CANDIDATES[name]:
            action = app.action(candidate)
            if action is not None and action.isEnabled():
                action.trigger()
                break
        else:
            raise OpError("ACTION_UNAVAILABLE", "%s is not currently available" % name)
        doc.refreshProjection()
        return _ok(document_session=self._session, action=name)
