# SPDX-License-Identifier: MIT
"""Authenticated loopback server and the Qt-main-thread request pump."""
import json
import queue
import secrets
import selectors
import socket
import threading
import time
import traceback
from pathlib import Path

from krita import Extension

from ._qt import QApplication, QTimer
from .operations import OperationDispatcher

__version__ = "1.2.2"
PROTOCOL = 1
HOST = "127.0.0.1"
MAX_LINE_BYTES = 1024 * 1024
MAX_OUTPUT_BUFFER = 32 * 1024 * 1024      # pending bytes per client
MAX_OPS = 64
MAX_SNAPSHOTS_PER_BATCH = 2               # bounds worst-case response size
MAX_CLIENTS = 8
MAX_PENDING_REQUESTS = 32
MAX_INFLIGHT_PER_CLIENT = 4
MAX_ID_LENGTH = 128
PUMP_TIME_BUDGET_SECONDS = 0.006
CLIENT_IDLE_SECONDS = 60.0
REQUEST_TIMEOUT_SECONDS = 30.0
PUMP_INTERVAL_MS = 10
PUMP_REQUESTS_PER_TICK = 8  # operations, not entire batches
SELECT_TIMEOUT = 0.1


def _error(code, message, details=None):
    out = {"status": "error", "code": code, "message": message}
    if details is not None:
        out["details"] = details
    return out


def _strict_json(raw):
    def reject(value):
        raise ValueError("Non-finite JSON number: " + value)
    return json.loads(raw, parse_constant=reject)


def load_config(home=None):
    """Read ~/.krita_nexus/config.json. Missing or invalid files yield defaults."""
    base = Path(home) if home else Path.home()
    try:
        with (base / ".krita_nexus" / "config.json").open("r", encoding="utf-8") as stream:
            data = json.load(stream)
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        raise RuntimeError("Invalid Nexus config; refusing to start: %s" % exc)
    if not isinstance(data, dict):
        raise ValueError("config.json must be an object")
    for key in ("read_only", "allow_history_actions"):
        if key in data and not isinstance(data[key], bool):
            raise ValueError("%s must be boolean" % key)
    return data


class _Client:
    __slots__ = ("sock", "ident", "input", "output", "discarding", "cancelled", "inflight", "last_activity")

    def __init__(self, sock, ident):
        self.sock = sock
        self.ident = ident
        self.input = bytearray()
        self.output = bytearray()
        self.cancelled = threading.Event()
        self.inflight = 0
        self.last_activity = time.monotonic()
        self.discarding = False  # True while skipping the tail of an oversized line


class NetworkThread(threading.Thread):
    """Owns every socket. It never imports or invokes a Krita object."""

    def __init__(self, token, request_queue, response_queue, ready_queue):
        super().__init__(name="KritaNexusNetwork", daemon=True)
        self.token = token  # bytes
        self.requests = request_queue
        self.responses = response_queue
        self.ready = ready_queue
        self.stop_event = threading.Event()
        self.selector = None
        self.clients = {}
        self.next_client_id = 1
        self.inflight = 0
        self.owners = {}

    def stop(self):
        self.stop_event.set()

    def run(self):
        server = None
        try:
            self.selector = selectors.DefaultSelector()
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server.setblocking(False)
            server.bind((HOST, 0))
            server.listen(MAX_CLIENTS)
            self.selector.register(server, selectors.EVENT_READ, None)
            self.ready.put((True, server.getsockname()[1], None))
        except Exception as exc:
            self.ready.put((False, None, "%s: %s" % (type(exc).__name__, exc)))
            self._teardown(server)
            return
        try:
            while not self.stop_event.is_set():
                self._drain_responses()
                now = time.monotonic()
                for client in list(self.clients.values()):
                    if now - client.last_activity > CLIENT_IDLE_SECONDS:
                        self._close(client)
                for key, mask in self.selector.select(timeout=SELECT_TIMEOUT):
                    if key.data is None:
                        self._accept(server)
                    else:
                        self._guard(key.data, mask)
        except Exception:
            print("Krita Nexus network thread stopped:\n%s" % traceback.format_exc())
        finally:
            self._teardown(server)

    def _teardown(self, server):
        for client in list(self.clients.values()):
            self._close(client)
        if server is not None:
            try:
                if self.selector is not None:
                    self.selector.unregister(server)
            except Exception:
                pass
            try:
                server.close()
            except Exception:
                pass
        if self.selector is not None:
            try:
                self.selector.close()
            except Exception:
                pass
            self.selector = None

    def _accept(self, server):
        try:
            sock, _address = server.accept()
        except OSError:
            return
        if len(self.clients) >= MAX_CLIENTS:
            sock.close()
            return
        try:
            sock.setblocking(False)
            ident = self.next_client_id
            self.next_client_id += 1
            client = _Client(sock, ident)
            self.selector.register(sock, selectors.EVENT_READ, client)
        except (OSError, ValueError):
            sock.close()
            return
        self.clients[ident] = client

    def _close(self, client):
        client.cancelled.set()
        self.clients.pop(client.ident, None)
        if self.selector is not None:
            try:
                self.selector.unregister(client.sock)
            except Exception:
                pass
        try:
            client.sock.close()
        except Exception:
            pass

    def _update_events(self, client):
        events = selectors.EVENT_READ | (selectors.EVENT_WRITE if client.output else 0)
        try:
            self.selector.modify(client.sock, events, client)
        except Exception:
            self._close(client)

    def _reply(self, client, payload):
        try:
            encoded = json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode("utf-8") + b"\n"
        except (TypeError, ValueError):
            encoded = b'{"status":"error","code":"SERIALIZATION_ERROR","message":"Response serialization failed"}\n'
        if len(client.output) + len(encoded) > MAX_OUTPUT_BUFFER:
            self._close(client)
            return
        client.output.extend(encoded)
        self._update_events(client)

    def _guard(self, client, mask):
        # One misbehaving connection must never take down the listener.
        try:
            self._service(client, mask)
        except Exception:
            print("Krita Nexus connection error:\n%s" % traceback.format_exc())
            self._close(client)

    def _service(self, client, mask):
        if mask & selectors.EVENT_READ:
            try:
                chunk = client.sock.recv(65536)
            except (BlockingIOError, InterruptedError):
                chunk = None
            except OSError:
                self._close(client)
                return
            if chunk is not None:
                if not chunk:
                    self._close(client)
                    return
                client.last_activity = time.monotonic()
                self._feed(client, chunk)
                if client.ident not in self.clients:
                    return
        if mask & selectors.EVENT_WRITE and client.output:
            try:
                sent = client.sock.send(client.output)
            except (BlockingIOError, InterruptedError):
                return
            except OSError:
                self._close(client)
                return
            if sent == 0:
                self._close(client)
                return
            client.last_activity = time.monotonic()
            del client.output[:sent]
            self._update_events(client)

    def _feed(self, client, chunk):
        client.input.extend(chunk)
        while True:
            newline = client.input.find(b"\n")
            if newline < 0:
                if client.discarding:
                    client.input.clear()
                elif len(client.input) > MAX_LINE_BYTES:
                    # Report once, then discard until the terminating newline.
                    client.discarding = True
                    client.input.clear()
                    self._reply(client, _error("LINE_TOO_LARGE", "Request line exceeds byte limit"))
                return
            raw = bytes(client.input[:newline])
            del client.input[:newline + 1]
            if client.discarding:
                client.discarding = False
                continue
            if len(raw) > MAX_LINE_BYTES:
                self._reply(client, _error("LINE_TOO_LARGE", "Request line exceeds byte limit"))
            else:
                self._parse(client, raw)
            if client.ident not in self.clients:
                return

    def _parse(self, client, raw):
        try:
            obj = _strict_json(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError, RecursionError) as exc:
            self._reply(client, _error("INVALID_JSON", str(exc)))
            return
        if not isinstance(obj, dict):
            self._reply(client, _error("INVALID_REQUEST", "Top-level value must be an object"))
            return
        request_id = obj.get("id")
        if not isinstance(request_id, (str, int)) or isinstance(request_id, bool):
            self._reply(client, _error("INVALID_REQUEST", "id must be a string or integer"))
            return
        if isinstance(request_id, str) and (len(request_id) > MAX_ID_LENGTH or any(0xD800 <= ord(c) <= 0xDFFF for c in request_id)):
            self._reply(client, _error("INVALID_REQUEST", "id is too long or contains invalid Unicode"))
            return
        if isinstance(request_id, int) and not -(2**63) <= request_id < 2**63:
            self._reply(client, _error("INVALID_REQUEST", "id must fit signed 64 bits"))
            return
        token = obj.get("token")
        if not isinstance(token, str):
            token = ""
        # bytes comparison: secrets.compare_digest raises TypeError on non-ASCII str.
        presented = token.encode("utf-8", "surrogatepass")
        if not secrets.compare_digest(presented, self.token):
            self._reply(client, {"id": request_id, **_error("AUTH_FAILED", "Invalid token")})
            return
        ops = obj.get("ops")
        if not isinstance(ops, list) or not (1 <= len(ops) <= MAX_OPS):
            self._reply(client, {"id": request_id, **_error(
                "INVALID_REQUEST", "ops must contain 1..%d objects" % MAX_OPS)})
            return
        if not all(isinstance(op, dict) for op in ops):
            self._reply(client, {"id": request_id, **_error("INVALID_REQUEST", "Every op must be an object")})
            return
        if any(not isinstance(op.get("op"), str) or len(op["op"]) > 64 for op in ops):
            self._reply(client, {"id": request_id, **_error("INVALID_REQUEST", "Each op needs a short op string")})
            return
        if not isinstance(obj.get("continue_on_error", False), bool):
            self._reply(client, {"id": request_id, **_error("INVALID_REQUEST", "continue_on_error must be boolean")})
            return
        if sum(op["op"] == "canvas.snapshot" for op in ops) > MAX_SNAPSHOTS_PER_BATCH:
            self._reply(client, {"id": request_id, **_error("OUTPUT_LIMIT", "At most two snapshots per batch")})
            return
        if self.inflight >= MAX_PENDING_REQUESTS or client.inflight >= MAX_INFLIGHT_PER_CLIENT:
            self._reply(client, {"id": request_id, **_error("SERVER_BUSY", "In-flight request budget exhausted")})
            return
        request = {"client_id": client.ident, "id": request_id, "ops": ops,
                   "cancelled": client.cancelled, "continue_on_error": obj.get("continue_on_error", False),
                   "deadline": time.monotonic() + REQUEST_TIMEOUT_SECONDS}
        try:
            self.requests.put_nowait(request)
        except queue.Full:
            self._reply(client, {"id": request_id, **_error("SERVER_BUSY", "Main-thread queue is full")})
        else:
            self.inflight += 1
            client.inflight += 1
            self.owners[client.ident] = client

    def _drain_responses(self):
        while True:
            try:
                response = self.responses.get_nowait()
            except queue.Empty:
                return
            ident = response.pop("_client_id", None)
            owner = self.owners.get(ident)
            if owner is not None:
                owner.inflight -= 1
                self.inflight -= 1
                if owner.inflight == 0:
                    self.owners.pop(ident, None)
            client = self.clients.get(ident)
            if client is not None:
                self._reply(client, response)


class KritaNexusExtension(Extension):
    def __init__(self, parent):
        super().__init__(parent)
        self.token = secrets.token_hex(32)
        self.requests = queue.Queue(maxsize=MAX_PENDING_REQUESTS)
        # Network admission counts queued, executing AND undrained responses.
        # Thus put_nowait cannot overflow this queue under the admission invariant.
        self.responses = queue.Queue(maxsize=MAX_PENDING_REQUESTS)
        self._active_request = None
        self.ready = queue.Queue(maxsize=1)
        self.config = load_config()
        self.read_only = self.config.get("read_only", False)
        self.dispatcher = OperationDispatcher(read_only=self.read_only,
            allow_history_actions=self.config.get("allow_history_actions", False))
        self.network = None
        self.timer = None
        self.connection_path = None
        self._closed = False
        self._response_full_warned = False

    def setup(self):
        # Called by Krita on the GUI thread after the application exists.
        self.network = NetworkThread(self.token.encode("utf-8"), self.requests, self.responses, self.ready)
        self.network.start()
        try:
            success, port, error = self.ready.get(timeout=5.0)
        except queue.Empty:
            success, port, error = False, None, "Network thread startup timed out"
        if not success:
            print("Krita Nexus disabled: %s" % error)
            self.network.stop()
            return
        try:
            self.connection_path = self._write_connection_file(port)
        except Exception as exc:
            print("Krita Nexus disabled: cannot write connection file: %s" % exc)
            self.network.stop()
            return
        self.timer = QTimer(self)
        self.timer.setInterval(PUMP_INTERVAL_MS)
        self.timer.timeout.connect(self._pump_main_thread)
        self.timer.start()
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self.shutdown)
        print("Krita Nexus %s listening on %s:%d (read_only=%s)" % (
            __version__, HOST, port, self.read_only))

    def createActions(self, window):
        pass  # Runtime starts automatically; no menu action is required.

    def _write_connection_file(self, port):
        import os
        directory = Path.home() / ".krita_nexus"
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            os.chmod(str(directory), 0o700)
        except OSError:
            pass
        target = directory / "connection.json"
        temporary = directory / (".connection.%d.tmp" % os.getpid())
        payload = {"protocol": PROTOCOL, "version": __version__, "host": HOST, "port": port,
                   "token": self.token, "pid": os.getpid(), "created_unix": int(time.time())}
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        fd = os.open(str(temporary), flags, 0o600)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, separators=(",", ":"))
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(str(temporary), 0o600)
            os.replace(str(temporary), str(target))
        finally:
            try:
                if temporary.exists():
                    temporary.unlink()
            except OSError:
                pass
        return target

    def shutdown(self):
        """Stop the timer and network thread, and remove our connection file."""
        if self._closed:
            return
        self._closed = True
        if self.timer is not None:
            self.timer.stop()
        if self.network is not None:
            self.network.stop()
            self.network.join(timeout=2.0)
        self._remove_connection_file()

    def _remove_connection_file(self):
        path = self.connection_path
        if path is None:
            return
        try:
            info = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(info, dict) and info.get("token") == self.token:
                path.unlink()
        except (OSError, ValueError):
            pass

    def _pump_main_thread(self):
        """Cooperative budget: one API call cannot be preempted."""
        started = time.monotonic()
        for _ in range(PUMP_REQUESTS_PER_TICK):
            if time.monotonic() - started >= PUMP_TIME_BUDGET_SECONDS:
                break
            if self._active_request is None:
                try:
                    request = self.requests.get_nowait()
                except queue.Empty:
                    break
                request["results"] = []
                request["next"] = 0
                request["failed"] = False
                self._active_request = request
            request = self._active_request
            if request["next"] < len(request["ops"]):
                self._step_request(request)
            if request["next"] == len(request["ops"]):
                results = request["results"]
                response = {"id": request["id"], "status": "success",
                            "batch_status": "error" if request["failed"] else "success",
                            "results": results, "_client_id": request["client_id"]}
                try:
                    self.responses.put_nowait(response)
                except queue.Full:
                    # Admission accounting makes this unreachable in practice.
                    # If it ever happens, keep the request active and retry on a
                    # later tick: never crash the Qt slot or lose the response.
                    if not getattr(self, "_response_full_warned", False):
                        self._response_full_warned = True
                        print("Krita Nexus: response queue full; response deferred")
                    break
                self._response_full_warned = False
                self._active_request = None

    def _step_request(self, request):
        index = request["next"]
        op = request["ops"][index]
        cancelled = request.get("cancelled")
        if cancelled is not None and cancelled.is_set():
            result = _error("CANCELLED", "Connection closed before this operation began")
        elif time.monotonic() > request["deadline"]:
            result = _error("REQUEST_TIMEOUT", "Request expired before this operation began")
        elif request["failed"] and not request.get("continue_on_error", False):
            result = _error("SKIPPED", "An earlier operation failed; batch stopped")
        else:
            try:
                result = self.dispatcher.dispatch(op)
            except Exception as exc:
                if hasattr(exc, "code") and hasattr(exc, "message"):
                    result = _error(exc.code, exc.message, getattr(exc, "details", None))
                else:
                    print("Krita Nexus operation failure:\n%s" % traceback.format_exc())
                    result = _error("INTERNAL_ERROR", "%s: %s" % (type(exc).__name__, exc))
        result.update(index=index, op=op.get("op"))
        request["results"].append(result)
        request["failed"] |= result.get("status") != "success"
        request["next"] += 1

    def __del__(self):
        # Not relied upon for cleanup (see shutdown()); kept as a last resort.
        try:
            self.shutdown()
        except Exception:
            pass
