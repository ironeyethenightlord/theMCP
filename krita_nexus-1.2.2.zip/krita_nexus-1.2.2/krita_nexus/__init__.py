# SPDX-License-Identifier: MIT
"""Krita Nexus plugin entry point (1.2.2)."""
from krita import Krita

from .runtime import KritaNexusExtension, __version__

__all__ = ["__version__"]

_extension = KritaNexusExtension(Krita.instance())
Krita.instance().addExtension(_extension)
