# SPDX-License-Identifier: MIT
"""Qt5-only release for Krita 5. Never probe/import a second Qt major."""
import sys
from krita import Krita


def _check_binding(modules):
    # This release intentionally does not support a Qt6 host. Fail closed.
    if any(name == "PyQt6" or name.startswith("PyQt6.") or
           name == "PySide6" or name.startswith("PySide6.")
           for name in modules):
        raise ImportError("Krita Nexus 1.2.2 targets Krita 5 / PyQt5; Qt6 binding detected")


def _check_host(version):
    if str(version).split(".", 1)[0] != "5":
        raise ImportError("Krita Nexus 1.2.2 requires Krita 5 / PyQt5; host is " + str(version))


_check_host(Krita.instance().version())
_check_binding(sys.modules)
from PyQt5.QtCore import QBuffer, QByteArray, QIODevice, QRect, QThread, QTimer, QUuid
from PyQt5.QtGui import QColor, QImage, QPainter
from PyQt5.QtWidgets import QApplication

WRITE_ONLY = QIODevice.WriteOnly
FORMAT_RGB32 = QImage.Format_RGB32
QT_MAJOR = 5

__all__ = [
    "QApplication", "QBuffer", "QByteArray", "QColor", "QImage", "QPainter",
    "QRect", "QThread", "QTimer", "QUuid", "FORMAT_RGB32", "WRITE_ONLY", "QT_MAJOR",
]
